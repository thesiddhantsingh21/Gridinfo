package com.fadv.cspi.workflow.pojo;

import java.util.Date;

import com.fasterxml.jackson.databind.JsonNode;

import lombok.Data;

@Data
public class WorkflowDetailsTransactionPOJO {

	private long wdTransactionId;

	private long taskListId;
	private long activityTypeId;
	private Date issuedTimestamp;
	private JsonNode requestJson;
	private Date requestTimestamp;
	private JsonNode responseJson;
	private Date responseTimestamp;
	private String status;
	private JsonNode errorJson;
	private String error_cause;
	private boolean isPicked;
	private JsonNode metaData;

	public WorkflowDetailsTransactionPOJO() {
		super();
	}

}
