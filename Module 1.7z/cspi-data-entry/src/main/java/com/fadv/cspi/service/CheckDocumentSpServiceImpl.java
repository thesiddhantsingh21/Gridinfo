package com.fadv.cspi.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fadv.cspi.entities.transaction.CaseUploadedDocuments;
import com.fadv.cspi.repository.transaction.CaseUploadedDocumentsRepository;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;

@Service
public class CheckDocumentSpServiceImpl implements CheckDocumentSpService {

	@Autowired
	private CaseUploadedDocumentsRepository caseUploadedDocumentsRepository;

	ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

	@Override
	public JsonNode checkDocument(String request) {
		ArrayNode json = mapper.createArrayNode();
		JsonNode json2 = mapper.createObjectNode();
		try {
			JsonNode requestJsonNode = mapper.readTree(request);
			ArrayNode arrayNode = (ArrayNode) requestJsonNode.get("response");
			for (JsonNode JsonRequest : arrayNode) {
				if (JsonRequest.has("caseUploadedDocumentsId")) {
					CaseUploadedDocuments caseUploadedDocuments = caseUploadedDocumentsRepository
							.findByCaseUploadedDocumentsIdAndActive(JsonRequest.get("caseUploadedDocumentsId").asLong(),
									true);
					if (caseUploadedDocuments != null && caseUploadedDocuments.getCaseOrigin() == null) {
						json.add(JsonRequest);
					} else if (caseUploadedDocuments.getCaseOrigin().equalsIgnoreCase("")) {
						json.add(JsonRequest);
					} else if (caseUploadedDocuments.getCaseOrigin().equalsIgnoreCase("sp")) {
						continue;
					}
				}
			}
			String js = json.toString();
			json2 = mapper.readValue(js, JsonNode.class);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return json2;
	}
}