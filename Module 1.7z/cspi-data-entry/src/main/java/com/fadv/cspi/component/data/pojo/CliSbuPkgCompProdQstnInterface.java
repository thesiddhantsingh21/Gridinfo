package com.fadv.cspi.component.data.pojo;

public interface CliSbuPkgCompProdQstnInterface {
	Long getGlobalQuestionId();

	String getQuestionName();

	String getQuestionScope();

	String getQuestionType();

	String getComponentName();

	String getProductName();

	String getFormLabel();

	Boolean getMandatory();

	String getMappedField();

	String getAnswer();
}
