package com.fadv.cspi.pojo;

import java.util.List;

import javax.validation.constraints.NotEmpty;

import com.fasterxml.jackson.databind.node.ObjectNode;

import lombok.Data;

@Data
public class RemoteApiPOJO {

	private ObjectNode input;

	@NotEmpty
	private String primaryKey;

	@NotEmpty
	private String primaryValue;

	private List<StaticFieldsPOJO> staticFields;
}
