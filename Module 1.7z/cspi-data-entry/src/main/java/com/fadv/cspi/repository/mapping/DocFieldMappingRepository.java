package com.fadv.cspi.repository.mapping;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.fadv.cspi.entities.mapping.DocFieldMapping;
import com.fadv.cspi.entities.master.DocumentMaster;

@Repository
public interface DocFieldMappingRepository extends JpaRepository<DocFieldMapping, Long> {

	List<DocFieldMapping> findByDocumentMasterAndActive(DocumentMaster documentMaster, boolean active);

	@Query(value = "select * from {h-schema}doc_field_mapping dfm "
			+ "left join {h-schema}document_master dm on dfm.document_master_id = dm.document_master_id "
			+ "left join {h-schema}ui_control_master ucm on dfm.ui_control_master_id = ucm.ui_control_master_id "
			+ "where dm.document_master_id = :documentMasterId " + "and dfm.active = :active", nativeQuery = true)
	List<DocFieldMapping> getByDocumentMasterIdAndActiveAndUiControl(long documentMasterId, boolean active);
	
	@Query(value = "select * from {h-schema}doc_field_mapping dfm "
			+ "left join {h-schema}document_field_master dfmaster on dfm.document_field_master_id = dfmaster.document_field_master_id "
			+ "left join {h-schema}ui_control_master ucm on dfm.ui_control_master_id = ucm.ui_control_master_id "
			+ "where dfmaster.document_field_name = :fieldName " + "and dfm.active = :active limit 1", nativeQuery = true)
	DocFieldMapping getDocFieldMappingByDocumentFieldName(String fieldName, boolean active);

	@Query(value = "select distinct dfm2.document_field_key from {h-schema}doc_field_mapping dfm  "
			+ "left join {h-schema}document_field_master dfm2  "
			+ "on dfm.document_field_master_id = dfm2.document_field_master_id  "
			+ "where dfm.document_master_id = :documentMasterId and dfm.active = true "
			+ "order by dfm2.document_field_key ", nativeQuery = true)
	List<String> getAllDocumentFieldKeysByDocumentMasterId(long documentMasterId);

	@Query(value = "select * from {h-schema}doc_field_mapping dfm where "
			+ "dfm.document_field_master_id = :documentFieldMasterId and dfm.document_master_id = :documentMasterId "
			+ "and dfm.active = :active", nativeQuery = true)
	List<DocFieldMapping> findByDocumentFieldMasterIdAndDocumentMasterIdAndActive(long documentFieldMasterId,
			long documentMasterId, boolean active);

	@Query(value = "select dfm.* from {h-schema}doc_field_mapping dfm  "
			+ "left join {h-schema}document_master dm on dfm.document_master_id = dm.document_master_id  "
			+ "left join {h-schema}document_field_master dfm2 on dfm.document_field_master_id = dfm2.document_field_master_id  "
			+ "where lower(dm.document_name) = lower(:documentName) and  "
			+ "(dfm2.document_field_name) = (:documentFieldName) and dfm.active is true", nativeQuery = true)
	List<DocFieldMapping> getByDocumentNameAndDocumentFieldName(String documentName, String documentFieldName);

	@Query(value = "select * from {h-schema}doc_field_mapping dfm  "
			+ "left join {h-schema}document_field_master dfm2 on dfm.document_field_master_id = dfm2.document_field_master_id  "
			+ "where dfm.document_master_id = :documentMasterId and dfm2.document_field_key in :documentFieldKeys ", nativeQuery = true)
	List<DocFieldMapping> getByDocumentMasterIdAndDocumentFieldKeys(long documentMasterId,
			List<String> documentFieldKeys);
	
	@Query(value = "select * from {h-schema}doc_field_mapping dfm  "
			+ "left join {h-schema}document_field_master dfm2 on dfm.document_field_master_id = dfm2.document_field_master_id  "
			+ "where dfm.document_master_id = :documentMasterId and dfm2.document_field_name in :documentFieldNames and dfm.active is true ", nativeQuery = true)
	List<DocFieldMapping> getByDocumentMasterIdAndDocumentFieldNames(long documentMasterId,
			List<String> documentFieldNames);

}
