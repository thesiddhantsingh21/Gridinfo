package com.fadv.cspi.repository.master;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fadv.cspi.entities.master.ClientMaster;
import com.fadv.cspi.entities.master.EmailTemplateMaster;
import com.fadv.cspi.entities.master.SbuMaster;

public interface EmailTemplateMasterRepository extends JpaRepository<EmailTemplateMaster, Long> {

	List<EmailTemplateMaster> findByemailTemplateIgnoreCaseAndClientMasterAndSbuMaster(String emailTemplate,
			ClientMaster clientMaster, SbuMaster sbuMaster);
}
