package com.fadv.cspi.interfaces;

import java.util.Date;

public interface CaseDetailsResponseInterface {

	long getCaseDetailsId();

	String getCrn();

	String getCaseNo();

	String getCaseCreationStatus();

	Boolean getDeComplete();

	Date getCrnCreatedDate();

	Date getRequestDate();

	String getClientName();

	String getCaseType();

	Boolean getIsManualScoping();

	String getRequestId();

	String getReferenceId();

	Boolean getIsManualScopingCompleted();

	String getCaseOrigin();

	String getCandidateName();

	String getClientReference();

	String getSbuName();

	String getPackageName();

	String getCaseCreatedBy();

	String getDeCompletedBy();

	String getManualScopingCompletedBy();

}
