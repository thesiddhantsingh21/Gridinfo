package com.fadv.cspi.repository.mapping;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fadv.cspi.entities.mapping.CliSbuPkgCompProd;
import com.fadv.cspi.entities.master.ClientMaster;
import com.fadv.cspi.entities.master.PackageMaster;
import com.fadv.cspi.entities.master.SbuMaster;

public interface CliSbuPkgCompProdRepository extends JpaRepository<CliSbuPkgCompProd, Long> {

	List<CliSbuPkgCompProd> findByClientMasterAndSbuMasterAndPackageMasterAndActive(ClientMaster clientMaster,
			SbuMaster sbuMaster, PackageMaster packageMaster, boolean active);
}
