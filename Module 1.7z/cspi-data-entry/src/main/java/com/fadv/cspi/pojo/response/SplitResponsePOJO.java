package com.fadv.cspi.pojo.response;

import lombok.Data;

@Data
public class SplitResponsePOJO {

	String sourcePath;
	String fileName;
}
