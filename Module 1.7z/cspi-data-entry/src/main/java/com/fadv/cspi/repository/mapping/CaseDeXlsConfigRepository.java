package com.fadv.cspi.repository.mapping;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.fadv.cspi.entities.mapping.CaseDeXlsConfig;

@Repository
public interface CaseDeXlsConfigRepository extends JpaRepository<CaseDeXlsConfig, Long> {

	@Query(value = "select * from cspi.case_de_xls_config cdxc  " + 
			"join {h-schema}client_master cm on cdxc.client_master_id =cm.client_master_id  " + 
			"join {h-schema}sbu_master sm on cdxc .sbu_master_id =sm.sbu_master_id  " + 
			"join {h-schema}package_master pm on cdxc.package_master_id =pm.package_master_id  " + 
			"where cm.client_name =:clientName and cm.active =true " + 
			"and sm.sbu_name =:sbuName and sm.active =true " + 
			"and pm.package_name =:packageName and pm.active =true " + 
			"and cdxc.active =true",nativeQuery = true)
	List<CaseDeXlsConfig> getDocumentNameByClientAndSbuAndPackage(String clientName,String sbuName,String packageName);
}
