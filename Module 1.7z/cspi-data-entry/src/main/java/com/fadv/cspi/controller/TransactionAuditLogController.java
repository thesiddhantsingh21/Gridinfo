package com.fadv.cspi.controller;

import javax.validation.Valid;
import javax.validation.constraints.Positive;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fadv.cspi.exception.ServiceException;
import com.fadv.cspi.pojo.request.TransactionAuditLogRequestFilterPOJO;
import com.fadv.cspi.pojo.request.TransactionAuditLogRequestPOJO;
import com.fadv.cspi.pojo.response.ResponseStatusPOJO;
import com.fadv.cspi.service.TransactionAuditLogService;

import io.swagger.annotations.ApiOperation;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/india/")
public class TransactionAuditLogController {

	private static final String SUCCESS_CODE_200 = "SUCCESS_CODE_200";

	@Autowired
	private TransactionAuditLogService transactionAuditLogService;

	@ApiOperation(value = "This API is used for creating a new entry in transaction_audit_log table using the data provided by the user.", response = ResponseStatusPOJO.class)
	@PostMapping(path = "transaction_audit_log", produces = "application/json", consumes = "application/json")
	public ResponseEntity<ResponseStatusPOJO> createAuditLog(
			@Valid @RequestBody TransactionAuditLogRequestPOJO transactionAuditLogRequestPOJO) {
		try {
			return new ResponseEntity<>(
					new ResponseStatusPOJO(true, "Transaction Audit Log Data Saved Successfully", SUCCESS_CODE_200,
							transactionAuditLogService.createTransactionAuditLog(transactionAuditLogRequestPOJO)),
					HttpStatus.OK);
		} catch (ServiceException e1) {
			if (e1.getObj() != null) {
				return new ResponseEntity<>(new ResponseStatusPOJO(false, e1.getMessage(), e1.getObj()), HttpStatus.OK);
			} else {
				return new ResponseEntity<>(new ResponseStatusPOJO(false, e1.getMessage(), e1.getMessageId()),
						HttpStatus.OK);
			}
		} catch (Exception e2) {
			return new ResponseEntity<>(new ResponseStatusPOJO(false, e2.getMessage()), HttpStatus.OK);
		}
	}

	@ApiOperation(value = "This API is used for fetching entry in transaction_audit_log table using the id provided by the user.", response = ResponseStatusPOJO.class)
	@PostMapping(path = "transaction_audit_log/search", produces = "application/json")
	public ResponseEntity<ResponseStatusPOJO> getCheckTypeMasterByCheckTypeName(
			@RequestBody TransactionAuditLogRequestPOJO transactionAuditLogRequestPOJO) {
		try {
			return new ResponseEntity<>(new ResponseStatusPOJO(true,
					"Transaction Audit Log Data Data fetched Successfully", SUCCESS_CODE_200,
					transactionAuditLogService.findByTableName(transactionAuditLogRequestPOJO)), HttpStatus.OK);
		} catch (Exception e2) {
			return new ResponseEntity<>(new ResponseStatusPOJO(false, e2.getMessage()), HttpStatus.OK);
		}
	}

	@ApiOperation(value = "This API is used for fetching entry in audit_log table using the id provided by the user.", response = ResponseStatusPOJO.class)
	@PostMapping(path = "transaction_audit_log/filter", produces = "application/json")
	public ResponseEntity<ResponseStatusPOJO> getCheckTypeMasterByCheckTypeName(
			@RequestBody TransactionAuditLogRequestFilterPOJO transactionAuditLogRequestFilterPOJO) {
		try {
			return new ResponseEntity<>(
					new ResponseStatusPOJO(true, "Transaction Audit Log Data fetched Successfully", SUCCESS_CODE_200,
							transactionAuditLogService
									.findByTableNameAndOperationTypeAndUpdatedBy(transactionAuditLogRequestFilterPOJO)),
					HttpStatus.OK);
		} catch (Exception e2) {
			return new ResponseEntity<>(new ResponseStatusPOJO(false, e2.getMessage()), HttpStatus.OK);
		}
	}

	@ApiOperation(value = "This API is used for fetching entry in transaction_audit_log table using the id provided by the user.", response = ResponseStatusPOJO.class)
	@PostMapping(path = "transaction_audit_log/get", produces = "application/json")
	public ResponseEntity<ResponseStatusPOJO> getAuditLogResponseInterface(
			@RequestBody TransactionAuditLogRequestPOJO auditLogRequestPOJO) {
		try {
			return new ResponseEntity<>(new ResponseStatusPOJO(true, "Audit Log Data Data fetched Successfully",
					SUCCESS_CODE_200, transactionAuditLogService.findByTableNameData(auditLogRequestPOJO)),
					HttpStatus.OK);
		} catch (Exception e2) {
			return new ResponseEntity<>(new ResponseStatusPOJO(false, e2.getMessage()), HttpStatus.OK);
		}
	}

	@ApiOperation(value = "This API is used for fetching entry in transaction_audit_log table using the id provided by the user.", response = ResponseStatusPOJO.class)
	@GetMapping(path = "transaction_audit_log/{transactionAuditLogId}", produces = "application/json")
	public ResponseEntity<ResponseStatusPOJO> getByAuditLogId(
			@PathVariable(value = "auditLogId") @Positive Long transactionAuditLogId) {
		try {
			return new ResponseEntity<>(
					new ResponseStatusPOJO(true, "Transaction Audit Log Data Data fetched Successfully",
							SUCCESS_CODE_200,
							transactionAuditLogService
									.getTransactionAuditLogByTransactionAuditLogId(transactionAuditLogId)),
					HttpStatus.OK);
		} catch (ServiceException e1) {
			return new ResponseEntity<>(new ResponseStatusPOJO(false, e1.getMessage(), e1.getMessageId()),
					HttpStatus.OK);
		} catch (Exception e2) {
			return new ResponseEntity<>(new ResponseStatusPOJO(false, e2.getMessage()), HttpStatus.OK);
		}
	}
}
