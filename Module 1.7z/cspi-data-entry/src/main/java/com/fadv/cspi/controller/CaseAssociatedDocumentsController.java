package com.fadv.cspi.controller;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import javax.validation.constraints.Positive;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fadv.cspi.exception.ServiceException;
import com.fadv.cspi.pojo.request.CaseAssociatedDocumentsRequestPOJO;
import com.fadv.cspi.pojo.request.FecthAssociateDocsPOJO;
import com.fadv.cspi.pojo.response.ResponseStatusPOJO;
import com.fadv.cspi.service.CaseAssociatedDocumentsService;
import com.fadv.cspi.userdetail.pojo.UserDetailPOJO;

import io.swagger.annotations.ApiOperation;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/india/")
public class CaseAssociatedDocumentsController {

	private static final String SUCCESS_CODE_200 = "SUCCESS_CODE_200";

	private static final String TOKEN_ID = "tokenid";

	private static final String USER_ID = "userId";

	private static final String USER_NAME = "userName";

	@Autowired
	private CaseAssociatedDocumentsService caseAssociatedDocumentsService;

	@PostMapping(path = "save-associate-docs", produces = "application/json", consumes = "application/json")
	public ResponseEntity<ResponseStatusPOJO> splitAndSaveAssociateDocument(HttpServletRequest request,
			@Valid @RequestBody CaseAssociatedDocumentsRequestPOJO caseAssociatedDocumentsRequestPOJO) {

		String userName = request.getAttribute(USER_NAME).toString().isEmpty() ? USER_NAME
				: request.getAttribute(USER_NAME).toString();
		String userId = request.getAttribute(USER_ID).toString().isEmpty() ? USER_ID
				: request.getAttribute(USER_ID).toString();
		String tokenId = request.getHeader(TOKEN_ID).isEmpty() ? TOKEN_ID : request.getHeader(TOKEN_ID);

		UserDetailPOJO userDetailPOJO = new UserDetailPOJO(userName, userId);

		try {
			return new ResponseEntity<>(new ResponseStatusPOJO(true, "File Split successfull", SUCCESS_CODE_200,
					caseAssociatedDocumentsService.processSplitDocumentRequest(caseAssociatedDocumentsRequestPOJO,
							userDetailPOJO, tokenId)),
					HttpStatus.OK);
		} catch (ServiceException e1) {
			return new ResponseEntity<>(new ResponseStatusPOJO(false, e1.getMessage(), e1.getMessageId()),
					HttpStatus.OK);
		} catch (Exception e2) {
			return new ResponseEntity<>(new ResponseStatusPOJO(false, e2.getMessage()),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@ApiOperation(value = "This API is used for fetching all associated document details related to given case id", response = ResponseStatusPOJO.class)
	@GetMapping(path = "fetch-associated-docs/{caseDetailsId}", produces = "application/json")
	public ResponseEntity<ResponseStatusPOJO> fetchAssociateDocument(
			@PathVariable(value = "caseDetailsId") Long caseDetailsId) {
		try {
			return new ResponseEntity<>(
					new ResponseStatusPOJO(true, "Record retrieved successfully", SUCCESS_CODE_200,
							caseAssociatedDocumentsService.getAssociatedDocumentDetailsByCaseDetailsId(caseDetailsId)),
					HttpStatus.OK);
		} catch (Exception e2) {
			return new ResponseEntity<>(new ResponseStatusPOJO(false, e2.getMessage()),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@ApiOperation(value = "This API is used for fetching all supporting associated document details related to given case id", response = ResponseStatusPOJO.class)
	@PostMapping(path = "fetch-supporting-associate-docs", produces = "application/json", consumes = "application/json")
	public ResponseEntity<ResponseStatusPOJO> fetchSupportingAssociateDocument(
			@RequestBody FecthAssociateDocsPOJO fecthAssociateDocsPOJO) {
		try {
			return new ResponseEntity<>(
					new ResponseStatusPOJO(true, "Record retrieved successfully", SUCCESS_CODE_200,
							caseAssociatedDocumentsService.fetchSupportingSplitDocuments(fecthAssociateDocsPOJO)),
					HttpStatus.OK);
		} catch (Exception e2) {
			return new ResponseEntity<>(new ResponseStatusPOJO(false, e2.getMessage()),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@ApiOperation(value = "This API is used for fetching all associated document details related to given case id", response = ResponseStatusPOJO.class)
	@GetMapping(path = "fulfillment/fetch-associated-docs/{caseDetailsId}/{fulfillmentId}", produces = "application/json")
	public ResponseEntity<ResponseStatusPOJO> fetchFulfillmentAssociateDocument(
			@Positive @PathVariable(value = "caseDetailsId") Long caseDetailsId,
			@Positive @PathVariable(value = "fulfillmentId") Long fulfillmentId) {
		try {
			return new ResponseEntity<>(new ResponseStatusPOJO(true, "Record retrieved successfully", SUCCESS_CODE_200,
					caseAssociatedDocumentsService
							.getAssociatedDocumentDetailsByCaseDetailsIdAndFulfillmentId(caseDetailsId, fulfillmentId)),
					HttpStatus.OK);
		} catch (Exception e2) {
			return new ResponseEntity<>(new ResponseStatusPOJO(false, e2.getMessage()),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
}
