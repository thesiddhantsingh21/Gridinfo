package com.fadv.cspi.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fadv.cspi.pojo.response.ResponseStatusPOJO;
import com.fadv.cspi.service.CheckDocumentSpService;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/india/")
public class CheckDocumentsSpController {

	private static final String SUCCESS_CODE_200 = "SUCCESS_CODE_200";

	private static final Logger logger = LoggerFactory.getLogger(CheckDocumentsSpController.class);

	@Autowired
	private CheckDocumentSpService checkDocumentSpService;

	@PostMapping(path = "sp-documents-check", produces = "application/json")
	public ResponseEntity<ResponseStatusPOJO> checkDocumentIsSP(@RequestBody String request) {
		try {
			logger.info("Request recieve:{}", request);
			return new ResponseEntity<>(new ResponseStatusPOJO(true, "Document fetch successfully", SUCCESS_CODE_200,
					checkDocumentSpService.checkDocument(request)), HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(new ResponseStatusPOJO(false, e.getMessage()),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

}
