package com.fadv.cspi.pojo.response;

import java.util.Date;

import com.fasterxml.jackson.databind.JsonNode;

import lombok.Data;

@Data
public class TransactionAuditLogResponsePOJO {

	private Long transactionAuditLogId;
	private String tableName;
	private JsonNode prevValues;
	private JsonNode newValues;
	private String updatedBy;
	private String updatedByUserId;
	private String operationType;
	private Date updatedDateTime;
}
