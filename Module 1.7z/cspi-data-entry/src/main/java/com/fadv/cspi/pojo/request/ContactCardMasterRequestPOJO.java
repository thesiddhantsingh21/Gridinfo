package com.fadv.cspi.pojo.request;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.PositiveOrZero;

import com.fasterxml.jackson.databind.node.ObjectNode;

import lombok.Data;

@Data
public class ContactCardMasterRequestPOJO {

	@NotEmpty
	private String akaName;

	@NotEmpty
	private String countryName;

	@NotEmpty
	private String stateName;

	@NotEmpty
	private String cityName;

	@NotEmpty
	private String componentName;

	@PositiveOrZero
	private int avl;

	@PositiveOrZero
	private int mrl;

	@PositiveOrZero
	private int costApproval;

	@PositiveOrZero
	private int stellar;

	@PositiveOrZero
	private int singleSpoc;

	@PositiveOrZero
	private int bulkSpoc;

	@PositiveOrZero
	private int cbv;

	@PositiveOrZero
	private int utv;

	@PositiveOrZero
	private int suspect;

	@PositiveOrZero
	private int i4v;

	private String existingUniversityEmploymentCollege;

	@NotEmpty
	private String universityEmploymentName;

	private String areaLocalityName;

	private String enterAkaName;

	private String fadvRelationship;

	private String mandatoryDocuments;

	private String phoneType;

	private String modeOfInitiation;

	private String entityType;

	private ObjectNode additionalFields;

}
