package com.fadv.cspi.fullfilment.service;

import org.springframework.stereotype.Service;

import com.fadv.cspi.exception.ServiceException;
import com.fadv.cspi.fullfilment.pojo.MiRemarksPOJO;
import com.fadv.cspi.userdetail.pojo.UserDetailPOJO;

@Service
public interface FinalMiFulfillmentService {

	String finalMiFulfillment(long caseDetailsId, boolean validate, long fulfillmentId, MiRemarksPOJO miRemarksPOJO,
			UserDetailPOJO userDetailPOJO, String tokenId) throws ServiceException;

}
