package com.fadv.cspi.pojo.request;

import java.util.List;

import javax.validation.constraints.NotEmpty;

import lombok.Data;

@Data
public class SharedPathFilesUploadReqPOJO {

	@NotEmpty
	private String caseNo;

	@NotEmpty
	private List<String> filePath;

	private String requestSource;
}
