package com.fadv.cspi.service;

import org.springframework.stereotype.Service;

import com.fadv.cspi.entities.transaction.CaseClientDetails;
import com.fadv.cspi.entities.transaction.CaseDetails;
import com.fadv.cspi.exception.ServiceException;
import com.fadv.cspi.pojo.response.CaseClientDetailsResponsePOJO;

@Service
public interface CaseClientDetailsService {

	CaseClientDetails findByCaseDetailsId(Long caseId) throws ServiceException;

	CaseClientDetailsResponsePOJO getCaseClientDetailsByCaseDetailsId(Long caseDetailsId) throws ServiceException;

	CaseClientDetails findByCaseDetails(CaseDetails caseDetails);

}
