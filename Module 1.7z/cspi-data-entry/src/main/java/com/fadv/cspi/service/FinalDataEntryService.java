package com.fadv.cspi.service;

import org.springframework.stereotype.Service;

import com.fadv.cspi.exception.ServiceException;
import com.fadv.cspi.userdetail.pojo.UserDetailPOJO;

@Service
public interface FinalDataEntryService {

	String finalDataEntrySave(long caseId, boolean validate, UserDetailPOJO userDetailPOJO) throws ServiceException;

}
