package com.fadv.cspi.pojo.response;

import java.util.List;

import com.fadv.cspi.pojo.FileInfoPOJO;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class CombinedFileResposnePOJO {

	private List<FileInfoPOJO> convertedFiles;
	private List<BatchErrorPOJO> batchErrorPOJOs;
	List<InfoMapPOJO> infoMapPOJOs;

	public CombinedFileResposnePOJO() {
		// Default constructor
	}
}
