package com.fadv.cspi.component.data.pojo;
import java.util.Date;

import lombok.Data;

@Data
public class CheckIdRequestPOJO {
	private Date toDate;
	private Date fromDate;
}