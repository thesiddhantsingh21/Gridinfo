package com.fadv.cspi.repository.master;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.fadv.cspi.entities.master.CaseSpecificRecordDetail;

@Repository
public interface CaseSpecificRecordDetailRepository extends JpaRepository<CaseSpecificRecordDetail, Long> {

//	@Query(value = "Select case_specific_record_status as caseSpecificRecordStatus, cbv_utv_status as cbvUtvStatus,check_allocation_status as checkAllocationStatus  "
//			+ ",csi.case_specific_id as caseSpecificId,check_status as checkStatus,component_name as componentName,component_record_field as componentRecordField "
//			+ ",entity_location as entityLocation,check_due_date as checkDueDate,check_tat as checkTat,functional_entity_name as functionalEntityName, instruction_check_id as instructionCheckId "
//			+ ", is_check_manual as isCheckManual, online_status as onlineStatus, product as product, spoc_status as spocStatus, stellar_status as stellarStatus, suspect_status as suspectStatus,vendor_status as vendorStatus "
//			+ ", wellknown_status as wellknownStatus,user_id as userId"
//			+ " from {h-schema}case_specific_record_detail csrd left join {h-schema}case_specific_info csi on csrd.case_specific_id = csi.case_specific_id"
//			+ " where csi.case_ref_number =:crn", nativeQuery = true)

	@Query(value = "Select * from {h-schema}case_specific_record_detail csrd left join {h-schema}case_specific_info csi on csrd.case_specific_id = csi.case_specific_id"
			+ " where csi.case_ref_number =:crn", nativeQuery = true)
	List<CaseSpecificRecordDetail> findByCrn(String crn);

	@Query(value = "Select * from {h-schema}case_specific_record_detail csrd where csrd.instruction_check_id=:instuctionCheckId", nativeQuery = true)
	List<CaseSpecificRecordDetail> findByInstructionCheckId(String instuctionCheckId);

	
}
