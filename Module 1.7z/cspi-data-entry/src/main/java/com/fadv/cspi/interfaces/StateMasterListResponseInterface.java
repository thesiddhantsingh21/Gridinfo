package com.fadv.cspi.interfaces;

public interface StateMasterListResponseInterface {
	long getStateMasterId();

	String getStateName();
}
