package com.fadv.cspi.repository.transaction;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.fadv.cspi.entities.transaction.CaseClientDetails;
import com.fadv.cspi.entities.transaction.CaseDetails;

@Repository
public interface CaseClientDetailsRepository extends JpaRepository<CaseClientDetails, Long> {

	List<CaseClientDetails> findByCaseDetails(CaseDetails caseDetails);
}
