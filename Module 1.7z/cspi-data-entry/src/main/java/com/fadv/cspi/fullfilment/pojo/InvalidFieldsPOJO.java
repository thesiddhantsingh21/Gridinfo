package com.fadv.cspi.fullfilment.pojo;

import lombok.Data;

@Data
public class InvalidFieldsPOJO {

	private String field;

	private String value;

	private String expectedValue;

}
