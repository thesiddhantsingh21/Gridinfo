package com.fadv.cspi.fullfilment.pojo;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class IncompleteDocsPOJO {

	@JsonProperty("Document Name")
	private String documentName;

	private List<String> message;

	private List<IncompleteFieldsPOJO> fields;

}
