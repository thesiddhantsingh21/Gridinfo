package com.fadv.cspi.repository.mapping;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.fadv.cspi.entities.mapping.ComponentProduct;
import com.fadv.cspi.entities.master.ComponentMaster;
import com.fadv.cspi.entities.master.ProductMaster;

public interface ComponentProductRepository extends JpaRepository<ComponentProduct, Long> {

	List<ComponentProduct> findByComponentMasterAndProductMaster(ComponentMaster componentMaster,
			ProductMaster productMaster);

	List<ComponentProduct> findByComponentMaster(ComponentMaster componentMaster);

	List<ComponentProduct> findByComponentProductIdAndActive(long componentProductId, boolean active);

	@Query(value = "select * from {h-schema}component_product cp "
			+ "where cp.component_master_id in (:componentMasterIds)", nativeQuery = true)
	List<ComponentProduct> getByListOfComponentsId(List<Long> componentMasterIds);

	List<ComponentProduct> findByActive(boolean active);

	@Query(value = "select cp.* from cspi.component_product cp "
			+ "left join {h-schema}component_master cm on cp.component_master_id = cm.component_master_id "
			+ "left join {h-schema}product_master pm on cp.product_master_id = pm.product_master_id where "
			+ "case when :componentName != '' then lower(cm.component_name) = lower(:componentName) else true end and "
			+ "case when :productName != '' then lower(pm.product_name) = lower(:productName) else true end", nativeQuery = true)
	List<ComponentProduct> fetchByComponentNameAndProductName(String componentName, String productName);

	@Query(value = "select pm.product_name as productName "
			+ "from {h-schema}product_master pm, {h-schema}component_product cp, {h-schema}component_master as cm "
			+ "where cp.active = :active and "
			+ "pm.product_master_id = cp.product_master_id and cm.component_master_id = cp.component_master_id "
			+ "and case when :componentName != '' then lower(cm.component_name) like lower(:componentName) else true end ", nativeQuery = true)
	List<String> getProductNameByComponent(String componentName, boolean active);

}
