package com.fadv.cspi.fullfilment.interfaces;

public interface CaseDetailsInterface {

	String getCrn();

	String getCaseMoreInfo();

	String getCaseReference();

	String getCaseDetails();
}
