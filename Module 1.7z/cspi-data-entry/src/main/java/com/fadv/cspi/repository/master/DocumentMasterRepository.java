package com.fadv.cspi.repository.master;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.fadv.cspi.entities.master.DocumentMaster;

@Repository
public interface DocumentMasterRepository extends JpaRepository<DocumentMaster, Long> {

	List<DocumentMaster> findByDocumentNameIgnoreCaseAndActive(String documentName, boolean active);
}
