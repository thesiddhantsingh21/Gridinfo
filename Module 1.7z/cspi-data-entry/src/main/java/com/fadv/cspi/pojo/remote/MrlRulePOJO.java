package com.fadv.cspi.pojo.remote;

import lombok.Data;

@Data
public class MrlRulePOJO {

	private String akaName;

	private String componentName;

	private String ruleDescription;
}
