package com.fadv.cspi.interfaces;

public interface CityMasterListResponseInterface {
	long getCityMasterId();

	String getCityName();
}
