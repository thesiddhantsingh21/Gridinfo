package com.fadv.cspi.pojo.request;

import java.util.Date;

import lombok.Data;

@Data
public class TransactionAuditLogRequestFilterPOJO {
	private String tableName;
	private String updatedBy;
	private String operationType;
	private Date toDate;
	private Date fromDate;

}
