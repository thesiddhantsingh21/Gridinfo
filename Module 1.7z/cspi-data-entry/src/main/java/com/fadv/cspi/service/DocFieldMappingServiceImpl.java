package com.fadv.cspi.service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fadv.cspi.entities.mapping.DocFieldMapping;
import com.fadv.cspi.entities.master.DocumentFieldMaster;
import com.fadv.cspi.entities.master.DocumentMaster;
import com.fadv.cspi.exception.ServiceException;
import com.fadv.cspi.pojo.response.DocumentFieldMasterResponsePOJO;
import com.fadv.cspi.repository.mapping.DocFieldMappingRepository;
import com.fadv.cspi.utility.ConversionUtility;

@Service
public class DocFieldMappingServiceImpl implements DocFieldMappingService {
	
	
	private static final Logger logger = LoggerFactory.getLogger(DocFieldMappingServiceImpl.class);


	@Autowired
	private DocFieldMappingRepository docFieldMappingRepository;

	@Override
	public List<DocumentFieldMasterResponsePOJO> getAllDocumentsFieldsByDocumentMasterId(long documentMasterId)
			throws ServiceException {
		List<DocFieldMapping> docFieldMappings = docFieldMappingRepository
				.getByDocumentMasterIdAndActiveAndUiControl(documentMasterId, true);

		return docFieldMappings.parallelStream().map(data -> convertDocFieldMapping(data)).collect(Collectors.toList());

	}
	
	@Override
	public List<DocumentFieldMasterResponsePOJO> getAllFieldsByFieldName(List<String> fields)throws ServiceException{
		if(CollectionUtils.isEmpty(fields)) {
			
			throw new ServiceException("Fields  array are empty!!");
		}
		List<DocFieldMapping> docFieldMappings= new ArrayList<>();
		for(String fieldName:fields) {
			try {
				DocFieldMapping dfm = docFieldMappingRepository.getDocFieldMappingByDocumentFieldName(fieldName, true);
				if(dfm!=null) {
					docFieldMappings.add(dfm);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		logger.info("DocFieldMapping data :{} ",docFieldMappings.toString());
		
		return docFieldMappings.parallelStream().map(data -> convertDocFieldMapping(data)).collect(Collectors.toList());
	}
	

	@Override
	public List<String> getAllDocumentFieldKeysByDocumentMasterId(long documentMasterId) {
		return docFieldMappingRepository.getAllDocumentFieldKeysByDocumentMasterId(documentMasterId);
	}

	@Override
	public DocumentFieldMasterResponsePOJO findByDocumentFieldAndDocumentMaster(DocumentFieldMaster documentFieldMaster,
			long documentMasterId) throws ServiceException {

		List<DocFieldMapping> docFieldMappings = docFieldMappingRepository
				.findByDocumentFieldMasterIdAndDocumentMasterIdAndActive(documentFieldMaster.getDocumentFieldMasterId(),
						documentMasterId, true);

		if (CollectionUtils.isNotEmpty(docFieldMappings)) {
			return convertDocFieldMapping(docFieldMappings.get(0));

		}
		return null;
	}

	@Override
	public DocumentFieldMasterResponsePOJO convertDocFieldMapping(DocFieldMapping docFieldMapping) {
		DocumentFieldMasterResponsePOJO documentFieldMasterResponsePOJO = new DocumentFieldMasterResponsePOJO();
		documentFieldMasterResponsePOJO
				.setDocumentFieldKey(docFieldMapping.getDocumentFieldMaster().getDocumentFieldKey());
		documentFieldMasterResponsePOJO
				.setDocumentFieldName(docFieldMapping.getDocumentFieldMaster().getDocumentFieldName());
		documentFieldMasterResponsePOJO.setMandatory(docFieldMapping.getMandatory());
		documentFieldMasterResponsePOJO.setPossibleValues(docFieldMapping.getPossibleValues());
		documentFieldMasterResponsePOJO.setRemoteApi(docFieldMapping.getRemoteApi());
		documentFieldMasterResponsePOJO.setSequenceId(docFieldMapping.getSequenceId());
		documentFieldMasterResponsePOJO.setShowInGrid(docFieldMapping.getShowInGrid());
		documentFieldMasterResponsePOJO.setAutoPopulate(docFieldMapping.isAutoPopulate());
		documentFieldMasterResponsePOJO.setUiControlName(docFieldMapping.getUiControlMaster().getUiControlName());
		if (docFieldMapping.getParentDocField() != null
				&& StringUtils.isNotEmpty(docFieldMapping.getParentDocField())) {
			documentFieldMasterResponsePOJO.setParentDocumentKey(
					ConversionUtility.removeNonAlphaNumericAndSpace(docFieldMapping.getParentDocField()));
		}
		return documentFieldMasterResponsePOJO;
	}

	@Override
	public List<DocFieldMapping> findByDocumentNameAndDocumentFieldName(String documentName, String documentFieldName) {
		return docFieldMappingRepository.getByDocumentNameAndDocumentFieldName(documentName, documentFieldName);
	}

	@Override
	public List<DocFieldMapping> findByDocumentMaster(DocumentMaster documentMaster) {
		return docFieldMappingRepository.findByDocumentMasterAndActive(documentMaster, true);
	}

	@Override
	public List<DocumentFieldMasterResponsePOJO> findByDocumentMasterIdAndDocumentKeys(long documentMasterId,
			List<String> documentFieldKeys) {
		List<DocFieldMapping> docFieldMappings = docFieldMappingRepository
				.getByDocumentMasterIdAndDocumentFieldKeys(documentMasterId, documentFieldKeys);

		return docFieldMappings.parallelStream().map(data -> convertDocFieldMapping(data)).collect(Collectors.toList());
	}
}
