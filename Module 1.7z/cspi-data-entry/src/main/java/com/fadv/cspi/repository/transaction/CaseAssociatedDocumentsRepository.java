package com.fadv.cspi.repository.transaction;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.fadv.cspi.entities.master.ContactCardMaster;
import com.fadv.cspi.entities.transaction.CaseAssociatedDocuments;
import com.fadv.cspi.entities.transaction.CaseDetails;
import com.fadv.cspi.interfaces.CaseAssociatedDocumentsInterface;

@Transactional
@Repository
public interface CaseAssociatedDocumentsRepository extends JpaRepository<CaseAssociatedDocuments, Long> {

	List<CaseAssociatedDocuments> findByFilePath(String filePath);

	List<CaseAssociatedDocuments> findByCaseDetails(CaseDetails caseDetails);

	@Query(value = "select cad.case_details_id as caseDetailsId, cud.page_count as pageCount, "
			+ "cud.file_path as sourceFolder, cud.original_name as originalName, "
			+ "cad.start_page as startPage, cad.row_id as rowId, cad.parent_row_id as parentRowId, "
			+ "cad.file_path as filePath, cad.end_page as endPage, dm.document_master_id as documentMasterId, "
			+ "cad.case_uploaded_documents_id as caseUploadedDocumentsId, "
			+ "dm.document_name as documentName, case when ccm.aka_name <> '' then ccm.aka_name else cad.sp_aka_name end as akaName, "
			+ "cad.agency_aka_name as agencyAkaName, "
			+ "cud.file_extension as fileExtension, cad.file_name as fileName, cad.updated_by_user as updatedByUser, "
			+ "dm.associated_to as associatedTo from {h-schema}case_associated_documents cad "
			+ "left join {h-schema}case_uploaded_documents cud on cad.case_uploaded_documents_id = cud.case_uploaded_documents_id "
			+ "left join {h-schema}document_master dm on cad.document_master_id = dm.document_master_id "
			+ "left join {h-schema}contact_card_master ccm on cad.contact_card_master_id = ccm.contact_card_master_id "
			+ "where cad.case_details_id = :caseDetailsId order by cad.case_associated_documents_id", nativeQuery = true)
	List<CaseAssociatedDocumentsInterface> getDocumentAssociationAndDetailsByCaseId(Long caseDetailsId);

	@Query(value = "select cad.row_id from {h-schema}case_associated_documents cad "
			+ "left join {h-schema}case_details cd on cad.case_details_id = cd.case_details_id  "
			+ "where cd.case_no in (select cd.previous_case_no from {h-schema}case_details cd  "
			+ "where cd.case_details_id = :caseDetailsId and cd.is_case_cloned is true)", nativeQuery = true)
	List<String> getPrevCaseRowIds(Long caseDetailsId);

	@Query(value = "select cad.case_details_id as caseDetailsId, cud.page_count as pageCount, "
			+ "cud.file_path as sourceFolder, cud.original_name as originalName, "
			+ "cad.start_page as startPage, cad.row_id as rowId, cad.parent_row_id as parentRowId, "
			+ "cad.file_path as filePath, cad.end_page as endPage, dm.document_master_id as documentMasterId, "
			+ "cad.case_uploaded_documents_id as caseUploadedDocumentsId, "
			+ "dm.document_name as documentName, ccm.aka_name as akaName, cad.agency_aka_name as agencyAkaName, "
			+ "cud.file_extension as fileExtension, cud.file_name as fileName, cad.updated_by_user as updatedByUser, "
			+ "dm.associated_to as associatedTo from {h-schema}case_associated_documents cad "
			+ "left join {h-schema}case_uploaded_documents cud on cad.case_uploaded_documents_id = cud.case_uploaded_documents_id "
			+ "left join {h-schema}document_master dm on cad.document_master_id = dm.document_master_id "
			+ "left join {h-schema}contact_card_master ccm on cad.contact_card_master_id = ccm.contact_card_master_id "
			+ "where cad.case_details_id = :caseDetailsId and ccm.aka_name = :akaName and cad.parent_row_id = :parentRowId", nativeQuery = true)
	List<CaseAssociatedDocumentsInterface> getByParentRowIdAndAkaNameAndCaseDetails(String parentRowId, String akaName,
			Long caseDetailsId);

	@Query(value = "select * from {h-schema}case_associated_documents cad where cad.document_master_id = :documentMasterId "
			+ "and cad.row_id = :rowId and cad.case_details_id = :caseDetailsId", nativeQuery = true)
	List<CaseAssociatedDocuments> getCaseAssociateDocumentByCaseDetailsIdDocumentMasterIdAndRowId(long caseDetailsId,
			long documentMasterId, String rowId);

	@Query(value = "select * from {h-schema}case_associated_documents cad where cad.document_master_id = :documentMasterId "
			+ "and cad.case_details_id = :caseDetailsId", nativeQuery = true)
	List<CaseAssociatedDocuments> getCaseAssociateDocumentByCaseDetailsIdAndDocumentMasterId(long caseDetailsId,
			long documentMasterId);

	@Query(value = "select * from {h-schema}case_associated_documents cad where "
			+ "cad.row_id = :rowId and cad.case_details_id = :caseDetailsId", nativeQuery = true)
	List<CaseAssociatedDocuments> getCaseAssociateDocumentByCaseDetailsIdAndRowId(long caseDetailsId, String rowId);

	@Modifying
	@Query(value = "delete from {h-schema}case_associated_documents cad where "
			+ "cad.case_associated_documents_id = :caseAssociatedDocumentsId", nativeQuery = true)
	void deleteByCaseAssociatedDocumentsId(long caseAssociatedDocumentsId);

	List<CaseAssociatedDocuments> findByContactCardMasterAndCaseDetailsAndParentRowId(
			ContactCardMaster contactCardMaster, CaseDetails caseDetails, String parentRowId);
}
