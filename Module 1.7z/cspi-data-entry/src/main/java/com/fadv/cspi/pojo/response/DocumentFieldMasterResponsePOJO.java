package com.fadv.cspi.pojo.response;

import java.util.ArrayList;
import java.util.List;

import com.fadv.cspi.pojo.UniqueFormArrayPOJO;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;
import com.fasterxml.jackson.databind.node.ObjectNode;

import lombok.Data;

@Data
public class DocumentFieldMasterResponsePOJO {

	private boolean isMandatory = false;

	private List<String> possibleValues;

	private ObjectNode remoteApi;

	private int sequenceId = 1;

	private boolean showInGrid = true;

	private String uiControlName;

	private String documentFieldName;

	private String documentFieldKey;

	private String defaultValue = "";

	private boolean readOnly = false;

	private List<UniqueFormArrayPOJO> formArray = new ArrayList<>();

	private boolean autoPopulate = false;

	private String parentDocumentKey;

	private String groupKey;

	private String ingestedValue = "";
	
	@JsonProperty(access = Access.WRITE_ONLY)
	public String getUpdatedDefaulValue() {
		return this.defaultValue != null ? this.defaultValue : "";
	}
}
