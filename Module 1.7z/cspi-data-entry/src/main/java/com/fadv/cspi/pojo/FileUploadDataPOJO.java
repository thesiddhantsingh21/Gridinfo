package com.fadv.cspi.pojo;

import java.util.List;

import com.fadv.cspi.fullfilment.entities.MiFulfilmentRequest;

import lombok.Data;

@Data
public class FileUploadDataPOJO {
	private String transactionId;
	private String tokenId;
	private Long caseDetailsId;
	private MiFulfilmentRequest miFulfilmentRequest;
	private List<FileInfoPOJO> originalData;
	private List<FileInfoPOJO> convertedData;
	private String caseOrigin;
}
