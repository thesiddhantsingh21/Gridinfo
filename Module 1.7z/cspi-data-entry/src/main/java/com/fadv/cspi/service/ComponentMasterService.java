package com.fadv.cspi.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.fadv.cspi.entities.master.ComponentMaster;
import com.fadv.cspi.exception.ServiceException;
import com.fadv.cspi.pojo.response.ComponentMasterResponsePOJO;

@Service
public interface ComponentMasterService {

	List<ComponentMasterResponsePOJO> fetchComponentMasterList();

	ComponentMaster findByComponentMasterId(Long componentMasterId) throws ServiceException;

	List<ComponentMaster> findByComponentName(String componentName);

}
