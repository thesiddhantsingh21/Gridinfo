package com.fadv.cspi.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fadv.cspi.entities.master.DocumentFieldMaster;
import com.fadv.cspi.repository.master.DocumentFieldMasterRepository;

@Service
public class DocumentFieldMasterServiceImpl implements DocumentFieldMasterService {

	@Autowired
	private DocumentFieldMasterRepository documentFieldMasterRepository;

	@Override
	public DocumentFieldMaster findByDocumentFieldKey(String documentFieldKey) {
		List<DocumentFieldMaster> documentFieldMasters = documentFieldMasterRepository
				.findByDocumentFieldKeyIgnoreCaseAndActive(documentFieldKey, true);
		if (CollectionUtils.isNotEmpty(documentFieldMasters)) {
			return documentFieldMasters.get(0);
		}
		return null;
	}

	@Override
	public List<DocumentFieldMaster> getByFieldKeyReverse(String fieldKey) {
		String docFieldKeyRev = StringUtils.reverse(fieldKey);

		List<String> values = Arrays.asList(docFieldKeyRev.split("\\D+"));

		docFieldKeyRev = StringUtils.reverse(docFieldKeyRev);

		if (CollectionUtils.isNotEmpty(values) && StringUtils.isNotEmpty(values.get(0))) {
			int strLen = values.get(0).length();
			while (strLen > 0) {
				docFieldKeyRev = StringUtils.chop(docFieldKeyRev);
				strLen--;
			}
			return documentFieldMasterRepository.getByFieldKeyReverse(docFieldKeyRev);
		}

		return new ArrayList<>();
	}

}
