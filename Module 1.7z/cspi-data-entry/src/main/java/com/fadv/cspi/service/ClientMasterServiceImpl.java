package com.fadv.cspi.service;

import java.util.List;

import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fadv.cspi.entities.master.ClientMaster;
import com.fadv.cspi.exception.ServiceException;
import com.fadv.cspi.repository.master.ClientMasterRepository;

@Service
public class ClientMasterServiceImpl implements ClientMasterService {

	@Autowired
	private ClientMasterRepository clientMasterRepository;

	@Override
	public List<String> getAllDistinctClientNamesOrderByClientName() {
		return clientMasterRepository.getAllDistinctClientNamesOrderByClientName();
	}

	@Override
	public ClientMaster findByClientName(String clientName) throws ServiceException {
		List<ClientMaster> clientMasters = clientMasterRepository.findByClientNameIgnoreCaseAndActive(clientName, true);
		if (CollectionUtils.isNotEmpty(clientMasters)) {
			return clientMasters.get(0);
		}
		throw new ServiceException("Sbu Details not found for given sbu name", "ERROR_CODE_400");
	}
}
