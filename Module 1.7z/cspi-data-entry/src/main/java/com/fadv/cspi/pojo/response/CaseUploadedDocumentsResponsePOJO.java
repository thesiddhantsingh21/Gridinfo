package com.fadv.cspi.pojo.response;

import java.util.List;
import java.util.Map;

import com.fadv.cspi.pojo.ConvertedDocumentsResponsePOJO;

import lombok.Data;

@Data
public class CaseUploadedDocumentsResponsePOJO {

	private List<ConvertedDocumentsResponsePOJO> files;
	private Map<String, String> errorMap;

}
