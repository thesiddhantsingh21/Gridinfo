package com.fadv.cspi.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.fadv.cspi.entities.transaction.CaseDetails;
import com.fadv.cspi.exception.ServiceException;
import com.fadv.cspi.fullfilment.pojo.CasePOJO;
import com.fadv.cspi.interfaces.CaseDetailsResponseInterface;
import com.fadv.cspi.pojo.CaseSearchPOJO;
import com.fadv.cspi.pojo.request.CaseSearchCriteriaPOJO;
import com.fadv.cspi.pojo.response.CaseDetailsResponsePOJO;
import com.fasterxml.jackson.core.JsonProcessingException;

@Service
public interface CaseDetailsService {

	CaseDetails findByCaseDetailsId(Long caseDetailsId) throws ServiceException;

	List<CaseDetailsResponseInterface> getCaseDetailsUsingFilters(CaseSearchCriteriaPOJO caseSearchCriteriaPOJO);

	CaseDetailsResponsePOJO getCaseDetailsByCaseDetailsId(Long caseDetailsId) throws ServiceException;

	CaseDetails saveCaseDetails(CaseDetails caseDetails);

	List<String> getDeCompletedCrns();

	CaseDetails findByCaseNo(String caseNo) throws ServiceException;

	CaseDetails getByCaseDetailsId(Long caseId);

	CasePOJO getCaseDetailsJsonDataByCrn(Long caseDetailsId) throws JsonProcessingException;

	List<String> getAllDeCompletedCrns();

	List<CaseDetails> getCasesBySearchCriteria(CaseSearchPOJO caseSearchPOJO) throws ServiceException;

}
