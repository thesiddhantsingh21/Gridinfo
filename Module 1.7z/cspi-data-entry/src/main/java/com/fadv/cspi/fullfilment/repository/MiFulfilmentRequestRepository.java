package com.fadv.cspi.fullfilment.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.fadv.cspi.entities.master.CaseSpecificRecordDetail;
import com.fadv.cspi.entities.transaction.CaseDetails;
import com.fadv.cspi.fullfilment.entities.MiFulfilmentRequest;
import com.fadv.cspi.fullfilment.interfaces.MiFulfilmentResponseInterface;

@Repository
public interface MiFulfilmentRequestRepository extends JpaRepository<MiFulfilmentRequest, Long> {

	@Query(value = "select mfr.mi_fulfilment_request_id as miFulfilmentRequestId, "
			+ "cd.case_details_id as caseDetailsId, cast(mfr.de_documents as varchar) deDocuments, mfr.fulfilled, "
			+ "mfr.status, mfr.remarks, mfr.created_date as miRaisedDate, mfr.completed_date as miReleasedDate, "
			+ "cd.request_date as caseCreationDate, "
			+ "cd.case_no as caseNo, cd.crn, cm.client_name as clientName, cd.case_type as caseType "
			+ "from {h-schema}mi_fulfilment_request mfr "
			+ "left join {h-schema}case_details cd on  mfr.case_details_id = cd.case_details_id "
			+ "left join {h-schema}case_client_details ccd on cd.case_details_id = ccd.case_details_id "
			+ "left join {h-schema}client_master cm on ccd.client_master_id = cm.client_master_id "
			+ "order by mfr.created_date desc", nativeQuery = true)
	List<MiFulfilmentResponseInterface> getAllMiFulfillments();

	@Query(value = "select mfr.mi_fulfilment_request_id as miFulfilmentRequestId, "
			+ "cd.case_details_id as caseDetailsId, cast(mfr.de_documents as varchar) deDocuments, mfr.fulfilled, "
			+ "mfr.status, mfr.remarks, mfr.created_date as miRaisedDate, mfr.completed_date as miReleasedDate, mfr.check_id as checkId, "
			+ "cd.request_date as caseCreationDate, "
			+ "cd.case_no as caseNo, cd.crn, cm.client_name as clientName, cd.case_type as caseType "
			+ "from {h-schema}mi_fulfilment_request mfr "
			+ "left join {h-schema}case_details cd on  mfr.case_details_id = cd.case_details_id "
			+ "left join {h-schema}case_client_details ccd on cd.case_details_id = ccd.case_details_id "
			+ "left join {h-schema}client_master cm on ccd.client_master_id = cm.client_master_id "
			+ "where mfr.mi_fulfilment_request_id = :miFulfilmentRequestId limit 1", nativeQuery = true)
	MiFulfilmentResponseInterface getMiFulfillmentsById(long miFulfilmentRequestId);

	@Query(value = "select mfr.mi_fulfilment_request_id as miFulfilmentRequestId, "
			+ "cd.case_details_id as caseDetailsId, cast(mfr.de_documents as varchar) deDocuments, mfr.fulfilled, "
			+ "mfr.status, mfr.remarks, mfr.created_date as miRaisedDate, mfr.completed_date as miReleasedDate, "
			+ "cd.request_date as caseCreationDate, "
			+ "cd.case_no as caseNo, cd.crn, cm.client_name as clientName, cd.case_type as caseType, mfr.check_id as checkId "
			+ "from {h-schema}mi_fulfilment_request mfr "
			+ "left join {h-schema}case_details cd on  mfr.case_details_id = cd.case_details_id "
			+ "left join {h-schema}case_client_details ccd on cd.case_details_id = ccd.case_details_id "
			+ "left join {h-schema}client_master cm on ccd.client_master_id = cm.client_master_id "
			+ "where cd.case_no = :caseNo order by mfr.created_date desc", nativeQuery = true)
	List<MiFulfilmentResponseInterface> getMiFulfillmentsByCaseNo(String caseNo);

	@Query(value = "select mfr.mi_fulfilment_request_id as miFulfilmentRequestId, "
			+ "cd.case_details_id as caseDetailsId, cast(mfr.de_documents as varchar) deDocuments, mfr.fulfilled, "
			+ "mfr.status, mfr.remarks, mfr.created_date as miRaisedDate, mfr.completed_date as miReleasedDate, "
			+ "cd.request_date as caseCreationDate, "
			+ "cd.case_no as caseNo, cd.crn, cm.client_name as clientName, cd.case_type as caseType, mfr.check_id as checkId "
			+ "from {h-schema}mi_fulfilment_request mfr "
			+ "left join {h-schema}case_details cd on  mfr.case_details_id = cd.case_details_id "
			+ "left join {h-schema}case_client_details ccd on cd.case_details_id = ccd.case_details_id "
			+ "left join {h-schema}client_master cm on ccd.client_master_id = cm.client_master_id "
			+ "where cd.crn = :crn order by mfr.created_date desc", nativeQuery = true)
	List<MiFulfilmentResponseInterface> getMiFulfillmentsByCrn(String crn);
	
	
	@Query(value = "select mfr.mi_fulfilment_request_id as miFulfilmentRequestId, "
			+ "cd.case_details_id as caseDetailsId, cast(mfr.de_documents as varchar) deDocuments, mfr.fulfilled, "
			+ "mfr.status, mfr.remarks, mfr.created_date as miRaisedDate, mfr.completed_date as miReleasedDate, "
			+ "cd.request_date as caseCreationDate, "
			+ "cd.case_no as caseNo, cd.crn, cm.client_name as clientName, cd.case_type as caseType, mfr.check_id as checkId "
			+ "from {h-schema}mi_fulfilment_request mfr "
			+ "left join {h-schema}case_details cd on  mfr.case_details_id = cd.case_details_id "
			+ "left join {h-schema}case_client_details ccd on cd.case_details_id = ccd.case_details_id "
			+ "left join {h-schema}client_master cm on ccd.client_master_id = cm.client_master_id "
			+ "where mfr.check_id = :checkId order by mfr.created_date desc", nativeQuery = true)
	List<MiFulfilmentResponseInterface> getMiFulfillmentsByCheckId(String checkId);

	@Query(value = "select mfr.mi_fulfilment_request_id as miFulfilmentRequestId, "
			+ "cd.case_details_id as caseDetailsId, cast(mfr.de_documents as varchar) deDocuments, mfr.fulfilled, "
			+ "mfr.status, mfr.remarks, mfr.created_date as miRaisedDate, mfr.completed_date as miReleasedDate, "
			+ "cd.request_date as caseCreationDate, "
			+ "cd.case_no as caseNo, cd.crn, cm.client_name as clientName, cd.case_type as caseType, mfr.check_id as checkId "
			+ "from {h-schema}mi_fulfilment_request mfr "
			+ "left join {h-schema}case_details cd on  mfr.case_details_id = cd.case_details_id "
			+ "left join {h-schema}case_client_details ccd on cd.case_details_id = ccd.case_details_id "
			+ "left join {h-schema}client_master cm on ccd.client_master_id = cm.client_master_id "
			+ "where CAST(DATE(mfr.created_date) AS VARCHAR) BETWEEN SYMMETRIC :fromDate AND :toDate "
			+ "and case when :clientName != '' then lower(cm.client_name) like lower(:clientName) else true end "
			+ "and case when :crnNo != '' then cd.crn = :crnNo else true end "
			+ "and case when :checkId != '' then mfr.check_id =:checkId else true end "
//			+ "and case when :fulfillmentType = '' then true end "
//			+ "and case when :fulfillmentType = 'Check Level' then mfr.check_id is not null else mfr.check_id is null end "
			+ "and case when :fulfillmentType = '' then true else (case when :fulfillmentType = 'Check Level' then mfr.check_id is not null else mfr.check_id is null end) end "
			//+ "and case when :fulfillmentType = 'Check Level' then mfr.check_id is not null else mfr.check_id is null end "
			+ "and case when :status != '' then lower(mfr.status) "
			+ "like lower(:status) else true end order by mfr.created_date desc", nativeQuery = true)
	List<MiFulfilmentResponseInterface> getMiFulfillmentsByFilter(String fromDate, String toDate, String clientName,
			String crnNo, String status,String checkId,String fulfillmentType);

	List<MiFulfilmentRequest> findByCaseDetails(CaseDetails caseDetails);

	@Modifying(clearAutomatically = true)
	@Query(value = "UPDATE {h-schema}mi_fulfilment_request SET released = true "
			+ "WHERE mi_fulfilment_request_id = (select mfr.mi_fulfilment_request_id from {h-schema}mi_fulfilment_request mfr "
			+ "left join {h-schema}case_details cd on mfr.case_details_id = cd.case_details_id "
			+ "where cd.is_fulfillment = true and mfr.fulfilled = true and mfr.released = false and mfr.check_id is null "
			+ "LIMIT 1 FOR UPDATE SKIP LOCKED) RETURNING *", nativeQuery = true)
	List<MiFulfilmentRequest> getAndUpdateMiFulfilledData();

	@Modifying(clearAutomatically = true)
	@Query(value = "UPDATE {h-schema}mi_fulfilment_request SET released = true "
			+ "WHERE mi_fulfilment_request_id = (select mfr.mi_fulfilment_request_id from {h-schema}mi_fulfilment_request mfr "
			+ "left join {h-schema}case_details cd on mfr.case_details_id = cd.case_details_id "
			+ "where cd.is_fulfillment = true and mfr.fulfilled = true and mfr.released = false and cd.case_no= :caseNo and mfr.check_id is null  "
			+ "LIMIT 1 FOR UPDATE SKIP LOCKED) RETURNING *", nativeQuery = true)
	List<MiFulfilmentRequest> getAndUpdateMiFulfilledDataByCaseNo(String caseNo);
	
	
}