package com.fadv.cspi.interfaces;

public interface QualificationLevelMasterListResponseInterface {
	long getQualificationLevelMasterId();

	String getQualificationLevel();
}
