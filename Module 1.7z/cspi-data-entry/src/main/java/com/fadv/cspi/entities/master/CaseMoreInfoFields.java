package com.fadv.cspi.entities.master;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.vladmihalcea.hibernate.type.json.JsonBinaryType;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
@Entity
@JsonInclude(value = Include.NON_NULL)
@TypeDef(name = "jsonb", typeClass = JsonBinaryType.class)
public class CaseMoreInfoFields implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(nullable = false, updatable = false)
	private long caseMoreInfoFieldsId;

	@Column(nullable = false)
	private String fieldLabel;

	@Column(nullable = false)
	private String fieldName;

	@Column(nullable = false)
	private Boolean fieldMandatory = false;

	@Column(nullable = false)
	private String fieldDataType;

	@Column(nullable = false)
	private int fieldSequenceId;

	@Column(nullable = false)
	private String fieldUiControl;

	@Type(type = "jsonb")
	@Column(columnDefinition = "jsonb", nullable = false)
	private ArrayNode possibleValues = new ObjectMapper().createArrayNode();

	@ManyToOne
	@JoinColumn(name = "client_master_id", nullable = false)
	private ClientMaster clientMaster;

	@Column(name = "client_name", nullable = false)
	private String clientName;

	@Column(name = "client_code", nullable = false)
	private String clientCode;

	@JsonProperty(access = Access.WRITE_ONLY)
	@Column(nullable = false, columnDefinition = "boolean default false")
	private Boolean active;

}
