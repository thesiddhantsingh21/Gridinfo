package com.fadv.cspi.service;

import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.util.MultiValueMap;

import com.fadv.cspi.userdetail.pojo.UserDetailPOJO;
import com.fasterxml.jackson.databind.JsonNode;

@Service
public interface ApiService {

	String sendDataToPost(String requestUrl, String requestStr);

	String sendDataToGet(String requestUrl);

	String sendDataToSecuredPost(String requestUrl, String requestStr, Map<String, String> headerMap);

	String sendDataToPostFormData(String requestUrl, MultiValueMap<String, Object> map);

	boolean addAuditLog(String tableName, JsonNode prevValues, JsonNode newValues, UserDetailPOJO userDetailPOJO,
			String operationType, String tokenId);

	String saveAuditLog(String requestUrl, String requestStr, String tokenId);

	String sendDataToPostMi(String requestUrl, String requestStr, String tokenId);

}
