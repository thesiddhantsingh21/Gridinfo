package com.fadv.cspi.repository.master;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fadv.cspi.entities.master.ComponentMaster;

public interface ComponentMasterRepository extends JpaRepository<ComponentMaster, Long> {

	List<ComponentMaster> findByComponentNameIgnoreCase(String componentName);
}
