package com.fadv.cspi.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.fadv.cspi.entities.master.ContactCardMaster;
import com.fadv.cspi.entities.master.DocumentMaster;
import com.fadv.cspi.entities.transaction.CaseAssociatedDocuments;
import com.fadv.cspi.entities.transaction.CaseDataEntry;
import com.fadv.cspi.entities.transaction.CaseDetails;
import com.fadv.cspi.entities.transaction.CaseUploadedDocuments;
import com.fadv.cspi.exception.ServiceException;
import com.fadv.cspi.fullfilment.entities.MiFulfilmentRequest;
import com.fadv.cspi.fullfilment.pojo.MiDocumentsPOJO;
import com.fadv.cspi.fullfilment.service.MiFulfilmentRequestService;
import com.fadv.cspi.interfaces.CaseAssociatedDocumentsInterface;
import com.fadv.cspi.pojo.request.CaseAssociatedDocumentsRequestPOJO;
import com.fadv.cspi.pojo.request.FecthAssociateDocsPOJO;
import com.fadv.cspi.pojo.request.SplitRequestPOJO;
import com.fadv.cspi.pojo.response.CaseAssociatedDocumentsResponsePOJO;
import com.fadv.cspi.pojo.response.DocumentFieldMasterResponsePOJO;
import com.fadv.cspi.pojo.response.DocumentMasterResponsePOJO;
import com.fadv.cspi.pojo.response.SplitResponsePOJO;
import com.fadv.cspi.repository.transaction.CaseAssociatedDocumentsRepository;
import com.fadv.cspi.repository.transaction.CaseDataEntryRepository;
import com.fadv.cspi.service.remote.RemoteDataService;
import com.fadv.cspi.userdetail.pojo.UserDetailPOJO;
import com.fadv.cspi.utility.ConversionUtility;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

@Service
public class CaseAssociatedDocumentsServiceImpl implements CaseAssociatedDocumentsService {

	private static final String DELETE = "DELETE";

	private static final String ERROR_CODE_400 = "ERROR_CODE_400";

	private static final String ERROR_CODE_404 = "ERROR_CODE_404";

	private static final String CASE_ASSOCIATED_DOCUMENTS = "case_associated_documents";

	@Autowired
	private CaseAssociatedDocumentsRepository caseAssociatedDocumentsRepository;

	@Autowired
	private CaseDataEntryRepository caseDataEntryRepository;

	@Autowired
	private CaseDetailsService caseDetailsService;

	@Autowired
	private RemoteDataService remoteDataService;

	@Autowired
	private DocumentMasterService documentMasterService;

	@Autowired
	private ContactCardMasterService contactCardMasterService;

	@Autowired
	private CaseUploadedDocumentsService caseUploadedDocumentsService;

	@Autowired
	private MiFulfilmentRequestService miFulfilmentRequestService;

	@Autowired
	private DocFieldMappingService docFieldMappingService;

	@Autowired
	private CaseDataEntryService caseDataEntryService;

	@Autowired
	private ApiService apiService;

	@Value("${search.s3.file.url}")
	private String searchS3FileUrl;

	@Value("${split.file.url}")
	private String fileSplitUrl;

	@Value("${de.first.document}")
	private String deFirstDocument;

	private static final Logger logger = LoggerFactory.getLogger(CaseAssociatedDocumentsServiceImpl.class);
	ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

	@Override
	public List<String> getAkaNamesByCaseId(Long caseDetailsId) throws ServiceException {

		List<CaseAssociatedDocuments> caseAssociatedDocuments = getAssociatedDocumentsByCaseDetailsId(caseDetailsId);

		if (CollectionUtils.isNotEmpty(caseAssociatedDocuments)) {
			return new ArrayList<>(
					caseAssociatedDocuments.parallelStream().filter(data -> data.getContactCardMaster() != null
							&& StringUtils.isNotEmpty(data.getContactCardMaster().getAkaName())).map(data -> {
								if (data.getAgencyAkaName() != null
										&& StringUtils.isNotEmpty(data.getAgencyAkaName())) {
									return data.getAgencyAkaName();
								}
								return data.getContactCardMaster().getAkaName();
							}).collect(Collectors.toSet()));
		}
		return new ArrayList<>();
	}

	@Override
	public List<CaseAssociatedDocuments> getAssociatedDocumentsByCaseDetailsId(Long caseDetailsId)
			throws ServiceException {
		CaseDetails caseDetails = caseDetailsService.findByCaseDetailsId(caseDetailsId);

		return caseAssociatedDocumentsRepository.findByCaseDetails(caseDetails);
	}

//================================================================================================================	
//------------------------------------------Fetch split documents-------------------------------------------------
//================================================================================================================	
	@Override
	public List<CaseAssociatedDocumentsResponsePOJO> getAssociatedDocumentDetailsByCaseDetailsId(Long caseDetailsId)
			throws ServiceException {
// ***************DE Completion and crn check******************
		checkForValidCrn(caseDetailsService.findByCaseDetailsId(caseDetailsId));
// ************************************************************

		List<CaseAssociatedDocumentsInterface> caseAssociatedDocumentsInterfaces = caseAssociatedDocumentsRepository
				.getDocumentAssociationAndDetailsByCaseId(caseDetailsId);
		List<CaseAssociatedDocumentsResponsePOJO> caseAssociatedDocumentsResponsePOJOs = mapper.convertValue(
				caseAssociatedDocumentsInterfaces, new TypeReference<List<CaseAssociatedDocumentsResponsePOJO>>() {
				});

		List<CaseAssociatedDocumentsResponsePOJO> newCaseAssociatedDocumentsResponsePOJOs = new ArrayList<>();

		List<CaseAssociatedDocumentsResponsePOJO> tempCaseAssociatedDocumentsResponsePOJOs = caseAssociatedDocumentsResponsePOJOs
				.stream().filter(data -> StringUtils.equalsAnyIgnoreCase(data.getDocumentName(), deFirstDocument))
				.collect(Collectors.toList());

		if (CollectionUtils.isNotEmpty(tempCaseAssociatedDocumentsResponsePOJOs)) {
			caseAssociatedDocumentsResponsePOJOs.removeAll(tempCaseAssociatedDocumentsResponsePOJOs);
			newCaseAssociatedDocumentsResponsePOJOs.addAll(tempCaseAssociatedDocumentsResponsePOJOs);
		}

		if (CollectionUtils.isNotEmpty(caseAssociatedDocumentsResponsePOJOs)) {
			newCaseAssociatedDocumentsResponsePOJOs.addAll(caseAssociatedDocumentsResponsePOJOs);
		}

		return newCaseAssociatedDocumentsResponsePOJOs;
	}
//================================================================================================================	
//------------------------------------------Fetch split documents-------------------------------------------------
// ================================================================================================================

//================================================================================================================	
//-------------------------------------Fetch supporting split documents-------------------------------------------
//================================================================================================================

	@Override
	public List<CaseAssociatedDocumentsResponsePOJO> fetchSupportingSplitDocuments(
			FecthAssociateDocsPOJO fetchAssociateDocsPOJO) throws ServiceException {
		logger.info("Fecth supporting associate docs request : {}", fetchAssociateDocsPOJO);
		Long caseDetailsId = fetchAssociateDocsPOJO.getCaseId();
		String parentRowId = fetchAssociateDocsPOJO.getParentRowId();
		String akaName = fetchAssociateDocsPOJO.getAkaName();
		String componentName = fetchAssociateDocsPOJO.getComponentName();
		String agencyAkaName = fetchAssociateDocsPOJO.getAgencyAkaName() != null
				? fetchAssociateDocsPOJO.getAgencyAkaName()
				: "";

		// ***************DE Completion and crn check******************
		checkForValidCrn(caseDetailsService.findByCaseDetailsId(caseDetailsId));
		// ************************************************************

		ObjectNode mrlSearchNode = mapper.createObjectNode();

		mrlSearchNode.put("akaName", akaName);
		mrlSearchNode.put("componentName", componentName);

		if (StringUtils.isNotEmpty(agencyAkaName)) {
			mrlSearchNode.put("akaName", agencyAkaName);
		}

		List<String> mrlDocsList = new ArrayList<>();
		try {
			mrlDocsList = remoteDataService.getMrlDocs(mrlSearchNode);
		} catch (ServiceException e) {
			logger.error("Exception while fetching from MRL : {}", e.getMessage());
			mrlDocsList = new ArrayList<>();
		}

		List<CaseAssociatedDocumentsInterface> caseAssociatedDocuments = caseAssociatedDocumentsRepository
				.getByParentRowIdAndAkaNameAndCaseDetails(parentRowId, akaName, caseDetailsId);
		List<CaseAssociatedDocumentsResponsePOJO> caseAssociatedDocumentsResponsePOJOs = mapper
				.convertValue(caseAssociatedDocuments, new TypeReference<List<CaseAssociatedDocumentsResponsePOJO>>() {
				});

		List<String> mrlDocsListNew = mrlDocsList;
		caseAssociatedDocumentsResponsePOJOs.parallelStream().forEach(data -> {
			if (mrlDocsListNew.contains(data.getDocumentName())) {
				data.setMandatory(true);
			}
		});

		List<String> mrlFiltered = new ArrayList<>(mrlDocsListNew.parallelStream().filter(mrlDoc -> {
			List<CaseAssociatedDocumentsResponsePOJO> caseAssociatedDocumentsResponsePOJOsNew = caseAssociatedDocumentsResponsePOJOs
					.parallelStream()
					.filter(customDoc -> StringUtils.equalsIgnoreCase(customDoc.getDocumentName(), mrlDoc))
					.collect(Collectors.toList());
			return CollectionUtils.isEmpty(caseAssociatedDocumentsResponsePOJOsNew);
		}).collect(Collectors.toSet()));

		List<DocumentMasterResponsePOJO> masterDocList = documentMasterService.getAllDocumentsOrderByDocumentName();

		List<DocumentMasterResponsePOJO> mrlFullDocList = masterDocList.parallelStream()
				.filter(data -> mrlFiltered.contains(data.getDocumentName())).collect(Collectors.toList());

		List<CaseAssociatedDocumentsResponsePOJO> customDocsDataListMrl = mrlFullDocList.parallelStream()
				.map(document -> {
					UUID uuid = UUID.randomUUID();
					String rowId = uuid.toString();
					CaseAssociatedDocumentsResponsePOJO caseAssociatedDocumentsResponsePOJO = new CaseAssociatedDocumentsResponsePOJO();
					caseAssociatedDocumentsResponsePOJO.setCaseDetailsId(caseDetailsId);
					caseAssociatedDocumentsResponsePOJO.setAkaName(akaName);
					caseAssociatedDocumentsResponsePOJO.setAgencyAkaName(agencyAkaName);
					caseAssociatedDocumentsResponsePOJO.setDocumentMasterId(document.getDocumentMasterId());
					caseAssociatedDocumentsResponsePOJO.setDocumentName(document.getDocumentName());
					caseAssociatedDocumentsResponsePOJO.setParentRowId(parentRowId);
					caseAssociatedDocumentsResponsePOJO.setRowId(rowId); // Generate new
					caseAssociatedDocumentsResponsePOJO.setMandatory(true);
					return caseAssociatedDocumentsResponsePOJO;
				}).collect(Collectors.toList());

		caseAssociatedDocumentsResponsePOJOs.addAll(customDocsDataListMrl);
		return caseAssociatedDocumentsResponsePOJOs;
	}
//================================================================================================================	
//-------------------------------------Fetch supporting split documents-------------------------------------------
//================================================================================================================

	@Override
	public CaseAssociatedDocuments getCaseAssociateDocumentByCaseDetailsIdDocumentMasterIdAndRowId(long caseDetailsId,
			long documentMasterId, String rowId) {
		List<CaseAssociatedDocuments> caseAssociatedDocuments = caseAssociatedDocumentsRepository
				.getCaseAssociateDocumentByCaseDetailsIdDocumentMasterIdAndRowId(caseDetailsId, documentMasterId,
						rowId);
		if (CollectionUtils.isNotEmpty(caseAssociatedDocuments)) {
			return caseAssociatedDocuments.get(0);
		}
		return null;
	}

	@Override
	public CaseAssociatedDocuments getCaseAssociateDocumentByCaseDetailsIdAndDocumentMasterId(long caseDetailsId,
			long documentMasterId) {
		List<CaseAssociatedDocuments> caseAssociatedDocuments = caseAssociatedDocumentsRepository
				.getCaseAssociateDocumentByCaseDetailsIdAndDocumentMasterId(caseDetailsId, documentMasterId);
		if (CollectionUtils.isNotEmpty(caseAssociatedDocuments)) {
			return caseAssociatedDocuments.get(0);
		}
		return null;
	}

//================================================================================================================	
//---------------------------------------Save and split documents-------------------------------------------------
//================================================================================================================	

	@Override
	public List<CaseAssociatedDocumentsResponsePOJO> processSplitDocumentRequest(
			CaseAssociatedDocumentsRequestPOJO caseAssociatedDocumentsRequestPOJO, UserDetailPOJO userDetailPOJO,
			String tokenId) throws ServiceException, JsonProcessingException {

		String operation = "ADD";
		JsonNode previousJson = mapper.createObjectNode();

		logger.info("CaseAssociatedDocumentsRequestPOJO: {}", caseAssociatedDocumentsRequestPOJO);

		long caseDetailsId = caseAssociatedDocumentsRequestPOJO.getCaseDetailsId();
		Long fulfillmentId = caseAssociatedDocumentsRequestPOJO.getFulfillmentId();

		String akaName = caseAssociatedDocumentsRequestPOJO.getAkaName() != null
				? caseAssociatedDocumentsRequestPOJO.getAkaName()
				: "";

		String agencyAkaName = caseAssociatedDocumentsRequestPOJO.getAgencyAkaName() != null
				? caseAssociatedDocumentsRequestPOJO.getAgencyAkaName()
				: "";

		String parentRowId = caseAssociatedDocumentsRequestPOJO.getParentRowId() != null
				? caseAssociatedDocumentsRequestPOJO.getParentRowId()
				: "";
		String rowId = caseAssociatedDocumentsRequestPOJO.getRowId();
		long documentMasterId = caseAssociatedDocumentsRequestPOJO.getDocumentMasterId();
		long caseUploadedDocumentId = caseAssociatedDocumentsRequestPOJO.getCaseUploadedDocumentsId();

		ContactCardMaster contactCardMasters = null;

		// ***************DE Completion and crn check******************
		CaseDetails caseDetails = caseDetailsService.findByCaseDetailsId(caseDetailsId);
		checkForValidCrn(caseDetails);

		MiFulfilmentRequest miFulfilmentRequest = null;
		if (fulfillmentId != null) {
			miFulfilmentRequest = miFulfilmentRequestService.findByMiFulfilmentRequestId(fulfillmentId);
		}
		checkForDeCompletion(caseDetails, miFulfilmentRequest);
		// ************************************************************

		CaseUploadedDocuments caseUploadedDocuments = caseUploadedDocumentsService
				.findByCaseUploadedDocumentsId(caseUploadedDocumentId);
		DocumentMaster documentMaster = documentMasterService.findByDocumentMasterId(documentMasterId);

		if (StringUtils.isNotEmpty(akaName)) {
			contactCardMasters = contactCardMasterService.getContactCardByAkaName(akaName);
			if (contactCardMasters == null) {
				throw new ServiceException("Aka Name does not exist. Please add a new aka name first", ERROR_CODE_400);
			}
		}

		if (StringUtils.isNotEmpty(parentRowId)) {
			if (StringUtils.isEmpty(akaName)) {
				throw new ServiceException("Aka Name cannot be empty", ERROR_CODE_400);
			}
			List<CaseAssociatedDocuments> caseAssociatedDocuments = caseAssociatedDocumentsRepository
					.getCaseAssociateDocumentByCaseDetailsIdAndRowId(caseDetailsId, parentRowId);
			logger.info("Document exists for \"parentRowId\" : {}", caseAssociatedDocuments);
			if (CollectionUtils.isEmpty(caseAssociatedDocuments)) {
				throw new ServiceException("Parent row id doesn't exist. Please associate parent data first",
						ERROR_CODE_400);
			}
		}

		CaseAssociatedDocuments caseAssociatedDocuments = getCaseAssociateDocumentByCaseDetailsIdDocumentMasterIdAndRowId(
				caseDetailsId, documentMasterId, rowId);
		logger.info("Document exists for \"caseDetailsId\" and \"rowId\" : {}", caseAssociatedDocuments);

		checkAndSplitCaseAssociatedDocumentsRequestPOJO(caseAssociatedDocumentsRequestPOJO);

		CaseAssociatedDocuments newCaseAssociatedDocuments = new CaseAssociatedDocuments();
		newCaseAssociatedDocuments.setActive(true);
		newCaseAssociatedDocuments.setCaseDetails(caseDetails);
		newCaseAssociatedDocuments.setCaseUploadedDocuments(caseUploadedDocuments);
		newCaseAssociatedDocuments.setContactCardMaster(contactCardMasters);
		newCaseAssociatedDocuments.setAgencyAkaName(agencyAkaName);
		newCaseAssociatedDocuments.setDocumentMaster(documentMaster);
		newCaseAssociatedDocuments.setEndPage(caseAssociatedDocumentsRequestPOJO.getEndPage());
		newCaseAssociatedDocuments.setFileName(caseAssociatedDocumentsRequestPOJO.getFileName());
		newCaseAssociatedDocuments.setFilePath(caseAssociatedDocumentsRequestPOJO.getSourceFolder());
		newCaseAssociatedDocuments.setParentRowId(parentRowId);
		newCaseAssociatedDocuments.setRowId(rowId);
		newCaseAssociatedDocuments.setStartPage(caseAssociatedDocumentsRequestPOJO.getStartPage());
		newCaseAssociatedDocuments.setUpdatedDate(new Date());
		newCaseAssociatedDocuments.setCreatedDate(new Date());
		newCaseAssociatedDocuments.setUpdatedByUser(userDetailPOJO.getUserId());
		if (miFulfilmentRequest != null) {
			miFulfilmentRequest = miFulfilmentRequestService.updateDeDocumentsByFulfillment(
					documentMaster.getDocumentName(), rowId, parentRowId, miFulfilmentRequest, userDetailPOJO, tokenId);
			newCaseAssociatedDocuments.setMiFulfilmentRequest(miFulfilmentRequest);
		}

		if (caseAssociatedDocuments != null) {

			akaNameEditCheckAndUpdate(userDetailPOJO, tokenId, rowId, contactCardMasters, caseDetails, documentMaster,
					caseAssociatedDocuments);

			operation = "EDIT";
			previousJson = mapper.convertValue(caseAssociatedDocuments, JsonNode.class);

			newCaseAssociatedDocuments
					.setCaseAssociatedDocumentsId(caseAssociatedDocuments.getCaseAssociatedDocumentsId());
			newCaseAssociatedDocuments.setCreatedDate(caseAssociatedDocuments.getCreatedDate());
		}

		newCaseAssociatedDocuments = caseAssociatedDocumentsRepository.save(newCaseAssociatedDocuments);

		JsonNode newJson = mapper.convertValue(newCaseAssociatedDocuments, JsonNode.class);
		logger.info("CaseAssociatedDocuments Json: {}", newJson);
		apiService.addAuditLog(CASE_ASSOCIATED_DOCUMENTS, previousJson, newJson, userDetailPOJO, operation, tokenId);

		if (fulfillmentId != null) {
			return getAssociatedDocumentDetailsByCaseDetailsIdAndFulfillmentId(caseDetailsId, fulfillmentId);
		}

		return getAssociatedDocumentDetailsByCaseDetailsId(caseDetailsId);
	}

	private void akaNameEditCheckAndUpdate(UserDetailPOJO userDetailPOJO, String tokenId, String rowId,
			ContactCardMaster contactCardMasters, CaseDetails caseDetails, DocumentMaster documentMaster,
			CaseAssociatedDocuments caseAssociatedDocuments) {
		// Delete supporting documents and data entry if new aka name is different from
		// existing aka name
		if (contactCardMasters != null && caseAssociatedDocuments.getContactCardMaster() != null
				&& !contactCardMasters.equals(caseAssociatedDocuments.getContactCardMaster())) {

			ContactCardMaster contactCardMaster = contactCardMasters;
			List<CaseDataEntry> childCaseDataEntries = caseDataEntryRepository.findByAkaNameIgnoreCaseAndCaseDetails(
					caseAssociatedDocuments.getContactCardMaster().getAkaName(), caseDetails);
			ArrayNode prevChildCaseDataEntries = mapper.convertValue(childCaseDataEntries, ArrayNode.class);

			childCaseDataEntries.stream().forEach(caseDataEntry -> {
				caseDataEntry.setAkaName(contactCardMaster.getAkaName());
				ObjectNode deDataNode = caseDataEntry.getDataEntryData();
				List<String> deNodeKeys = ConversionUtility.findKeys(deDataNode);

				List<DocumentFieldMasterResponsePOJO> documentFieldMasterResponsePOJOs = docFieldMappingService
						.findByDocumentMasterIdAndDocumentKeys(documentMaster.getDocumentMasterId(), deNodeKeys);
				documentFieldMasterResponsePOJOs = caseDataEntryService.checkUrlAndUpdateAkaEditValue(contactCardMaster,
						documentFieldMasterResponsePOJOs);
				documentFieldMasterResponsePOJOs.stream()
						.forEach(data -> deDataNode.put(data.getDocumentFieldKey(), data.getDefaultValue()));
				caseDataEntryService.handleConcatenatedKeys(deDataNode);
				caseDataEntry.setDataEntryData(deDataNode);
			});

			if (CollectionUtils.isNotEmpty(childCaseDataEntries)) {
				childCaseDataEntries = caseDataEntryRepository.saveAll(childCaseDataEntries);

				apiService.addAuditLog("case_data_entry", mapper.convertValue(childCaseDataEntries, ArrayNode.class),
						prevChildCaseDataEntries, userDetailPOJO, "EDIT", tokenId);
			}

			List<CaseAssociatedDocuments> childCaseAssociatedDocuments = caseAssociatedDocumentsRepository
					.findByContactCardMasterAndCaseDetailsAndParentRowId(caseAssociatedDocuments.getContactCardMaster(),
							caseDetails, rowId);

			childCaseAssociatedDocuments.stream().forEach(data -> data.setContactCardMaster(contactCardMaster));

			if (CollectionUtils.isNotEmpty(childCaseAssociatedDocuments)) {
				ArrayNode prevChildCaseAssociatedDocuments = mapper.convertValue(childCaseAssociatedDocuments,
						ArrayNode.class);
				childCaseAssociatedDocuments = caseAssociatedDocumentsRepository.saveAll(childCaseAssociatedDocuments);

				apiService.addAuditLog(CASE_ASSOCIATED_DOCUMENTS,
						mapper.convertValue(childCaseAssociatedDocuments, ArrayNode.class),
						prevChildCaseAssociatedDocuments, userDetailPOJO, "EDIT", tokenId);
			}
		}
	}

	private void checkAndSplitCaseAssociatedDocumentsRequestPOJO(
			CaseAssociatedDocumentsRequestPOJO caseAssociatedDocumentsRequestPOJO)
			throws ServiceException, JsonProcessingException {
		int totalPages = caseAssociatedDocumentsRequestPOJO.getPageCount();

		int startPage = caseAssociatedDocumentsRequestPOJO.getStartPage();
		int endPage = caseAssociatedDocumentsRequestPOJO.getEndPage();
		if (startPage > 0 && endPage > 0 && (startPage > totalPages || endPage > totalPages)) {
			throw new ServiceException("Start / end page should not greater than total no of pages", "ERROR_CODE_65");
		}

		String response = apiService.sendDataToGet(searchS3FileUrl + caseAssociatedDocumentsRequestPOJO.getFileName());
		if (response == null) {
			throw new ServiceException("Invalid file to associate", ERROR_CODE_404);
		}

		SplitRequestPOJO splitRequestPOJO = new SplitRequestPOJO();
		splitRequestPOJO.setDocumentName(caseAssociatedDocumentsRequestPOJO.getDocumentName());
		splitRequestPOJO.setFileName(caseAssociatedDocumentsRequestPOJO.getFileName());
		splitRequestPOJO.setSourceFolder(response);
		splitRequestPOJO.setStartPage(startPage);
		splitRequestPOJO.setEndPage(endPage);

		String splitFileResponse = apiService.sendDataToPost(fileSplitUrl, mapper.writeValueAsString(splitRequestPOJO));
		if (splitFileResponse == null) {
			throw new ServiceException("Exception occurred while associating file", ERROR_CODE_404);
		}
		SplitResponsePOJO splitResponsePOJO = mapper.readValue(splitFileResponse, SplitResponsePOJO.class);
		caseAssociatedDocumentsRequestPOJO.setFileName(splitResponsePOJO.getFileName());
		caseAssociatedDocumentsRequestPOJO.setFilePath(splitResponsePOJO.getSourcePath());
		caseAssociatedDocumentsRequestPOJO.setSourceFolder(splitResponsePOJO.getSourcePath());

	}

	@Override
	public boolean deleteByCaseDetailsIdAndRowIdAndDocumentMasterId(long caseDetailsId, String rowId,
			long documentMasterId, UserDetailPOJO userDetailPOJO, String tokenId) {

		List<CaseAssociatedDocuments> caseAssociatedDocuments = caseAssociatedDocumentsRepository
				.getCaseAssociateDocumentByCaseDetailsIdDocumentMasterIdAndRowId(caseDetailsId, documentMasterId,
						rowId);
		if (CollectionUtils.isNotEmpty(caseAssociatedDocuments)) {
			caseAssociatedDocumentsRepository.delete(caseAssociatedDocuments.get(0));

			JsonNode previousJson = mapper.convertValue(caseAssociatedDocuments.get(0), JsonNode.class);
			String option = DELETE;
			JsonNode newJson = mapper.createObjectNode();
			apiService.addAuditLog(CASE_ASSOCIATED_DOCUMENTS, previousJson, newJson, userDetailPOJO, option, tokenId);

			return true;
		}

		return false;
	}

	private void checkForValidCrn(CaseDetails caseDetails) throws ServiceException {

		String crNo = caseDetails.getCrn();

		if (crNo == null || StringUtils.isEmpty(crNo) || StringUtils.equalsIgnoreCase(crNo, "pending")) {
			throw new ServiceException("Invalid CRN", ERROR_CODE_404);
		}
	}

	private void checkForDeCompletion(CaseDetails caseDetails, MiFulfilmentRequest miFulfilmentRequest)
			throws ServiceException {

		if (caseDetails.getDeComplete() != null && caseDetails.getDeComplete()) {

			if (miFulfilmentRequest != null) {
				boolean fulfilled = miFulfilmentRequest.getFulfilled() != null && miFulfilmentRequest.getFulfilled();

				if (fulfilled) {
					throw new ServiceException("MI Fulfillment already done", ERROR_CODE_404);
				}
			} else {
				throw new ServiceException("DE Already done", ERROR_CODE_404);
			}
		}
	}

	@Override
	public List<CaseAssociatedDocuments> findByCaseDetails(CaseDetails caseDetails) {
		return caseAssociatedDocumentsRepository.findByCaseDetails(caseDetails);
	}

	@Override
	public CaseAssociatedDocuments saveNewRecord(CaseAssociatedDocuments caseAssociatedDocuments) {
		return caseAssociatedDocumentsRepository.save(caseAssociatedDocuments);
	}

//================================================================================================================	
//-------------------------------------Fetch Fulfillment split documents------------------------------------------
//================================================================================================================	
	@Override
	public List<CaseAssociatedDocumentsResponsePOJO> getAssociatedDocumentDetailsByCaseDetailsIdAndFulfillmentId(
			Long caseDetailsId, Long fulfillmentId) throws ServiceException {
		// ***************DE Completion and crn check******************
		checkForValidCrn(caseDetailsService.findByCaseDetailsId(caseDetailsId));
		// ************************************************************

		List<CaseAssociatedDocumentsInterface> caseAssociatedDocumentsInterfaces = caseAssociatedDocumentsRepository
				.getDocumentAssociationAndDetailsByCaseId(caseDetailsId);
		caseAssociatedDocumentsInterfaces.stream()
				.forEach(data -> logger.info("caseUploadedDocumentId : {}", data.getCaseUploadedDocumentsId()));

		List<CaseAssociatedDocumentsResponsePOJO> caseAssociatedDocumentsResponsePOJOs = mapper.convertValue(
				caseAssociatedDocumentsInterfaces, new TypeReference<List<CaseAssociatedDocumentsResponsePOJO>>() {
				});

		MiFulfilmentRequest miFulfilmentRequest = miFulfilmentRequestService.findByMiFulfilmentRequestId(fulfillmentId);
		ArrayNode deDocuments = miFulfilmentRequest.getDeDocuments();
		List<MiDocumentsPOJO> miDocumentsPOJOs = mapper.convertValue(deDocuments,
				new TypeReference<List<MiDocumentsPOJO>>() {
				});

		List<CaseAssociatedDocumentsResponsePOJO> resCseAssociatedDocumentsResponsePOJOs = new ArrayList<>();
		for (MiDocumentsPOJO miDocumentsPOJO : miDocumentsPOJOs) {
			List<CaseAssociatedDocumentsResponsePOJO> newCaseAssociatedDocumentsResponsePOJOs = caseAssociatedDocumentsResponsePOJOs
					.stream().filter(data -> {
						String miRowId = miDocumentsPOJO.getRowId() != null ? miDocumentsPOJO.getRowId() : "";
						String miParentRowId = miDocumentsPOJO.getParentRowId() != null
								? miDocumentsPOJO.getParentRowId()
								: "";
						String rowId = data.getRowId() != null ? data.getRowId() : "";
						String parentRowId = data.getParentRowId() != null ? data.getParentRowId() : "";
						return miRowId.equals(rowId) && miParentRowId.equals(parentRowId);
					}).collect(Collectors.toList());

			newCaseAssociatedDocumentsResponsePOJOs.stream().forEach(data -> {
				data.setMandatory(true);
				data.setInvalidFields(miDocumentsPOJO.getInvalidFields());
				data.setMiMessage(miFulfilmentRequest.getMiMessage());
				data.setFulfillmentId(fulfillmentId);
			});

			if (CollectionUtils.isNotEmpty(newCaseAssociatedDocumentsResponsePOJOs)) {
				resCseAssociatedDocumentsResponsePOJOs.addAll(newCaseAssociatedDocumentsResponsePOJOs);
			} else {
				DocumentMaster documentMaster = documentMasterService
						.findByDocumentName(miDocumentsPOJO.getDocumentName());
				if (documentMaster != null) {
					CaseAssociatedDocumentsResponsePOJO caseAssociatedDocumentsResponsePOJO = new CaseAssociatedDocumentsResponsePOJO();
					caseAssociatedDocumentsResponsePOJO.setCaseDetailsId(caseDetailsId);
					caseAssociatedDocumentsResponsePOJO.setDocumentMasterId(documentMaster.getDocumentMasterId());
					caseAssociatedDocumentsResponsePOJO.setDocumentName(documentMaster.getDocumentName());
					caseAssociatedDocumentsResponsePOJO.setMandatory(true);
					caseAssociatedDocumentsResponsePOJO.setParentRowId(miDocumentsPOJO.getParentRowId());
					caseAssociatedDocumentsResponsePOJO.setRowId(miDocumentsPOJO.getRowId());
					caseAssociatedDocumentsResponsePOJO.setMiMessage(miFulfilmentRequest.getMiMessage());
					caseAssociatedDocumentsResponsePOJO.setFulfillmentId(fulfillmentId);
					resCseAssociatedDocumentsResponsePOJOs.add(caseAssociatedDocumentsResponsePOJO);
				}
			}
		}
		return resCseAssociatedDocumentsResponsePOJOs;
	}
//================================================================================================================	
//-------------------------------------Fetch Fulfillment split documents------------------------------------------
//================================================================================================================

}
