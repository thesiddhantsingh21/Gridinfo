package com.fadv.cspi.entities.transaction;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;

import com.fadv.cspi.entities.master.ClientMaster;
import com.fadv.cspi.entities.master.DocumentMaster;
import com.fadv.cspi.entities.master.PackageMaster;
import com.fadv.cspi.entities.master.SbuMaster;
import com.fadv.cspi.fullfilment.entities.MiFulfilmentRequest;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.vladmihalcea.hibernate.type.json.JsonBinaryType;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
@Entity
@JsonInclude(value = Include.NON_NULL)
@TypeDef(name = "jsonb", typeClass = JsonBinaryType.class)
public class CaseDataEntry implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(nullable = false, updatable = false)
	private Long caseDataEntryId;

	@Type(type = "jsonb")
	@Column(columnDefinition = "jsonb", nullable = true)
	private ObjectNode dataEntryData;
	
	@Type(type = "jsonb")
	@Column(columnDefinition = "jsonb", nullable = true)
	private ObjectNode dataEntryError;
	
	@Type(type = "jsonb")
	@Column(columnDefinition = "jsonb", nullable = true)
	private ObjectNode dataEntryErrorHistory;

	@Column(nullable = false)
	private String rowId;

	private String parentRowId;
	
	private String instructionCheckId;

	@ManyToOne
	@JoinColumn(name = "case_details_id", nullable = false)
	private CaseDetails caseDetails;

	@OneToOne(cascade = CascadeType.ALL)
	@OnDelete(action = OnDeleteAction.CASCADE)
	@JoinColumn(name = "case_associated_documents_id")
	private CaseAssociatedDocuments caseAssociatedDocuments;

	@ManyToOne
	@JoinColumn(name = "sbu_master_id")
	private SbuMaster sbuMaster;

	@ManyToOne
	@JoinColumn(name = "client_master_id")
	private ClientMaster clientMaster;

	@ManyToOne
	@JoinColumn(name = "package_master_id")
	private PackageMaster packageMaster;

	@Column(columnDefinition = "text", nullable = true)
	private String akaName;

	@Column(columnDefinition = "text", nullable = true)
	private String agencyAkaName;

	@ManyToOne
	@JoinColumn(name = "document_master_id", nullable = false)
	private DocumentMaster documentMaster;

	private Date updatedDate = new Date();

	private Date createdDate = new Date();

	private String updatedByUser;
	
	@ManyToOne
	@JoinColumn(name = "mi_fulfilment_requestId")
	private MiFulfilmentRequest miFulfilmentRequest;
}
