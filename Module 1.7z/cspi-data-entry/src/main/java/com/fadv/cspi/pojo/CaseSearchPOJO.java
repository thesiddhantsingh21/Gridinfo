package com.fadv.cspi.pojo;

import lombok.Data;

@Data
public class CaseSearchPOJO {

	private String caseNo;
	private String crnNo;
}
