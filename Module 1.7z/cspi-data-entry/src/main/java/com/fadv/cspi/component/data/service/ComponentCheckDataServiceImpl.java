package com.fadv.cspi.component.data.service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fadv.cspi.component.data.pojo.CliSbuPkgCompProdQstnInterface;
import com.fadv.cspi.component.data.pojo.ComponentPOJO;
import com.fadv.cspi.component.data.pojo.ComponentScopingInterface;
import com.fadv.cspi.component.data.pojo.ComponentScopingPOJO;
import com.fadv.cspi.component.data.pojo.CspiCheckCreationCaseDetailsInterface;
import com.fadv.cspi.component.data.pojo.QuestionCheckDataResponsePOJO;
import com.fadv.cspi.entities.master.CaseSpecificRecordDetail;
import com.fadv.cspi.entities.transaction.ProcessTaskStages;
import com.fadv.cspi.exception.ServiceException;
import com.fadv.cspi.fullfilment.entities.MiFulfilmentRequest;
import com.fadv.cspi.fullfilment.repository.MiFulfilmentRequestRepository;
import com.fadv.cspi.repository.mapping.CliSbuPkgCompProdQstnRepository;
import com.fadv.cspi.repository.master.CaseSpecificRecordDetailRepository;
import com.fadv.cspi.repository.transaction.CaseDetailsRepository;
import com.fadv.cspi.repository.transaction.CspiCheckCreationRepository;
import com.fadv.cspi.repository.transaction.ProcessTaskStagesRepository;
import com.fadv.cspi.utility.ConversionUtility;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;


@Service
public class ComponentCheckDataServiceImpl implements ComponentCheckDataService {

	@Autowired
	CspiCheckCreationRepository cspiCheckCreationRepository;

	@Autowired
	CaseDetailsRepository caseDetailsRepository;

	@Autowired
	ProcessTaskStagesRepository processTaskStagesRepository;

	@Autowired
	CliSbuPkgCompProdQstnRepository cliSbuPkgCompProdQstnRepository;
	
	@Autowired
	CaseSpecificRecordDetailRepository caseSpecificRecordDetailRepository;
	
	@Autowired
	private MiFulfilmentRequestRepository miFulfilmentRequestRepository;

	private ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES,
			false);
	private static final Logger logger = LoggerFactory.getLogger(ComponentCheckDataServiceImpl.class);

	@Override
	public JsonNode getComponentCheckData(String cspiCheckId) throws ServiceException {

		List<ComponentScopingInterface> componentScopingList = caseDetailsRepository
				.findCaseDetailsByCspiCheckId(cspiCheckId);

		String requestStage = "scoping";

		if (CollectionUtils.isEmpty(componentScopingList)) {
			throw new ServiceException("ComponentScopingList is empty for given checkId: ", cspiCheckId);
		}
		ComponentScopingInterface componentScoping = componentScopingList.get(0);

		String caseNo = componentScoping.getCaseNo();
		String requestId = componentScoping.getRequestId();

		List<ProcessTaskStages> processTaskStages = processTaskStagesRepository.findByCaseNoAndRequestStageOrderByRequestDateDesc(caseNo, requestStage);

		if (CollectionUtils.isEmpty(processTaskStages)) {
			throw new ServiceException("ProcessTaskStages is empty for given caseNo and requestStage",
					caseNo + " : " + requestStage);
		}
		String result = processTaskStages.get(0).getResponseBody();

		try {
			ObjectNode scopingResponse = mapper.readValue(result, ObjectNode.class);
			ComponentScopingPOJO componentScopingPOJO = mapper.convertValue(
					scopingResponse.get("data").get(0).get("result").get("ComponentScoping"),
					ComponentScopingPOJO.class);
			List<ComponentPOJO> components = componentScopingPOJO.getComponents();
			List<ComponentPOJO> resultComponents = new ArrayList<>();
			for (ComponentPOJO component : components) {

				List<ObjectNode> records = component.getRecords() != null ? component.getRecords() : new ArrayList<>();
				records = records.stream().filter(data -> {
					String reqId = data.has("requestId") ? data.get("requestId").asText() : "";
					return reqId.equals(requestId);
				}).map(data -> {
					data.put("checkId", cspiCheckId);
					return data;
				}).collect(Collectors.toList());

				if (CollectionUtils.isNotEmpty(records)) {

					ComponentPOJO newComponent = new ComponentPOJO();
					newComponent.setAddOnPackages(component.getAddOnPackages());
					newComponent.setComponentName(component.getComponentName());
					newComponent.setAddOnPackage(component.isAddOnPackage());
					newComponent.setComponentNameFull(component.getComponentNameFull());
					newComponent.setDbComponent(component.isDbComponent());
					newComponent.setPackageName(component.getPackageName());
					newComponent.setProduct(component.getProduct());
					newComponent.setRecords(records);
					newComponent.setSequence(component.getSequence());
					resultComponents.add(newComponent);
				}

			}
			componentScopingPOJO.setComponents(resultComponents);
			((ObjectNode) scopingResponse.get("data").get(0).get("result")).set("ComponentScoping",
					mapper.convertValue(componentScopingPOJO, JsonNode.class));
			return scopingResponse;
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return null;
	}
	
	
	
	
	@Override
	public ObjectNode getProcessTaskStagesDataforMiVerification(String cspiCheckId) throws ServiceException {

		try {
//		List<ComponentScopingInterface> componentScopingList = caseDetailsRepository
//				.findCaseDetailsByCspiCheckId(cspiCheckId);
			
			List<CaseSpecificRecordDetail> caseSpecificRecordDetailsList= caseSpecificRecordDetailRepository.findByInstructionCheckId(cspiCheckId);
			   
			   CaseSpecificRecordDetail caseSpecificRecordDetail= new CaseSpecificRecordDetail();
			   
			   String caseNo = "";
			   if(CollectionUtils.isNotEmpty(caseSpecificRecordDetailsList)) {
				   
				   caseSpecificRecordDetail=caseSpecificRecordDetailsList.get(0);
				   
				   caseNo= caseSpecificRecordDetail.getCaseSpecificId().getCaseNumber();
			   }
			   
		String requestStage = "caseLevelMi";

//		if (CollectionUtils.isEmpty(componentScopingList)) {
//			throw new ServiceException(" checkId is empty : ", cspiCheckId);
//		}
//		ComponentScopingInterface componentScoping = componentScopingList.get(0);
//		String caseNo = componentScoping.getCaseNo();
		List<ProcessTaskStages> processTaskStages = processTaskStagesRepository.findByCaseNoAndRequestStageOrderByRequestDateDesc(caseNo, requestStage);

		if (CollectionUtils.isEmpty(processTaskStages)) {
			throw new ServiceException("ProcessTaskStages is empty for given caseNo and requestStage",
					caseNo + " : " + requestStage);
		}
		
		ProcessTaskStages processTaskStages1 = new ProcessTaskStages();
		processTaskStages1 = processTaskStages.get(0);
		 
		ObjectNode processTaskResponseNode = (ObjectNode) mapper.readTree(processTaskStages1.getResponseBody());
		return  processTaskResponseNode;

		} catch (Exception e) {
			// TODO Auto-generated catch block
			logger.error("Exception get occured while getting process_task_stages data for Mi Verification");
			e.printStackTrace();
		}

		return null;
	}
	
	
	

	@Override
	public List<QuestionCheckDataResponsePOJO> getQuestionCheckData(String cspiCheckId) throws ServiceException {
		List<CspiCheckCreationCaseDetailsInterface> cspiCheckCreationCaseDetailsInterfaces = cspiCheckCreationRepository
				.findByCheckIdAndActive(cspiCheckId, true);
		if (CollectionUtils.isEmpty(cspiCheckCreationCaseDetailsInterfaces)) {
			throw new ServiceException("cspiCheckCreations or caseDetails is empty for given checkId: ", cspiCheckId);
		}

		CspiCheckCreationCaseDetailsInterface cspiCheckCreationCaseDetailsInterface = cspiCheckCreationCaseDetailsInterfaces
				.get(0);
		Long clientMasterId = cspiCheckCreationCaseDetailsInterface.getClientMasterId();
		Long componentMasterId = cspiCheckCreationCaseDetailsInterface.getComponentMasterId();
		Long packageMasterId = cspiCheckCreationCaseDetailsInterface.getPackageMasterId();
		Long productMasterId = cspiCheckCreationCaseDetailsInterface.getProductMasterId();
		String recordNodeString = cspiCheckCreationCaseDetailsInterface.getRecordNode();
		Long sbuMasterId = cspiCheckCreationCaseDetailsInterface.getSbuMasterId();

		List<QuestionCheckDataResponsePOJO> questionCheckDataResponsePOJOs = new ArrayList<QuestionCheckDataResponsePOJO>();

		try {
			ObjectNode recordNode = mapper.readValue(recordNodeString, ObjectNode.class);
			List<String> recordNodeKeys = ConversionUtility.findKeys(recordNode);

			List<CliSbuPkgCompProdQstnInterface> cliSbuPkgCompProdQstnInterfaces = cliSbuPkgCompProdQstnRepository
					.findByClientMasterAndSbuMasterAndPackageMasterAndMappedFieldsAndActive(clientMasterId, sbuMasterId,
							packageMasterId, componentMasterId, productMasterId, recordNodeKeys, true);
			logger.info("Size : ", cliSbuPkgCompProdQstnInterfaces.size());
			if (CollectionUtils.isEmpty(cliSbuPkgCompProdQstnInterfaces)) {
				throw new ServiceException("cliSbuPkgCompProdQstnInterface is empty for given checkId: ", cspiCheckId);
			}
//			for(CliSbuPkgCompProdQstnInterface cliSbuPkgCompProdQstnInterface : cliSbuPkgCompProdQstnInterfaces) {
//				logger.info("cliSbuPkgCompProdQstnInterface : ", cliSbuPkgCompProdQstnInterface);
//			}

			for (CliSbuPkgCompProdQstnInterface cliSbuPkgCompProdQstnInterface : cliSbuPkgCompProdQstnInterfaces) {
				QuestionCheckDataResponsePOJO questionCheckDataResponsePOJO = new QuestionCheckDataResponsePOJO();
				logger.info("Question : ", cliSbuPkgCompProdQstnInterface.getQuestionName());
				String answer = recordNode.get(cliSbuPkgCompProdQstnInterface.getQuestionName()).asText();
				questionCheckDataResponsePOJO.setAnswere(answer);
				questionCheckDataResponsePOJO.setComponentName(cliSbuPkgCompProdQstnInterface.getComponentName());
				questionCheckDataResponsePOJO.setFormLabel(cliSbuPkgCompProdQstnInterface.getFormLabel());
				questionCheckDataResponsePOJO.setMandatory(cliSbuPkgCompProdQstnInterface.getMandatory());
				questionCheckDataResponsePOJO.setQlobalQuestionId(cliSbuPkgCompProdQstnInterface.getGlobalQuestionId());
//			questionCheckDataResponsePOJO.setMappedField(cliSbuPkgCompProdQstnInterface.getMappedField());
				questionCheckDataResponsePOJO.setProductName(cliSbuPkgCompProdQstnInterface.getProductName());
				questionCheckDataResponsePOJO.setQuestionName(cliSbuPkgCompProdQstnInterface.getQuestionName());
				questionCheckDataResponsePOJO.setQuestionScope(cliSbuPkgCompProdQstnInterface.getQuestionScope());
				questionCheckDataResponsePOJO.setQuestionType(cliSbuPkgCompProdQstnInterface.getQuestionType());
				questionCheckDataResponsePOJOs.add(questionCheckDataResponsePOJO);
			}

		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return questionCheckDataResponsePOJOs;
	}
	
	

}
