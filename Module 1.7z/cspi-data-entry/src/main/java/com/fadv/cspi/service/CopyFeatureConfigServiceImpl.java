package com.fadv.cspi.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fadv.cspi.entities.mapping.CopyFeatureConfig;
import com.fadv.cspi.repository.mapping.CopyFeatureConfigRepository;

@Service
public class CopyFeatureConfigServiceImpl implements CopyFeatureConfigSevice {

	@Autowired
	private CopyFeatureConfigRepository copyFeatureConfigRepository;

	@Override
	public Map<String, List<String>> getDocumentAndFiledKeyMap() {

		List<CopyFeatureConfig> copyFeatureConfigs = copyFeatureConfigRepository.findAll();
		Map<String, List<String>> docFields = new HashMap<>();

		copyFeatureConfigs.parallelStream().forEach(copyFeatureConfig -> {
			String documentName = copyFeatureConfig.getDocumentMaster().getDocumentName();
			String fieldKey = copyFeatureConfig.getDocumentFieldMaster().getDocumentFieldKey();

			List<String> fieldKeys = docFields.get(documentName);
			if (fieldKeys == null) {
				fieldKeys = new ArrayList<>();
			}
			fieldKeys.add(fieldKey);
			docFields.put(documentName, fieldKeys);
		});
		return docFields;
	}

	@Override
	public Map<String, List<String>> getDocumentAndFiledNameMap() {

		List<CopyFeatureConfig> copyFeatureConfigs = copyFeatureConfigRepository.findAll();
		Map<String, List<String>> docFields = new HashMap<>();

		copyFeatureConfigs.parallelStream().forEach(copyFeatureConfig -> {
			String documentName = copyFeatureConfig.getDocumentMaster().getDocumentName();
			String fieldName = copyFeatureConfig.getDocumentFieldMaster().getDocumentFieldName();

			List<String> fieldNames = docFields.get(documentName);
			if (fieldNames == null) {
				fieldNames = new ArrayList<>();
			}
			fieldNames.add(fieldName);
			docFields.put(documentName, fieldNames);
		});
		return docFields;
	}
}
