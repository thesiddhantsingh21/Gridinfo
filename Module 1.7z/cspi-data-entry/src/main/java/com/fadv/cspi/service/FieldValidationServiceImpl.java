package com.fadv.cspi.service;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.fadv.cspi.entities.transaction.CaseDetails;
import com.fadv.cspi.interfaces.ComponentDataEntryInterface;
import com.fadv.cspi.pojo.ValidationErrorPOJO;
import com.fadv.cspi.pojo.response.DocumentFieldMasterResponsePOJO;
import com.fadv.cspi.repository.transaction.CaseDataEntryRepository;
import com.fadv.cspi.utility.ConversionUtility;
import com.fadv.cspi.utility.ValidationUtility;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class FieldValidationServiceImpl implements FieldValidationService {

	private static final String DATE_OF_EXIT = "Date of Exit";

	private static final String DATE_OF_EXIT_TILL_DATE = "Date Of Exit (Till Date)";

	private static final String DATE_OF_JOINING = "Date of joining";

	private static final String NATIONALITY2 = "Nationality";

	private static final String PERSONAL_MOBILE_NO = "Personal Mobile No";

	private static final String YEAR_OF_PASSING = "Year of Passing";

	private static final String PROFESSIONAL_EMAIL_ID = "Professional Email ID";

	private static final String PERSONAL_EMAIL_ID = "Personal Email Id";

	private static final String PERIOD_OF_STUDY_FROM = "Period of Study (From)";

	private static final String PERIOD_OF_STAY_TO = "Period of Stay - To";

	private static final String PERIOD_OF_STAY_FROM = "Period of Stay - From";

	private static final String INVALID_DATE = "Invalid Date";

	private static final String PERIOD_OF_STUDY_TO = "Period of Study (To)";

	private static final String DOC_IDENTIFICATION_NO = "Doc Identification No";

	private static final String DATE_OF_EXPIRY = "Date of Expiry";

	private ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES,
			false);

	private static final String INVALID_DATE_IN_DATE_OF_EXPIRY = "Invalid date in Date of Expiry";
	private static final Logger logger = LoggerFactory.getLogger(FieldValidationServiceImpl.class);

	@Override
	public List<ValidationErrorPOJO> validatedFormField(
			List<DocumentFieldMasterResponsePOJO> documentFieldMasterResponsePOJOs, String documentName,
			CaseDataEntryRepository caseDataEntryRepository, String akaName, String rowId, String parentRowId,
			long caseDetailsId, CaseDetails caseDetails) throws JsonProcessingException {

		Map<String, String> fieldValueMap = documentFieldMasterResponsePOJOs.parallelStream()
				.collect(Collectors.toMap(DocumentFieldMasterResponsePOJO::getDocumentFieldName,
						DocumentFieldMasterResponsePOJO::getUpdatedDefaulValue, (field1, field2) -> {
							logger.info("Duplicate Field Name Found:{}", field1);
							return field2;
						}));

		String caseType = caseDetails.getCaseType() != null ? caseDetails.getCaseType() : "";
		String caseOrigin = caseDetails.getCaseOrigin() != null ? caseDetails.getCaseOrigin().toLowerCase() : "";

		String dateOfExit = fieldValueMap.getOrDefault(DATE_OF_EXIT, "");
		dateOfExit = dateOfExit == null || StringUtils.isEmpty(dateOfExit)
				? fieldValueMap.getOrDefault(DATE_OF_EXIT_TILL_DATE, "")
				: dateOfExit;
		String dateOfExpiry = fieldValueMap.getOrDefault(DATE_OF_EXPIRY, "");
		String dateOfJoining = fieldValueMap.getOrDefault(DATE_OF_JOINING, "");
		String docIdentificationNumber = fieldValueMap.getOrDefault(DOC_IDENTIFICATION_NO, "");
		String mobile = fieldValueMap.getOrDefault(PERSONAL_MOBILE_NO, "");
		String nationality = fieldValueMap.getOrDefault(NATIONALITY2, "");
		String periodOfStayFrom = fieldValueMap.getOrDefault(PERIOD_OF_STAY_FROM, "");
		String periodOfStayTo = fieldValueMap.getOrDefault(PERIOD_OF_STAY_TO, "");
		String periodOfStudyFrom = fieldValueMap.getOrDefault(PERIOD_OF_STUDY_FROM, "");
		String periodOfStudyTo = fieldValueMap.getOrDefault(PERIOD_OF_STUDY_TO, "");
		String personalEmailId = fieldValueMap.getOrDefault(PERSONAL_EMAIL_ID, "");
		String professionalEmailId = fieldValueMap.getOrDefault(PROFESSIONAL_EMAIL_ID, "");
		String yearOfPassing = fieldValueMap.getOrDefault(YEAR_OF_PASSING, "");

		List<ValidationErrorPOJO> validationErrorPOJOs = new ArrayList<>();

		if (StringUtils.isNotEmpty(periodOfStayFrom) && StringUtils.isNotEmpty(periodOfStayTo)) {
			Date periodOfStayFromDate = ValidationUtility.checkAndParseValidDate(periodOfStayFrom);
			Date periodOfStayToDate = ValidationUtility.checkAndParseValidDate(periodOfStayTo);

			if (periodOfStayFromDate == null) {
				validationErrorPOJOs.add(new ValidationErrorPOJO(PERIOD_OF_STAY_FROM, INVALID_DATE));
			}

			if (periodOfStayToDate == null) {
				validationErrorPOJOs.add(new ValidationErrorPOJO(PERIOD_OF_STAY_TO, INVALID_DATE));
			}

			if (periodOfStayFromDate != null && periodOfStayToDate != null
					&& periodOfStayFromDate.after(periodOfStayToDate)) {
				validationErrorPOJOs.add(new ValidationErrorPOJO("Period of Stay - From & Period of Stay - To",
						"Period of Stay - From can not be Greater than Period of Stay - To"));
			}
		}

		if (StringUtils.isNotEmpty(periodOfStudyTo) && StringUtils.isNotEmpty(yearOfPassing)) {
			Integer yearOfPassingDate = ValidationUtility.converYearToDate(yearOfPassing);
			Date periodOfStudyToDate = ValidationUtility.checkAndParseValidDate(periodOfStudyTo);

			if (yearOfPassingDate == null) {
				validationErrorPOJOs.add(new ValidationErrorPOJO(YEAR_OF_PASSING, "Invalid Year"));
			}

			if (periodOfStudyToDate == null) {
				validationErrorPOJOs.add(new ValidationErrorPOJO(PERIOD_OF_STUDY_TO, INVALID_DATE));
			}

			if ((yearOfPassingDate != null && periodOfStudyToDate != null)) {
				Calendar calendar = new GregorianCalendar();
				calendar.setTime(periodOfStudyToDate);
				int year = calendar.get(Calendar.YEAR);
				if (year > yearOfPassingDate) {
					validationErrorPOJOs.add(new ValidationErrorPOJO("Year of Passing & Period of Study (To)",
							"Year of Passing can not be Less than Period of Study (To)"));
				}
			}
		}

		if (StringUtils.isNotEmpty(periodOfStudyTo) && StringUtils.isNotEmpty(periodOfStudyFrom)) {
			Date periodOfStudyFromDate = ValidationUtility.checkAndParseValidDate(periodOfStudyFrom);
			Date periodOfStudyToDate = ValidationUtility.checkAndParseValidDate(periodOfStudyTo);

			if (periodOfStudyFromDate == null) {
				validationErrorPOJOs.add(new ValidationErrorPOJO(PERIOD_OF_STUDY_FROM, INVALID_DATE));
			}

			if (periodOfStudyToDate == null) {
				validationErrorPOJOs.add(new ValidationErrorPOJO(PERIOD_OF_STUDY_TO, INVALID_DATE));
			}

			if (periodOfStudyFromDate != null && periodOfStudyToDate != null
					&& periodOfStudyFromDate.after(periodOfStudyToDate)) {
				validationErrorPOJOs.add(new ValidationErrorPOJO("Period of Study (From) & Period of Study (To)",
						"Period of Study (From) can not be Greater than Period of Study (To)"));
			}
		}

		if (StringUtils.isNotEmpty(dateOfJoining) && StringUtils.isNotEmpty(dateOfExit)) {
			Date dateOfJoiningDate = ValidationUtility.checkAndParseValidDate(dateOfJoining);
			Date dateOfExitDate = ValidationUtility.checkAndParseValidDate(dateOfExit);

			if (dateOfJoiningDate == null) {
				validationErrorPOJOs.add(new ValidationErrorPOJO(DATE_OF_JOINING, INVALID_DATE));
			}

			if (dateOfExitDate == null) {
				validationErrorPOJOs.add(new ValidationErrorPOJO(DATE_OF_EXIT, INVALID_DATE));
			}

			if (dateOfJoiningDate != null && dateOfExitDate != null
					&& !(dateOfExitDate.after(dateOfJoiningDate) || dateOfExitDate.equals(dateOfJoiningDate))) {
				validationErrorPOJOs.add(new ValidationErrorPOJO("Date of Exit & Date of Joining",
						"Date of Exit can not be Greater than Date of Joining"));
			}

			if (StringUtils.isNotEmpty(akaName)) {
				List<String> rowIds = new ArrayList<>();
				List<String> parentRowIds = new ArrayList<>();
				rowIds.add(rowId);
				parentRowIds.add(rowId);
				if (StringUtils.isNotEmpty(parentRowId)) {
					rowIds.add(parentRowId);
					parentRowIds.add(parentRowId);
				}
				List<ComponentDataEntryInterface> componentDataEntryInterfaces = caseDataEntryRepository
						.getDataEntryGroupByComponentNameAndRowIdAndCaseDetailsId(rowIds, parentRowIds, caseDetailsId);

				for (ComponentDataEntryInterface componentDataEntryInterface : componentDataEntryInterfaces) {
					String akaNameNew = componentDataEntryInterface.getAkaName();
					String documentData = componentDataEntryInterface.getDocumentData();
					JsonNode documentNode = mapper.readTree(documentData);
					List<String> documentKeys = ConversionUtility.findKeys(documentNode);
					String dateOfJoiningSaved = "";
					String dateOfExitSaved = "";

					for (String documentKey : documentKeys) {
						JsonNode docNode = documentNode.get(documentKey);

						if (dateOfJoiningSaved == null || StringUtils.isEmpty(dateOfJoiningSaved)) {
							dateOfJoiningSaved = docNode.has("dateofjoining") ? docNode.get("dateofjoining").asText()
									: "";
						}
						if (dateOfExitSaved == null || StringUtils.isEmpty(dateOfExitSaved)) {
							dateOfExitSaved = docNode.has("dateofexit") ? docNode.get("dateofexit").asText() : "";
							if (dateOfExitSaved == null || StringUtils.isEmpty(dateOfExitSaved)) {
								dateOfExitSaved = docNode.has("dateofexittilldate")
										? docNode.get("dateofexittilldate").asText()
										: "";
							}
						}
					}
					Date dateOfJoiningSavedDate = ValidationUtility.checkAndParseValidDate(dateOfJoiningSaved);
					Date dateOfExitSavedDate = ValidationUtility.checkAndParseValidDate(dateOfExitSaved);

					boolean isDojSkippend = false;
					if (StringUtils.isNotEmpty(caseType) && StringUtils.isNotEmpty(caseOrigin)
							&& (caseType.equalsIgnoreCase("CDE") || caseOrigin.contains("touchless"))) {

						if (akaName.equalsIgnoreCase(akaNameNew) && dateOfJoiningDate.equals(dateOfJoiningSavedDate)
								&& dateOfExitDate.equals(dateOfExitSavedDate)) {
							isDojSkippend = true;
						}
					}

					if (!isDojSkippend && dateOfJoiningSavedDate != null && dateOfExitSavedDate != null
							&& dateOfJoiningDate != null && dateOfExitDate != null
							&& (ValidationUtility.checkDateOverLap(dateOfJoiningSavedDate, dateOfExitSavedDate,
									dateOfJoiningDate, dateOfExitDate))) {
						validationErrorPOJOs.add(new ValidationErrorPOJO("Date of Exit & Date of Joining",
								"POE overlapping with another Employment"));
						break;
					}
				}
			}
		}

		// Driving License
		if (StringUtils.equalsIgnoreCase("Driving License (As per Document)", documentName)
				&& StringUtils.isNotEmpty(dateOfExpiry)) {

			Date dateOfExpiryDate = ValidationUtility.checkAndParseValidDate(dateOfExpiry);
			Date todaysDate = new Date();
			if (dateOfExpiryDate == null) {
				validationErrorPOJOs.add(new ValidationErrorPOJO(DATE_OF_EXPIRY, INVALID_DATE_IN_DATE_OF_EXPIRY));
			}

			if (dateOfExpiryDate != null
					&& !(dateOfExpiryDate.after(todaysDate) || dateOfExpiryDate.equals(todaysDate))) {
				validationErrorPOJOs.add(new ValidationErrorPOJO(DATE_OF_EXPIRY, "Driving License is Expired"));
			}
		}

		// Passport Expired
		if (StringUtils.equalsIgnoreCase("Passport (As per Document)", documentName)) {

			Date dateOfExpiryDate = ValidationUtility.checkAndParseValidDate(dateOfExpiry);
			Date todaysDate = new Date();
			if (dateOfExpiryDate == null) {
				validationErrorPOJOs.add(new ValidationErrorPOJO(DATE_OF_EXPIRY, INVALID_DATE_IN_DATE_OF_EXPIRY));
			}

			if (dateOfExpiryDate != null
					&& !(dateOfExpiryDate.after(todaysDate) || dateOfExpiryDate.equals(todaysDate))) {
				validationErrorPOJOs.add(new ValidationErrorPOJO(DATE_OF_EXPIRY, "Passport is Expired"));
			}

			// Passport Number
			if (!(ValidationUtility.isPassportNoValid(docIdentificationNumber))) {
				validationErrorPOJOs.add(new ValidationErrorPOJO(DOC_IDENTIFICATION_NO, "Incorrect Passport number"));
			}
		}

		if (StringUtils.equalsIgnoreCase("All Identity", documentName) && StringUtils.isNotEmpty(dateOfExpiry)) {

			Date dateOfExpiryDate = ValidationUtility.checkAndParseValidDate(dateOfExpiry);
			Date todaysDate = new Date();
			if (dateOfExpiryDate == null) {
				validationErrorPOJOs.add(new ValidationErrorPOJO(DATE_OF_EXPIRY, INVALID_DATE_IN_DATE_OF_EXPIRY));
			}

			if (dateOfExpiryDate != null
					&& !(dateOfExpiryDate.after(todaysDate) || dateOfExpiryDate.equals(todaysDate))) {
				validationErrorPOJOs.add(new ValidationErrorPOJO(DATE_OF_EXPIRY,
						"Passport and DL expiry date should not be less than today. This shall be then considered as expired passport"));
			}
		}

		if (StringUtils.isNotEmpty(personalEmailId) && !ValidationUtility.isValidEmail(personalEmailId)) {
			validationErrorPOJOs.add(new ValidationErrorPOJO(PERSONAL_EMAIL_ID, "Invalid email address"));
		}

		if (StringUtils.isNotEmpty(professionalEmailId) && !ValidationUtility.isValidEmail(professionalEmailId)) {
			validationErrorPOJOs.add(new ValidationErrorPOJO(PROFESSIONAL_EMAIL_ID, "Invalid email address"));
		}

		if (StringUtils.isNotEmpty(mobile) && StringUtils.isNotEmpty(nationality)
				&& !(ValidationUtility.isMobileNoValid(mobile, nationality))) {
			validationErrorPOJOs.add(new ValidationErrorPOJO(PERSONAL_MOBILE_NO, "Mobile number should be 10 digit"));
		}

		// Voter ID Card
		if (StringUtils.equalsIgnoreCase("Voter ID (As per Document)", documentName)
				&& StringUtils.isNotEmpty(docIdentificationNumber)
				&& !(ValidationUtility.isVoterIdValid(docIdentificationNumber))) {
			validationErrorPOJOs.add(new ValidationErrorPOJO(DOC_IDENTIFICATION_NO, "Incorrect Voter ID number"));
		}
		// Pan Card (As per Document)
		if (StringUtils.equalsIgnoreCase("Pan Card (As per Document)", documentName)
				&& StringUtils.isNotEmpty(docIdentificationNumber)
				&& !(ValidationUtility.isPanNoValid(docIdentificationNumber))) {
			validationErrorPOJOs.add(new ValidationErrorPOJO(DOC_IDENTIFICATION_NO, "Incorrect Pan Card number"));
		}
		return validationErrorPOJOs;
	}

}
