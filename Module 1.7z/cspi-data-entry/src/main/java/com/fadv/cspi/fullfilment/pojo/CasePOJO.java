package com.fadv.cspi.fullfilment.pojo;

import com.fasterxml.jackson.databind.JsonNode;

import lombok.Data;

@Data
public class CasePOJO {

	private long miFulfilmentRequestId;

	private String crn;

	private String status;

	private JsonNode caseMoreInfo;

	private CaseReferencePOJO caseReference;

	private CaseDetailsDocValPOJO caseDetails;

	private JsonNode clientSpecificFields;

	private String miRemarks;

	private String remarks;

}
