package com.fadv.cspi.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fadv.cspi.entities.mapping.CliSbuPkgCompProd;
import com.fadv.cspi.entities.master.ClientMaster;
import com.fadv.cspi.entities.master.PackageMaster;
import com.fadv.cspi.entities.master.SbuMaster;
import com.fadv.cspi.exception.ServiceException;
import com.fadv.cspi.repository.mapping.CliSbuPkgCompProdRepository;

@Service
public class CliSbuPkgCompProdServiceImpl implements CliSbuPkgCompProdService {

	@Autowired
	private CliSbuPkgCompProdRepository cliSbuPkgCompProdRepository;

	@Autowired
	private PackageMasterService packageMasterService;

	@Autowired
	private ClientMasterService clientMasterService;

	@Autowired
	private SbuMasterService sbuMasterService;

	@Override
	public List<CliSbuPkgCompProd> findByClientNameAndSbuNameAndPackageMasterId(String clientName, String sbuName,
			Long packageMasterId) throws ServiceException {
		PackageMaster packageMaster = packageMasterService.findByPackageMasterId(packageMasterId);
		ClientMaster clientMaster = clientMasterService.findByClientName(clientName);
		SbuMaster sbuMaster = sbuMasterService.findBySbuName(sbuName);

		return cliSbuPkgCompProdRepository.findByClientMasterAndSbuMasterAndPackageMasterAndActive(clientMaster,
				sbuMaster, packageMaster, true);
	}
}
