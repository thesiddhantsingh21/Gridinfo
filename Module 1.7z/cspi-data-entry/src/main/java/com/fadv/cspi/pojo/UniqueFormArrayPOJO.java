package com.fadv.cspi.pojo;

import com.fasterxml.jackson.databind.node.ArrayNode;

import lombok.Data;

@Data
public class UniqueFormArrayPOJO {

	private String uiControlName;
	private String documentFieldName;
	private String documentFieldKey;
	private Integer sequenceId = 1;
	private String defaultValue;
	private Boolean isMandatory = false;
	private Boolean showInGrid = true;
	private ArrayNode possibleValues;
}
