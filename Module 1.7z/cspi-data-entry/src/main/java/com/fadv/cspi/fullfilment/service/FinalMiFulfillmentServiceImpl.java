package com.fadv.cspi.fullfilment.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.fadv.cspi.entities.transaction.CaseDataEntry;
import com.fadv.cspi.entities.transaction.CaseDetails;
import com.fadv.cspi.exception.ServiceException;
import com.fadv.cspi.fullfilment.entities.MiFulfilmentRequest;
import com.fadv.cspi.fullfilment.pojo.MiRemarksPOJO;
import com.fadv.cspi.fullfilment.repository.MiFulfilmentRequestRepository;
import com.fadv.cspi.interfaces.ComponentAkaNameInterface;
import com.fadv.cspi.repository.transaction.CaseDataEntryRepository;
import com.fadv.cspi.service.ApiService;
import com.fadv.cspi.service.CaseDetailsService;
import com.fadv.cspi.service.remote.RemoteDataService;
import com.fadv.cspi.userdetail.pojo.UserDetailPOJO;
import com.fadv.cspi.utility.ConversionUtility;
import com.fadv.cspi.workflow.pojo.ActivityWorkerTransaction;
import com.fadv.cspi.workflow.pojo.TaskList;
import com.fadv.cspi.workflow.pojo.WorkflowDetailsTransaction;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

@Service
public class FinalMiFulfillmentServiceImpl implements FinalMiFulfillmentService {

	private static final String UNABLE_TO_CONNECT_TO_WORKFLOW_API = "Unable to connect to workflow API";

	private static final String ERROR_CODE_404 = "ERROR_CODE_404";

	private static final String ERROR_CODE_400 = "ERROR_CODE_400";

	private static final Logger logger = LoggerFactory.getLogger(FinalMiFulfillmentServiceImpl.class);

	@Autowired
	private CaseDetailsService caseDetailsService;

	@Autowired
	private CaseDataEntryRepository caseDataEntryRepository;

	@Autowired
	private RemoteDataService remoteDataService;

	@Autowired
	private ApiService apiService;

	@Autowired
	private MiFulfilmentRequestService miFulfilmentRequestService;

	@Autowired
	private MiFulfilmentRequestRepository miFulfilmentRequestRepository;

	private ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES,
			false);

	@Value("${find.metadata.url}")
	private String findMetadataURL;

	@Value("${previous.worker.for.mi.release}")
	private String previousWorker;

	@Value("${activity.worker.name}")
	private String currentActivityWorkerName;

	@Value("${activity.worker.description}")
	private String activityWorkerDescription;

	@Value("${workflow.activity.worker.url}")
	private String searchActivityWorkerURL;

	@Value("${workflow.taskList.url}")
	private String taskListURL;

	@Value("${workflow.details.transaction.url}")
	private String workflowDetailsTransactionURL;

	@Value("${activity.worker.transaction.url}")
	private String activityWorkerTransactionURL;

	@Override
	public String finalMiFulfillment(long caseDetailsId, boolean validate, long fulfillmentId,
			MiRemarksPOJO miRemarksPOJO, UserDetailPOJO userDetailPOJO, String tokenId) throws ServiceException {

		String miRemarks = miRemarksPOJO.getRemarks() != null ? miRemarksPOJO.getRemarks() : "";
		if (StringUtils.isEmpty(miRemarks)) {
			throw new ServiceException("MI Remarks cannot be left blank", ERROR_CODE_400);
		}

		CaseDetails caseDetails = caseDetailsService.findByCaseDetailsId(caseDetailsId);

		// ***************DE Completion and crn check******************
		checkForValidCrn(caseDetails);

		MiFulfilmentRequest miFulfilmentRequest = miFulfilmentRequestService.findByMiFulfilmentRequestId(fulfillmentId);
		checkForDeCompletion(caseDetails, miFulfilmentRequest);

		String operation = "EDIT";
		JsonNode previousJson = mapper.convertValue(miFulfilmentRequest, JsonNode.class);

		// ************************************************************

		// ***************DE Validation Check**************************
		if (validate) {
			validateDataEntry(caseDetailsId, fulfillmentId);
		}

		String caseNo = caseDetails.getCaseNo();
		String checkId = miFulfilmentRequest.getCheckId();
		if(StringUtils.isEmpty(checkId)) {
			createTaskInWorkFlow(caseNo);
		}
		miFulfilmentRequest.setRemarks(miRemarks);
		miFulfilmentRequest.setFulfilled(true);
		miFulfilmentRequest.setCompletedDate(new Date());
		miFulfilmentRequestRepository.save(miFulfilmentRequest);

		JsonNode newJson = mapper.convertValue(miFulfilmentRequest, JsonNode.class);
		logger.info("mi_fulfilment_request -NEW- EDIT - Json: {}", newJson);
		apiService.addAuditLog("mi_fulfilment_request", previousJson, newJson, userDetailPOJO, operation, tokenId);
		
		return "Final Mi Fulfillment submit successful";
		
	}

	private void createTaskInWorkFlow(String caseNo) throws ServiceException {

		ObjectNode searchPreviousActivityWorkerId = mapper.createObjectNode();
		searchPreviousActivityWorkerId.put("activityWorkerName", previousWorker);
		String activityWorkerSearchResp = apiService.sendDataToPost(searchActivityWorkerURL,
				searchPreviousActivityWorkerId.toString());

		JsonNode activityWorkerSearchRespJson = ConversionUtility.convertStringToJsonNode(activityWorkerSearchResp);
		String activityTypeId = activityWorkerSearchRespJson.get(0).get("activityWorkerId").asText();

		String findMetadataNewURL = findMetadataURL.replace("{caseNo}", caseNo).replace("{activityTypeId}",
				activityTypeId);
		ObjectNode requestBody = mapper.createObjectNode();
		requestBody.put("caseNo", caseNo);

		String metaDataResponseStr = apiService.sendDataToGet(findMetadataNewURL);

		if (metaDataResponseStr == null) {
			throw new ServiceException("Unable to connect to workflow API to fetch metadata");
		}

		logger.info("Got response from the find-metadata api: {}", metaDataResponseStr);

		JsonNode metadataResponseNode = ConversionUtility.convertStringToJsonNode(metaDataResponseStr);
		boolean isSuccess = metadataResponseNode.has("success") && metadataResponseNode.get("success").asBoolean();

		if (!isSuccess) {
			String successMsg = metadataResponseNode.has("successMsg") ? metadataResponseNode.get("successMsg").asText()
					: "";
			throw new ServiceException(successMsg);
		}

		JsonNode metadataNode = metadataResponseNode.has("response") ? metadataResponseNode.get("response")
				: mapper.createObjectNode();

		sendDataToWorkflowToCreateNewTask(metadataNode);

	}

	private void sendDataToWorkflowToCreateNewTask(JsonNode metadata) throws ServiceException {
		((ObjectNode) metadata).put("status", "completed");
		ObjectNode searchActivityWorkerId = mapper.createObjectNode();
		searchActivityWorkerId.put("activityWorkerName", currentActivityWorkerName);
		String activityWorkerSearchResp = apiService.sendDataToPost(searchActivityWorkerURL,
				searchActivityWorkerId.toString());

		if (activityWorkerSearchResp == null) {
			throw new ServiceException(UNABLE_TO_CONNECT_TO_WORKFLOW_API);
		}

		JsonNode activityWorkerSearchRespJson = ConversionUtility.convertStringToJsonNode(activityWorkerSearchResp);
		if (activityWorkerSearchRespJson.isEmpty()) {
			throw new ServiceException(String.format("%s not found in workflow DB", currentActivityWorkerName));
		}

		String activityWorkerId = activityWorkerSearchRespJson.get(0).get("activityWorkerId").asText();

		ObjectNode taskListRequestJson = mapper.createObjectNode();
		taskListRequestJson.put("success", true);
		taskListRequestJson.put("successMsg", "Mi fullfilled successfully");

		TaskList taskList = new TaskList();

		taskList.setActivityTypeId(Long.parseLong(activityWorkerId));
		taskList.setRequestJson(taskListRequestJson);
		taskList.setStatus("completed");
		taskList.setTaskListDescription(activityWorkerDescription);
		taskList.setTaskListName(currentActivityWorkerName);

		String taskListResponse = "";
		try {
			taskListResponse = apiService.sendDataToPost(taskListURL, mapper.writeValueAsString(taskList));
		} catch (JsonProcessingException e2) {
			e2.printStackTrace();
		}

		if (taskListResponse == null) {
			throw new ServiceException(UNABLE_TO_CONNECT_TO_WORKFLOW_API);
		}
		logger.info("task list response : {}", taskListResponse);

		TaskList taskListPOJOResp = new TaskList();
		try {
			taskListPOJOResp = mapper.readValue(taskListResponse, TaskList.class);
		} catch (JsonProcessingException e2) {
			e2.printStackTrace();
		}

		/*---------------------WorkFlow Transaction---------------*/
		WorkflowDetailsTransaction workflowDetailsTransaction = new WorkflowDetailsTransaction();
		workflowDetailsTransaction.setTaskListId(taskListPOJOResp.getTaskListId());
		workflowDetailsTransaction.setActivityTypeId(taskListPOJOResp.getActivityTypeId());
		workflowDetailsTransaction.setRequestJson(taskListPOJOResp.getRequestJson());
		workflowDetailsTransaction.setRequestTimestamp(new Date());
		workflowDetailsTransaction.setMetaData(metadata);
		workflowDetailsTransaction.setStatus("completed");
		workflowDetailsTransaction.setResponseJson(taskListPOJOResp.getRequestJson());

		String workflowDetailsTransactionStr = "";
		try {
			workflowDetailsTransactionStr = mapper.writeValueAsString(workflowDetailsTransaction);
		} catch (JsonProcessingException e1) {
			e1.printStackTrace();
		}

		String workflowDetailsTransactionRespose = apiService.sendDataToPost(workflowDetailsTransactionURL,
				workflowDetailsTransactionStr);

		if (workflowDetailsTransactionRespose == null) {
			throw new ServiceException(UNABLE_TO_CONNECT_TO_WORKFLOW_API);
		}

		logger.info("Workflow details transaction response: {} ", workflowDetailsTransactionRespose);

		JsonNode workflowDetailsTransactionPOJOResp = null;
		try {
			workflowDetailsTransactionPOJOResp = mapper.readValue(workflowDetailsTransactionRespose, JsonNode.class);
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("Exception:{}", e.getMessage());
		}
		if (workflowDetailsTransactionPOJOResp != null) {
			ActivityWorkerTransaction activityWorkerTransaction = new ActivityWorkerTransaction();
			activityWorkerTransaction.setKey(workflowDetailsTransactionPOJOResp.get("wdTransactionId").asText() + "#"
					+ workflowDetailsTransactionPOJOResp.get("taskListId").asText() + "#"
					+ workflowDetailsTransactionPOJOResp.get("activityTypeId").asText());
			activityWorkerTransaction.setActivityWorkerId(Long.parseLong(activityWorkerId));

			activityWorkerTransaction.setStatus("completed");

			String activityWorkerReq = null;
			try {
				activityWorkerReq = mapper.writeValueAsString(activityWorkerTransaction);
			} catch (Exception e) {
				e.printStackTrace();
				logger.info("Exception:{}", e.getMessage());
			}

			String activityWorkerTransactionResponse = apiService.sendDataToPost(activityWorkerTransactionURL,
					activityWorkerReq);

			logger.info("Activity worker transaction Response: {} ", activityWorkerTransactionResponse);
		} else {
			logger.info("workflowDetailsTransactionPOJOResp is null");
		}
	}

	private void validateDataEntry(long caseDetailsId, long fulfillmentId) throws ServiceException {
		List<ComponentAkaNameInterface> componentAkaNameInterfaces = caseDataEntryRepository
				.getAllAkaNameWithComponentByCaseDetailsIdAndFulfillmentId(caseDetailsId, fulfillmentId);

		List<String> errors = new ArrayList<>();
		for (ComponentAkaNameInterface componentAkaNameInterface : componentAkaNameInterfaces) {
			String akaName = componentAkaNameInterface.getAkaName();

			ObjectNode mrlNode = mapper.createObjectNode();
			mrlNode.put("akaName", akaName);
			mrlNode.put("componentName", componentAkaNameInterface.getComponentName());

			try {
				List<String> documentNameList = remoteDataService.getMrlDocs(mrlNode);
				List<String> errDocList = new ArrayList<>();
				for (String documentName : documentNameList) {
					List<CaseDataEntry> caseDataEntries = caseDataEntryRepository
							.getByCaseDetailsIdAndDocumentNameAndAkaName(caseDetailsId, documentName, akaName);
					if (CollectionUtils.isEmpty(caseDataEntries)) {
						errDocList.add(documentName);
					}
				}
				if (CollectionUtils.isNotEmpty(errDocList)) {
					String docList = String.join(", ", errDocList);
					String errorMsg = "You have not associated " + docList + " for " + akaName
							+ " which is a mandatory requirement. Do you want to proceed?";
					errors.add(errorMsg);
				}
			} catch (ServiceException e) {
				logger.info("{} {}", e.getMessageId(), e.getMessage());
			}
		}

		if (CollectionUtils.isNotEmpty(errors)) {
			logger.info("Final data entry errors : {}", errors);
			throw new ServiceException("Validation Error occurred", ERROR_CODE_400, errors);
		}
	}

	private void checkForValidCrn(CaseDetails caseDetails) throws ServiceException {

		String crNo = caseDetails.getCrn();

		if (crNo == null || StringUtils.isEmpty(crNo) || StringUtils.equalsIgnoreCase(crNo, "pending")) {
			throw new ServiceException("Invalid CRN", ERROR_CODE_404);
		}
	}

	private void checkForDeCompletion(CaseDetails caseDetails, MiFulfilmentRequest miFulfilmentRequest)
			throws ServiceException {

		if (caseDetails.getDeComplete() != null && caseDetails.getDeComplete()) {

			if (miFulfilmentRequest != null) {
				boolean fulfilled = miFulfilmentRequest.getFulfilled() != null && miFulfilmentRequest.getFulfilled();

				if (fulfilled) {
					throw new ServiceException("MI Fulfillment already done", ERROR_CODE_404);
				}
			} else {
				throw new ServiceException("DE Already done", ERROR_CODE_404);
			}
		}
	}
}
