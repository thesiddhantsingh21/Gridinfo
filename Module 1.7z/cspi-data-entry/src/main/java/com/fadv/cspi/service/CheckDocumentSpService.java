package com.fadv.cspi.service;

import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.JsonNode;

@Service
public interface CheckDocumentSpService {

	JsonNode checkDocument(String request);

}
