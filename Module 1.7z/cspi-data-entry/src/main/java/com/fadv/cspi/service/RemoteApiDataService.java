package com.fadv.cspi.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.fadv.cspi.exception.ServiceException;
import com.fadv.cspi.pojo.RemoteApiPOJO;
import com.fasterxml.jackson.databind.node.ObjectNode;

@Service
public interface RemoteApiDataService {

	List<ObjectNode> getRemoteApiData(RemoteApiPOJO remoteApiPOJO) throws ServiceException;

}
