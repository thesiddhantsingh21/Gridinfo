package com.fadv.cspi.pojo;

import java.util.List;
import java.util.Map;

import lombok.Data;

@Data
public class ConversionResponsePOJO {

	private Map<String, String> errorMap;

	private List<FileInfoPOJO> originalFiles;

	private List<FileInfoPOJO> convertedFiles;
}
