package com.fadv.cspi.pojo;

import java.util.List;

import javax.validation.constraints.NotEmpty;

import lombok.Data;

@Data
public class AutoDataEntryPOJO {

	private String caseNo;

	@NotEmpty
	private List<AutoDataEntryDataPOJO> documents;

	private String requestSource;
	
	private String clientName;
	private String sbuName;
	private String packageName;
}
