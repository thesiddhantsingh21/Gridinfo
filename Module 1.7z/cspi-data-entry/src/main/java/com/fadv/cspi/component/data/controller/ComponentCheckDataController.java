package com.fadv.cspi.component.data.controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fadv.cspi.component.data.pojo.CheckIdRequestPOJO;
import com.fadv.cspi.component.data.service.ComponentCheckDataService;
import com.fadv.cspi.entities.transaction.CaseDataEntry;
import com.fadv.cspi.fullfilment.repository.MiFulfilmentRequestRepository;
import com.fadv.cspi.pojo.response.ResponseStatusPOJO;
import com.fadv.cspi.repository.transaction.CaseDataEntryRepository;
import com.fadv.cspi.repository.transaction.CaseDetailsRepository;

import io.swagger.annotations.ApiOperation;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/india/")
public class ComponentCheckDataController {

	private static final String SUCCESS_CODE_200 = "SUCCESS_CODE_200";

	@Autowired
	ComponentCheckDataService componentCheckDataService;
	
	@Autowired
	private CaseDataEntryRepository caseDataEntryRepository;
	
	@Autowired
	private CaseDetailsRepository caseDetailsRepository;
	
	

	@ApiOperation(value = "This API is used for fetching all associated document details related to given case id", response = ResponseStatusPOJO.class)
	@GetMapping(path = "fetch-component-check-data/{checkId}", produces = "application/json")
	public ResponseEntity<ResponseStatusPOJO> fetchComponentCheckData(@PathVariable(value = "checkId") String checkId) {
		try {
			return new ResponseEntity<>(new ResponseStatusPOJO(true, "Record retrieved successfully", SUCCESS_CODE_200,
					componentCheckDataService.getComponentCheckData(checkId)), HttpStatus.OK);
		} catch (Exception e2) {
			e2.printStackTrace();
			return new ResponseEntity<>(new ResponseStatusPOJO(false, e2.getMessage()), HttpStatus.OK);
		}
	}
	
	
	@ApiOperation(value = "This API is used  to fetch data from process_task_stages data for MI verification ", response = ResponseStatusPOJO.class)
	@GetMapping(path = "fetch-mi-check-data/{checkId}", produces = "application/json")
	public ResponseEntity<ResponseStatusPOJO> fetchProcessTaskStagesDataByCheckId(@PathVariable(value = "checkId") String checkId) {
		try {
			return new ResponseEntity<>(new ResponseStatusPOJO(true, "Record retrieved successfully", SUCCESS_CODE_200,
					componentCheckDataService.getProcessTaskStagesDataforMiVerification(checkId)), HttpStatus.OK);
		} catch (Exception e2) {
			e2.printStackTrace();
			return new ResponseEntity<>(new ResponseStatusPOJO(false, e2.getMessage()), HttpStatus.OK);
		}
	}
	
	

	@ApiOperation(value = "This API is used for fetching all associated document details related to given case id", response = ResponseStatusPOJO.class)
	@GetMapping(path = "fetch-question-check-data/{checkId}", produces = "application/json")
	public ResponseEntity<ResponseStatusPOJO> fetchQuestionCheckData(@PathVariable(value = "checkId") String checkId) {
		try {
			return new ResponseEntity<>(new ResponseStatusPOJO(true, "Record retrieved successfully", SUCCESS_CODE_200,
					componentCheckDataService.getQuestionCheckData(checkId)), HttpStatus.OK);
		} catch (Exception e2) {
			e2.printStackTrace();
			return new ResponseEntity<>(new ResponseStatusPOJO(false, e2.getMessage()), HttpStatus.OK);
		}
	}
	
	@ApiOperation(value = "This API is used for fetching all data entry related to given case id", response = ResponseStatusPOJO.class)
	@GetMapping(path = "get-data-entry/{caseDetailsId}", produces = "application/json")
	public ResponseEntity<ResponseStatusPOJO> getDataEntryByCaseDetailsId(@PathVariable(value = "caseDetailsId") Long caseDetailsId) {
		try {
			List<CaseDataEntry> deData= caseDataEntryRepository.getDataEntryByCaseDetailsId(caseDetailsId);
			return new ResponseEntity<>(new ResponseStatusPOJO(true, "Record retrieved successfully", SUCCESS_CODE_200,
					deData), HttpStatus.OK);
		} catch (Exception e2) {
			e2.printStackTrace();
			return new ResponseEntity<>(new ResponseStatusPOJO(false, e2.getMessage()), HttpStatus.OK);
		}
	}
	
	@ApiOperation(value = "This API is used for fetching all data entry related to given case id", response = ResponseStatusPOJO.class)
	@PostMapping(path = "get-check-data", produces = "application/json")
	public ResponseEntity<ResponseStatusPOJO> getCheckData(@RequestBody CheckIdRequestPOJO checkIdRequestPOJO) {
		try {
			
			Date toDate = checkIdRequestPOJO.getToDate() != null ? checkIdRequestPOJO.getToDate()
					: new Date();
			Date fromDate = checkIdRequestPOJO.getFromDate() != null ? checkIdRequestPOJO.getFromDate()
					: new Date();

			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
			String startDateStr = simpleDateFormat.format(fromDate);
			String endDateStr = simpleDateFormat.format(toDate);

			if (checkIdRequestPOJO.getToDate() == null && checkIdRequestPOJO.getFromDate() == null) {
				startDateStr = "";
				endDateStr = "";
			}
			
			return new ResponseEntity<>(new ResponseStatusPOJO(true, "Record retrieved successfully", SUCCESS_CODE_200,
					caseDetailsRepository.findCheckDetails(startDateStr,endDateStr)), HttpStatus.OK);
		} catch (Exception e2) {
			e2.printStackTrace();
			return new ResponseEntity<>(new ResponseStatusPOJO(false, e2.getMessage()), HttpStatus.OK);
		}
	}

}
