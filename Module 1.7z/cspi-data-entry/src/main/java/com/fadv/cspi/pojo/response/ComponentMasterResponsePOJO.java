package com.fadv.cspi.pojo.response;

import lombok.Data;

@Data
public class ComponentMasterResponsePOJO {

	private long componentMasterId;
	private String componentName;
}
