package com.fadv.cspi.pojo.request;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Positive;

import lombok.Data;

@Data
public class FecthAssociateDocsPOJO {

	@Positive
	private Long caseId;

	@NotEmpty
	private String parentRowId;

	@NotEmpty
	private String akaName;

	@NotEmpty
	private String componentName;

	private String agencyAkaName;
}
