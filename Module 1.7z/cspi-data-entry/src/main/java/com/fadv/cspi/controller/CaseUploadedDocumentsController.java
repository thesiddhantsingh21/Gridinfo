package com.fadv.cspi.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Positive;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.fadv.cspi.exception.ServiceException;
import com.fadv.cspi.pojo.request.SharedPathFilesUploadReqPOJO;
import com.fadv.cspi.pojo.response.ResponseStatusPOJO;
import com.fadv.cspi.service.CaseUploadedDocumentsService;
import com.fadv.cspi.userdetail.pojo.UserDetailPOJO;

import io.swagger.annotations.ApiOperation;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/india/")
public class CaseUploadedDocumentsController {

	private static final String SUCCESS_CODE_200 = "SUCCESS_CODE_200";

	private static final Logger logger = LoggerFactory.getLogger(CaseUploadedDocumentsController.class);

	private static final String TOKEN_ID = "tokenid";

	private static final String USER_ID = "userId";

	private static final String USER_NAME = "userName";

	@Autowired
	private CaseUploadedDocumentsService caseUploadedDocumentsService;

	@ApiOperation(value = "This API is used for all uploaded documents related to given case id", response = ResponseStatusPOJO.class)
	@GetMapping(path = "case-uploaded-documents/{caseId}", produces = "application/json")
	public ResponseEntity<ResponseStatusPOJO> getCaseAdditionalDetails(@PathVariable(value = "caseId") Long caseId) {
		logger.info("Case id to find : {}", caseId);
		try {
			return new ResponseEntity<>(
					new ResponseStatusPOJO(true, "Record found", SUCCESS_CODE_200,
							caseUploadedDocumentsService.getCaseUploadedDocumentsByCaseDetailsId(caseId)),
					HttpStatus.OK);
		} catch (ServiceException e1) {
			return new ResponseEntity<>(new ResponseStatusPOJO(false, e1.getMessage(), e1.getMessageId()),
					HttpStatus.OK);
		} catch (Exception e2) {
			return new ResponseEntity<>(new ResponseStatusPOJO(false, e2.getMessage()), HttpStatus.OK);
		}
	}

	@PostMapping(path = "upload/save/multipart", produces = "application/json")
	public ResponseEntity<ResponseStatusPOJO> saveAndUploadFile(HttpServletRequest request,
			@NotEmpty @RequestParam("fileName") List<MultipartFile[]> multipartFiles,
			@Positive @RequestParam("caseDetailsId") long caseDetailsId,
			@NotEmpty @RequestParam("uploadType") String uploadType,
			@RequestParam(name = "fulfillmentId", required = false) Long fulfillmentId) {

		String userName = request.getAttribute(USER_NAME).toString().isEmpty() ? USER_NAME
				: request.getAttribute(USER_NAME).toString();
		String userId = request.getAttribute(USER_ID).toString().isEmpty() ? USER_ID
				: request.getAttribute(USER_ID).toString();
		String tokenId = request.getHeader(TOKEN_ID).isEmpty() ? TOKEN_ID : request.getHeader(TOKEN_ID);

		UserDetailPOJO userDetailPOJO = new UserDetailPOJO(userName, userId);
		try {
			return new ResponseEntity<>(new ResponseStatusPOJO(true, "Upload Document data save successfully",
					SUCCESS_CODE_200, caseUploadedDocumentsService.uploadAndSaveMultipartFile(multipartFiles,
							caseDetailsId, uploadType, fulfillmentId, userDetailPOJO, tokenId)),
					HttpStatus.OK);
		} catch (ServiceException e1) {
			return new ResponseEntity<>(new ResponseStatusPOJO(false, e1.getMessage(), e1.getMessageId()),
					HttpStatus.OK);
		} catch (Exception e2) {
			return new ResponseEntity<>(new ResponseStatusPOJO(false, e2.getMessage()),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@PostMapping(path = "delete/upload/file/{caseUploadedDocumentsId}", produces = "application/json")
	public ResponseEntity<ResponseStatusPOJO> deleteUploadedFile(HttpServletRequest request,
			@Positive @PathVariable(value = "caseUploadedDocumentsId") long caseUploadedDocumentsId,
			@RequestParam(name = "fulfillmentId", required = false) Long fulfillmentId) {
		String userName = request.getAttribute(USER_NAME).toString().isEmpty() ? USER_NAME
				: request.getAttribute(USER_NAME).toString();
		String userId = request.getAttribute(USER_ID).toString().isEmpty() ? USER_ID
				: request.getAttribute(USER_ID).toString();
		String tokenId = request.getHeader(TOKEN_ID).isEmpty() ? TOKEN_ID : request.getHeader(TOKEN_ID);

		UserDetailPOJO userDetailPOJO = new UserDetailPOJO(userName, userId);
		try {
			return new ResponseEntity<>(new ResponseStatusPOJO(true, "Document deleted successfully", SUCCESS_CODE_200,
					caseUploadedDocumentsService.deleteUploadedDocument(caseUploadedDocumentsId, fulfillmentId,
							userDetailPOJO, tokenId)),
					HttpStatus.OK);
		} catch (ServiceException e1) {
			return new ResponseEntity<>(new ResponseStatusPOJO(false, e1.getMessage(), e1.getMessageId()),
					HttpStatus.OK);
		} catch (Exception e2) {
			return new ResponseEntity<>(new ResponseStatusPOJO(false, e2.getMessage()),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@PostMapping(path = "upload-case-documents", produces = "application/json")
	public ResponseEntity<ResponseStatusPOJO> saveSharedPathDocuments(HttpServletRequest request,
			@Valid @RequestBody SharedPathFilesUploadReqPOJO sharedPathFilesUploadReqPOJO) {

		String userName = request.getAttribute(USER_NAME).toString().isEmpty() ? USER_NAME
				: request.getAttribute(USER_NAME).toString();
		String userId = request.getAttribute(USER_ID).toString().isEmpty() ? USER_ID
				: request.getAttribute(USER_ID).toString();
		String tokenId = request.getHeader(TOKEN_ID).isEmpty() ? TOKEN_ID : request.getHeader(TOKEN_ID);

		UserDetailPOJO userDetailPOJO = new UserDetailPOJO(userName, userId);
		try {
			return new ResponseEntity<>(new ResponseStatusPOJO(true, "Shared File data uploaded successfully",
					SUCCESS_CODE_200, caseUploadedDocumentsService
							.convertAndSaveSharedPathFiles(sharedPathFilesUploadReqPOJO, userDetailPOJO, tokenId)),
					HttpStatus.OK);
		} catch (ServiceException e1) {
			logger.error("Exception occurred while saving data : {}", e1.getMessage());
			if (e1.getObj() != null) {
				return new ResponseEntity<>(new ResponseStatusPOJO(false, e1.getMessage(), e1.getObj()), HttpStatus.OK);
			} else {
				return new ResponseEntity<>(new ResponseStatusPOJO(false, e1.getMessage(), e1.getMessageId()),
						HttpStatus.OK);
			}
		} catch (Exception e2) {
			return new ResponseEntity<>(new ResponseStatusPOJO(false, e2.getMessage()),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
}
