package com.fadv.cspi.repository.master;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.fadv.cspi.entities.master.CountryMaster;
import com.fadv.cspi.entities.master.StateMaster;
import com.fadv.cspi.interfaces.StateMasterListResponseInterface;

@Repository
public interface StateMasterRepository extends JpaRepository<StateMaster, Long> {

	List<StateMaster> findByStateNameIgnoreCaseAndCountryMasterAndActive(String stateName, CountryMaster countryMaster,
			boolean active);

	List<StateMaster> findByStateNameIgnoreCaseAndActive(String stateName, boolean active);

	@Query(value = "select sm.state_master_id as stateMasterId, sm.state_name as stateName "
			+ "from {h-schema}state_master sm "
			+ "left join {h-schema}country_master cm on sm.country_master_id = cm.country_master_id "
			+ "where case when :stateName != '' then lower(sm.state_name) = lower(:stateName) else true end "
			+ "and case when :countryName != '' then lower(cm.country_name) = lower(:countryName) else true end "
			+ "and sm.active is true and cm.active is true order by sm.state_name", nativeQuery = true)
	List<StateMasterListResponseInterface> getStateListByCountryOrStateName(String stateName, String countryName);

	@Query(value = "select sm.state_name from {h-schema}state_master sm "
			+ "where lower(sm.state_name) = lower(:stateName) and sm.active is true order by sm.state_name", nativeQuery = true)
	List<String> getByStateNameList(String stateName);
	
	@Query(value = "select sm.state_name as stateName "
			+ "from {h-schema}state_master sm "
			+ "left join {h-schema}country_master cm on sm.country_master_id = cm.country_master_id "
			+ "where lower(sm.state_name) = lower(:stateName) and lower(cm.country_name) = lower(:countryName) and"
			+ " sm.active is true and cm.active is true order by sm.state_name", nativeQuery = true)
	List<String> getByStateNameAndCountryNameList(String stateName, String countryName);
}
