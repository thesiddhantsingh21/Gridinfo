package com.fadv.cspi.component.data.pojo;

public interface CspiCheckCreationCaseDetailsInterface {
	Long getClientMasterId();

	Long getSbuMasterId();

	Long getPackageMasterId();

	Long getComponentMasterId();

	Long getProductMasterId();

	String getRecordNode();

}
