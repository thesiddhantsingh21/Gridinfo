package com.fadv.cspi.repository.master;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.fadv.cspi.entities.master.QualificationLevelMaster;
import com.fadv.cspi.interfaces.QualificationLevelMasterListResponseInterface;

@Repository
public interface QualificationLevelMasterRepository extends JpaRepository<QualificationLevelMaster, Long> {

	List<QualificationLevelMaster> findByQualificationLevelAndActive(String qualificationLevel, boolean active);

	@Query(value = "select qlm.qualification_level_master_id as qualificationLevelMasterId, qlm.qualification_level as qualificationLevel "
			+ "from {h-schema}qualification_level_master qlm "
			+ "where case when :qualificationLevel != '' then lower(qlm.qualification_level) = lower(:qualificationLevel) "
			+ "else true end and qlm.active is true order by qlm.qualification_level", nativeQuery = true)
	List<QualificationLevelMasterListResponseInterface> getQualificationLevelMasterByFilter(String qualificationLevel);

	@Query(value = "select qlm.qualification_level from {h-schema}qualification_level_master qlm "
			+ "where lower(qlm.qualification_level) = lower(:qualificationLevel) and qlm.active is true", nativeQuery = true)
	List<String> getByQualificationLevelList(String qualificationLevel);
}
