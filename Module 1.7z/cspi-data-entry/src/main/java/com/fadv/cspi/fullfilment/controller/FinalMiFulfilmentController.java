package com.fadv.cspi.fullfilment.controller;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fadv.cspi.exception.ServiceException;
import com.fadv.cspi.fullfilment.pojo.MiRemarksPOJO;
import com.fadv.cspi.fullfilment.service.FinalMiFulfillmentService;
import com.fadv.cspi.pojo.response.ResponseStatusPOJO;
import com.fadv.cspi.userdetail.pojo.UserDetailPOJO;

import io.swagger.annotations.ApiOperation;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/india/")
public class FinalMiFulfilmentController {

	private static final String SUCCESS_CODE_200 = "SUCCESS_CODE_200";

	private static final Logger logger = LoggerFactory.getLogger(FinalMiFulfilmentController.class);

	private static final String TOKEN_ID = "tokenid";

	private static final String USER_ID = "userId";

	private static final String USER_NAME = "userName";

	@Autowired
	private FinalMiFulfillmentService finalMiFulfillmentService;

	@ApiOperation(value = "This API is used for submitting final data entry", response = ResponseStatusPOJO.class)
	@PostMapping(path = "final-fulfillment-submit/{caseId}/{fulfillmentId}", produces = "application/json")
	public ResponseEntity<ResponseStatusPOJO> getCaseDetails(HttpServletRequest request,
			@Positive @PathVariable(value = "caseId") long caseId, @NotNull @RequestParam("validate") boolean validate,
			@Positive @PathVariable(value = "fulfillmentId") long miFulfilmentRequestId,
			@Valid @RequestBody MiRemarksPOJO miRemarksPOJO) {

		String userName = request.getAttribute(USER_NAME).toString().isEmpty() ? USER_NAME
				: request.getAttribute(USER_NAME).toString();
		String userId = request.getAttribute(USER_ID).toString().isEmpty() ? USER_ID
				: request.getAttribute(USER_ID).toString();
		String tokenId = request.getHeader(TOKEN_ID).isEmpty() ? TOKEN_ID : request.getHeader(TOKEN_ID);
		UserDetailPOJO userDetailPOJO = new UserDetailPOJO(userName, userId);

		logger.info("Case id to final data entry submit : {}", caseId);
		try {
			return new ResponseEntity<>(new ResponseStatusPOJO(true, "Final Mi fulfillment saved successfully",
					SUCCESS_CODE_200, finalMiFulfillmentService.finalMiFulfillment(caseId, validate,
							miFulfilmentRequestId, miRemarksPOJO, userDetailPOJO, tokenId)),
					HttpStatus.OK);
		} catch (ServiceException e1) {
			logger.error("Exception occurred while final de save : {}", e1.getMessage());
			if (e1.getObj() != null) {
				return new ResponseEntity<>(new ResponseStatusPOJO(false, e1.getMessage(), e1.getObj()), HttpStatus.OK);
			} else {
				return new ResponseEntity<>(new ResponseStatusPOJO(false, e1.getMessage(), e1.getMessageId()),
						HttpStatus.OK);
			}
		} catch (Exception e2) {
			return new ResponseEntity<>(new ResponseStatusPOJO(false, e2.getMessage()), HttpStatus.OK);
		}
	}
}
