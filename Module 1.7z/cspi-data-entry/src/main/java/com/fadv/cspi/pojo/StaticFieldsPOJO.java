package com.fadv.cspi.pojo;

import lombok.Data;

@Data
public class StaticFieldsPOJO {

	private boolean readonly;

	private String mapFieldName;

	private String selectedFieldName;
}
