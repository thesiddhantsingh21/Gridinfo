package com.fadv.cspi.service;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

@Service
public interface CopyFeatureConfigSevice {

	Map<String, List<String>> getDocumentAndFiledKeyMap();

	Map<String, List<String>> getDocumentAndFiledNameMap();

}
