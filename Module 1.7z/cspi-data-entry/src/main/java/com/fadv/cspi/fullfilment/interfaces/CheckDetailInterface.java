package com.fadv.cspi.fullfilment.interfaces;

public interface CheckDetailInterface {
	String getChecks();
	String getCaseNo();
}
