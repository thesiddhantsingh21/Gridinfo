package com.fadv.cspi.repository.master;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.fadv.cspi.entities.master.DataSourceMaster;

@Repository
public interface DataSourceMasterRepository extends JpaRepository<DataSourceMaster, Long> {

	List<DataSourceMaster> findByDataSourceNameIgnoreCase(String dataSourceName);
}
