package com.fadv.cspi.fullfilment.pojo;

import java.util.List;

import lombok.Data;

@Data
public class RuleResultPOJO {

	private List<Object> reason;
}
