package com.fadv.cspi.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fadv.cspi.pojo.response.ResponseStatusPOJO;
import com.fadv.cspi.service.CountryMasterService;

import io.swagger.annotations.ApiOperation;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/india/")
public class CountryMasterController {

	@Autowired
	private CountryMasterService countryMasterService;

	@ApiOperation(value = "This API is used for fetching all countries", response = ResponseStatusPOJO.class)
	@GetMapping(path = "/country-list", produces = "application/json")
	public ResponseEntity<ResponseStatusPOJO> getCountryMasterList() {
		try {
			return new ResponseEntity<>(new ResponseStatusPOJO(true, "Record found", "SUCCESS_CODE_200",
					countryMasterService.getCountryList()), HttpStatus.OK);
		} catch (Exception e2) {
			return new ResponseEntity<>(new ResponseStatusPOJO(false, e2.getMessage()), HttpStatus.OK);
		}
	}
}
