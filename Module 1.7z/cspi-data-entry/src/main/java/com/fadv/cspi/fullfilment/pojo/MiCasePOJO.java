package com.fadv.cspi.fullfilment.pojo;

import java.util.List;

import lombok.Data;

@Data
public class MiCasePOJO {

	private List<DocumentsPOJO> documents;

	private RuleOutputPOJO ruleOutput;
}
