package com.fadv.cspi.pojo;

import java.util.List;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Positive;

import com.fadv.cspi.pojo.response.DocumentFieldMasterResponsePOJO;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.Data;

@Data
@JsonInclude(value = Include.NON_NULL)
public class DataEntryFormSearchPOJO {

	@Positive
	private long caseDetailsId;

	@NotEmpty
	private String rowId;

	@Positive
	private long documentMasterId;

	@NotEmpty
	private String documentName;

	private String akaName;

	private String agencyAkaName;

	private String parentRowId;

	private Long parentDocumentMasterId;

	private int formDataSize;

	private Long fulfillmentId;
	
	private String instructionCheckId;

	private List<DocumentFieldMasterResponsePOJO> formData;

	@JsonIgnore
	public String toJSON() {

		ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		try {
			return mapper.writeValueAsString(this);
		} catch (JsonProcessingException var2) {
			return "{}";
		}
	}

}
