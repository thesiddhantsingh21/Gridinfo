package com.fadv.cspi.interfaces;

public interface CaseAssociatedDocumentsInterface {

	long getCaseDetailsId();

	int getPageCount();

	String getSourceFolder();

	String getOriginalName();

	int getStartPage();

	String getRowId();

	String getParentRowId();

	String getFilePath();

	int getEndPage();

	String getDocumentName();

	long getDocumentMasterId();

	String getAkaName();

	String getAgencyAkaName();

	String getFileExtension();

	String getFileName();

	String getUpdatedByUser();

	long getCaseUploadedDocumentsId();

	String getAssociatedTo();
}
