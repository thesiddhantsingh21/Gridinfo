package com.fadv.cspi.pojo.response;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class BatchErrorPOJO {

	private String path;
	private String error;

	public BatchErrorPOJO() {
		// Do nothing because of.
	}
}
