package com.fadv.cspi.entities.master;

public interface QuestionnairePOJO {
	String getId();

	String getQuestion();

	String getGlobalQuestionId();

	String getQuestionScope();

	String getQuestionType();

	String getComponentName();

	String getProductName();

	String getFormLabel();

	String getAnswere();

	Boolean getMandatory();

	String getStatus();

	String getVerifiedData();

	String getReportData();
	
	String getAdjudication();
}
