package com.fadv.cspi.repository.master;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.fadv.cspi.entities.master.CountryMaster;
import com.fadv.cspi.interfaces.CountryMasterListResponseInterface;

@Repository
public interface CountryMasterRepository extends JpaRepository<CountryMaster, Long> {

	List<CountryMaster> findByCountryNameIgnoreCase(String countryName);

	@Query(value = "select cm.country_master_id as countryMasterId, cm.country_name as countryName "
			+ "from {h-schema}country_master cm where cm.active is true "
			+ "and case when :countryName != '' then lower(cm.country_name) = lower(:countryName) else true end "
			+ "order by cm.country_name ", nativeQuery = true)
	List<CountryMasterListResponseInterface> getCountryListByFilter(String countryName);

	@Query(value = "select cm.country_name from {h-schema}country_master cm "
			+ "where lower(cm.country_name) = lower(:countryName) and cm.active is true order by cm.country_name ", nativeQuery = true)
	List<String> getByCountryNameList(String countryName);
}
