package com.fadv.cspi.service;

import org.springframework.stereotype.Service;

import com.fadv.cspi.exception.ServiceException;

@Service
public interface CopyDataEntryService {

	String copyDataEntryUsingCaseNo(String oldCaseNo, String newCaseNo) throws ServiceException;

}
