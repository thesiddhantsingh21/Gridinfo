package com.fadv.cspi.service;

import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.multipart.MultipartFile;

import com.fadv.cspi.entities.transaction.CaseDetails;
import com.fadv.cspi.entities.transaction.CaseUploadedDocuments;
import com.fadv.cspi.exception.ServiceException;
import com.fadv.cspi.fullfilment.entities.MiFulfilmentRequest;
import com.fadv.cspi.fullfilment.service.MiFulfilmentRequestService;
import com.fadv.cspi.pojo.ConversionResponsePOJO;
import com.fadv.cspi.pojo.ConvertedDocumentsResponsePOJO;
import com.fadv.cspi.pojo.FileInfoPOJO;
import com.fadv.cspi.pojo.FileUploadDataPOJO;
import com.fadv.cspi.pojo.request.SharedPathFilesUploadReqPOJO;
import com.fadv.cspi.pojo.response.BatchErrorPOJO;
import com.fadv.cspi.pojo.response.CaseUploadedDocumentsResponsePOJO;
import com.fadv.cspi.pojo.response.CombinedFileResposnePOJO;
import com.fadv.cspi.repository.transaction.CaseUploadedDocumentsRepository;
import com.fadv.cspi.userdetail.pojo.UserDetailPOJO;
import com.fadv.cspi.utility.ConversionUtility;
import com.fadv.cspi.utility.MultipartInputStreamFileResource;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;

@Service
public class CaseUploadedDocumentsServiceImpl implements CaseUploadedDocumentsService {

	private static final String ERROR_CODE_404 = "ERROR_CODE_404";

	@Autowired
	private CaseUploadedDocumentsRepository caseUploadedDocumentsRepository;

	@Autowired
	private CaseDetailsService caseDetailsService;

	@Autowired
	private ApiService apiService;

	@Autowired
	private MiFulfilmentRequestService miFulfilmentRequestService;

	private static final String CASE_UPLOADED_DOCUMENTS = "case_uploaded_documents";

	private ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES,
			false);

	private static final Logger logger = LoggerFactory.getLogger(CaseUploadedDocumentsServiceImpl.class);

	@Value("${upload.case.document.url}")
	private String caseUploadDocumentUrl;

	@Value("${upload.shared.document.url}")
	private String uploadSharedDocumentUrl;

	@Value("${shared.mount.path.map}")
	private String sharedMountPathMap;

	@Override
	public List<CaseUploadedDocuments> findByCaseDetailsId(Long caseDetailsId) throws ServiceException {

		CaseDetails caseDetails = caseDetailsService.findByCaseDetailsId(caseDetailsId);
		List<CaseUploadedDocuments> caseUploadedDocuments = caseUploadedDocumentsRepository
				.findByUploadTypeIgnoreCaseAndCaseDetails("converted", caseDetails);

		if (CollectionUtils.isNotEmpty(caseUploadedDocuments)) {
			return caseUploadedDocuments;
		}
		throw new ServiceException("Case Uploaded Documents not found for given case id", ERROR_CODE_404);
	}

	@Override
	public List<ConvertedDocumentsResponsePOJO> getCaseUploadedDocumentsByCaseDetailsId(Long caseDetailsId)
			throws ServiceException {

		checkForValidCrn(caseDetailsService.findByCaseDetailsId(caseDetailsId));
		List<CaseUploadedDocuments> caseUploadedDocuments = findByCaseDetailsId(caseDetailsId);

		List<ConvertedDocumentsResponsePOJO> convertedDocumentsResponsePOJOs = mapper
				.convertValue(caseUploadedDocuments, new TypeReference<List<ConvertedDocumentsResponsePOJO>>() {
				});

		convertedDocumentsResponsePOJOs.stream().forEach(data -> data.setCaseDetailsId(caseDetailsId));
		return convertedDocumentsResponsePOJOs;
	}

	private void checkForValidCrn(CaseDetails caseDetails) throws ServiceException {

		String crNo = caseDetails.getCrn();

		if (crNo == null || StringUtils.isEmpty(crNo) || StringUtils.equalsIgnoreCase(crNo, "pending")) {
			throw new ServiceException("Invalid CRN", ERROR_CODE_404);
		}
	}

	private void checkForDeCompletion(CaseDetails caseDetails, MiFulfilmentRequest miFulfilmentRequest)
			throws ServiceException {

		if (caseDetails.getDeComplete() != null && caseDetails.getDeComplete()) {

			if (miFulfilmentRequest != null) {
				boolean fulfilled = miFulfilmentRequest.getFulfilled() != null && miFulfilmentRequest.getFulfilled();

				if (fulfilled) {
					throw new ServiceException("MI Fulfillment already done", ERROR_CODE_404);
				}
			} else {
				throw new ServiceException("DE Already done", ERROR_CODE_404);
			}
		}
	}

	@Override
	public CaseUploadedDocuments findByCaseUploadedDocumentsId(long caseUploadedDocumentsId) throws ServiceException {
		Optional<CaseUploadedDocuments> caseUploadedDocumentsOptional = caseUploadedDocumentsRepository
				.findById(caseUploadedDocumentsId);
		if (caseUploadedDocumentsOptional.isPresent()) {
			return caseUploadedDocumentsOptional.get();
		}
		throw new ServiceException("Invalid case uploaded document id", ERROR_CODE_404);
	}

	@Override
	public CaseUploadedDocumentsResponsePOJO uploadAndSaveMultipartFile(List<MultipartFile[]> multipartFiles,
			long caseDetailsId, String uploadType, Long fulfillmentId, UserDetailPOJO userDetailPOJO, String tokenId)
			throws ServiceException, JsonProcessingException {

		FileUploadDataPOJO fileUploadDataPOJO = new FileUploadDataPOJO();
		if (caseDetailsId > 0 && uploadType.equalsIgnoreCase("verification")) {
			fileUploadDataPOJO.setCaseDetailsId(caseDetailsId);
		} else if (!uploadType.equalsIgnoreCase("case") && caseDetailsId > 0) {
			CaseDetails caseDetails = caseDetailsService.findByCaseDetailsId(caseDetailsId);
			MiFulfilmentRequest miFulfilmentRequest = null;
			checkForValidCrn(caseDetails);

			if (fulfillmentId != null) {
				miFulfilmentRequest = miFulfilmentRequestService.findByMiFulfilmentRequestId(fulfillmentId);
			}

			checkForDeCompletion(caseDetails, miFulfilmentRequest);

			fileUploadDataPOJO.setMiFulfilmentRequest(miFulfilmentRequest);
			fileUploadDataPOJO.setCaseDetailsId(caseDetailsId);
		}

		MultiValueMap<String, Object> map = new LinkedMultiValueMap<>();

		for (MultipartFile[] multiFiles : multipartFiles) {
			for (MultipartFile file : multiFiles) {
				if (!file.isEmpty()) {
					try {
						map.add("filename", new MultipartInputStreamFileResource(file.getInputStream(),
								file.getOriginalFilename()));
					} catch (IOException e) {
						throw new ServiceException("Some error occurred while converting the document.",
								ERROR_CODE_404);
					}
				}
			}
		}

		String response = apiService.sendDataToPostFormData(caseUploadDocumentUrl, map);

		if (response == null) {
			throw new ServiceException("Some error occurred while converting the document.", ERROR_CODE_404);
		}

		JsonNode responseNode = mapper.readTree(response);
		JsonNode responseBody = responseNode.has("response") ? responseNode.get("response") : mapper.createObjectNode();

		ConversionResponsePOJO conversionResponsePOJO = mapper.convertValue(responseBody, ConversionResponsePOJO.class);
		List<FileInfoPOJO> originalData = conversionResponsePOJO.getOriginalFiles();
		List<FileInfoPOJO> convertedData = conversionResponsePOJO.getConvertedFiles();

		fileUploadDataPOJO.setOriginalData(originalData);
		fileUploadDataPOJO.setConvertedData(convertedData);

		List<ConvertedDocumentsResponsePOJO> convertedDocumentsResponsePOJOs = mapper.convertValue(
				saveUploadedFile(fileUploadDataPOJO, userDetailPOJO, tokenId),
				new TypeReference<List<ConvertedDocumentsResponsePOJO>>() {
				});

		if (caseDetailsId > 0) {
			convertedDocumentsResponsePOJOs.stream().forEach(data -> data.setCaseDetailsId(caseDetailsId));
		}

		CaseUploadedDocumentsResponsePOJO caseUploadedDocumentsResponsePOJO = new CaseUploadedDocumentsResponsePOJO();
		caseUploadedDocumentsResponsePOJO.setFiles(convertedDocumentsResponsePOJOs);
		caseUploadedDocumentsResponsePOJO.setErrorMap(conversionResponsePOJO.getErrorMap());
		return caseUploadedDocumentsResponsePOJO;

	}

	public List<CaseUploadedDocuments> saveUploadedFile(FileUploadDataPOJO fileUploadDataPOJO,
			UserDetailPOJO userDetailPOJO, String tokenId) throws ServiceException {

		Long caseDetailsId = fileUploadDataPOJO.getCaseDetailsId() != null ? fileUploadDataPOJO.getCaseDetailsId() : 0L;
		MiFulfilmentRequest miFulfilmentRequest = fileUploadDataPOJO.getMiFulfilmentRequest();

		List<FileInfoPOJO> originalData = fileUploadDataPOJO.getOriginalData() != null
				? fileUploadDataPOJO.getOriginalData()
				: new ArrayList<>();
		List<FileInfoPOJO> convertedData = fileUploadDataPOJO.getConvertedData() != null
				? fileUploadDataPOJO.getConvertedData()
				: new ArrayList<>();

		String caseOrigin = fileUploadDataPOJO.getCaseOrigin() != null ? fileUploadDataPOJO.getCaseOrigin() : "";

		if (CollectionUtils.isNotEmpty(convertedData) || CollectionUtils.isNotEmpty(originalData)) {

			CaseDetails caseDetails = caseDetailsService.getByCaseDetailsId(caseDetailsId);

			List<CaseUploadedDocuments> caseUploadedDocuments = new ArrayList<>();

			originalData.stream().forEach(data -> {
				CaseUploadedDocuments caseUploadedDocument = new CaseUploadedDocuments();
				caseUploadedDocument.setActive(true);

				if (caseDetailsId > 0) {
					caseUploadedDocument.setCaseDetails(caseDetails);
				}
				if (miFulfilmentRequest != null) {
					caseUploadedDocument.setMiFulfilmentRequest(miFulfilmentRequest);

				}
				caseUploadedDocument.setContentType(data.getContentType());
				caseUploadedDocument.setErrorLog(data.getErrorLog());
				caseUploadedDocument.setFileExtension(data.getExtension());
				caseUploadedDocument.setFileName(data.getName());
				caseUploadedDocument.setFilePath(data.getPath());
				caseUploadedDocument.setFilePathName(data.getFilePathName());
				caseUploadedDocument.setFileSize(data.getSize());
				caseUploadedDocument.setFileStatus(data.getFileStatus() != null ? data.getFileStatus().toString() : "");
				caseUploadedDocument.setFileUrl(data.getUrl());
				caseUploadedDocument.setOriginalName(data.getOriginalName());
				caseUploadedDocument.setPageCount(data.getPageCount());
				caseUploadedDocument.setRequestId(data.getRequestId());
				caseUploadedDocument.setUploadType("original");
				caseUploadedDocument.setCreatedDate(new Date());
				caseUploadedDocument.setUpdatedDate(new Date());
				caseUploadedDocument.setUpdatedByUser(userDetailPOJO.getUserId());
				caseUploadedDocument.setCaseOrigin(caseOrigin);

				caseUploadedDocuments.add(caseUploadedDocument);
			});

			convertedData.stream().forEach(data -> {
				CaseUploadedDocuments caseUploadedDocument = new CaseUploadedDocuments();
				caseUploadedDocument.setActive(true);

				if (caseDetailsId > 0) {
					caseUploadedDocument.setCaseDetails(caseDetails);
				}
				if (miFulfilmentRequest != null) {
					caseUploadedDocument.setMiFulfilmentRequest(miFulfilmentRequest);

				}

				caseUploadedDocument.setContentType(data.getContentType());
				caseUploadedDocument.setErrorLog(data.getErrorLog());
				caseUploadedDocument.setFileExtension(data.getExtension());
				caseUploadedDocument.setFileName(data.getName());
				caseUploadedDocument.setFilePath(data.getPath());
				caseUploadedDocument.setFilePathName(data.getFilePathName());
				caseUploadedDocument.setFileSize(data.getSize());
				caseUploadedDocument.setFileStatus(data.getFileStatus() != null ? data.getFileStatus().toString() : "");
				caseUploadedDocument.setFileUrl(data.getUrl());
				caseUploadedDocument.setOriginalName(data.getOriginalName());
				caseUploadedDocument.setPageCount(data.getPageCount());
				caseUploadedDocument.setRequestId(data.getRequestId());
				caseUploadedDocument.setUploadType("converted");
				caseUploadedDocument.setCreatedDate(new Date());
				caseUploadedDocument.setUpdatedDate(new Date());
				caseUploadedDocument.setUpdatedByUser(userDetailPOJO.getUserId());
				caseUploadedDocument.setCaseOrigin(caseOrigin);

				caseUploadedDocuments.add(caseUploadedDocument);
			});
			List<CaseUploadedDocuments> newCaseUploadedDocuments = caseUploadedDocumentsRepository
					.saveAll(caseUploadedDocuments);

			JsonNode prevJson = mapper.createArrayNode();
			JsonNode newJson = mapper.convertValue(newCaseUploadedDocuments, ArrayNode.class);
			logger.info("case_uploaded_documents - ADD - NEW : {}", newJson);
			apiService.addAuditLog(CASE_UPLOADED_DOCUMENTS, prevJson, newJson, userDetailPOJO, "ADD", tokenId);

			return newCaseUploadedDocuments;
		}
		throw new ServiceException("Unsupported file - Can not be uploaded", ERROR_CODE_404);
	}

	@Override
	public String deleteUploadedDocument(long caseUploadedDocumentsId, Long fulfillmentId,
			UserDetailPOJO userDetailPOJO, String tokenId) throws ServiceException {

		CaseUploadedDocuments caseUploadedDocument = findByCaseUploadedDocumentsId(caseUploadedDocumentsId);

		CaseDetails caseDetails = caseUploadedDocument.getCaseDetails();
		MiFulfilmentRequest miFulfilmentRequest = null;
		checkForValidCrn(caseDetails);

		if (fulfillmentId != null) {
			miFulfilmentRequest = miFulfilmentRequestService.findByMiFulfilmentRequestId(fulfillmentId);
		}
		checkForDeCompletion(caseDetails, miFulfilmentRequest);

		String fileName = caseUploadedDocument.getFileName();
		int index = fileName.lastIndexOf('.');
		fileName = fileName.substring(0, index - 1);
		fileName = fileName + "%";

		List<CaseUploadedDocuments> caseUploadedDocuments = caseUploadedDocumentsRepository
				.getByFileNameIgnoreCaseAndOriginalNameIgnoreCase(fileName, caseUploadedDocument.getOriginalName());

		JsonNode prevJson = mapper.convertValue(caseUploadedDocuments, ArrayNode.class);
		logger.info("case_uploaded_documents - DELETE - PREV : {}", prevJson);

		JsonNode newJson = mapper.createArrayNode();
		logger.info("case_uploaded_documents - ADD - NEW : {}", newJson);
		apiService.addAuditLog(CASE_UPLOADED_DOCUMENTS, prevJson, newJson, userDetailPOJO, "DELETE", tokenId);

		for (CaseUploadedDocuments newCaseUploadedDocuments : caseUploadedDocuments) {
			caseUploadedDocumentsRepository.delete(newCaseUploadedDocuments);
		}

		return "Document deleted successfully";
	}

	@Override
	public CaseUploadedDocuments saveNewRecord(CaseUploadedDocuments caseUploadedDocuments) {
		return caseUploadedDocumentsRepository.save(caseUploadedDocuments);
	}

	@Override
	public List<CaseUploadedDocuments> findByCaseDetails(CaseDetails caseDetails) {
		return caseUploadedDocumentsRepository.findByCaseDetails(caseDetails);
	}

	@Override
	public List<CaseUploadedDocuments> findByCaseDetailsAndUploadType(CaseDetails caseDetails, String uploadType) {
		return caseUploadedDocumentsRepository.findByCaseDetailsAndUploadTypeIgnoreCase(caseDetails, uploadType);
	}

	@Override
	public List<CaseUploadedDocuments> findByCaseDetailsAndUploadTypeAndCaseOrigin(CaseDetails caseDetails,
			String uploadType, String caseOrigin) {
		return caseUploadedDocumentsRepository
				.findByCaseDetailsAndUploadTypeIgnoreCaseAndCaseOriginIgnoreCase(caseDetails, uploadType, caseOrigin);
	}

	@Override
	public CombinedFileResposnePOJO convertAndSaveSharedPathFiles(
			SharedPathFilesUploadReqPOJO sharedPathFilesUploadReqPOJO, UserDetailPOJO userDetailPOJO, String tokenId)
			throws ServiceException, JsonProcessingException {

		String caseNo = sharedPathFilesUploadReqPOJO.getCaseNo();
		CaseDetails caseDetails = caseDetailsService.findByCaseNo(caseNo);
		List<File> files = validateAndGetFiles(sharedPathFilesUploadReqPOJO);

		ArrayNode filesNode = mapper.convertValue(files, ArrayNode.class);

		String url = uploadSharedDocumentUrl.replace("{caseNo}", caseNo);

		String response = apiService.sendDataToPost(url, filesNode.toString());

		if (response == null) {
			throw new ServiceException("Some error occurred while converting the document.", ERROR_CODE_404);
		}

		JsonNode responseNode = mapper.readTree(response);
		JsonNode responseBody = responseNode.has("response") ? responseNode.get("response") : mapper.createObjectNode();

		CombinedFileResposnePOJO combinedFileResposnePOJO = mapper.convertValue(responseBody,
				CombinedFileResposnePOJO.class);

		List<BatchErrorPOJO> batchErrorPOJOs = combinedFileResposnePOJO.getBatchErrorPOJOs();
		List<FileInfoPOJO> convertedData = combinedFileResposnePOJO.getConvertedFiles();

		if (CollectionUtils.isNotEmpty(batchErrorPOJOs)) {
			throw new ServiceException("Some batch error occured while converting files", "ERROR_CODE_400",
					combinedFileResposnePOJO);
		}

		FileUploadDataPOJO fileUploadDataPOJO = new FileUploadDataPOJO();
		fileUploadDataPOJO.setConvertedData(convertedData);
		fileUploadDataPOJO.setCaseDetailsId(caseDetails.getCaseDetailsId());
		fileUploadDataPOJO.setCaseOrigin(sharedPathFilesUploadReqPOJO.getRequestSource() != null
				? sharedPathFilesUploadReqPOJO.getRequestSource()
				: "");

		List<ConvertedDocumentsResponsePOJO> convertedDocumentsResponsePOJOs = mapper.convertValue(
				saveUploadedFile(fileUploadDataPOJO, userDetailPOJO, tokenId),
				new TypeReference<List<ConvertedDocumentsResponsePOJO>>() {
				});

		convertedDocumentsResponsePOJOs.stream().forEach(data -> data.setCaseDetailsId(caseDetails.getCaseDetailsId()));

		return combinedFileResposnePOJO;
	}

	private List<File> validateAndGetFiles(SharedPathFilesUploadReqPOJO sharedPathFilesUploadReqPOJO)
			throws ServiceException {

		List<String> filePathStrList = sharedPathFilesUploadReqPOJO.getFilePath();

		String requestSource = sharedPathFilesUploadReqPOJO.getRequestSource() != null
				? sharedPathFilesUploadReqPOJO.getRequestSource()
				: "";
		if (StringUtils.isNotEmpty(requestSource) && StringUtils.equalsIgnoreCase(requestSource, "sp")) {
			List<File> filePaths = new ArrayList<>();
			for (String fileName : filePathStrList) {
				try {
					Path filePath = Paths.get(fileName);
					filePaths.add(filePath.toFile());
				} catch (Exception e) {
					logger.error("Exception in finding file : {}, {}", fileName, e.getMessage());
				}
			}
			return filePaths;
		}

		Map<String, String> sharePathMaps = ConversionUtility.convertStringToMap(sharedMountPathMap);
		logger.info("Shared path to mounted path map : {}", sharePathMaps);

		List<Path> filePaths = new ArrayList<>();
		for (Map.Entry<String, String> sharePathMap : sharePathMaps.entrySet()) {
			List<Path> tempFilePaths = filePathStrList.stream().filter(
					data -> data != null && StringUtils.isNotEmpty(data) && data.contains(sharePathMap.getKey()))
					.map(data -> {
						data = data.replace(sharePathMap.getKey(), sharePathMap.getValue());
						data = data.replace("\\", "/");
						return Paths.get(data);
					}).collect(Collectors.toList());
			filePaths.addAll(tempFilePaths);
		}
		logger.info("Updated file paths : {}", filePaths);

		List<File> fileList = new ArrayList<>();
		filePaths.stream().forEach(data -> {
			fileList.addAll(ConversionUtility.listAllFilesInDirectory(data.toFile(), new ArrayList<>()));
		});

		logger.info("List of all files : {}", fileList);

		if (CollectionUtils.isEmpty(fileList)) {
			throw new ServiceException("No file found in the given directory", ERROR_CODE_404);
		}

		return fileList;
	}
}
