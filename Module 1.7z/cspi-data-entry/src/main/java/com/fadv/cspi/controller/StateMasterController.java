package com.fadv.cspi.controller;

import javax.validation.constraints.NotEmpty;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fadv.cspi.pojo.response.ResponseStatusPOJO;
import com.fadv.cspi.service.StateMasterService;

import io.swagger.annotations.ApiOperation;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/india/")
public class StateMasterController {

	@Autowired
	private StateMasterService stateMasterService;

	@ApiOperation(value = "This API is used for fetching all states in a given country", response = ResponseStatusPOJO.class)
	@GetMapping(path = "/state-list/{countryName}", produces = "application/json")
	public ResponseEntity<ResponseStatusPOJO> getStateMasterListByCountryName(
			@NotEmpty @PathVariable(value = "countryName") String countryName) {
		try {
			return new ResponseEntity<>(new ResponseStatusPOJO(true, "Record found", "SUCCESS_CODE_200",
					stateMasterService.getStateListByCountry(countryName)), HttpStatus.OK);
		} catch (Exception e2) {
			return new ResponseEntity<>(new ResponseStatusPOJO(false, e2.getMessage()), HttpStatus.OK);
		}
	}
}
