package com.fadv.cspi.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fadv.cspi.exception.ServiceException;
import com.fadv.cspi.pojo.response.ResponseStatusPOJO;
import com.fadv.cspi.service.CaseSpecificInfoService;

import io.swagger.annotations.ApiOperation;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/india/")
public class CaseSpecificInfoController {

	private static final String SUCCESS_CODE_200 = "SUCCESS_CODE_200";

	@Autowired
	private CaseSpecificInfoService caseSpecificInfoService;

	@ApiOperation(value = "This API is used for creating a new entry in  table using the data provided by the user.", response = ResponseStatusPOJO.class)
	@GetMapping(path = "case-specific-info/{caseDetailsId}", produces = "application/json")
	public ResponseEntity<ResponseStatusPOJO> saveCaseSpecificInfoDetails(
			@PathVariable(value = "caseDetailsId") long caseDetailsId) {
		try {
			return new ResponseEntity<>(new ResponseStatusPOJO(true, "Data Saved Successfully", SUCCESS_CODE_200,
					caseSpecificInfoService.saveCaseSpecificInfoDetails(caseDetailsId)), HttpStatus.OK);
		} catch (ServiceException e1) {
			if (e1.getObj() != null) {
				return new ResponseEntity<>(new ResponseStatusPOJO(false, e1.getMessage(), e1.getObj()), HttpStatus.OK);
			} else {
				return new ResponseEntity<>(new ResponseStatusPOJO(false, e1.getMessage(), e1.getMessageId()),
						HttpStatus.OK);
			}
		} catch (Exception e2) {
			return new ResponseEntity<>(new ResponseStatusPOJO(false, e2.getMessage()), HttpStatus.OK);
		}
	}

	@ApiOperation(value = "This API is used for creating a new entry in  table using the data provided by the user.", response = ResponseStatusPOJO.class)
	@GetMapping(path = "record-data/{crn}", produces = "application/json")
	public ResponseEntity<ResponseStatusPOJO> getData(@PathVariable(value = "crn") String crn) {
		try {
			return new ResponseEntity<>(new ResponseStatusPOJO(true, "Data Saved Successfully", SUCCESS_CODE_200,
					caseSpecificInfoService.getDataByCrn(crn)), HttpStatus.OK);
		} catch (ServiceException e1) {
			if (e1.getObj() != null) {
				return new ResponseEntity<>(new ResponseStatusPOJO(false, e1.getMessage(), e1.getObj()), HttpStatus.OK);
			} else {
				return new ResponseEntity<>(new ResponseStatusPOJO(false, e1.getMessage(), e1.getMessageId()),
						HttpStatus.OK);
			}
		} catch (Exception e2) {
			return new ResponseEntity<>(new ResponseStatusPOJO(false, e2.getMessage()), HttpStatus.OK);
		}
	}
}
