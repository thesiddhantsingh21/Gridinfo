package com.fadv.cspi.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.fadv.cspi.entities.master.ContactCardMaster;
import com.fadv.cspi.entities.transaction.CaseDataEntry;
import com.fadv.cspi.entities.transaction.CaseDetails;
import com.fadv.cspi.exception.ServiceException;
import com.fadv.cspi.pojo.AutoDataEntryPOJO;
import com.fadv.cspi.pojo.DataEntryFormSearchPOJO;
import com.fadv.cspi.pojo.DeleteDataEntryPOJO;
import com.fadv.cspi.pojo.FieldFormSearchPOJO;
import com.fadv.cspi.pojo.response.DocumentFieldMasterResponsePOJO;
import com.fadv.cspi.userdetail.pojo.UserDetailPOJO;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

@Service
public interface CaseDataEntryService {

	DataEntryFormSearchPOJO fetchDataEntryForm(DataEntryFormSearchPOJO dataEntryFormSearchPOJO) throws ServiceException;
	
	FieldFormSearchPOJO fetchFieldEntryForm(FieldFormSearchPOJO fieldFormSearchPOJO) throws ServiceException;

	DataEntryFormSearchPOJO saveDataEntryDetails(DataEntryFormSearchPOJO dataEntryFormSearchPOJO,
			UserDetailPOJO userDetailPOJO, String tokenId) throws ServiceException, JsonProcessingException;

	String deleteDataEntry(DeleteDataEntryPOJO deleteDataEntryPOJO, UserDetailPOJO userDetailPOJO, String tokenId)
			throws ServiceException;

	List<CaseDataEntry> findByCaseDetails(CaseDetails caseDetails);

	CaseDataEntry saveNewRecord(CaseDataEntry caseDataEntry);

	String saveAutoDataEntry(AutoDataEntryPOJO autoDataEntryPOJO, UserDetailPOJO userDetailPOJO, String tokenId)
			throws ServiceException;

	List<DocumentFieldMasterResponsePOJO> updateDocumentFieldsUsingRowIdNode(String documentNameKey,
			long documentMasterId, JsonNode rowIdNode) throws ServiceException;

	void checkUrlAndUpdateDefaultValue(ContactCardMaster contactCardMaster,
			List<DocumentFieldMasterResponsePOJO> documentFieldMasterResponsePOJOs);

	List<DocumentFieldMasterResponsePOJO> checkUrlAndUpdateAkaEditValue(ContactCardMaster contactCardMaster,
			List<DocumentFieldMasterResponsePOJO> documentFieldMasterResponsePOJOs);

	void handleConcatenatedKeys(ObjectNode documentNode);

}
