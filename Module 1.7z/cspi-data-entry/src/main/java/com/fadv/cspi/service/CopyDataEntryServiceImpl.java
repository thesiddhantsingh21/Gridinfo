package com.fadv.cspi.service;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.fadv.cspi.entities.transaction.CaseAssociatedDocuments;
import com.fadv.cspi.entities.transaction.CaseClientDetails;
import com.fadv.cspi.entities.transaction.CaseDataEntry;
import com.fadv.cspi.entities.transaction.CaseDetails;
import com.fadv.cspi.entities.transaction.CaseUploadedDocuments;
import com.fadv.cspi.exception.ServiceException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class CopyDataEntryServiceImpl implements CopyDataEntryService {

	@Autowired
	private CaseDetailsService caseDetailsService;

	@Autowired
	private CaseClientDetailsService caseClientDetailsService;

	@Autowired
	private CaseUploadedDocumentsService caseUploadedDocumentsService;

	@Autowired
	private CaseAssociatedDocumentsService caseAssociatedDocumentsService;

	@Autowired
	private CaseDataEntryService caseDataEntryService;

	@Autowired
	private ApiService apiService;

	private ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES,
			false);

	private static final Logger logger = LoggerFactory.getLogger(CopyDataEntryServiceImpl.class);

	@Value("${copy.file.url}")
	private String copyFileUrl;

	@Override
	public String copyDataEntryUsingCaseNo(String oldCaseNo, String newCaseNo) throws ServiceException {
		CaseDetails oldCaseDetails = caseDetailsService.findByCaseNo(oldCaseNo);
		CaseDetails newCaseDetails = caseDetailsService.findByCaseNo(newCaseNo);
		CaseClientDetails newCaseClientDetails = caseClientDetailsService
				.findByCaseDetailsId(newCaseDetails.getCaseDetailsId());

		List<CaseUploadedDocuments> caseUploadedDocuments = caseUploadedDocumentsService
				.findByCaseDetails(oldCaseDetails);

		Map<Long, CaseUploadedDocuments> uploadedDocNewOldMap = new TreeMap<>();
		for (CaseUploadedDocuments caseUploadedDocument : caseUploadedDocuments) {
			String fileName = caseUploadedDocument.getFileName();
			String newFileName = fileName;
			if (fileName.contains(oldCaseNo)) {
				newFileName = newFileName.replace(oldCaseNo, newCaseNo);
			} else {
				newFileName = newCaseNo + fileName;
			}

			String response = apiService.sendDataToGet(copyFileUrl + fileName + "/" + newFileName);

			if (response != null) {
				try {
					JsonNode responseNode = mapper.readTree(response);
					boolean success = responseNode.has("success") ? responseNode.get("success").asBoolean() : false;
					if (success) {
						Long caseUploadId = caseUploadedDocument.getCaseUploadedDocumentsId();

						CaseUploadedDocuments newCaseUploadedDocument = new CaseUploadedDocuments();
						BeanUtils.copyProperties(caseUploadedDocument, newCaseUploadedDocument);

						newCaseUploadedDocument.setCaseUploadedDocumentsId(null);
						newCaseUploadedDocument.setFileName(newFileName);
						newCaseUploadedDocument.setCaseDetails(newCaseDetails);
						newCaseUploadedDocument.setCreatedDate(new Date());
						newCaseUploadedDocument.setUpdatedDate(new Date());
						newCaseUploadedDocument = caseUploadedDocumentsService.saveNewRecord(newCaseUploadedDocument);

						uploadedDocNewOldMap.put(caseUploadId, newCaseUploadedDocument);
					}
				} catch (Exception e) {
					logger.error("Exception occurred while parsing file copy response : {}", e.getMessage());
				}
			}
		}

		List<CaseAssociatedDocuments> caseAssociatedDocuments = caseAssociatedDocumentsService
				.findByCaseDetails(oldCaseDetails);

		Map<Long, CaseAssociatedDocuments> associatedDocNewOldMap = new TreeMap<>();
		for (CaseAssociatedDocuments caseAssociatedDocument : caseAssociatedDocuments) {
			String fileName = caseAssociatedDocument.getFileName();
			String newFileName = fileName;
			if (fileName.contains(oldCaseNo)) {
				newFileName = newFileName.replace(oldCaseNo, newCaseNo);
			} else {
				newFileName = newCaseNo + fileName;
			}
			String response = apiService.sendDataToGet(copyFileUrl + fileName + "/" + newFileName);

			if (response != null) {
				try {
					JsonNode responseNode = mapper.readTree(response);
					boolean success = responseNode.has("success") ? responseNode.get("success").asBoolean() : false;
					if (success) {
						Long caseAssociationId = caseAssociatedDocument.getCaseAssociatedDocumentsId();

						CaseAssociatedDocuments newCaseAssociatedDocument = new CaseAssociatedDocuments();
						BeanUtils.copyProperties(caseAssociatedDocument, newCaseAssociatedDocument);

						newCaseAssociatedDocument.setCaseUploadedDocuments(uploadedDocNewOldMap
								.get(caseAssociatedDocument.getCaseUploadedDocuments().getCaseUploadedDocumentsId()));
						newCaseAssociatedDocument.setCaseAssociatedDocumentsId(null);
						newCaseAssociatedDocument.setFileName(newFileName);
						newCaseAssociatedDocument.setCaseDetails(newCaseDetails);
						newCaseAssociatedDocument.setCreatedDate(new Date());
						newCaseAssociatedDocument.setUpdatedDate(new Date());
						newCaseAssociatedDocument = caseAssociatedDocumentsService
								.saveNewRecord(newCaseAssociatedDocument);

						associatedDocNewOldMap.put(caseAssociationId, newCaseAssociatedDocument);
					}
				} catch (Exception e) {
					logger.error("Exception occurred while parsing file copy response : {}", e.getMessage());
				}
			}
		}

		List<CaseDataEntry> caseDataEntries = caseDataEntryService.findByCaseDetails(oldCaseDetails);
		for (CaseDataEntry caseDataEntry : caseDataEntries) {

			CaseDataEntry newCaseDataEntry = new CaseDataEntry();
			BeanUtils.copyProperties(caseDataEntry, newCaseDataEntry);

			newCaseDataEntry.setCaseDataEntryId(null);
			if (newCaseDataEntry.getCaseAssociatedDocuments() != null) {
				newCaseDataEntry.setCaseAssociatedDocuments(associatedDocNewOldMap
						.get(newCaseDataEntry.getCaseAssociatedDocuments().getCaseAssociatedDocumentsId()));
			}
			newCaseDataEntry.setCaseDetails(newCaseDetails);
			newCaseDataEntry.setClientMaster(newCaseClientDetails.getClientMaster());
			newCaseDataEntry.setSbuMaster(newCaseClientDetails.getSbuMaster());
			newCaseDataEntry.setPackageMaster(newCaseClientDetails.getPackageMaster());
			newCaseDataEntry.setCreatedDate(new Date());
			newCaseDataEntry.setUpdatedDate(new Date());
			caseDataEntryService.saveNewRecord(newCaseDataEntry);
		}

		return "Case Data Entry Cloning successful";
	}
}
