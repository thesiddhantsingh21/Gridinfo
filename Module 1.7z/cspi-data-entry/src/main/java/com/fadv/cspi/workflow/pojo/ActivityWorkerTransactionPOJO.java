package com.fadv.cspi.workflow.pojo;

import lombok.Data;

@Data
public class ActivityWorkerTransactionPOJO {

	private long activityWorkerTransactionId;
	private long activityWorkerId;
	private String key; // key (JWT Token)

	public ActivityWorkerTransactionPOJO() {
		super();
	}

	private String status;
}
