package com.fadv.cspi.entities.master;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.Type;

import com.fasterxml.jackson.databind.JsonNode;

import lombok.Data;

@Data
@Entity
public class CaseSpecificRecordDetail {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(nullable = false, updatable = false)
	private Long caseSpecificDetailId;

	private String caseSpecificRecordStatus;
	private String cbvUtvStatus;
	private String checkAllocationStatus;

	@ManyToOne
	@JoinColumn(name = "case_specific_id", nullable = false)
	private CaseSpecificInfo caseSpecificId;

	private Date checkCreatedDate;
	private Date checkDueDate;
	private String checkStatus;
	private String checkTat;
	private String componentName;

	@Type(type = "jsonb")
	@Column(columnDefinition = "jsonb", nullable = false)
	private JsonNode componentRecordField;

	private String entityLocation;
	private String functionalEntityName;
	private String instructionCheckId;
	private Boolean isCheckManual;
	private String onlineStatus;
	private String product;
	private String spocStatus;
	private String stellarStatus;
	private String suspectStatus;
	private Date updatedDate;
	private Integer userId;
	private String vendorStatus;
	private String wellknownStatus;

}
