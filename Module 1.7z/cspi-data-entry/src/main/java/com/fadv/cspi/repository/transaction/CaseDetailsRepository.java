package com.fadv.cspi.repository.transaction;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.fadv.cspi.component.data.pojo.ComponentScopingInterface;
import com.fadv.cspi.entities.transaction.CaseDetails;
import com.fadv.cspi.fullfilment.interfaces.CaseDetailsInterface;
import com.fadv.cspi.fullfilment.interfaces.CheckDetailInterface;
import com.fadv.cspi.interfaces.CaseDetailsResponseInterface;

@Repository
@Transactional
public interface CaseDetailsRepository extends JpaRepository<CaseDetails, Long> {

	@Query(value = "select cd.case_no as caseNo,ccc.cspi_check_id as cspiCheckId,ccc.request_id as requestId "
			+ "from {h-schema}cspi_check_creation ccc " + "left join {h-schema}case_details cd "
			+ "on ccc.case_details_id =cd.case_details_id " + "where ccc.cspi_check_id =:cspiCheckId "
			+ "order by ccc.check_id desc ", nativeQuery = true)
	List<ComponentScopingInterface> findCaseDetailsByCspiCheckId(String cspiCheckId);

	List<CaseDetails> findByCaseDetailsId(Long caseDetailsId);

	List<CaseDetails> findByCaseNo(String caseNo);

	List<CaseDetails> findByCrn(String crnNo);

	@Query(value = "select distinct cd.de_completed_by as deCompletedBy, cd.case_created_by as caseCreatedBy, cd.manual_scoping_completed_by as manualScopingCompletedBy,cd.case_details_id as caseDetailsId, cd.crn as crn, cd.case_no as caseNo, "
			+ "cd.case_creation_status as caseCreationStatus, cd.de_complete as deComplete,  "
			+ "cd.crn_creation_date as crnCreatedDate, cm.client_name as clientName, cd.request_date as requestDate, "
			+ "cd.case_type caseType, cd.is_manual_scoping as isManualScoping, cd.request_id as requestId, cd.reference_id as referenceId, cd.is_manual_scoping_completed as isManualScopingCompleted, "
			+ "cd.case_origin as caseOrigin,cd.candidate_name as candidateName,cd.client_reference as clientReference, "
			+ "sm.sbu_name as sbuName,pm.package_name as packageName " + "from {h-schema}case_details cd "
			+ "left join {h-schema}case_client_details ccd on cd.case_details_id = ccd.case_details_id "
			+ "left join {h-schema}client_master cm on ccd.client_master_id = cm.client_master_id "
			+ "left join {h-schema}sbu_master sm on ccd.sbu_master_id = sm.sbu_master_id "
			+ "left join {h-schema}package_master pm on pm.package_master_id = ccd.package_master_id "
			+ "where cd.case_no = :caseNo", nativeQuery = true)
	List<CaseDetailsResponseInterface> getCaseDetailsByCaseNo(String caseNo);

	@Query(value = "select distinct cd.case_details_id as caseDetailsId, cd.crn as crn, cd.case_no as caseNo, "
			+ "cd.case_creation_status as caseCreationStatus, cd.de_complete as deComplete, "
			+ "cd.de_completed_by as deCompletedBy, cd.case_created_by as caseCreatedBy, cd.manual_scoping_completed_by as manualScopingCompletedBy, "
			+ "cd.crn_creation_date as crnCreatedDate, cm.client_name as clientName, cd.request_date as requestDate, "
			+ "cd.case_type caseType, cd.is_manual_scoping as isManualScoping, cd.request_id as requestId, cd.reference_id as referenceId, cd.is_manual_scoping_completed as isManualScopingCompleted, "
			+ "cd.case_origin as caseOrigin,cd.candidate_name as candidateName,cd.client_reference as clientReference, "
			+ "sm.sbu_name as sbuName,pm.package_name as packageName " + "from {h-schema}case_details cd "
			+ "left join {h-schema}case_client_details ccd on cd.case_details_id = ccd.case_details_id "
			+ "left join {h-schema}client_master cm on ccd.client_master_id = cm.client_master_id "
			+ "left join {h-schema}sbu_master sm on ccd.sbu_master_id = sm.sbu_master_id "
			+ "left join {h-schema}package_master pm on pm.package_master_id = ccd.package_master_id "
			+ "where cd.crn = :crn", nativeQuery = true)
	List<CaseDetailsResponseInterface> getCaseDetailsByCrn(String crn);

	@Query(value = "select distinct cd.case_details_id as caseDetailsId, cd.crn as crn, cd.case_no as caseNo, "
			+ "cd.case_creation_status as caseCreationStatus, cd.de_complete as deComplete, "
			+ "cd.de_completed_by as deCompletedBy, cd.case_created_by as caseCreatedBy, cd.manual_scoping_completed_by as manualScopingCompletedBy, "
			+ "cd.crn_creation_date as crnCreatedDate, cm.client_name as clientName, "
			+ "cd.request_date as requestDate, cd.case_type caseType, cd.is_manual_scoping as isManualScoping, cd.request_id as requestId, cd.reference_id as referenceId, cd.is_manual_scoping_completed as isManualScopingCompleted, "
			+ "cd.case_origin as caseOrigin,cd.candidate_name as candidateName,cd.client_reference as clientReference, "
			+ "sm.sbu_name as sbuName,pm.package_name as packageName "
			+ "from {h-schema}case_details cd, {h-schema}client_master cm, {h-schema}case_client_details ccd, "
			+ "{h-schema}sbu_master sm, {h-schema}package_master pm "
			+ "where cd.case_details_id = ccd.case_details_id and ccd.client_master_id = cm.client_master_id and "
			+ "ccd.sbu_master_id = sm.sbu_master_id and pm.package_master_id = ccd.package_master_id "
			+ "and CAST(DATE(cd.crn_creation_date) AS VARCHAR) BETWEEN SYMMETRIC :fromDate AND :toDate "
			+ "and CAST(DATE(cd.request_date) AS VARCHAR) BETWEEN SYMMETRIC :fromDate AND :toDate "
			+ "and case when :clientName != '' then lower(cm.client_name) like lower(:clientName) else true end "
			+ "and case when :crnNo != '' then cd.crn = :crnNo else true end "
			+ "and case when :requestId != '' then cd.request_id = :requestId else true end "
			+ "and case when :referenceId != '' then cd.reference_id = :referenceId else true end "
			+ "and case when :caseCreationStatus != '' then lower(cd.case_creation_status) "
			+ "like lower(:caseCreationStatus) else true end", nativeQuery = true)
	List<CaseDetailsResponseInterface> getCaseDetailsByFilter(String fromDate, String toDate, String clientName,
			String crnNo, String caseCreationStatus, String requestId, String referenceId);

	@Modifying(clearAutomatically = true)
	@Query(value = "UPDATE {h-schema}case_details SET move_to_workflow = true "
			+ "WHERE case_details_id = (SELECT case_details_id FROM {h-schema}case_details  "
			+ "WHERE de_complete =true and move_to_workflow = false order by de_completed_time asc  LIMIT 1 FOR UPDATE SKIP LOCKED) RETURNING crn", nativeQuery = true)
	List<String> getAndUpdateDeCompleteData();

	@Query(value = "select cd.crn, CAST(cd.case_more_info as VARCHAR) caseMoreInfo, "
			+ "CAST(row_to_json((SELECT d FROM (SELECT ccd.client_master_id as \"clientId\", "
			+ "ccd.sbu_master_id as \"sbuId\", CAST(DATE(cd.crn_creation_date) AS VARCHAR) \"crnCreatedDate\", "
			+ "ccd.package_master_id as \"packageId\", cd.crn as \"crnNo\", null as \"scrnCreatedDate\", "
			+ "cd.case_no as \"caseNo\", cd.case_no as \"TxLabel\", null as \"checkId\", "
			+ "cd.case_details_id as \"caseUUID\", cd.case_type as \"caseType\") d)) AS VARCHAR) caseReference, "
			+ "CAST(row_to_json((select d from (select '' as \"Type of Check\", "
			+ "pm.package_name as \"Package Name\", 'Completed' as \"Request Status\", ccd.contact_date as \"Contact Date\", "
			+ "ccd.case_origin as \"Case Origin\", case when etm.email_to_name is null then '' else etm.email_to_name end \"Email To\", "
			+ "ccd.first_name as \"Candidate's First Name\", "
			+ "ccd.official_email as \"Official Email Address\", CAST(ccd.start_date AS VARCHAR) \"Start Date\", "
			+ "ccd.mobile_number as \"Number\", ccd.srt as \"SRT\", ccd.mobile_mandatory as \"Is Mobile Number Mandatory?\", "
			+ "cd.remarks as \"Remarks\", cm.client_name as \"Client Name(Full Business name)\", "
			+ "stm.type_name as \"Subject Type\", cd.is_duplicate_case as \"Is Duplicate Case\", "
			+ "sm.sbu_name as \"SBU\", ccd.loa_submitted as \"LOA Submitted\", ccd.email as \"Personal Email Address\", "
			+ "ccd.last_name as \"Candidate's Last Name\", 'PACKAGE_TYPE' as \"Package Type\", "
			+ "sdm.subject_name as \"Subject Details to be Entered By\", "
			+ "case when etm2.email_template is null then '' else etm2.email_template end \"Email Template\", "
			+ "ccd.cost_code as \"Client Cost Code\", '' as \"Client Reference #\", "
			+ "ccd.middle_name as \"Candidate's Middle Name\", "
			+ "CAST(ccd.case_date AS VARCHAR) \"Case Date\", ccd.dob \"Date of Birth\", "
			+ "ccd.mobile_country_code as \"Country Code\", '' as \"Candidate Auhorization Letter\""
			+ ") d)) as VARCHAR) caseDetails from {h-schema}case_client_details ccd "
			+ "inner join {h-schema}case_details cd on ccd.case_details_id = cd.case_details_id "
			+ "left join {h-schema}client_master cm on ccd.client_master_id = cm.client_master_id "
			+ "left join {h-schema}sbu_master sm on ccd.sbu_master_id = sm.sbu_master_id "
			+ "left join {h-schema}package_master pm on ccd.package_master_id = pm.package_master_id "
			+ "left join {h-schema}subject_detail_master sdm on ccd.subject_detail_master_id = sdm.subject_detail_master_id "
			+ "left join {h-schema}subject_type_master stm on ccd.subject_type_master_id = stm.subject_type_master_id "
			+ "left join {h-schema}email_to_master etm on ccd.email_to_master_id = etm.email_to_master_id "
			+ "left join {h-schema}email_template_master etm2 on ccd.email_template_master_id = etm2.email_template_master_id "
			+ "where cd.case_details_id = :caseDetailsId", nativeQuery = true)
	List<CaseDetailsInterface> getCaseDetailsInterface(Long caseDetailsId);

	@Modifying(clearAutomatically = true)
	@Query(value = "Select crn from {h-schema}case_details "
			+ "WHERE de_complete =true and move_to_workflow = false ", nativeQuery = true)
	List<String> getAndUpdateAllDeCompleteData();
	
//	@Query(value = "select cast(array_agg(cspi_check_id) as varchar) checks,case_no  "
//			+ "from {h-schema}cspi_check_creation ccc " + "left join {h-schema}case_details cd "
//			+ "on ccc.case_details_id =cd.case_details_id " + "where cspi_check_id is not null "
//			+ "group by case_no ", nativeQuery = true)
//	List<CheckIdRequestPOJO> findCheckDetails();
	@Query(value = "select cast(array_agg(cspi_check_id) as varchar) checks,case_no as caseNo  "
			+ "from {h-schema}cspi_check_creation ccc " + "left join {h-schema}case_details cd "
			+ "on ccc.case_details_id =cd.case_details_id where cspi_check_id is not null "
			+ "and case when (:startDateStr != '' and :endDateStr != '') then (CAST(DATE(cd.request_date) AS VARCHAR) BETWEEN SYMMETRIC :startDateStr AND :endDateStr) else true end"
			+ " group by case_no ", nativeQuery = true)
	List<CheckDetailInterface> findCheckDetails(String startDateStr, String endDateStr);
//	@Query(value = "select *  "
//			+ "from {h-schema}cspi_check_creation ccc " + "left join {h-schema}case_details cd "
//			+ "on ccc.case_details_id =cd.case_details_id where cspi_check_id is not null "
//			+ " and case when (:startDateStr != '' and :endDateStr != '') then (CAST(DATE(wdt.request_timestamp) AS VARCHAR) BETWEEN SYMMETRIC :startDateStr AND :endDateStr) else true end", nativeQuery = true)
//	List<CspiCheckCreation> findCheckDetailsData(String startDateStr, String endDateStr);
}
