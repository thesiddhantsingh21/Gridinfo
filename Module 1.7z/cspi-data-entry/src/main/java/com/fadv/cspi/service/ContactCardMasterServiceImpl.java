package com.fadv.cspi.service;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fadv.cspi.entities.master.CityMaster;
import com.fadv.cspi.entities.master.ComponentMaster;
import com.fadv.cspi.entities.master.ContactCardMaster;
import com.fadv.cspi.exception.ServiceException;
import com.fadv.cspi.interfaces.ContactCardMasterInterface;
import com.fadv.cspi.pojo.request.ContactCardMasterRequestPOJO;
import com.fadv.cspi.pojo.response.ContactCardMasterResponsePOJO;
import com.fadv.cspi.repository.master.ContactCardMasterRepository;
import com.fadv.cspi.userdetail.pojo.UserDetailPOJO;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

@Service
public class ContactCardMasterServiceImpl implements ContactCardMasterService {

	private static final String ERROR_CODE_404 = "ERROR_CODE_404";

	private static final String NOT_APPLICABLE = "NOT_APPLICABLE";

	private static final String CONTACT_CARD_MASTER = "contact_card_master";

	private static final Logger logger = LoggerFactory.getLogger(ContactCardMasterServiceImpl.class);

	@Autowired
	private ContactCardMasterRepository contactCardMasterRepository;

	@Autowired
	private ComponentMasterService componentMasterService;

	@Autowired
	private CityMasterService cityMasterService;

	@Autowired
	private ApiService apiService;

	private ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES,
			false);

	@Override
	public ContactCardMaster getContactCardByAkaName(String akaName) {

		List<ContactCardMaster> contactCardMasters = contactCardMasterRepository
				.findByAkaNameIgnoreCaseAndActive(akaName, true);
		if (CollectionUtils.isNotEmpty(contactCardMasters)) {
			return contactCardMasters.get(0);
		}
		return null;
	}

	@Override
	public List<ContactCardMasterInterface> getUniversityEmploymentName(String searchStr, String componentName) {
		if (searchStr.length() < 5) {
			return new ArrayList<>();
		}
		searchStr = searchStr + "%";
		return contactCardMasterRepository.getContactCardMasterBySearchStr(searchStr, componentName);
	}

	@Override
	public ContactCardMasterResponsePOJO createNewContactCardMaster(
			ContactCardMasterRequestPOJO contactCardMasterRequestPOJO, UserDetailPOJO userDetailPOJO, String tokenId)
			throws ServiceException {
		String componentName = contactCardMasterRequestPOJO.getComponentName();
		String cityName = contactCardMasterRequestPOJO.getCityName();
		String stateName = contactCardMasterRequestPOJO.getStateName();
		String countryName = contactCardMasterRequestPOJO.getCountryName();
		String akaName = contactCardMasterRequestPOJO.getAkaName();
		int avl = contactCardMasterRequestPOJO.getAvl();
		int mrl = contactCardMasterRequestPOJO.getMrl();
		int costApproval = contactCardMasterRequestPOJO.getCostApproval();
		int stellar = contactCardMasterRequestPOJO.getStellar();
		int singleSpoc = contactCardMasterRequestPOJO.getSingleSpoc();
		int bulkSpoc = contactCardMasterRequestPOJO.getBulkSpoc();
		int cbv = contactCardMasterRequestPOJO.getCbv();
		int utv = contactCardMasterRequestPOJO.getUtv();
		int suspect = contactCardMasterRequestPOJO.getSuspect();
		int i4v = contactCardMasterRequestPOJO.getI4v();
		String existingUniversityEmploymentCollege = contactCardMasterRequestPOJO
				.getExistingUniversityEmploymentCollege();
		String universityEmploymentName = contactCardMasterRequestPOJO.getUniversityEmploymentName();
		String areaLocalityName = contactCardMasterRequestPOJO.getAreaLocalityName();
		String enterAkaName = contactCardMasterRequestPOJO.getEnterAkaName();
		ObjectNode additionalFields = contactCardMasterRequestPOJO.getAdditionalFields();

		List<ComponentMaster> componentMasters = componentMasterService.findByComponentName(componentName);
		List<CityMaster> cityMasters = cityMasterService.findByCityNameAndCountryNameAndStateName(cityName, countryName,
				stateName);

		if (CollectionUtils.isNotEmpty(componentMasters) && CollectionUtils.isNotEmpty(cityMasters)) {
			List<ContactCardMaster> contactCardMasters = contactCardMasterRepository
					.findByUniversityEmploymentNameIgnoreCaseAndAkaNameIgnoreCaseAndComponentMasterAndActive(
							universityEmploymentName, akaName, componentMasters.get(0), true);
			JsonNode prevJson = mapper.createObjectNode();
			ContactCardMaster contactCardMaster = new ContactCardMaster();

			if (CollectionUtils.isNotEmpty(contactCardMasters)) {
				contactCardMaster = contactCardMasters.get(0);
				prevJson = mapper.convertValue(contactCardMaster, JsonNode.class);
			}
			logger.info("contact_card_master - ADD - PREV : {}", prevJson);
			if (contactCardMaster.getActive() != null && contactCardMaster.getActive()) {
				throw new ServiceException("Data already exists", "DATA_ALREADY_EXIST",
						convertContactCardMasterForResponse(contactCardMaster));
			}

			contactCardMaster.setActive(true);
			contactCardMaster.setAkaName(akaName);
			contactCardMaster.setAvl(avl);
			contactCardMaster.setBulkSpoc(bulkSpoc);
			contactCardMaster.setCbv(cbv);
			contactCardMaster.setCityMaster(cityMasters.get(0));
			contactCardMaster.setComponentMaster(componentMasters.get(0));
			contactCardMaster.setCostApproval(costApproval);
			contactCardMaster.setCountryMaster(cityMasters.get(0).getCountryMaster());
			contactCardMaster.setMrl(mrl);
			contactCardMaster.setSingleSpoc(singleSpoc);
			contactCardMaster.setStateMaster(cityMasters.get(0).getStateMaster());
			contactCardMaster.setStellar(stellar);
			contactCardMaster.setSuspect(suspect);
			contactCardMaster.setUtv(utv);
			contactCardMaster.setI4v(i4v);
			contactCardMaster.setExistingUniversityEmploymentCollege(existingUniversityEmploymentCollege);
			contactCardMaster.setUniversityEmploymentName(universityEmploymentName);
			contactCardMaster.setAreaLocalityName(areaLocalityName);
			contactCardMaster.setEnterAkaName(enterAkaName);
			if (StringUtils.equalsIgnoreCase(componentMasters.get(0).getComponentName(), "Employment")) {
				contactCardMaster.setFadvRelationship("NON_SPOC");
				contactCardMaster.setMandatoryDocuments(NOT_APPLICABLE);
				contactCardMaster.setPhoneType("BOARD_LINE");
				contactCardMaster.setModeOfInitiation("OTHER");
				contactCardMaster.setEntityType("INSTITUTE");
			}
			if (StringUtils.equalsIgnoreCase(componentMasters.get(0).getComponentName(), "Education")) {
				contactCardMaster.setFadvRelationship("OTHERS");
				contactCardMaster.setMandatoryDocuments(NOT_APPLICABLE);
				contactCardMaster.setPhoneType("PHONE");
				contactCardMaster.setModeOfInitiation("OTHER");
				contactCardMaster.setEntityType("UNIVERSITY");
			}
			contactCardMaster.setAdditionalFields(additionalFields);
			contactCardMaster = contactCardMasterRepository.save(contactCardMaster);

			JsonNode newJson = mapper.convertValue(contactCardMaster, JsonNode.class);
			logger.info("contact_card_master - ADD - NEW : {}", newJson);
			apiService.addAuditLog(CONTACT_CARD_MASTER, prevJson, newJson, userDetailPOJO, "ADD", tokenId);
			return convertContactCardMasterForResponse(contactCardMaster);
		}
		throw new ServiceException("component_name or city_name not found in existing tables", ERROR_CODE_404);
	}

	private ContactCardMasterResponsePOJO convertContactCardMasterForResponse(ContactCardMaster contactCardMaster) {
		ContactCardMasterResponsePOJO contactCardMasterResponsePOJO = new ContactCardMasterResponsePOJO();
		contactCardMasterResponsePOJO.setContactCardMasterId(contactCardMaster.getContactCardMasterId());
		contactCardMasterResponsePOJO.setAkaName(contactCardMaster.getAkaName());
		contactCardMasterResponsePOJO.setAvl(contactCardMaster.getAvl());
		contactCardMasterResponsePOJO.setBulkSpoc(contactCardMaster.getBulkSpoc());
		contactCardMasterResponsePOJO.setCbv(contactCardMaster.getCbv());
		contactCardMasterResponsePOJO.setCityMasterId(contactCardMaster.getCityMaster().getCityMasterId());
		contactCardMasterResponsePOJO.setCityName(contactCardMaster.getCityMaster().getCityName());
		contactCardMasterResponsePOJO
				.setComponentMasterId(contactCardMaster.getComponentMaster().getComponentMasterId());
		contactCardMasterResponsePOJO.setComponentName(contactCardMaster.getComponentMaster().getComponentName());
		contactCardMasterResponsePOJO.setContactCardMasterId(contactCardMaster.getContactCardMasterId());
		contactCardMasterResponsePOJO.setCostApproval(contactCardMaster.getCostApproval());
		contactCardMasterResponsePOJO
				.setCountryMasterId(contactCardMaster.getCityMaster().getCountryMaster().getCountryMasterId());
		contactCardMasterResponsePOJO
				.setCountryName(contactCardMaster.getCityMaster().getCountryMaster().getCountryName());
		contactCardMasterResponsePOJO.setMrl(contactCardMaster.getMrl());
		contactCardMasterResponsePOJO.setSingleSpoc(contactCardMaster.getSingleSpoc());
		contactCardMasterResponsePOJO
				.setStateMasterId(contactCardMaster.getCityMaster().getStateMaster().getStateMasterId());
		contactCardMasterResponsePOJO.setStateName(contactCardMaster.getCityMaster().getStateMaster().getStateName());
		contactCardMasterResponsePOJO.setStellar(contactCardMaster.getStellar());
		contactCardMasterResponsePOJO.setSuspect(contactCardMaster.getSuspect());
		contactCardMasterResponsePOJO.setUtv(contactCardMaster.getUtv());
		contactCardMasterResponsePOJO.setI4v(contactCardMaster.getI4v());
		contactCardMasterResponsePOJO
				.setExistingUniversityEmploymentCollege(contactCardMaster.getExistingUniversityEmploymentCollege());
		contactCardMasterResponsePOJO.setUniversityEmploymentName(contactCardMaster.getUniversityEmploymentName());
		contactCardMasterResponsePOJO.setAreaLocalityName(contactCardMaster.getAreaLocalityName());
		contactCardMasterResponsePOJO.setEnterAkaName(contactCardMaster.getEnterAkaName());
		contactCardMasterResponsePOJO.setFadvRelationship(contactCardMaster.getFadvRelationship());
		contactCardMasterResponsePOJO.setMandatoryDocuments(contactCardMaster.getMandatoryDocuments());
		contactCardMasterResponsePOJO.setPhoneType(contactCardMaster.getPhoneType());
		contactCardMasterResponsePOJO.setModeOfInitiation(contactCardMaster.getModeOfInitiation());
		contactCardMasterResponsePOJO.setEntityType(contactCardMaster.getEntityType());
		contactCardMasterResponsePOJO.setAdditionalFields(contactCardMaster.getAdditionalFields());
		contactCardMasterResponsePOJO.setOrgId(contactCardMaster.getOrgId());
		return contactCardMasterResponsePOJO;
	}

	@Override
	public List<ObjectNode> getContactCardDetailsBySearch(String componentName, String akaName) {

		if (StringUtils.isNotEmpty(akaName) && StringUtils.length(akaName) >= 5) {
			akaName = akaName + "%";
			return mapper.convertValue(contactCardMasterRepository.getContactCardMasterByFIlter(akaName, componentName),
					new TypeReference<List<ObjectNode>>() {
					});
		} else {
			return new ArrayList<>();
		}
	}
}
