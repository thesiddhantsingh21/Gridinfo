package com.fadv.cspi.pojo;

import java.util.Date;

import lombok.Data;

@Data
public class ConvertedDocumentsResponsePOJO {

	private long caseUploadedDocumentsId;

	private String transactionId;

	private String fileName;

	private String filePath;

	private String fileUrl;

	private String originalName;

	private Long fileSize;

	private String fileExtension;

	private String contentType;

	private String errorLog;

	private int pageCount;

	private String filePathName;

	private String uploadType;

	private String fileStatus;

	private String requestId;

	private long caseDetailsId;

	private Date updatedDate;

	private Date createdDate;

	private String updatedByUser;

}
