package com.fadv.cspi.service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fadv.cspi.entities.master.SubjectDetailMaster;
import com.fadv.cspi.entities.master.SubjectTypeMaster;
import com.fadv.cspi.entities.transaction.CaseDetails;
import com.fadv.cspi.entities.transaction.CspiCheckCreation;
import com.fadv.cspi.exception.ServiceException;
import com.fadv.cspi.fullfilment.interfaces.CaseDetailsInterface;
import com.fadv.cspi.fullfilment.pojo.CaseDetailsDocValPOJO;
import com.fadv.cspi.fullfilment.pojo.CasePOJO;
import com.fadv.cspi.fullfilment.pojo.CaseReferencePOJO;
import com.fadv.cspi.interfaces.CaseDetailsResponseInterface;
import com.fadv.cspi.pojo.CaseSearchPOJO;
import com.fadv.cspi.pojo.request.CaseSearchCriteriaPOJO;
import com.fadv.cspi.pojo.response.CaseDetailsResponsePOJO;
import com.fadv.cspi.repository.transaction.CaseDetailsRepository;
import com.fadv.cspi.repository.transaction.CspiCheckCreationRepository;
import com.fadv.cspi.utility.ConversionUtility;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

@Service
public class CaseDetailsServiceImpl implements CaseDetailsService {

	private static final String ERROR_CODE_404 = "ERROR_CODE_404";

	@Autowired
	private CaseDetailsRepository caseDetailsRepository;

	@Autowired
	CspiCheckCreationRepository cspiCheckCreationRepository;

	private ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES,
			false);

	private static final Logger logger = LoggerFactory.getLogger(CaseDetailsServiceImpl.class);

	@Override
	public CaseDetails findByCaseDetailsId(Long caseId) throws ServiceException {

		Optional<CaseDetails> caseDetailsOptional = caseDetailsRepository.findById(caseId);
		if (caseDetailsOptional.isPresent()) {
			return caseDetailsOptional.get();
		}

		throw new ServiceException("Case Details not found for given case id", ERROR_CODE_404);
	}

	@Override
	public CaseDetails getByCaseDetailsId(Long caseId) {

		Optional<CaseDetails> caseDetailsOptional = caseDetailsRepository.findById(caseId);
		if (caseDetailsOptional.isPresent()) {
			return caseDetailsOptional.get();
		}
		return null;
	}

	@Override
	public CaseDetails saveCaseDetails(CaseDetails caseDetails) {

		return caseDetailsRepository.save(caseDetails);
	}

	@Override
	public CaseDetailsResponsePOJO getCaseDetailsByCaseDetailsId(Long caseId) throws ServiceException {

		CaseDetails caseDetails = findByCaseDetailsId(caseId);
		String crNo = caseDetails.getCrn();

		if (crNo == null || StringUtils.isEmpty(crNo) || StringUtils.equalsIgnoreCase(crNo, "pending")) {
			throw new ServiceException("Invalid CRN", ERROR_CODE_404);
		}
		CaseDetailsResponsePOJO caseDetailsResponsePOJO = mapper.convertValue(caseDetails,
				CaseDetailsResponsePOJO.class);
		SubjectDetailMaster subjectDetailMaster = caseDetails.getSubjectDetailMaster();
		SubjectTypeMaster subjectTypeMaster = caseDetails.getSubjectTypeMaster();
		if (subjectDetailMaster != null) {
			caseDetailsResponsePOJO.setSubjectDetailMasterId(subjectDetailMaster.getSubjectDetailMasterId());
		}
		if (subjectTypeMaster != null) {
			caseDetailsResponsePOJO.setSubjectTypeMasterId(subjectTypeMaster.getSubjectTypeMasterId());
		}
		return caseDetailsResponsePOJO;
	}

	@Override
	public List<CaseDetailsResponseInterface> getCaseDetailsUsingFilters(
			CaseSearchCriteriaPOJO caseSearchCriteriaPOJO) {

		String caseNo = caseSearchCriteriaPOJO.getCaseNo() != null ? caseSearchCriteriaPOJO.getCaseNo() : "";
		String crnNo = caseSearchCriteriaPOJO.getCrnNo() != null ? caseSearchCriteriaPOJO.getCrnNo() : "";
		if (StringUtils.isNotEmpty(caseNo)) {
			return caseDetailsRepository.getCaseDetailsByCaseNo(caseNo);
		} else if (StringUtils.isNotEmpty(crnNo)) {
			return caseDetailsRepository.getCaseDetailsByCrn(crnNo);
		} else {
			Date startDate = caseSearchCriteriaPOJO.getStartDate() != null ? caseSearchCriteriaPOJO.getStartDate()
					: new Date();
			Date endDate = caseSearchCriteriaPOJO.getEndDate() != null ? caseSearchCriteriaPOJO.getEndDate()
					: new Date();

			String caseCreationStatus = caseSearchCriteriaPOJO.getCaseCreationStatus() != null
					? caseSearchCriteriaPOJO.getCaseCreationStatus()
					: "";
			String clientName = caseSearchCriteriaPOJO.getClientName() != null ? caseSearchCriteriaPOJO.getClientName()
					: "";
			String requestId = caseSearchCriteriaPOJO.getRequestId() != null ? caseSearchCriteriaPOJO.getRequestId()
					: "";
			String referenceId = caseSearchCriteriaPOJO.getReferenceId() != null
					? caseSearchCriteriaPOJO.getReferenceId()
					: "";
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
			String startDateStr = simpleDateFormat.format(startDate);
			String endDateStr = simpleDateFormat.format(endDate);

			return caseDetailsRepository.getCaseDetailsByFilter(startDateStr, endDateStr, clientName, crnNo,
					caseCreationStatus, requestId, referenceId);

		}
	}

	@Override
	public List<String> getDeCompletedCrns() {
		return caseDetailsRepository.getAndUpdateDeCompleteData();
	}

	@Override
	public CaseDetails findByCaseNo(String caseNo) throws ServiceException {
		List<CaseDetails> caseDetails = caseDetailsRepository.findByCaseNo(caseNo);
		if (CollectionUtils.isNotEmpty(caseDetails)) {
			return caseDetails.get(0);
		}
		throw new ServiceException("Invalid case number provided.", "ERROR_CODE_400");
	}

	@Override
	public CasePOJO getCaseDetailsJsonDataByCrn(Long caseDetailsId) throws JsonProcessingException {
		List<CaseDetailsInterface> caseDetailsInterfaces = caseDetailsRepository.getCaseDetailsInterface(caseDetailsId);
		if (CollectionUtils.isEmpty(caseDetailsInterfaces)) {
			return null;
		}
		CaseDetailsInterface caseDetailsInterface = caseDetailsInterfaces.get(0);
		String caseMoreInfoStr = caseDetailsInterface.getCaseMoreInfo() != null ? caseDetailsInterface.getCaseMoreInfo()
				: "{}";
		String caseDetailsStr = caseDetailsInterface.getCaseDetails() != null ? caseDetailsInterface.getCaseDetails()
				: "{}";
		String caseRefStr = caseDetailsInterface.getCaseReference() != null ? caseDetailsInterface.getCaseReference()
				: "{}";
		JsonNode caseMoreInfo = mapper.readValue(caseMoreInfoStr, JsonNode.class);
		JsonNode caseDetailsNode = mapper.readValue(caseDetailsStr, JsonNode.class);

		ObjectNode newCaseDetailsNode = mapper.createObjectNode();
		List<String> caseDetailsKeys = ConversionUtility.findKeys(caseDetailsNode);

		for (String caseKey : caseDetailsKeys) {
			if (caseDetailsNode.get(caseKey).isTextual()) {
				String dataNew = ConversionUtility.convertDate(caseDetailsNode.get(caseKey).asText());
				newCaseDetailsNode.put(caseKey, dataNew);
			} else {
				newCaseDetailsNode.set(caseKey, caseDetailsNode.get(caseKey));
			}
		}

		logger.info("caseDetailsNode : {}", newCaseDetailsNode);
		CaseDetailsDocValPOJO caseDetailsDocValPOJO = mapper.convertValue(newCaseDetailsNode,
				CaseDetailsDocValPOJO.class);
		CaseReferencePOJO caseReferencePOJO = mapper.readValue(caseRefStr, CaseReferencePOJO.class);

		CasePOJO casePOJO = new CasePOJO();
		casePOJO.setCaseMoreInfo(caseMoreInfo);
		casePOJO.setCaseDetails(caseDetailsDocValPOJO);
		casePOJO.setCaseReference(caseReferencePOJO);
		casePOJO.setClientSpecificFields(mapper.createObjectNode());
		casePOJO.setRemarks("");
		casePOJO.setCrn(caseDetailsInterface.getCrn());

		return casePOJO;
	}

	@Override
	public List<String> getAllDeCompletedCrns() {
		return caseDetailsRepository.getAndUpdateAllDeCompleteData();
	}

	@Override
	public List<CaseDetails> getCasesBySearchCriteria(CaseSearchPOJO caseSearchPOJO) throws ServiceException {
		logger.info("Case Search POJO:{}", caseSearchPOJO);
		String caseNo = caseSearchPOJO.getCaseNo() != null ? caseSearchPOJO.getCaseNo() : "";
		String crnNo = caseSearchPOJO.getCrnNo() != null ? caseSearchPOJO.getCrnNo() : "";
		List<CaseDetails> caseCreation = new ArrayList<>();
		if (StringUtils.isNotEmpty(caseNo)) {
			caseCreation = caseDetailsRepository.findByCaseNo(caseNo);
		} else if (StringUtils.isNotEmpty(crnNo)) {
			caseCreation = caseDetailsRepository.findByCrn(crnNo);
		}
		if (caseCreation.isEmpty()) {
			throw new ServiceException("Data not found for given caseNo or crnNo");
		}
		List<CspiCheckCreation> cspiCheckCreationList = cspiCheckCreationRepository
				.findByCaseDetailsId(caseCreation.get(0).getCaseDetailsId());
		if (cspiCheckCreationList.isEmpty()) {
			throw new ServiceException("case is in-progress");
		}
		return caseCreation;
	}

}
