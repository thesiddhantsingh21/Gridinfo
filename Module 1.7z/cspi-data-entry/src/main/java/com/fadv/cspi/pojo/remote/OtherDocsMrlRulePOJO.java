package com.fadv.cspi.pojo.remote;

import javax.validation.constraints.Positive;

import lombok.Data;

@Data
public class OtherDocsMrlRulePOJO {

	@Positive
	private long caseDetailsId;

	@Positive
	private long documentMasterId;
}
