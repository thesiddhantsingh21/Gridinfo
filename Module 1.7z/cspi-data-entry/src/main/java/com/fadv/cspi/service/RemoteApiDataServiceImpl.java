package com.fadv.cspi.service;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fadv.cspi.exception.ServiceException;
import com.fadv.cspi.pojo.RemoteApiPOJO;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

@Service
public class RemoteApiDataServiceImpl implements RemoteApiDataService {

	private static final String SEARCH_STRING = "searchString";

	private static final String COMPONENT_NAME = "componentName";

	private static final String ERROR_CODE_404 = "ERROR_CODE_404";

	private static final String QUALIFICATION_LEVEL = "qualificationLevel";

	@Autowired
	private CityMasterService cityMasterService;

	@Autowired
	private CountryMasterService countryMasterService;

	@Autowired
	private StateMasterService stateMasterService;

	@Autowired
	private QualificationLevelMasterService qualificationLevelMasterService;

	@Autowired
	private QualificationMasterService qualificationMasterService;

	@Autowired
	private ContactCardMasterService contactCardMasterService;

	ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

	@Override
	public List<ObjectNode> getRemoteApiData(RemoteApiPOJO remoteApiPOJO) throws ServiceException {

		String primaryKey = remoteApiPOJO.getPrimaryKey();

		if (StringUtils.equalsIgnoreCase(primaryKey, "country")) {
			return countryMasterService.getCountryList();
		} else if (StringUtils.equalsIgnoreCase(primaryKey, "state")) {
			ObjectNode inputs = remoteApiPOJO.getInput() != null ? remoteApiPOJO.getInput() : mapper.createObjectNode();
			String countryName = inputs.has(SEARCH_STRING) ? inputs.get(SEARCH_STRING).asText() : "";
			return stateMasterService.getStateListByCountry(countryName);
		} else if (StringUtils.equalsIgnoreCase(primaryKey, "city")) {
			ObjectNode inputs = remoteApiPOJO.getInput() != null ? remoteApiPOJO.getInput() : mapper.createObjectNode();
			String stateName = inputs.has(SEARCH_STRING) ? inputs.get(SEARCH_STRING).asText() : "";
			return cityMasterService.getCityListByStateName(stateName);
		} else if (StringUtils.equalsIgnoreCase(primaryKey, "akaName")) {
			ObjectNode inputs = remoteApiPOJO.getInput() != null ? remoteApiPOJO.getInput() : mapper.createObjectNode();
			String componentName = inputs.has(COMPONENT_NAME) ? inputs.get(COMPONENT_NAME).asText() : "";
			String searchString = inputs.has(SEARCH_STRING) ? inputs.get(SEARCH_STRING).asText() : "";
			return contactCardMasterService.getContactCardDetailsBySearch(componentName, searchString);
		} else if (StringUtils.equalsIgnoreCase(primaryKey, "qualification")) {
			ObjectNode inputs = remoteApiPOJO.getInput() != null ? remoteApiPOJO.getInput() : mapper.createObjectNode();
			String qualificationLevel = inputs.has(SEARCH_STRING) ? inputs.get(SEARCH_STRING).asText() : "";
			return qualificationMasterService.getQualification(qualificationLevel);
		} else if (StringUtils.equalsIgnoreCase(primaryKey, QUALIFICATION_LEVEL)) {
			return qualificationLevelMasterService.getQualificationLevel();
		}
		throw new ServiceException("primary key field is not valid", ERROR_CODE_404);
	}

}
