package com.fadv.cspi.component.data.pojo;

import lombok.Data;

@Data
public class QuestionCheckDataResponsePOJO {
	Long qlobalQuestionId;
	String questionName;
	String questionScope;
	String questionType;
	String componentName;
	String productName;
	String formLabel;
	Boolean mandatory;
//	String mappedField;
	String answere;
}
