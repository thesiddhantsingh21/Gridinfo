package com.fadv.cspi.controller;

import javax.servlet.http.HttpServletRequest;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fadv.cspi.exception.ServiceException;
import com.fadv.cspi.pojo.response.ResponseStatusPOJO;
import com.fadv.cspi.service.FinalDataEntryService;
import com.fadv.cspi.userdetail.pojo.UserDetailPOJO;

import io.swagger.annotations.ApiOperation;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/india/")
public class FinalDataEntryController {

	private static final String SUCCESS_CODE_200 = "SUCCESS_CODE_200";

	private static final Logger logger = LoggerFactory.getLogger(FinalDataEntryController.class);

	private static final String USER_ID = "userId";

	private static final String USER_NAME = "userName";

	@Autowired
	FinalDataEntryService finalDataEntryService;

	@ApiOperation(value = "This API is used for submitting final data entry", response = ResponseStatusPOJO.class)
	@GetMapping(path = "final-de-submit/{caseId}", produces = "application/json")
	public ResponseEntity<ResponseStatusPOJO> getCaseDetails(HttpServletRequest request,
			@Positive @PathVariable(value = "caseId") long caseId,
			@NotNull @RequestParam("validate") boolean validate) {
		logger.info("Case id to final data entry submit : {}", caseId);

		String userName = request.getAttribute(USER_NAME).toString().isEmpty() ? USER_NAME
				: request.getAttribute(USER_NAME).toString();
		String userId = request.getAttribute(USER_ID).toString().isEmpty() ? USER_ID
				: request.getAttribute(USER_ID).toString();
		UserDetailPOJO userDetailPOJO = new UserDetailPOJO(userName, userId);

		try {
			return new ResponseEntity<>(new ResponseStatusPOJO(true, "Final Data Entry saved successfully",
					SUCCESS_CODE_200, finalDataEntryService.finalDataEntrySave(caseId, validate, userDetailPOJO)),
					HttpStatus.OK);
		} catch (ServiceException e1) {
			logger.error("Exception occurred while final de save : {}", e1.getMessage());
			if (e1.getObj() != null) {
				return new ResponseEntity<>(new ResponseStatusPOJO(false, e1.getMessage(), e1.getObj()), HttpStatus.OK);
			} else {
				return new ResponseEntity<>(new ResponseStatusPOJO(false, e1.getMessage(), e1.getMessageId()),
						HttpStatus.OK);
			}
		} catch (Exception e2) {
			return new ResponseEntity<>(new ResponseStatusPOJO(false, e2.getMessage()), HttpStatus.OK);
		}
	}
}
