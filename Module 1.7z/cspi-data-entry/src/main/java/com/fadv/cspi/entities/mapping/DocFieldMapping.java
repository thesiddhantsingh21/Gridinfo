package com.fadv.cspi.entities.mapping;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;

import com.fadv.cspi.entities.master.DocumentFieldMaster;
import com.fadv.cspi.entities.master.DocumentMaster;
import com.fadv.cspi.entities.master.UiControlMaster;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.vladmihalcea.hibernate.type.json.JsonBinaryType;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
@Entity
@JsonInclude(value = Include.NON_NULL)
@TypeDef(name = "jsonb", typeClass = JsonBinaryType.class)
public class DocFieldMapping implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(nullable = false, updatable = false)
	private long docFieldMappingId;

	@Column(nullable = false)
	private Boolean mandatory;

	@Type(type = "jsonb")
	@Column(columnDefinition = "jsonb", nullable = true)
	private List<String> possibleValues;

	@Type(type = "jsonb")
	@Column(columnDefinition = "jsonb", nullable = true)
	private ObjectNode remoteApi;

	@Column(nullable = false)
	private Integer sequenceId;

	@Column(nullable = false)
	private Boolean showInGrid;

	@JoinColumn(nullable = true)
	private String remoteApiFieldName;

	@Column(nullable = true)
	private String parentDocField;

	@ManyToOne
	@JoinColumn(name = "document_master_id", nullable = false)
	private DocumentMaster documentMaster;

	@ManyToOne
	@JoinColumn(name = "document_field_master_id", nullable = false)
	private DocumentFieldMaster documentFieldMaster;

	@ManyToOne
	@JoinColumn(name = "ui_control_master_id", nullable = false)
	private UiControlMaster uiControlMaster;

	@Column(nullable = false, columnDefinition = "boolean default false")
	private boolean autoPopulate = false;

	@JsonProperty(access = Access.WRITE_ONLY)
	@Column(nullable = false, columnDefinition = "boolean default false")
	private Boolean active;

	public String getDocumentName() {
		return this.documentFieldMaster.getDocumentFieldName();
	}
}
