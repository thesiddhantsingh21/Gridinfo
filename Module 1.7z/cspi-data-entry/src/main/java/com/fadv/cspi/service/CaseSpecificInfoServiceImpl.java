package com.fadv.cspi.service;

import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fadv.cspi.component.data.service.ComponentCheckDataService;
import com.fadv.cspi.entities.master.CaseSpecificInfo;
import com.fadv.cspi.entities.master.CaseSpecificRecordDetail;
import com.fadv.cspi.entities.transaction.CaseDataEntry;
import com.fadv.cspi.entities.transaction.CaseDetails;
import com.fadv.cspi.entities.transaction.CspiCheckCreation;
import com.fadv.cspi.exception.ServiceException;
import com.fadv.cspi.repository.master.CaseSpecificInfoRepository;
import com.fadv.cspi.repository.master.CaseSpecificRecordDetailRepository;
import com.fadv.cspi.repository.transaction.CaseDataEntryRepository;
import com.fadv.cspi.repository.transaction.CaseDetailsRepository;
import com.fadv.cspi.repository.transaction.CspiCheckCreationRepository;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

@Service
public class CaseSpecificInfoServiceImpl implements CaseSpecificInfoService {

	private ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES,
			false);
	private static final Logger logger = LoggerFactory.getLogger(CaseSpecificInfoServiceImpl.class);
	private static final String OPEN = "Open";

	@Autowired
	private CspiCheckCreationRepository cspiCheckCreationRepository;

	@Autowired
	private ComponentCheckDataService componentCheckDataService;

	@Autowired
	private CaseDataEntryRepository caseDataEntryRepository;

	@Autowired
	private CaseSpecificInfoRepository caseSpecificInfoRepository;

	@Autowired
	private CaseSpecificRecordDetailRepository caseSpecificRecordDetailRepository;

	@Autowired
	private CaseDetailsRepository caseDetailsRepository;

	@Override
	@Transactional
	public String saveCaseSpecificInfoDetails(long caseDetailsId) throws ServiceException {
		CaseSpecificInfo caseSpecificInfoSaved = new CaseSpecificInfo();
		CaseSpecificRecordDetail caseSpecificRecordDetailSaved = new CaseSpecificRecordDetail();

		List<CspiCheckCreation> cspiCheckCreationList = cspiCheckCreationRepository.findByCaseDetailsId(caseDetailsId);
		if (cspiCheckCreationList.isEmpty()) {
			logger.info("Data Not Found In Cspi Check Cretion For Given Id: {}" + caseDetailsId);
			throw new ServiceException(
					"Data Not Found In Cspi Check Creation For Given CaseDetailsId: {}" + caseDetailsId);
		}
		List<CaseDetails> caseDetailList = caseDetailsRepository.findByCaseDetailsId(caseDetailsId);
		if (caseDetailList.isEmpty()) {
			throw new ServiceException("Data Not Found In Case Details For Given CaseDetailsId: {}" + caseDetailsId);
		}
		CaseSpecificInfo caseSpecificInfo = new CaseSpecificInfo();
		for (CspiCheckCreation cspiCheckCreation : cspiCheckCreationList) {
			String cspiCheckId = cspiCheckCreation.getCspiCheckId();
			JsonNode node = mapper.createObjectNode();
			JsonNode componentScopingNode = mapper.createObjectNode();
			if (cspiCheckId == null) {
				continue;
			}
			node = componentCheckDataService.getComponentCheckData(cspiCheckId);
			if (node.isEmpty()) {
				continue;
			}
			componentScopingNode = node.get("data").get(0).get("result").get("ComponentScoping");
			Boolean flag = setDataForSaving(caseSpecificInfo, componentScopingNode, caseDetailsId, caseDetailList);
			logger.info("Values Set For Saving In CaseSpecificInfo:{}", flag);

			if (flag) {
				caseSpecificInfoSaved = caseSpecificInfoRepository.save(caseSpecificInfo);
				logger.info("CaseSpecificInfo Data Saved Successfully:{}", caseSpecificInfoSaved.getCaseSpecificId());
				break;
			}
		}
		for (CspiCheckCreation cspiCheckCreation : cspiCheckCreationList) {
			String cspiCheckId = cspiCheckCreation.getCspiCheckId();
			JsonNode node = mapper.createObjectNode();
			JsonNode componentScopingNode = mapper.createObjectNode();
			if (cspiCheckId != null) {
				logger.info("CheckId:{}", cspiCheckId);
				node = componentCheckDataService.getComponentCheckData(cspiCheckId);
				if (!node.isEmpty()) {
					componentScopingNode = node.get("data").get(0).get("result").get("ComponentScoping");
				}
			}
			CaseSpecificRecordDetail caseSpecificRecordDetail = new CaseSpecificRecordDetail();
			if (componentScopingNode.isEmpty()) {
				logger.info("ComponentScoping is empty:{}", node);
				continue;
			}
			Boolean flag2 = setDataInCaseSpecificRecordDetail(caseSpecificRecordDetail, cspiCheckCreation,
					componentScopingNode, caseDetailsId, caseSpecificInfoSaved, cspiCheckId);
			logger.info("Values Set For Saving In CaseSpecificRecordDetail:{}", flag2);

			if (flag2) {
				caseSpecificRecordDetailSaved = caseSpecificRecordDetailRepository.save(caseSpecificRecordDetail);
				logger.info("CaseSpecificRecordDetail Data Saved Successfully:{}",
						caseSpecificRecordDetailSaved.getCaseSpecificDetailId());
			}
		}
		return "Data Saved";

	}

	private Boolean setDataForSaving(CaseSpecificInfo caseSpecificInfo, JsonNode componentScopingNode,
			long caseDetailsId, List<CaseDetails> caseDetailList) {
		try {
			caseSpecificInfo.setCaseDetailsId(caseDetailList.get(0));
			caseSpecificInfo.setCandidateName(componentScopingNode.get("Candidate_Name").asText() != null
					? componentScopingNode.get("Candidate_Name").asText()
					: "");
			caseSpecificInfo.setCaseDetails(
					componentScopingNode.get("caseDetails").asText() != null ? componentScopingNode.get("caseDetails")
							: mapper.createObjectNode());

			caseSpecificInfo.setCaseMoreInfo(
					componentScopingNode.get("caseMoreInfo").asText() != null ? componentScopingNode.get("caseMoreInfo")
							: mapper.createObjectNode());
			caseSpecificInfo.setCaseNumber(componentScopingNode.get("CASE_NUMBER").asText() != null
					? componentScopingNode.get("CASE_NUMBER").asText()
					: "");
			caseSpecificInfo.setCaseReference(componentScopingNode.get("caseReference").asText() != null
					? componentScopingNode.get("caseReference")
					: mapper.createObjectNode());
			caseSpecificInfo.setCaseRefNumber(componentScopingNode.get("CASE_REF_NUMBER").asText() != null
					? componentScopingNode.get("CASE_REF_NUMBER").asText()
					: "");
			caseSpecificInfo.setClientCode(componentScopingNode.get("CLIENT_CODE").asText() != null
					? componentScopingNode.get("CLIENT_CODE").asText()
					: "");
			caseSpecificInfo.setClientName(componentScopingNode.get("CLIENT_NAME").asText() != null
					? componentScopingNode.get("CLIENT_NAME").asText()
					: "");
			caseSpecificInfo.setClientSpecificFields(componentScopingNode.get("clientSpecificFields").asText() != null
					? componentScopingNode.get("clientSpecificFields")
					: mapper.createObjectNode());
			caseSpecificInfo.setCreatedDate(new Date());
			caseSpecificInfo
					.setCrnCreationDate(componentScopingNode.get("caseReference").get("crnCreatedDate").asText() != null
							? componentScopingNode.get("caseReference").get("crnCreatedDate").asText()
							: "");

			// Call another endpoint to get dataEntry
			Boolean flag = setDataEntryData(caseSpecificInfo, caseDetailsId);
			logger.info("Set Data Entry Values :{}", flag);

			caseSpecificInfo.setPackageName(componentScopingNode.get("Package Name").asText() != null
					? componentScopingNode.get("Package Name").asText()
					: "");
			caseSpecificInfo.setSbuName(componentScopingNode.get("SBU_NAME").asText() != null
					? componentScopingNode.get("SBU_NAME").asText()
					: "");
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("Exception Occurred in Set Value in CaseSpecificInfo :{}");
			return false;
		}
		return true;
	}

	private Boolean setDataEntryData(CaseSpecificInfo caseSpecificInfo, long caseDetailsId) {
		ObjectNode node = mapper.createObjectNode();
		try {
			List<CaseDataEntry> caseDataEntrieList = caseDataEntryRepository.getDataEntryByCaseDetailsId(caseDetailsId);

			for (CaseDataEntry caseDataEntry : caseDataEntrieList) {
				String documentName = caseDataEntry.getDocumentMaster().getDocumentName().toLowerCase();
				documentName = documentName.replace(" ", "").replace("(", "").replace(")", "").replace("-", "");
				node.set(documentName, caseDataEntry.getDataEntryData());
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("Exception Occurred in Set Value in CaseSpecificInfo DataEntry :{}");
			return false;
		}
		caseSpecificInfo.setDataEntryInfo(node);
		return true;
	}

	private Boolean setDataInCaseSpecificRecordDetail(CaseSpecificRecordDetail caseSpecificRecordDetail,
			CspiCheckCreation cspiCheckCreation, JsonNode componentScopingNode, long caseDetailsId,
			CaseSpecificInfo caseSpecificInfoSaved, String cspiCheckId) {
		try {
			JsonNode components = componentScopingNode.get("Components").get(0);
			if (components == null || components.isEmpty()) {
				logger.info("Component is Empty for CheckId:{}", cspiCheckId);
				return false;
			}
			caseSpecificRecordDetail.setCaseSpecificId(caseSpecificInfoSaved);
			String componentName = components.get("componentName").asText();
			caseSpecificRecordDetail.setComponentName(componentName != null ? componentName : "");
			caseSpecificRecordDetail.setComponentRecordField(components.get("Records").get(0));

			ObjectNode recordNode = cspiCheckCreation.getRecordNode() != null ? cspiCheckCreation.getRecordNode()
					: mapper.createObjectNode();

			logger.info("recordNode:{}", recordNode);

			JsonNode dataEntryNode = cspiCheckCreation.getRecordNode();
			String city = "";
			caseSpecificRecordDetail.setInstructionCheckId(cspiCheckId);

			if (dataEntryNode.has("City")) {
				city = dataEntryNode.get("City").asText();
			}
			caseSpecificRecordDetail.setEntityLocation(city);

			String productName = components.get("PRODUCT").asText();

			caseSpecificRecordDetail.setProduct(productName != null ? productName : "");
			caseSpecificRecordDetail.setCheckCreatedDate(new Date());
			caseSpecificRecordDetail.setCheckStatus(OPEN);
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("Exception Occurred in Set Value in CaseSpecificRecordDetail:{}");
			return false;
		}
		return true;
	}

	@Override
	public List<CaseSpecificRecordDetail> getDataByCrn(String crn) throws ServiceException {
		List<CaseSpecificRecordDetail> caseSpecificRecordDetail = caseSpecificRecordDetailRepository.findByCrn(crn);
		if (caseSpecificRecordDetail.isEmpty()) {
			throw new ServiceException("Data Not Found For Given Crn:{}", crn);
		}
		return caseSpecificRecordDetail;
	}
}
