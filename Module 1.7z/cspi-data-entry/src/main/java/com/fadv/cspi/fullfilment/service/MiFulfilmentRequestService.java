package com.fadv.cspi.fullfilment.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.fadv.cspi.entities.transaction.CaseDetails;
import com.fadv.cspi.exception.ServiceException;
import com.fadv.cspi.fullfilment.entities.MiFulfilmentRequest;
import com.fadv.cspi.fullfilment.interfaces.MiFulfilmentResponseInterface;
import com.fadv.cspi.fullfilment.pojo.CasePOJO;
import com.fadv.cspi.fullfilment.pojo.request.MiFulfilmentRequestPOJO;
import com.fadv.cspi.fullfilment.pojo.response.MiFulfilmentResponsePOJO;
import com.fadv.cspi.pojo.request.CaseSearchCriteriaPOJO;
import com.fadv.cspi.userdetail.pojo.UserDetailPOJO;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

@Service
public interface MiFulfilmentRequestService {

	MiFulfilmentResponseInterface getMiFulfilmentRequestByMiFulfilmentRequestId(Long miFulfilmentRequestId)
			throws ServiceException;

	List<MiFulfilmentResponseInterface> getAllMiFulfilmentRequest();

	MiFulfilmentResponsePOJO createMiFulfilmentRequest(MiFulfilmentRequestPOJO miFulfilmentReqPOJO)
			throws ServiceException;

	List<MiFulfilmentResponseInterface> getCaseDetailsUsingFilters(CaseSearchCriteriaPOJO caseSearchCriteriaPOJO);

	MiFulfilmentRequest findByCaseDetails(CaseDetails caseDetails);

	MiFulfilmentRequest findByMiFulfilmentRequestId(Long miFulfilmentRequestId) throws ServiceException;

	List<CasePOJO> getAllMiFulfilledRequestData(String caseNo) throws ServiceException;

	ObjectNode getFulfillmentStatusByFulfillment(Long miFulfilmentRequestId) throws ServiceException;

	ObjectNode updateFulfillmentStatusByFulfillmentId(Long miFulfilmentRequestId, String status,
			UserDetailPOJO userDetailPOJO, String tokenId,JsonNode requestBody) throws ServiceException;

	MiFulfilmentRequest updateDeDocumentsByFulfillment(String documentName, String rowId, String parentRowId,
			MiFulfilmentRequest miFulfilmentRequest, UserDetailPOJO userDetailPOJO, String tokenId);

	JsonNode createBotMiRemarks(long miFulfilmentRequestId) throws ServiceException, JsonProcessingException;

	void updateMifulfillmentRequest(Long miFulfilmentRequestId)throws ServiceException, JsonProcessingException;

	

	

}
