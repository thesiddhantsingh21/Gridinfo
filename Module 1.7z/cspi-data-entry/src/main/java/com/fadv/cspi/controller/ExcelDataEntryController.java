package com.fadv.cspi.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fadv.cspi.pojo.AutoDataEntryPOJO;
import com.fadv.cspi.pojo.response.ResponseStatusPOJO;
import com.fadv.cspi.service.ExcelDataEntryService;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/india/")
public class ExcelDataEntryController {

	@Autowired
	private ExcelDataEntryService excelDataEntryService;

	@PostMapping(path = "data-entry-excel", produces = "application/json")
	public ResponseEntity<ResponseStatusPOJO> createCaseDetailsExcel(@RequestBody AutoDataEntryPOJO autoDataEntryPOJO) {

		try {
			return new ResponseEntity<>(new ResponseStatusPOJO(true, "Excel Created Successfully!",
					excelDataEntryService.createCaseDetailsExcel(autoDataEntryPOJO)), HttpStatus.OK);
		} catch (Exception ex) {
			return new ResponseEntity<>(new ResponseStatusPOJO(false, ex.getMessage()), HttpStatus.BAD_REQUEST);
		}
	}

}
