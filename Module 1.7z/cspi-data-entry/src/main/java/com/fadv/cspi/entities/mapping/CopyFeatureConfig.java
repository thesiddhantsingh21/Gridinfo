package com.fadv.cspi.entities.mapping;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import com.fadv.cspi.entities.master.DocumentFieldMaster;
import com.fadv.cspi.entities.master.DocumentMaster;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
@Entity
@JsonInclude(value = Include.NON_NULL)
public class CopyFeatureConfig implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(nullable = false, updatable = false)
	private long copyFeatureConfigId;

	@ManyToOne
	@JoinColumn(name = "document_master_id", nullable = false)
	private DocumentMaster documentMaster;

	@ManyToOne
	@JoinColumn(name = "document_field_master_id", nullable = false)
	private DocumentFieldMaster documentFieldMaster;
}
