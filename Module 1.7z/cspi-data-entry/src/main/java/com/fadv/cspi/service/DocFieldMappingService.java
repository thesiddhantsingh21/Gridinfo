package com.fadv.cspi.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.fadv.cspi.entities.mapping.DocFieldMapping;
import com.fadv.cspi.entities.master.DocumentFieldMaster;
import com.fadv.cspi.entities.master.DocumentMaster;
import com.fadv.cspi.exception.ServiceException;
import com.fadv.cspi.pojo.response.DocumentFieldMasterResponsePOJO;

@Service
public interface DocFieldMappingService {

	List<DocumentFieldMasterResponsePOJO> getAllDocumentsFieldsByDocumentMasterId(long documentMasterId)
			throws ServiceException;

	List<String> getAllDocumentFieldKeysByDocumentMasterId(long documentMasterId);

	DocumentFieldMasterResponsePOJO findByDocumentFieldAndDocumentMaster(DocumentFieldMaster documentFieldMaster,
			long documentMasterId) throws ServiceException;

	List<DocFieldMapping> findByDocumentNameAndDocumentFieldName(String documentName, String documentFieldName);

	List<DocFieldMapping> findByDocumentMaster(DocumentMaster documentMaster);

	DocumentFieldMasterResponsePOJO convertDocFieldMapping(DocFieldMapping docFieldMapping);

	List<DocumentFieldMasterResponsePOJO> findByDocumentMasterIdAndDocumentKeys(long documentMasterId,
			List<String> documentFieldKeys);

	List<DocumentFieldMasterResponsePOJO> getAllFieldsByFieldName(List<String> fields)throws ServiceException;

}
