package com.fadv.cspi.repository.master;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fadv.cspi.entities.master.PackageMaster;

public interface PackageMasterRepository extends JpaRepository<PackageMaster, Long> {

	List<PackageMaster> findByPackageNameIgnoreCase(String packageName);
}
