package com.fadv.cspi.pojo.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.node.ObjectNode;

import lombok.Data;

@Data
@JsonInclude(value = Include.NON_NULL)
public class ContactCardMasterResponsePOJO {

	private long contactCardMasterId;

	private String akaName;

	private long countryMasterId;

	private String countryName;

	private long stateMasterId;

	private String stateName;

	private long cityMasterId;

	private String cityName;

	private long componentMasterId;

	private String componentName;

	private Integer avl;

	private Integer mrl;

	private Integer costApproval;

	private Integer stellar;

	private Integer singleSpoc;

	private Integer bulkSpoc;

	private Integer cbv;

	private Integer utv;

	private Integer suspect;

	private Integer i4v;

	private String existingUniversityEmploymentCollege;

	private String universityEmploymentName;

	private String areaLocalityName;

	private String enterAkaName;

	private String fadvRelationship;

	private String mandatoryDocuments;

	private String phoneType;

	private String modeOfInitiation;

	private String entityType;

	private ObjectNode additionalFields;

	private Integer orgId;

}
