package com.fadv.cspi.interfaces;

public interface CountryMasterListResponseInterface {
	long getCountryMasterId();

	String getCountryName();
}
