package com.fadv.cspi.interfaces;

public interface ComponentAkaNameInterface {

	String getComponentName();

	String getAkaName();
}
