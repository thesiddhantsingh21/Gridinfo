package com.fadv.cspi.entities.master;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.Type;

import com.fadv.cspi.entities.transaction.CaseDetails;
import com.fasterxml.jackson.databind.JsonNode;

import lombok.Data;

@Data
@Entity
public class CaseSpecificInfo {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(nullable = false, updatable = false)
	private Long caseSpecificId;

	private String candidateName;

	@Type(type = "jsonb")
	@Column(columnDefinition = "jsonb", nullable = false)
	private JsonNode caseDetails;

	@Type(type = "jsonb")
	@Column(columnDefinition = "jsonb", nullable = false)
	private JsonNode caseMoreInfo;

	private String caseNumber;
	private String caseRefNumber;

	@Type(type = "jsonb")
	@Column(columnDefinition = "jsonb", nullable = false)
	private JsonNode caseReference;

	private String clientCode;
	private String clientName;

	@Type(type = "jsonb")
	@Column(columnDefinition = "jsonb", nullable = false)
	private JsonNode clientSpecificFields;

	private Date createdDate;
	private String crnCreationDate;
	private String sbuName;
	private String packageName;
	private String status;

	@Type(type = "jsonb")
	@Column(columnDefinition = "jsonb", nullable = false)
	private JsonNode dataEntryInfo;

	private Date updatedDate;

	@ManyToOne
	@JoinColumn(name = "case_details_id", nullable = false)
	private CaseDetails caseDetailsId;

}
