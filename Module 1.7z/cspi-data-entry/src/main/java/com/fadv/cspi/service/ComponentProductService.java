package com.fadv.cspi.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.fadv.cspi.entities.mapping.ComponentProduct;

@Service
public interface ComponentProductService {

	List<ComponentProduct> getComponentProductsByComponentMasterList(List<Long> componentMasterIds);

}
