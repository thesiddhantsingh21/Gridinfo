package com.fadv.cspi.fullfilment.pojo;

import javax.validation.constraints.NotEmpty;

import lombok.Data;

@Data
public class MiRemarksPOJO {

	@NotEmpty
	private String remarks;
}
