package com.fadv.cspi.pojo.response;

import lombok.Data;

@Data
public class InfoMapPOJO {

	private String path;
	private String infoMsg;
}
