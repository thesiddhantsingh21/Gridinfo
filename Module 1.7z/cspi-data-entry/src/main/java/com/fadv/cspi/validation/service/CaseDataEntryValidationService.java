package com.fadv.cspi.validation.service;

import java.util.Map;

import org.springframework.stereotype.Service;

import com.fadv.cspi.exception.ServiceException;
import com.fadv.cspi.pojo.AutoDataEntryPOJO;

@Service
public interface CaseDataEntryValidationService {

	Map<String, Object> validateAutoDataEntry(AutoDataEntryPOJO autoDataEntryPOJO) throws ServiceException;

}
