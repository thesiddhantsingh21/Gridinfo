package com.fadv.cspi.interfaces;

public interface ContactCardMasterInterface {

	String getAkaName();

	String getUniversityEmploymentName();

	String getCity();

	String getState();

	String getCountry();

	String getComponentName();

	Integer getOrgId();
	
	Long getContactCardMasterId();
}
