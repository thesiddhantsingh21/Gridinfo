package com.fadv.cspi.service.remote;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.fadv.cspi.entities.mapping.CliSbuPkgCompProd;
import com.fadv.cspi.entities.mapping.ComponentProduct;
import com.fadv.cspi.entities.master.ContactCardMaster;
import com.fadv.cspi.entities.transaction.CaseClientDetails;
import com.fadv.cspi.exception.ServiceException;
import com.fadv.cspi.pojo.remote.MrlRulePOJO;
import com.fadv.cspi.pojo.remote.OtherDocsMrlRulePOJO;
import com.fadv.cspi.pojo.remote.RuleDescriptionPOJO;
import com.fadv.cspi.pojo.remote.SlaSearchPOJO;
import com.fadv.cspi.service.ApiService;
import com.fadv.cspi.service.CaseAssociatedDocumentsService;
import com.fadv.cspi.service.CaseClientDetailsService;
import com.fadv.cspi.service.CliSbuPkgCompProdService;
import com.fadv.cspi.service.CompProdDocumentsService;
import com.fadv.cspi.service.ComponentProductService;
import com.fadv.cspi.service.ContactCardMasterService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

@Service
public class RemoteDataServiceImpl implements RemoteDataService {

	private static final String RULE_PARAM = "RuleParam";

	private static final String RULES_PARAM_JSON = "rulesParamJson";

	private static final String ERROR_CODE_404 = "ERROR_CODE_404";

	private static final String RECORD_NOT_FOUND = "Record not found";

	private static final Logger logger = LoggerFactory.getLogger(RemoteDataServiceImpl.class);

	ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

	@Value("${mrl.rule.document.url}")
	private String mrlRuleDescriptionUrl;

	@Value("${scoping.rule.document.url}")
	private String scopingRuleDescriptionUrl;

	@Autowired
	private CaseAssociatedDocumentsService caseAssociatedDocumentsService;

	@Autowired
	private ContactCardMasterService contactCardMasterService;

	@Autowired
	private ApiService apiService;

	@Autowired
	private CaseClientDetailsService caseClientDetailsService;

	@Autowired
	private CliSbuPkgCompProdService cliSbuPkgCompProdService;

	@Autowired
	private CompProdDocumentsService compProdDocumentsService;

	@Autowired
	private ComponentProductService componentProductService;

	@Override
	public List<String> getMrlDocs(JsonNode mrlNode) throws ServiceException {

		ArrayNode documentsName = mapper.createArrayNode();

		try {
			String mrlRuleDescriptionDocStr = mapper.writeValueAsString(mrlNode);

			String mrlRuleDescriptionResponse = apiService.sendDataToPost(mrlRuleDescriptionUrl,
					mrlRuleDescriptionDocStr);

			JsonNode mrlRuleDescriptionResponseNode = mrlRuleDescriptionResponse != null
					? mapper.readValue(mrlRuleDescriptionResponse, JsonNode.class)
					: mapper.createObjectNode();
			logger.info("Value of mrlRuleDescriptionResponseNode : {}", mrlRuleDescriptionResponseNode);
			if (mrlRuleDescriptionResponseNode.has("ducumentNames")
					&& mrlRuleDescriptionResponseNode.get("ducumentNames").asText().equalsIgnoreCase("null")) {
				throw new ServiceException("Document name Fetch from Mrl rule Is Null");
			}

			documentsName = mrlRuleDescriptionResponseNode.has("ducumentNames")
					? (ArrayNode) mrlRuleDescriptionResponseNode.get("ducumentNames")
					: mapper.createArrayNode();
			logger.info("Value of documentsName : {}", documentsName);

		} catch (JsonProcessingException e) {
			logger.error("Exception while mapping mrl document response : {}", e.getMessage());
		}
		if (documentsName != null && !documentsName.isEmpty()) {
			return mapper.convertValue(documentsName, new TypeReference<List<String>>() {
			});
		}

		throw new ServiceException(RECORD_NOT_FOUND, ERROR_CODE_404);
	}

//====================================================================================
// Get Rule Description
//====================================================================================
	public String getMrlRuleDescription(JsonNode mrlNode) throws ServiceException {

		String ruleDescription = "";

		try {
			String mrlRuleDescriptionDocStr = mapper.writeValueAsString(mrlNode);

			String mrlRuleDescriptionResponse = apiService.sendDataToPost(mrlRuleDescriptionUrl,
					mrlRuleDescriptionDocStr);

			JsonNode mrlRuleDescriptionResponseNode = mrlRuleDescriptionResponse != null
					? mapper.readValue(mrlRuleDescriptionResponse, JsonNode.class)
					: mapper.createObjectNode();
			logger.info("Value of mrlRuleDescriptionResponseNode : {}", mrlRuleDescriptionResponseNode);

			ruleDescription = mrlRuleDescriptionResponseNode.has("ruleDescription")
					? mrlRuleDescriptionResponseNode.get("ruleDescription").asText()
					: "";
			logger.info("Value of  : {}", ruleDescription);

		} catch (JsonProcessingException e) {
			logger.error("Exception while mapping mrl document response : {}", e.getMessage());
		}
		return ruleDescription;
	}

	// ========================================================================================
	// ============================= Mrl Docs Rules -
	// Start====================================
	// ========================================================================================
	@Override
	public List<ObjectNode> getMrlDocRules(JsonNode mrlNode) throws ServiceException {

		List<ObjectNode> ruleParam = new ArrayList<>();

		try {
			String mrlRuleDescriptionDocStr = mapper.writeValueAsString(mrlNode);

			String mrlRuleDescriptionResponse = apiService.sendDataToPost(mrlRuleDescriptionUrl,
					mrlRuleDescriptionDocStr);

			JsonNode mrlRuleDescriptionResponseNode = mrlRuleDescriptionResponse != null
					? mapper.readValue(mrlRuleDescriptionResponse, JsonNode.class)
					: mapper.createObjectNode();
			logger.info("Value of mrlRuleDescriptionResponseNode : {}", mrlRuleDescriptionResponseNode);

			String rulesParamStr = mrlRuleDescriptionResponseNode.has(RULES_PARAM_JSON)
					? mrlRuleDescriptionResponseNode.get(RULES_PARAM_JSON).asText()
					: "{}";
			if (rulesParamStr != null && StringUtils.isNotEmpty(rulesParamStr)) {
				JsonNode rulesParamJson = mapper.readTree(rulesParamStr);
				ArrayNode ruleParamNewNode = rulesParamJson.has(RULE_PARAM) ? (ArrayNode) rulesParamJson.get(RULE_PARAM)
						: mapper.createArrayNode();

				List<Map<String, Object>> ruleParamMap = mapper.convertValue(ruleParamNewNode,
						new TypeReference<List<Map<String, Object>>>() {
						});

				ruleParamMap = ruleParamMap.parallelStream().map(data -> {
					Map<String, Object> newData = new HashMap<>();
					for (Map.Entry<String, Object> ruleMap : data.entrySet()) {
						String newKey = ruleMap.getKey().replaceAll(" \\s*", "");
						newData.put(newKey, ruleMap.getValue());
					}

					return newData;
				}).collect(Collectors.toList());

				ruleParam = mapper.convertValue(ruleParamMap, new TypeReference<List<ObjectNode>>() {
				});
			}
			logger.info("Value of rulesParamJson : {}", ruleParam);

		} catch (JsonProcessingException e) {
			logger.error("Exception while mapping mrl document response : {}", e.getMessage());
		}
		if (ruleParam != null && !ruleParam.isEmpty()) {
			return ruleParam;
		}

		throw new ServiceException(RECORD_NOT_FOUND, ERROR_CODE_404);
	}

	// ========================================================================================
	// =============================Mrl Docs Rule -
	// End========================================
	// ========================================================================================
	@Override
	public List<MrlRulePOJO> getMrlRuleList(Long caseId) {

		List<String> akaNameList = new ArrayList<>();
		try {
			akaNameList = caseAssociatedDocumentsService.getAkaNamesByCaseId(caseId);
		} catch (ServiceException e1) {
			akaNameList = new ArrayList<>();
			logger.error("Exception occurred while fetching akaName list : {}", e1.getMessage());
		}

		List<MrlRulePOJO> mrlRulePOJOs = new ArrayList<>();

		for (String akaName : akaNameList) {
			ContactCardMaster contactCardMaster = contactCardMasterService.getContactCardByAkaName(akaName);
			if (contactCardMaster != null) {
				String componentName = contactCardMaster.getComponentMaster() != null
						? contactCardMaster.getComponentMaster().getComponentName()
						: "";

				MrlRulePOJO mrlRulePOJO = new MrlRulePOJO();
				mrlRulePOJO.setAkaName(akaName);
				mrlRulePOJO.setComponentName(componentName);

				ObjectNode mrlSearchNode = mapper.createObjectNode();
				mrlSearchNode.put("akaName", akaName);
				mrlSearchNode.put("componentName", componentName);

				String mrlDocList = "";
				try {
					mrlDocList = getMrlRuleDescription(mrlSearchNode);
				} catch (ServiceException e) {
					logger.error("Mrl Docs Not found for search details : {}", mrlSearchNode);
				}
				mrlRulePOJO.setRuleDescription(mrlDocList);
				mrlRulePOJOs.add(mrlRulePOJO);
			}
		}
		return mrlRulePOJOs;
	}

	@Override
	public List<RuleDescriptionPOJO> getMrlRuleDescription(Long caseId) throws ServiceException {
		List<SlaSearchPOJO> slaSearchPOJOs = createSlaSearchRequestBody(caseId);
		List<RuleDescriptionPOJO> ruleDescriptionPOJOs = new ArrayList<>();

		for (SlaSearchPOJO slaSearchPOJO : slaSearchPOJOs) {
			JsonNode slaSearchNode = mapper.convertValue(slaSearchPOJO, JsonNode.class);
			String ruleDescriptionResponse = apiService.sendDataToPost(mrlRuleDescriptionUrl, slaSearchNode.toString());

			if (ruleDescriptionResponse != null) {
				try {
					RuleDescriptionPOJO ruleDescriptionPOJO = mapper.readValue(ruleDescriptionResponse,
							RuleDescriptionPOJO.class);
					ruleDescriptionPOJOs.add(ruleDescriptionPOJO);
				} catch (JsonProcessingException e) {
					logger.error("Exception occurred while mapping rule response to object : {}", e.getMessage());
				}
			}
		}
		return ruleDescriptionPOJOs;
	}

	@Override
	public List<RuleDescriptionPOJO> getSlaRuleDescription(Long caseId) throws ServiceException {
		List<SlaSearchPOJO> slaSearchPOJOs = createSlaSearchRequestBody(caseId);
		ArrayNode slaSearchNode = mapper.convertValue(slaSearchPOJOs, ArrayNode.class);
		List<RuleDescriptionPOJO> ruleDescriptionPOJOs = new ArrayList<>();
		logger.info("Sla Rule request : {}", slaSearchNode);
		String ruleDescriptionResponse = apiService.sendDataToSecuredPost(scopingRuleDescriptionUrl,
				slaSearchNode.toString(), null);

		if (ruleDescriptionResponse != null) {
			try {
				JsonNode ruleResponseNode = mapper.readTree(ruleDescriptionResponse);
				ArrayNode dataNode = ruleResponseNode.has("data") ? (ArrayNode) ruleResponseNode.get("data")
						: mapper.createArrayNode();
				ruleDescriptionPOJOs = mapper.convertValue(dataNode, new TypeReference<List<RuleDescriptionPOJO>>() {
				});
				ruleDescriptionPOJOs = ruleDescriptionPOJOs.parallelStream().filter(
						data -> !StringUtils.containsIgnoreCase(data.getDescription(), "Error: incorrect request"))
						.collect(Collectors.toList());
			} catch (JsonProcessingException e) {
				logger.error("Exception occurred while mapping rule response to object : {}", e.getMessage());
			}
		}

		return ruleDescriptionPOJOs;
	}

	private List<SlaSearchPOJO> createSlaSearchRequestBody(Long caseId) throws ServiceException {

		CaseClientDetails caseClientDetails = caseClientDetailsService.findByCaseDetailsId(caseId);
		String clientName = caseClientDetails.getClientMaster() != null
				? caseClientDetails.getClientMaster().getClientName()
				: "";
		String sbuName = caseClientDetails.getSbuMaster() != null ? caseClientDetails.getSbuMaster().getSbuName() : "";
		String packageName = caseClientDetails.getPackageMaster() != null
				? caseClientDetails.getPackageMaster().getPackageName()
				: "";
		Long packageId = caseClientDetails.getPackageMaster() != null
				? caseClientDetails.getPackageMaster().getPackageMasterId()
				: 0;

		return setSlaSearchByProduct(packageId, clientName, sbuName, packageName);

	}

	private List<SlaSearchPOJO> setSlaSearchByProduct(Long packageId, String clientName, String sbuName,
			String packageName) throws ServiceException {

		List<SlaSearchPOJO> slaSearchPOJOs = new ArrayList<>();

		if (packageId > 0 && StringUtils.isNotEmpty(clientName) && StringUtils.isNotEmpty(sbuName)
				&& StringUtils.isNotEmpty(packageName)) {

			List<CliSbuPkgCompProd> cliSbuPkgCompProds = cliSbuPkgCompProdService
					.findByClientNameAndSbuNameAndPackageMasterId(clientName, sbuName, packageId);

			for (CliSbuPkgCompProd cliSbuPkgCompProd : cliSbuPkgCompProds) {
				String componentName = cliSbuPkgCompProd.getComponentMaster() != null
						? cliSbuPkgCompProd.getComponentMaster().getComponentName()
						: "";
				String productName = cliSbuPkgCompProd.getProductMaster() != null
						? cliSbuPkgCompProd.getProductMaster().getProductName()
						: "";

				if (StringUtils.isNotEmpty(componentName) && StringUtils.isNotEmpty(productName)) {
					SlaSearchPOJO slaSearchPOJO = new SlaSearchPOJO();
					slaSearchPOJO.setClientCode(clientName);
					slaSearchPOJO.setComponentName(componentName);
					slaSearchPOJO.setPackageCode(packageName);
					slaSearchPOJO.setSbu(sbuName);
					slaSearchPOJO.setSubComponentName(productName);
					slaSearchPOJOs.add(slaSearchPOJO);
				}
			}
		}
		return slaSearchPOJOs;
	}

	@Override
	public List<ObjectNode> getOtherDocsMRLRules(OtherDocsMrlRulePOJO otherDocsMrlRulePOJO) throws ServiceException {
		long caseDetailsId = otherDocsMrlRulePOJO.getCaseDetailsId();
		long documentMasterId = otherDocsMrlRulePOJO.getDocumentMasterId();

		CaseClientDetails caseClientDetails = caseClientDetailsService.findByCaseDetailsId(caseDetailsId);
		String clientName = caseClientDetails.getClientMaster() != null
				? caseClientDetails.getClientMaster().getClientName()
				: "";
		String sbuName = caseClientDetails.getSbuMaster() != null ? caseClientDetails.getSbuMaster().getSbuName() : "";
		String packageName = caseClientDetails.getPackageMaster() != null
				? caseClientDetails.getPackageMaster().getPackageName()
				: "";
		List<Long> componentMasterIds = compProdDocumentsService.getComponentsByDocumentMasterId(documentMasterId);
		List<ComponentProduct> componentProducts = componentProductService
				.getComponentProductsByComponentMasterList(componentMasterIds);

		List<Map<String, Object>> ruleParamMap = new ArrayList<>();
		List<ObjectNode> ruleParam = new ArrayList<>();

		for (ComponentProduct componentProduct : componentProducts) {
			ObjectNode requestNode = mapper.createObjectNode();
			requestNode.put("clientCode", clientName);
			requestNode.put("sbu", sbuName);
			requestNode.put("packageCode", packageName);
			requestNode.put("componentName", componentProduct.getComponentMaster().getComponentName());
			requestNode.put("subComponentName", componentProduct.getProductMaster().getProductName());

			try {
				String mrlRuleDescriptionDocStr = mapper.writeValueAsString(requestNode);

				String mrlRuleDescriptionResponse = apiService.sendDataToPost(mrlRuleDescriptionUrl,
						mrlRuleDescriptionDocStr);

				JsonNode mrlRuleDescriptionResponseNode = mrlRuleDescriptionResponse != null
						? mapper.readValue(mrlRuleDescriptionResponse, JsonNode.class)
						: mapper.createObjectNode();

				logger.info("Value of mrlRuleDescriptionResponseNode : {}", mrlRuleDescriptionResponseNode);

				String rulesParamStr = mrlRuleDescriptionResponseNode.has(RULES_PARAM_JSON)
						? mrlRuleDescriptionResponseNode.get(RULES_PARAM_JSON).asText()
						: "{}";
				if (rulesParamStr != null && StringUtils.isNotEmpty(rulesParamStr)) {
					JsonNode rulesParamJson = mapper.readTree(rulesParamStr);
					ArrayNode ruleParamNewNode = rulesParamJson.has(RULE_PARAM)
							? (ArrayNode) rulesParamJson.get(RULE_PARAM)
							: mapper.createArrayNode();

					ruleParamMap.addAll(
							mapper.convertValue(ruleParamNewNode, new TypeReference<List<Map<String, Object>>>() {
							}));

				}
			} catch (JsonProcessingException | IllegalArgumentException e) {
				logger.error("Exception occurred while parsing response : {}", e.getMessage());
			}
		}

		Map<String, List<String>> newMap = new HashMap<>();
		for (Map<String, Object> ruleMap : ruleParamMap) {
			for (Map.Entry<String, Object> entrySet : ruleMap.entrySet()) {
				String newKey = entrySet.getKey().replaceAll(" \\s*", "");

				List<String> stringValues = newMap.get(newKey);
				if (stringValues == null) {
					stringValues = new ArrayList<>();
				}
				Object values = entrySet.getValue();
				stringValues.addAll(mapper.convertValue(values, new TypeReference<List<String>>() {
				}));
				newMap.put(newKey, stringValues);
			}
		}
		if (!newMap.isEmpty()) {
			List<Map<String, List<String>>> newRuleParamMap = new ArrayList<>();
			newRuleParamMap.add(newMap);
			ruleParam = mapper.convertValue(newRuleParamMap, new TypeReference<List<ObjectNode>>() {
			});
		}
		logger.info("Value of rulesParamJson : {}", ruleParam);
		return ruleParam;
	}
}
