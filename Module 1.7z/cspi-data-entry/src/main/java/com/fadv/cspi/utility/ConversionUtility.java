package com.fadv.cspi.utility;

import java.io.File;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;

import com.fadv.cspi.pojo.StartEndPagePOJO;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

public class ConversionUtility {
	static ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

	private ConversionUtility() {
		throw new IllegalStateException("DataEntryUtility class");
	}

	public static String removeNonAlphaNumericAndSpace(String str) {
		str = str.trim().replaceAll("[^a-zA-Z0-9]+", "");
		return str.toLowerCase();
	}

	public static List<String> findKeys(JsonNode jsonValue) {
		List<String> keys = new ArrayList<>();
		Map<String, Object> treeMap = mapper.convertValue(jsonValue, new TypeReference<Map<String, Object>>() {
		});
		treeMap.forEach((key, value) -> keys.add(key));
		return keys;
	}

	public static String convertDefaultDate(String str) {
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
		simpleDateFormat.setLenient(false);
		try {
			Date date = simpleDateFormat.parse(str);
			return simpleDateFormat.format(date);
		} catch (ParseException e) {
			return str;
		}
	}

	public static String convertDate(String str) {
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MM/dd/yyyy");
		simpleDateFormat.setLenient(false);
		SimpleDateFormat simpleDateFormat2 = new SimpleDateFormat("yyyy-MM-dd");
		try {
			Date date = simpleDateFormat.parse(str);
			return simpleDateFormat2.format(date);
		} catch (ParseException e) {
			return str;
		}
	}

	public static String checkDate(String str) {
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
		simpleDateFormat.setLenient(false);
		try {
			Date date = simpleDateFormat.parse(str);
			return str;
		} catch (ParseException e) {
			return "";
		}
	}

	public static List<StartEndPagePOJO> getPageRange(int numDocs, int pageCount) {
		List<StartEndPagePOJO> startEndPagePOJOs = new ArrayList<>();

		if (pageCount == 0) {
			while (numDocs > 0) {
				startEndPagePOJOs.add(new StartEndPagePOJO(1, 1));
				numDocs--;
			}
		} else if (pageCount > 0 && pageCount < numDocs) {

			int iter = 1;
			while (numDocs > 0) {
				if (iter > pageCount) {
					iter = 1;
				}
				startEndPagePOJOs.add(new StartEndPagePOJO(iter, iter));
				iter++;
				numDocs--;
			}
		} else {
			int equalParts = pageCount / numDocs;
			int iter = 0;
			while (numDocs > 0) {
				if (numDocs == 1) {
					equalParts = pageCount - iter;
				}
				startEndPagePOJOs.add(new StartEndPagePOJO(iter + 1, iter + equalParts));
				iter += equalParts;
				numDocs--;
			}
		}
		return startEndPagePOJOs;
	}

	public static Map<String, String> convertStringToMap(String mapAsString) {
		return Arrays.stream(mapAsString.split("\\s*,\\s*")).map(entry -> entry.split("\\s*=\\s*"))
				.collect(Collectors.toMap(entry -> entry[0], entry -> entry[1]));
	}

	public static List<File> listAllFilesInDirectory(File dirPath, List<File> fileList) {
		File[] filesList = dirPath.listFiles();
		if (filesList != null) {
			for (File file : filesList) {
				if (file.isFile()) {
					fileList.add(file);
				} else {
					listAllFilesInDirectory(file, fileList);
				}
			}
		}
		return fileList;
	}

	public static String formatString(String inputStr) {

		if (inputStr == null || StringUtils.isEmpty(inputStr)) {
			return inputStr;
		}

		inputStr = inputStr.trim();
		// removes extra spaces from string
		inputStr = inputStr.replaceAll(" \\s*", " ");

		// strips off all non-ASCII characters
		inputStr = inputStr.replaceAll("[^\\x00-\\x7F]", "");

		// removes non-printable characters from Unicode
		inputStr = inputStr.replaceAll("\\p{C}", "");

		return inputStr.trim();
	}

	public static boolean checkValidDate(String str) {
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
		simpleDateFormat.setLenient(false);
		try {
			simpleDateFormat.parse(str);
			return true;
		} catch (ParseException e) {
			return false;
		}
	}

	public static JsonNode convertStringToJsonNode(String metaDataStr) {
		ObjectMapper mapper = new ObjectMapper();
		JsonNode metaData = mapper.createObjectNode();
		try {
			metaData = mapper.readTree(metaDataStr);
		} catch (JsonProcessingException e1) {
			e1.printStackTrace();
		}
		return metaData;
	}

	public static String removeCharacter(String str) {
		String str1 = "";
		if (str.isEmpty() || str == null) {
			return str1;
		}
//		return str.replaceAll("[^a-zA-Z0-9]", " ");
		return str.replace("\"", "");
	}

	public static String splitCamelCase(String s) {
		return s.replaceAll(String.format("%s|%s|%s", "(?<=[A-Z])(?=[A-Z][a-z])", "(?<=[^A-Z])(?=[A-Z])",
				"(?<=[A-Za-z])(?=[^A-Za-z])"), " ");
	}

	public static final String capitalize(String str) {

		if (str == null || str.length() == 0)
			return str;

		return str.substring(0, 1).toUpperCase() + str.substring(1);

	}

}
