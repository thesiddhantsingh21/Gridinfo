package com.fadv.cspi.repository.master;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.fadv.cspi.entities.master.ComponentMaster;
import com.fadv.cspi.entities.master.ContactCardMaster;
import com.fadv.cspi.interfaces.ContactCardMasterInterface;

@Repository
public interface ContactCardMasterRepository extends JpaRepository<ContactCardMaster, Long> {

	List<ContactCardMaster> findByUniversityEmploymentNameIgnoreCaseAndAkaNameIgnoreCaseAndActive(
			String universityEmploymentName, String akaName, boolean active);

	List<ContactCardMaster> findByUniversityEmploymentNameIgnoreCaseAndAkaNameIgnoreCaseAndComponentMasterAndActive(
			String universityEmploymentName, String akaName, ComponentMaster componentMaster, boolean active);

	List<ContactCardMaster> findByAkaNameIgnoreCaseAndActive(String akaName, boolean active);

	@Query(value = "select ccm.aka_name as akaName, ccm.university_employment_name as universityEmploymentName,ccm.org_id as orgId, "
			+ "cm2.city_name as city, sm.state_name as state, cm3.country_name as country, "
			+ "cm.component_name as componentName, ccm.contact_card_master_id as contactCardMasterId from {h-schema}contact_card_master ccm "
			+ "left join {h-schema}component_master cm on ccm.component_master_id = cm.component_master_id "
			+ "left join {h-schema}city_master cm2 on ccm.city_master_id = cm2.city_master_id "
			+ "left join {h-schema}state_master sm on ccm.state_master_id = sm.state_master_id "
			+ "left join {h-schema}country_master cm3 on ccm.country_master_id = cm3.country_master_id "
			+ "where case when :searchStr != '' then lower(ccm.aka_name) like lower(:searchStr) else true end "
			+ "and case when :componentName != '' then lower(cm.component_name) = lower(:componentName) else true end and ccm.active is true "
			+ "order by ccm.aka_name", nativeQuery = true)
	List<ContactCardMasterInterface> getContactCardMasterByFIlter(String searchStr, String componentName);

	@Query(value = "select ccm.aka_name as akaName, ccm.university_employment_name as universityEmploymentName, "
			+ "cm2.city_name as cityName, sm.state_name as stateName, cm3.country_name as countryName, "
			+ "cm.component_name as componentName, ccm.contact_card_master_id as contactCardMasterId from {h-schema}contact_card_master ccm "
			+ "left join {h-schema}component_master cm on ccm.component_master_id = cm.component_master_id "
			+ "left join {h-schema}city_master cm2 on ccm.city_master_id = cm2.city_master_id "
			+ "left join {h-schema}state_master sm on ccm.state_master_id = sm.state_master_id "
			+ "left join {h-schema}country_master cm3 on ccm.country_master_id = cm3.country_master_id "
			+ "where ccm.university_employment_name like :searchStr and lower(cm.component_name) = lower(:componentName) "
			+ "and ccm.active is true", nativeQuery = true)
	List<ContactCardMasterInterface> getContactCardMasterBySearchStr(String searchStr, String componentName);

	@Query(value = "select ccm.aka_name from {h-schema}contact_card_master ccm "
			+ "where lower(ccm.aka_name) = lower(:akaName) and ccm.active is true", nativeQuery = true)
	List<String> getByAkaNameList(String akaName);
}
