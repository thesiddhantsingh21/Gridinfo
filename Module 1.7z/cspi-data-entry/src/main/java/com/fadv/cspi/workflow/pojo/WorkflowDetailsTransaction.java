package com.fadv.cspi.workflow.pojo;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.JsonNode;

import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain=true)
@JsonInclude(value = Include.NON_NULL)
public class WorkflowDetailsTransaction {
	private long wdTransactionId;

	private long taskListId;

	private Date issuedTimestamp;
	private JsonNode requestJson;
	private Date requestTimestamp;
	private JsonNode responseJson;
	private Date responseTimestamp;
	private String status;
	private String errorJson;
	private String error_cause;
	private long activityTypeId;
	private boolean isPicked;
	private JsonNode metaData;
	
}
