package com.fadv.cspi.service.remote;

import java.util.List;

import org.springframework.stereotype.Service;

import com.fadv.cspi.exception.ServiceException;
import com.fadv.cspi.pojo.remote.MrlRulePOJO;
import com.fadv.cspi.pojo.remote.OtherDocsMrlRulePOJO;
import com.fadv.cspi.pojo.remote.RuleDescriptionPOJO;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

@Service
public interface RemoteDataService {

	List<String> getMrlDocs(JsonNode mrlNode) throws ServiceException;

	List<MrlRulePOJO> getMrlRuleList(Long caseId) throws ServiceException;

	List<RuleDescriptionPOJO> getMrlRuleDescription(Long caseId) throws ServiceException;

	List<RuleDescriptionPOJO> getSlaRuleDescription(Long caseId) throws ServiceException;

	List<ObjectNode> getMrlDocRules(JsonNode mrlNode) throws ServiceException;

	List<ObjectNode> getOtherDocsMRLRules(OtherDocsMrlRulePOJO otherDocsMrlRulePOJO) throws ServiceException;

}
