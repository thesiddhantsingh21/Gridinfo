package com.fadv.cspi.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.fadv.cspi.entities.master.DocumentMaster;
import com.fadv.cspi.exception.ServiceException;
import com.fadv.cspi.pojo.response.DocumentMasterResponsePOJO;

@Service
public interface DocumentMasterService {

	DocumentMaster findByDocumentMasterId(Long documentMasterId) throws ServiceException;

	List<DocumentMasterResponsePOJO> getAllDocumentsOrderByDocumentName();

	DocumentMaster findByDocumentName(String documentName) throws ServiceException;

}
