package com.fadv.cspi.fullfilment.pojo;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class IncompleteFieldsPOJO {

	@JsonProperty("Field")
	private String field;

	@JsonProperty("Value")
	private String value;

	@JsonProperty("ExpectedValue")
	private List<String> expectedValue;

}
