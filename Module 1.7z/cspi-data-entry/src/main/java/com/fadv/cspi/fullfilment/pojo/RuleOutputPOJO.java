package com.fadv.cspi.fullfilment.pojo;

import java.util.List;

import lombok.Data;

@Data
public class RuleOutputPOJO {

	private String message;

	private List<String> missingDocs;

	private List<IncompleteDocsPOJO> incompleteDocs;
	
	private List<String> missingOrDocs;
	
	private List<String> missingFields;
	private List<String> missingOrFields;
}
