package com.fadv.cspi.repository.mapping;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fadv.cspi.entities.mapping.CopyFeatureConfig;

public interface CopyFeatureConfigRepository extends JpaRepository<CopyFeatureConfig, Long> {

}
