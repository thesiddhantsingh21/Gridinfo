package com.fadv.cspi.entities.transaction;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.vladmihalcea.hibernate.type.json.JsonBinaryType;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
@Entity
@JsonInclude(value = Include.NON_NULL)
@TypeDef(name = "jsonb", typeClass = JsonBinaryType.class)
public class ProcessTaskStages implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(nullable = false, updatable = false)
	private long processTaskStagesId;

	@Column(nullable = false)
	String caseNo;

	@Column(nullable = false)
	String crn;

	@Column(nullable = false)
	Date requestDate = new Date();

	@Column(nullable = true)
	Date responseDate;

	@Column(nullable = false)
	String requestStage;

	@Column(nullable = false)
	String requestStatus;

	@Type(type = "jsonb")
	@Column(columnDefinition = "jsonb", nullable = false)
	private ObjectNode requestBody;

	@Column(columnDefinition = "text", nullable = true)
	private String responseBody;
}
