package com.fadv.cspi.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fadv.cspi.entities.master.ComponentMaster;
import com.fadv.cspi.exception.ServiceException;
import com.fadv.cspi.pojo.response.ComponentMasterResponsePOJO;
import com.fadv.cspi.repository.master.ComponentMasterRepository;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class ComponentMasterServiceImpl implements ComponentMasterService {

	private static final String ERROR_CODE_404 = "ERROR_CODE_404";

	@Autowired
	private ComponentMasterRepository componentMasterRepository;

	private ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES,
			false);

	@Override
	public List<ComponentMasterResponsePOJO> fetchComponentMasterList() {

		List<ComponentMaster> componentMasters = componentMasterRepository.findAll();
		return mapper.convertValue(componentMasters, new TypeReference<List<ComponentMasterResponsePOJO>>() {
		});
	}

	@Override
	public ComponentMaster findByComponentMasterId(Long componentMasterId) throws ServiceException {
		Optional<ComponentMaster> componentMasterOptional = componentMasterRepository.findById(componentMasterId);
		if (componentMasterOptional.isPresent()) {
			return componentMasterOptional.get();
		}
		throw new ServiceException("Component Details not found for given component id", ERROR_CODE_404);
	}

	@Override
	public List<ComponentMaster> findByComponentName(String componentName) {
		return componentMasterRepository.findByComponentNameIgnoreCase(componentName);
	}
}
