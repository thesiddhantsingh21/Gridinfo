package com.fadv.cspi.controller;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fadv.cspi.exception.ServiceException;
import com.fadv.cspi.pojo.request.ContactCardMasterRequestPOJO;
import com.fadv.cspi.pojo.response.ResponseStatusPOJO;
import com.fadv.cspi.service.ContactCardMasterService;
import com.fadv.cspi.userdetail.pojo.UserDetailPOJO;

import io.swagger.annotations.ApiOperation;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/india/")
public class ContactCardMasterController {

	@Autowired
	private ContactCardMasterService contactCardMasterService;

	private static final String SUCCESS_CODE_200 = "SUCCESS_CODE_200";

	private static final String TOKEN_ID = "tokenid";

	private static final String USER_ID = "userId";

	private static final String USER_NAME = "userName";

	private static final Logger logger = LoggerFactory.getLogger(ContactCardMasterController.class);

	@ApiOperation(value = "This API is used for saving/updating a contact card", response = ResponseStatusPOJO.class)
	@PostMapping(path = "save-contact-card", produces = "application/json", consumes = "application/json")
	public ResponseEntity<ResponseStatusPOJO> createNewContactCard(HttpServletRequest request,
			@Valid @RequestBody ContactCardMasterRequestPOJO contactCardMasterRequestPOJO) {
		logger.info("Contact card to save/update : {}", contactCardMasterRequestPOJO);
		String userName = request.getAttribute(USER_NAME).toString().isEmpty() ? USER_NAME
				: request.getAttribute(USER_NAME).toString();
		String userId = request.getAttribute(USER_ID).toString().isEmpty() ? USER_ID
				: request.getAttribute(USER_ID).toString();
		String tokenId = request.getHeader(TOKEN_ID).isEmpty() ? TOKEN_ID : request.getHeader(TOKEN_ID);

		UserDetailPOJO userDetailPOJO = new UserDetailPOJO(userName, userId);
		try {
			return new ResponseEntity<>(
					new ResponseStatusPOJO(true, "Record saved successfully", SUCCESS_CODE_200, contactCardMasterService
							.createNewContactCardMaster(contactCardMasterRequestPOJO, userDetailPOJO, tokenId)),
					HttpStatus.OK);
		} catch (ServiceException e1) {
			return new ResponseEntity<>(new ResponseStatusPOJO(false, e1.getMessage(), e1.getMessageId()),
					HttpStatus.OK);
		} catch (Exception e2) {
			return new ResponseEntity<>(new ResponseStatusPOJO(false, e2.getMessage()), HttpStatus.OK);
		}
	}

	@ApiOperation(value = "This API is used for fetching all contact card matching with given search criteria", response = ResponseStatusPOJO.class)
	@GetMapping(path = "existing-university-college-name", produces = "application/json")
	public ResponseEntity<ResponseStatusPOJO> getContactCardUsingExistingUniversityCollegeName(
			@RequestParam(name = "componentName") String componentName,
			@RequestParam(name = "searchStr", required = true) String searchStr) {
		try {
			return new ResponseEntity<>(
					new ResponseStatusPOJO(true, "Record feched successfully", SUCCESS_CODE_200,
							contactCardMasterService.getContactCardDetailsBySearch(componentName, searchStr)),
					HttpStatus.OK);
		} catch (Exception e2) {
			return new ResponseEntity<>(new ResponseStatusPOJO(false, e2.getMessage()), HttpStatus.OK);
		}
	}
}
