package com.fadv.cspi.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.UUID;
import java.util.stream.Collectors;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.fadv.cspi.entities.mapping.CaseDeXlsConfig;
import com.fadv.cspi.entities.mapping.DocFieldMapping;
import com.fadv.cspi.entities.master.ContactCardMaster;
import com.fadv.cspi.entities.master.DocumentFieldMaster;
import com.fadv.cspi.entities.master.DocumentMaster;
import com.fadv.cspi.entities.transaction.CaseAssociatedDocuments;
import com.fadv.cspi.entities.transaction.CaseClientDetails;
import com.fadv.cspi.entities.transaction.CaseDataEntry;
import com.fadv.cspi.entities.transaction.CaseDetails;
import com.fadv.cspi.entities.transaction.CaseUploadedDocuments;
import com.fadv.cspi.exception.ServiceException;
import com.fadv.cspi.fullfilment.entities.MiFulfilmentRequest;
import com.fadv.cspi.fullfilment.service.MiFulfilmentRequestService;
import com.fadv.cspi.pojo.AutoDataEntryDataPOJO;
import com.fadv.cspi.pojo.AutoDataEntryPOJO;
import com.fadv.cspi.pojo.DataEntryFormSearchPOJO;
import com.fadv.cspi.pojo.DeleteDataEntryPOJO;
import com.fadv.cspi.pojo.FieldFormSearchPOJO;
import com.fadv.cspi.pojo.RemoteApiPOJO;
import com.fadv.cspi.pojo.StartEndPagePOJO;
import com.fadv.cspi.pojo.UniqueFormArrayPOJO;
import com.fadv.cspi.pojo.ValidationErrorPOJO;
import com.fadv.cspi.pojo.request.AutoDocAssociationPOJO;
import com.fadv.cspi.pojo.response.DocumentFieldMasterResponsePOJO;
import com.fadv.cspi.repository.mapping.CaseDeXlsConfigRepository;
import com.fadv.cspi.repository.master.CityMasterRepository;
import com.fadv.cspi.repository.master.ContactCardMasterRepository;
import com.fadv.cspi.repository.master.CountryMasterRepository;
import com.fadv.cspi.repository.master.QualificationLevelMasterRepository;
import com.fadv.cspi.repository.master.QualificationMasterRepository;
import com.fadv.cspi.repository.master.StateMasterRepository;
import com.fadv.cspi.repository.transaction.CaseDataEntryRepository;
import com.fadv.cspi.userdetail.pojo.UserDetailPOJO;
import com.fadv.cspi.utility.ConversionUtility;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

@Service
public class CaseDataEntryServiceImpl implements CaseDataEntryService {

	private static final String ADDRESS_DETAILS_PERMANENT_AS_PER_BVF = "Address Details - Permanent (As per BVF)";

	private static final String ADDRESS_PREVIOUS_AS_PER_BVF = "Address-Previous (As per BVF)";

	private static final String ADDRESS_DETAILS_CURRENT_AS_PER_BVF = "Address Details - Current (As per BVF)";

	private static final String CITY = "city";

	private static final String STATE = "state";

	private static final String COUNTRY = "country";

	private static final String AKA_NAME = "akaName";

	private static final String PERSONAL_DETAILS_AS_PER_BVF = "personaldetailsasperbvf";

	private static final String EMPLOYMENT_DETAILS_AS_PER_BVF = "employmentdetailsasperbvf";

	private static final String DATE_OF_EXIT_TILL_DATE = "dateofexittilldate";

	private static final String DATE_OF_EXIT = "dateofexit";

	private static final String ERROR_CODE_400 = "ERROR_CODE_400";

	private static final String ERROR_CODE_404 = "ERROR_CODE_404";

	private static final String CASE_DATA_ENTRY = "case_data_entry";

	@Autowired
	private CaseDataEntryRepository caseDataEntryRepository;

	@Autowired
	private CaseAssociatedDocumentsService caseAssociatedDocumentsService;

	@Autowired
	private DocFieldMappingService docFieldMappingService;

	@Autowired
	private ContactCardMasterService contactCardMasterService;

	@Autowired
	private CaseClientDetailsService caseClientDetailsService;

	@Autowired
	private DocumentMasterService documentMasterService;

	@Autowired
	private FieldValidationService fieldValidationService;

	@Autowired
	private CopyFeatureConfigSevice copyFeatureConfigSevice;

	@Autowired
	private CaseDetailsService caseDetailsService;

	@Autowired
	private DocumentFieldMasterService documentFieldMasterService;

	@Autowired
	private ApiService apiService;

	@Autowired
	private MiFulfilmentRequestService miFulfilmentRequestService;

	@Autowired
	private CaseUploadedDocumentsService caseUploadedDocumentsService;

	@Value("${search.s3.file.url}")
	private String searchS3FileUrl;

	@Value("${auto.split.file.url}")
	private String autoSplitFileUrl;

	@Value("${de.first.document}")
	private String deFirstDocument;

	@Value("${case-creation-field-config-url}")
	private String caseCreationFieldConfigUrl;

	@Autowired
	private CaseDeXlsConfigRepository caseDeXlsConfigRepository;

	@Autowired
	private CountryMasterRepository countryMasterRepository;

	@Autowired
	private StateMasterRepository stateMasterRepository;

	@Autowired
	private CityMasterRepository cityMasterRepository;

	@Autowired
	private ContactCardMasterRepository contactCardMasterRepository;

	@Autowired
	private QualificationLevelMasterRepository qualificationLevelMasterRepository;

	@Autowired
	private QualificationMasterRepository qualificationMasterRepository;

	@Autowired
	private InsertIntoWorkflowService insertIntoWorkflowService;

	@Value("${write.excel.data.entry}")
	private String writeExcelDataEntry;

	@Autowired
	private ExcelDataEntryService excelDataEntryService;

	private ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES,
			false);

	private static final Logger logger = LoggerFactory.getLogger(CaseDataEntryServiceImpl.class);

// ===============================================================================================================================
// ----------------------START------------------METHOD(S) FOR FETCHING SAVED DATA ENTRY DATA------------------START---------------
// ===============================================================================================================================
	@Override
	public DataEntryFormSearchPOJO fetchDataEntryForm(DataEntryFormSearchPOJO dataEntryFormSearchPOJO)
			throws ServiceException {
		String dataEntryFormSearchPOJOStr = dataEntryFormSearchPOJO.toJSON();
		logger.info("search parameters for : {}", dataEntryFormSearchPOJOStr);
		// Retrieve all variables from request POJO
		long caseDetailsId = dataEntryFormSearchPOJO.getCaseDetailsId();

		// ***************DE Completion and crn check******************
		CaseDetails caseDetails = caseDetailsService.findByCaseDetailsId(caseDetailsId);
		checkForValidCrn(caseDetails);
		// ************************************************************

		String rowId = dataEntryFormSearchPOJO.getRowId();
		long documentMasterId = dataEntryFormSearchPOJO.getDocumentMasterId();
		String documentName = dataEntryFormSearchPOJO.getDocumentName();

		// Initialize an array of document fields to be returned
		List<DocumentFieldMasterResponsePOJO> documentFieldMasterResponsePOJOs;

		// Fetch the data entry node done against the provided case_details_id, row_id
		// and document_master_id
		ObjectNode rowIdNode = getSpecificRowIdDataEntry(caseDetailsId, rowId, documentMasterId);
		logger.info("data entry data found for given row_id : {}", rowIdNode);

		/*
		 * if InstructionCheckId is present set it in the DataEntryFormSearchPOJO
		 */
		boolean isInstructionCheckIdPresent = rowIdNode.has("instructioncheckid");
		if (isInstructionCheckIdPresent) {
			String instructionCheckId = rowIdNode.get("instructioncheckid").asText();
			dataEntryFormSearchPOJO.setInstructionCheckId(instructionCheckId);
		}

		// Trim and change the document name to all lower case
		String documentNameKey = ConversionUtility.removeNonAlphaNumericAndSpace(documentName);

		// Check if document name is Personal Details (As per BVF)
		if (StringUtils.equalsIgnoreCase(documentNameKey, PERSONAL_DETAILS_AS_PER_BVF)) {

			// Update all the field values if there is any data entry done already
			documentFieldMasterResponsePOJOs = updateDocumentFieldsUsingRowIdNode(documentNameKey, documentMasterId,
					rowIdNode);

			// Update fields related to akaName
			updateFormFieldUsingAkaName(dataEntryFormSearchPOJO, documentFieldMasterResponsePOJOs);
		} else {
			// Fetch data other than Personal Details (As per BVF)
			documentFieldMasterResponsePOJOs = fetchNonPersonalDetailsForm(dataEntryFormSearchPOJO, rowIdNode);
		}
		documentFieldMasterResponsePOJOs.sort(Comparator.comparing(DocumentFieldMasterResponsePOJO::getSequenceId));
		dataEntryFormSearchPOJO.setFormDataSize(documentFieldMasterResponsePOJOs.size());

		// Fetch the data entry Error node against the provided case_details_id, row_id
		// and document_master_id
		ObjectNode errorNode = getSpecificRowIdDataEntryError(caseDetailsId, rowId, documentMasterId);
		List<String> errorKeys = ConversionUtility.findKeys(errorNode);

		documentFieldMasterResponsePOJOs.stream().filter(data -> errorKeys.contains(data.getDocumentFieldKey()))
				.forEach(data -> {
					/*
					 * Handling the null pointer exception caused by key not found
					 */
					try {
						String defaultValue = errorNode.get(data.getDocumentFieldKey()).get("defaultValue").asText();
						String ingestedValue = errorNode.get(data.getDocumentFieldKey()).get("ingestedValue").asText();

						if (data.getDocumentFieldKey().contains("akaname")) {
							data.setIngestedValue(ingestedValue);
						} else {
							data.setIngestedValue(ingestedValue);
							data.setDefaultValue(defaultValue);
						}
					} catch (Exception ex) {
						String defaultValue = "";
						String ingestedValue = errorNode.get(data.getDocumentFieldKey()).asText();

						if (data.getDocumentFieldKey().contains("akaname")) {
							data.setIngestedValue(ingestedValue);
						} else {
							data.setIngestedValue(ingestedValue);
							data.setDefaultValue(defaultValue);
						}
					}
				});

		dataEntryFormSearchPOJO.setFormData(documentFieldMasterResponsePOJOs);
		return dataEntryFormSearchPOJO;
	}

	@Override
	public FieldFormSearchPOJO fetchFieldEntryForm(FieldFormSearchPOJO fieldFormSearchPOJO) throws ServiceException {

		long caseDetailsId = fieldFormSearchPOJO.getCaseDetailsId();

		// ***************DE Completion and crn check******************
		CaseDetails caseDetails = caseDetailsService.findByCaseDetailsId(caseDetailsId);
		checkForValidCrn(caseDetails);

		// get unique field from doc_field_mapping by given fieldName
		List<DocumentFieldMasterResponsePOJO> documentFieldMasterResponseList = docFieldMappingService
				.getAllFieldsByFieldName(fieldFormSearchPOJO.getFields());

		fieldFormSearchPOJO
				.setFormDataSize(documentFieldMasterResponseList != null ? documentFieldMasterResponseList.size() : 0);
		fieldFormSearchPOJO.setFormData(documentFieldMasterResponseList);
		return fieldFormSearchPOJO;
	}

	@Override
	public List<DocumentFieldMasterResponsePOJO> updateDocumentFieldsUsingRowIdNode(String documentNameKey,
			long documentMasterId, JsonNode rowIdNode) throws ServiceException {

		// Initialize an array of strings to store all the keys of data entry data
		List<String> rowIdNodeKeys = new ArrayList<>();
		if (rowIdNode != null) {
			rowIdNodeKeys = ConversionUtility.findKeys(rowIdNode);
		}

		// get all the fields of a document by given document master id
		List<DocumentFieldMasterResponsePOJO> documentFieldMasterResponseList = docFieldMappingService
				.getAllDocumentsFieldsByDocumentMasterId(documentMasterId);

		List<String> parentDocFieldKeys = new ArrayList<>();

		documentFieldMasterResponseList.stream().filter(
				data -> data.getParentDocumentKey() != null && StringUtils.isNotEmpty(data.getParentDocumentKey()))
				.forEach(data -> {
					parentDocFieldKeys.add(data.getParentDocumentKey());
					data.setDocumentFieldKey(data.getDocumentFieldKey() + "1");
					data.setParentDocumentKey(data.getParentDocumentKey() + "1");
				});
		documentFieldMasterResponseList.stream().filter(data -> parentDocFieldKeys.contains(data.getDocumentFieldKey()))
				.forEach(data -> {
					data.setDocumentFieldKey(data.getDocumentFieldKey() + "1");
				});

		List<DocumentFieldMasterResponsePOJO> documentFieldMasterResponsePOJOs = new ArrayList<>();
		List<String> documentFieldResponseKeys = documentFieldMasterResponseList.stream()
				.map(DocumentFieldMasterResponsePOJO::getDocumentFieldKey).collect(Collectors.toList());

		rowIdNodeKeys.stream().filter(data -> !documentFieldResponseKeys.contains(data)).forEach(data -> {
			List<DocumentFieldMaster> documentFieldMasters = documentFieldMasterService.getByFieldKeyReverse(data);
			if (CollectionUtils.isNotEmpty(documentFieldMasters)) {
				try {
					DocumentFieldMasterResponsePOJO documentFieldMasterResponsePOJO = docFieldMappingService
							.findByDocumentFieldAndDocumentMaster(documentFieldMasters.get(0), documentMasterId);
					if (documentFieldMasterResponsePOJO != null) {
						documentFieldMasterResponsePOJO.setDocumentFieldKey(data);
						if (documentFieldMasterResponsePOJO.getParentDocumentKey() != null
								&& StringUtils.isNotEmpty(documentFieldMasterResponsePOJO.getParentDocumentKey())) {
							String docFieldKeyRev = StringUtils
									.reverse(documentFieldMasterResponsePOJO.getDocumentFieldKey());
							List<String> values = Arrays.asList(docFieldKeyRev.split("\\D+"));
							if (CollectionUtils.isNotEmpty(values) && StringUtils.isNotEmpty(values.get(0))) {
								documentFieldMasterResponsePOJO
										.setParentDocumentKey(documentFieldMasterResponsePOJO.getParentDocumentKey()
												+ StringUtils.reverse(values.get(0)));
							}
						}
						documentFieldMasterResponseList.add(documentFieldMasterResponsePOJO);
					}
				} catch (ServiceException e) {
					logger.error("Exception while fetching field details : {}", e.getMessage());
				}
			}
		});

		// Stream all fields in parallel and update the fields
		for (DocumentFieldMasterResponsePOJO documentFieldMasterResponsePOJO : documentFieldMasterResponseList) {
			String fieldKeys = documentFieldMasterResponsePOJO.getDocumentFieldKey();

			updateNonUniqueTypeFields(documentNameKey, rowIdNode, documentFieldMasterResponsePOJOs,
					documentFieldMasterResponsePOJO, fieldKeys);
		}

		List<String> parentDocKeys = new ArrayList<>();
		List<DocumentFieldMasterResponsePOJO> newDocumentFieldMasterResponsePOJOs = new ArrayList<>();

		for (DocumentFieldMasterResponsePOJO documentFieldMasterResponsePOJO : documentFieldMasterResponsePOJOs) {
			if (documentFieldMasterResponsePOJO.getParentDocumentKey() != null
					&& StringUtils.isNotEmpty(documentFieldMasterResponsePOJO.getParentDocumentKey())) {
				String docFieldKeyRev = StringUtils.reverse(documentFieldMasterResponsePOJO.getParentDocumentKey());
				List<String> values = Arrays.asList(docFieldKeyRev.split("\\D+"));
				docFieldKeyRev = StringUtils.reverse(docFieldKeyRev);
				if (CollectionUtils.isNotEmpty(values) && StringUtils.isNotEmpty(values.get(0))) {
					int strLen = values.get(0).length();
					while (strLen > 0) {
						docFieldKeyRev = StringUtils.chop(docFieldKeyRev);
						strLen--;
					}
				}
				documentFieldMasterResponsePOJO.setGroupKey(docFieldKeyRev);
				parentDocKeys.add(documentFieldMasterResponsePOJO.getParentDocumentKey());
			}
			newDocumentFieldMasterResponsePOJOs.add(documentFieldMasterResponsePOJO);
		}

		logger.info("parent doc keys : {}", parentDocKeys);
		newDocumentFieldMasterResponsePOJOs.stream().filter(data -> parentDocKeys.contains(data.getDocumentFieldKey()))
				.forEach(data -> {
					data.setGroupKey(ConversionUtility.removeNonAlphaNumericAndSpace(data.getDocumentFieldName()));
				});

		return newDocumentFieldMasterResponsePOJOs;
	}

	private void updateNonUniqueTypeFields(String documentNameKey, JsonNode finalRowIdNode,
			List<DocumentFieldMasterResponsePOJO> documentFieldMasterResponsePOJOs,
			DocumentFieldMasterResponsePOJO documentFieldMasterResponsePOJO, String fieldKeys) {
		if (StringUtils.equalsIgnoreCase(ConversionUtility.removeNonAlphaNumericAndSpace(documentNameKey),
				EMPLOYMENT_DETAILS_AS_PER_BVF)
				&& (StringUtils.equalsIgnoreCase(fieldKeys, DATE_OF_EXIT)
						|| StringUtils.equalsIgnoreCase(fieldKeys, DATE_OF_EXIT_TILL_DATE))) {
			documentFieldMasterResponsePOJO.setMandatory(false);
		}
		if (finalRowIdNode != null) {
			String fieldValue = finalRowIdNode.has(fieldKeys) ? finalRowIdNode.get(fieldKeys).asText() : null;
			documentFieldMasterResponsePOJO.setDefaultValue(fieldValue);
		}
		documentFieldMasterResponsePOJOs.add(documentFieldMasterResponsePOJO);
	}

	private void updateFormFieldUsingAkaName(DataEntryFormSearchPOJO dataEntryFormSearchPOJO,
			List<DocumentFieldMasterResponsePOJO> documentFieldMasterResponsePOJOs) {
		ContactCardMaster contactCardMaster = contactCardMasterService
				.getContactCardByAkaName(dataEntryFormSearchPOJO.getAkaName());

		if (contactCardMaster != null) {
			checkUrlAndUpdateDefaultValue(contactCardMaster, documentFieldMasterResponsePOJOs);
		}
	}

	@Override
	public void checkUrlAndUpdateDefaultValue(ContactCardMaster contactCardMaster,
			List<DocumentFieldMasterResponsePOJO> documentFieldMasterResponsePOJOs) {

		List<RemoteApiPOJO> remoteApiPOJOs = documentFieldMasterResponsePOJOs.stream()
				.filter(data -> data != null && data.isAutoPopulate() && data.getRemoteApi() != null
						&& data.getRemoteApi().has("staticFields"))
				.map(data -> mapper.convertValue(data.getRemoteApi(), RemoteApiPOJO.class))
				.collect(Collectors.toList());

		remoteApiPOJOs.stream().forEach(remoteApiPOJO -> {
			remoteApiPOJO.getStaticFields().stream().forEach(staticField -> documentFieldMasterResponsePOJOs.stream()
					.filter(documentFieldMasterResponsePOJO -> StringUtils.equalsIgnoreCase(
							documentFieldMasterResponsePOJO.getDocumentFieldKey(), staticField.getMapFieldName()))
					.forEach(documentFieldMasterResponsePOJO -> {
						documentFieldMasterResponsePOJO.setReadOnly(true);
						String selectedFieldName = staticField.getSelectedFieldName();
						if (StringUtils.equalsIgnoreCase(selectedFieldName, "universityEmploymentName")) {
							documentFieldMasterResponsePOJO
									.setDefaultValue(contactCardMaster.getUniversityEmploymentName());
						} else if (StringUtils.equalsIgnoreCase(selectedFieldName, COUNTRY)) {
							documentFieldMasterResponsePOJO
									.setDefaultValue(contactCardMaster.getCountryMaster().getCountryName());
						} else if (StringUtils.equalsIgnoreCase(selectedFieldName, STATE)) {
							documentFieldMasterResponsePOJO
									.setDefaultValue(contactCardMaster.getStateMaster().getStateName());
						} else if (StringUtils.equalsIgnoreCase(selectedFieldName, CITY)) {
							documentFieldMasterResponsePOJO
									.setDefaultValue(contactCardMaster.getCityMaster().getCityName());
						}
					}));

			documentFieldMasterResponsePOJOs.stream()
					.filter(data -> data.getRemoteApi() != null && data.isAutoPopulate()
							&& data.getRemoteApi().has("primaryKey")
							&& StringUtils.equalsIgnoreCase(data.getRemoteApi().get("primaryKey").asText(), AKA_NAME))
					.forEach(data -> {
						data.setDefaultValue(contactCardMaster.getAkaName());
						data.setReadOnly(true);
					});
		});

	}

	@Override
	public List<DocumentFieldMasterResponsePOJO> checkUrlAndUpdateAkaEditValue(ContactCardMaster contactCardMaster,
			List<DocumentFieldMasterResponsePOJO> documentFieldMasterResponsePOJOs) {

		List<RemoteApiPOJO> remoteApiPOJOs = documentFieldMasterResponsePOJOs.stream()
				.filter(data -> data != null && data.isAutoPopulate() && data.getRemoteApi() != null
						&& data.getRemoteApi().has("staticFields"))
				.map(data -> mapper.convertValue(data.getRemoteApi(), RemoteApiPOJO.class))
				.collect(Collectors.toList());

		List<DocumentFieldMasterResponsePOJO> newDocumentFieldMasterResponsePOJOs = new ArrayList<>();

		remoteApiPOJOs.stream().forEach(remoteApiPOJO -> {
			remoteApiPOJO.getStaticFields().stream().forEach(staticField -> documentFieldMasterResponsePOJOs.stream()
					.filter(documentFieldMasterResponsePOJO -> StringUtils.equalsIgnoreCase(
							documentFieldMasterResponsePOJO.getDocumentFieldKey(), staticField.getMapFieldName()))
					.forEach(documentFieldMasterResponsePOJO -> {
						documentFieldMasterResponsePOJO.setReadOnly(true);
						String selectedFieldName = staticField.getSelectedFieldName();
						if (StringUtils.equalsIgnoreCase(selectedFieldName, "universityEmploymentName")) {
							documentFieldMasterResponsePOJO
									.setDefaultValue(contactCardMaster.getUniversityEmploymentName());
							newDocumentFieldMasterResponsePOJOs.add(documentFieldMasterResponsePOJO);
						} else if (StringUtils.equalsIgnoreCase(selectedFieldName, COUNTRY)) {
							documentFieldMasterResponsePOJO
									.setDefaultValue(contactCardMaster.getCountryMaster().getCountryName());
							newDocumentFieldMasterResponsePOJOs.add(documentFieldMasterResponsePOJO);
						} else if (StringUtils.equalsIgnoreCase(selectedFieldName, STATE)) {
							documentFieldMasterResponsePOJO
									.setDefaultValue(contactCardMaster.getStateMaster().getStateName());
							newDocumentFieldMasterResponsePOJOs.add(documentFieldMasterResponsePOJO);
						} else if (StringUtils.equalsIgnoreCase(selectedFieldName, CITY)) {
							documentFieldMasterResponsePOJO
									.setDefaultValue(contactCardMaster.getCityMaster().getCityName());
							newDocumentFieldMasterResponsePOJOs.add(documentFieldMasterResponsePOJO);
						}
					}));

			documentFieldMasterResponsePOJOs.stream()
					.filter(data -> data.getRemoteApi() != null && data.isAutoPopulate()
							&& data.getRemoteApi().has("primaryKey")
							&& StringUtils.equalsIgnoreCase(data.getRemoteApi().get("primaryKey").asText(), AKA_NAME))
					.forEach(data -> {
						data.setDefaultValue(contactCardMaster.getAkaName());
						data.setReadOnly(true);

						newDocumentFieldMasterResponsePOJOs.add(data);
					});
		});

		return newDocumentFieldMasterResponsePOJOs;

	}

	private List<DocumentFieldMasterResponsePOJO> fetchNonPersonalDetailsForm(
			DataEntryFormSearchPOJO dataEntryFormSearchPOJO, ObjectNode rowIdNode) throws ServiceException {
		long caseDetailsId = dataEntryFormSearchPOJO.getCaseDetailsId();
		long documentMasterId = dataEntryFormSearchPOJO.getDocumentMasterId();
		String documentName = dataEntryFormSearchPOJO.getDocumentName();
		long parentDocumentMasterId = dataEntryFormSearchPOJO.getParentDocumentMasterId() != null
				? dataEntryFormSearchPOJO.getParentDocumentMasterId()
				: 0L;
		String parentRowId = dataEntryFormSearchPOJO.getParentRowId();
		List<DocumentFieldMasterResponsePOJO> documentFieldMasterResponsePOJOs;
		JsonNode personalDetailNode = fetchPersonalDetailsData(caseDetailsId);

		if (rowIdNode == null || rowIdNode.isEmpty()) {
			rowIdNode = getSupportingRowIdNodeIfNull(documentMasterId);
		}

		List<String> rowIdNodeKeys = ConversionUtility.findKeys(rowIdNode);
		if (StringUtils.isNotEmpty(parentRowId) && parentDocumentMasterId > 0) {

			JsonNode parentRowIdNode = getSpecificRowIdDataEntry(caseDetailsId, parentRowId, parentDocumentMasterId);

			if (parentRowIdNode == null || parentRowIdNode.isEmpty()) {
				throw new ServiceException("Parent document data entry not done", ERROR_CODE_400);
			}

			ObjectNode newRowIdNode = rowIdNode;
			rowIdNodeKeys.stream().forEach(rowKey -> {
				copyFromPrimaryToSupportingDoc(newRowIdNode, personalDetailNode, rowKey);
				copyFromPrimaryToSupportingDoc(newRowIdNode, parentRowIdNode, rowKey);
			});
			updateRowIdWithParentRowIdForUniqueTypeFields(newRowIdNode, parentRowIdNode);
			documentFieldMasterResponsePOJOs = updateDocumentFieldsUsingRowIdNode(documentName, documentMasterId,
					rowIdNode);
			updateFormFieldUsingAkaName(dataEntryFormSearchPOJO, documentFieldMasterResponsePOJOs);
		} else {
			ObjectNode newRowIdNode = rowIdNode;
			rowIdNodeKeys.stream()
					.forEach(rowKey -> copyFromPrimaryToSupportingDoc(newRowIdNode, personalDetailNode, rowKey));
			documentFieldMasterResponsePOJOs = updateDocumentFieldsUsingRowIdNode(documentName, documentMasterId,
					rowIdNode);
			updateFormFieldUsingAkaName(dataEntryFormSearchPOJO, documentFieldMasterResponsePOJOs);
		}
		return documentFieldMasterResponsePOJOs;
	}

	private void updateRowIdWithParentRowIdForUniqueTypeFields(ObjectNode newRowIdNode, JsonNode parentRowIdNode) {

		List<String> newRowIdKeys = ConversionUtility.findKeys(newRowIdNode);
		newRowIdKeys.stream().forEach(data -> {
			data = StringUtils.reverse(data);

			List<String> values = Arrays.asList(data.split("\\D+"));

			data = StringUtils.reverse(data);

			if (CollectionUtils.isNotEmpty(values) && StringUtils.isNotEmpty(values.get(0))) {
				int strLen = values.get(0).length();
				while (strLen > 0) {
					data = StringUtils.chop(data);
					strLen--;
				}
			}
		});
		List<String> parentNodeKeys = ConversionUtility.findKeys(parentRowIdNode);
		List<String> matchingKeys = new ArrayList<>();

		for (String parentNodeKey : parentNodeKeys) {
			for (String newNodeKey : newRowIdKeys) {
				if (parentNodeKey.startsWith(newNodeKey)) {
					matchingKeys.add(parentNodeKey);
				}
			}
		}

		for (String fieldName : matchingKeys) {
			if (newRowIdNode.get(fieldName) == null
					|| (newRowIdNode.has(fieldName) && StringUtils.isEmpty(newRowIdNode.get(fieldName).asText()))) {
				newRowIdNode.put(fieldName,
						parentRowIdNode.has(fieldName) ? parentRowIdNode.get(fieldName).asText() : "");
			}
		}
	}

	private JsonNode fetchPersonalDetailsData(long caseDetailsId) throws ServiceException {
		Map<String, List<String>> docFields = copyFeatureConfigSevice.getDocumentAndFiledKeyMap();
		List<String> fieldKeys = docFields.get("Personal Details (As per BVF)");
		if (fieldKeys == null) {
			fieldKeys = new ArrayList<>();
		}

		List<CaseDataEntry> caseDataEntries = caseDataEntryRepository
				.getCaseDataEntryByDocumentNameAndCaseDetailsId("Personal Details (As per BVF)", caseDetailsId);

		if (CollectionUtils.isNotEmpty(caseDataEntries)) {
			CaseDataEntry caseDataEntry = caseDataEntries.get(0);
			JsonNode deData = caseDataEntry.getDataEntryData() != null ? caseDataEntry.getDataEntryData()
					: mapper.createObjectNode();
			ObjectNode fieldNode = mapper.createObjectNode();
			for (String key : fieldKeys) {
				fieldNode.put(key, deData.has(key) ? deData.get(key).asText() : "");
			}
			return fieldNode;
		}
		throw new ServiceException("Personal Details (As per BVF) data entry not done", ERROR_CODE_400);
	}

	private ObjectNode getSupportingRowIdNodeIfNull(long documentMasterId) throws ServiceException {
		List<DocumentFieldMasterResponsePOJO> documentFieldMasterResponsePOJOs = docFieldMappingService
				.getAllDocumentsFieldsByDocumentMasterId(documentMasterId);
		ObjectNode rowIdNode = mapper.createObjectNode();

		for (DocumentFieldMasterResponsePOJO documentFieldMasterResponsePOJO : documentFieldMasterResponsePOJOs) {
			String keyFieldName = documentFieldMasterResponsePOJO.getDocumentFieldKey();
			if (!rowIdNode.has(keyFieldName)) {
				rowIdNode.put(keyFieldName, "");
			}
		}

		logger.info("rowIdNode size : {}", rowIdNode.size());

		return rowIdNode;
	}

	private void copyFromPrimaryToSupportingDoc(ObjectNode rowIdNode, JsonNode parentRowIdNode, String rowKey) {
		String rowValue = rowIdNode.has(rowKey) ? rowIdNode.get(rowKey).asText() : "";
		if (StringUtils.isEmpty(rowValue)) {
			String parentRowValue = parentRowIdNode.has(rowKey) ? parentRowIdNode.get(rowKey).asText() : "";
			if (parentRowValue != null && StringUtils.isNotEmpty(parentRowValue)) {
				rowIdNode.put(rowKey, parentRowValue);
			}
		}
	}
// ===============================================================================================================================
// -----------------------END-------------------METHOD(S) FOR FETCHING SAVED DATA ENTRY DATA-------------------END----------------
// ===============================================================================================================================

//===============================================================================================================================
//---------------------START-------------------METHOD(S) FOR SAVING DATA ENTRY DATA----------------START-------------------------
//===============================================================================================================================	

	@Override
	public DataEntryFormSearchPOJO saveDataEntryDetails(DataEntryFormSearchPOJO dataEntryFormSearchPOJO,
			UserDetailPOJO userDetailPOJO, String tokenId) throws ServiceException, JsonProcessingException {

		logger.info("DataEntryFormSearchPOJO: {}", dataEntryFormSearchPOJO);

		// Retrieve all variables from request POJO
		String documentName = dataEntryFormSearchPOJO.getDocumentName();

		long documentMasterId = dataEntryFormSearchPOJO.getDocumentMasterId();
		String rowId = dataEntryFormSearchPOJO.getRowId();

		long caseDetailsId = dataEntryFormSearchPOJO.getCaseDetailsId();
		Long fulfillmentId = dataEntryFormSearchPOJO.getFulfillmentId();

		// ***************DE Completion and crn check******************
		CaseDetails caseDetails = caseDetailsService.findByCaseDetailsId(caseDetailsId);
		checkForValidCrn(caseDetails);

		MiFulfilmentRequest miFulfilmentRequest = null;
		if (fulfillmentId != null) {
			miFulfilmentRequest = miFulfilmentRequestService.findByMiFulfilmentRequestId(fulfillmentId);
		}
		checkForDeCompletion(caseDetails, miFulfilmentRequest);
		// ************************************************************

		String parentRowId = dataEntryFormSearchPOJO.getParentRowId() != null ? dataEntryFormSearchPOJO.getParentRowId()
				: "";
		long parentDocumentMasterId = dataEntryFormSearchPOJO.getParentDocumentMasterId() != null
				? dataEntryFormSearchPOJO.getParentDocumentMasterId()
				: 0;
		String akaName = dataEntryFormSearchPOJO.getAkaName() != null ? dataEntryFormSearchPOJO.getAkaName() : "";
		String agencyAkaName = dataEntryFormSearchPOJO.getAgencyAkaName() != null
				? dataEntryFormSearchPOJO.getAgencyAkaName()
				: "";

		List<DocumentFieldMasterResponsePOJO> documentFieldMasterResponsePOJOs = dataEntryFormSearchPOJO.getFormData();
		List<ValidationErrorPOJO> validationResult = fieldValidationService.validatedFormField(
				documentFieldMasterResponsePOJOs, documentName, caseDataEntryRepository, akaName, rowId, parentRowId,
				caseDetailsId, caseDetails);

		logger.info("validationResult : {}", validationResult);
		if (!validationResult.isEmpty()) {
			throw new ServiceException("Validation Error occurred", ERROR_CODE_400, validationResult);
		}

		CaseAssociatedDocuments caseAssociatedDocuments = caseAssociatedDocumentsService
				.getCaseAssociateDocumentByCaseDetailsIdDocumentMasterIdAndRowId(caseDetailsId, documentMasterId,
						rowId);

		if (caseAssociatedDocuments == null) {
			throw new ServiceException("Document association not done. Please associate document first",
					ERROR_CODE_400);
		}

		ObjectNode documentNode = mapper.createObjectNode();
		ObjectNode failedNode = mapper.createObjectNode();

		String documentNameKey = ConversionUtility.removeNonAlphaNumericAndSpace(documentName);

		for (DocumentFieldMasterResponsePOJO documentFieldMasterResponsePOJO : documentFieldMasterResponsePOJOs) {
			String defaultValue = documentFieldMasterResponsePOJO.getDefaultValue() != null
					? documentFieldMasterResponsePOJO.getDefaultValue()
					: "";
			defaultValue = ConversionUtility.convertDefaultDate(defaultValue);
			String fieldKeys = documentFieldMasterResponsePOJO.getDocumentFieldKey();

			List<UniqueFormArrayPOJO> formArray = documentFieldMasterResponsePOJO.getFormArray() != null
					? documentFieldMasterResponsePOJO.getFormArray()
					: new ArrayList<>();

			validateFieldValues(documentNode, failedNode, documentFieldMasterResponsePOJO, defaultValue, fieldKeys,
					formArray);
		}

		handleConcatenatedKeys(documentNode);

		checkForFailedDefaultValueKeys(failedNode, documentNameKey);

		checkParentDocument(rowId, caseDetailsId, parentRowId, parentDocumentMasterId);

		saveDataEntryToDb(rowId, caseDetailsId, parentRowId, documentMasterId, documentNode, caseAssociatedDocuments,
				akaName, agencyAkaName, miFulfilmentRequest, userDetailPOJO, tokenId);

		return fetchDataEntryForm(dataEntryFormSearchPOJO);

	}

	@Override
	public void handleConcatenatedKeys(ObjectNode documentNode) {
		List<String> recordKeys = ConversionUtility.findKeys(documentNode);
		for (String recordKey : recordKeys) {
			DocumentFieldMaster documentFieldMaster = documentFieldMasterService.findByDocumentFieldKey(recordKey);
			if (documentFieldMaster != null
					&& (documentFieldMaster.getConcatenated() != null && documentFieldMaster.getConcatenated())) {
				ObjectNode concatenatedKeys = documentFieldMaster.getConcatenatedKeys();
				if (concatenatedKeys != null) {
					List<String> fieldKeys = concatenatedKeys.has("keys")
							? mapper.convertValue(concatenatedKeys.get("keys"), new TypeReference<List<String>>() {
							})
							: new ArrayList<>();
					String separator = concatenatedKeys.has("separator") ? concatenatedKeys.get("separator").asText()
							: "";

					List<String> fieldValues = new ArrayList<>();
					for (String key : fieldKeys) {
						String newKey = ConversionUtility.removeNonAlphaNumericAndSpace(key);
						String value = documentNode.has(newKey) ? documentNode.get(newKey).asText() : "";
						if (value != null && StringUtils.isNotEmpty(value)) {
							fieldValues.add(value);
						}
					}
					if (CollectionUtils.isNotEmpty(fieldValues)) {
						documentNode.put(recordKey, String.join(separator, fieldValues));
					}
				}
			}
		}
	}

	private void validateFieldValues(ObjectNode documentNode, ObjectNode failedNode,
			DocumentFieldMasterResponsePOJO documentFieldMasterResponsePOJO, String defaultValue, String fieldKeys,
			List<UniqueFormArrayPOJO> formArray) {
		if (CollectionUtils.isNotEmpty(formArray)) {
			for (UniqueFormArrayPOJO uniqueFormArrayPOJO : formArray) {
				defaultValue = uniqueFormArrayPOJO.getDefaultValue() != null ? uniqueFormArrayPOJO.getDefaultValue()
						: "";
				fieldKeys = uniqueFormArrayPOJO.getDocumentFieldKey();

				if (uniqueFormArrayPOJO.getIsMandatory() != null && uniqueFormArrayPOJO.getIsMandatory()
						&& StringUtils.isEmpty(defaultValue)) {
					failedNode.put(uniqueFormArrayPOJO.getDocumentFieldKey(), "This field is mandatory");
				}
				documentNode.put(fieldKeys, defaultValue);
			}
		} else {
			if (documentFieldMasterResponsePOJO.isMandatory() && StringUtils.isEmpty(defaultValue)) {
				failedNode.put(documentFieldMasterResponsePOJO.getDocumentFieldKey(), "This field is mandatory");
			}
			documentNode.put(fieldKeys, defaultValue);
		}
	}

	private void checkForFailedDefaultValueKeys(ObjectNode failedNode, String documentNameKey) throws ServiceException {
		if (StringUtils.equalsIgnoreCase(documentNameKey, EMPLOYMENT_DETAILS_AS_PER_BVF)
				&& (failedNode.has(DATE_OF_EXIT_TILL_DATE) && failedNode.has(DATE_OF_EXIT))) {
			throw new ServiceException(failedNode.toString(), ERROR_CODE_400);
		} else {
			if (failedNode.has(DATE_OF_EXIT_TILL_DATE)) {
				failedNode.remove(DATE_OF_EXIT_TILL_DATE);
			} else if (failedNode.has(DATE_OF_EXIT)) {
				failedNode.remove(DATE_OF_EXIT);
			}
		}

		if (!failedNode.isEmpty()) {
			throw new ServiceException(failedNode.toString(), ERROR_CODE_400);
		}
	}

	private void checkParentDocument(String rowId, long caseDetailsId, String parentRowId, long parentDocumentMasterId)
			throws ServiceException {
		if (StringUtils.isNotEmpty(parentRowId)) {
			if (parentDocumentMasterId <= 0) {
				throw new ServiceException("Invalid parent document ", ERROR_CODE_400);
			}
			if (StringUtils.equalsIgnoreCase(rowId, parentRowId)) {
				throw new ServiceException("Document row Id and supporting document row id cannot be same",
						ERROR_CODE_400);
			}

			List<CaseDataEntry> caseDataEntries = caseDataEntryRepository
					.getByDocumentMasterIdAndRowIdAndCaseDetailsId(parentDocumentMasterId, parentRowId, caseDetailsId);

			if (CollectionUtils.isEmpty(caseDataEntries)) {
				throw new ServiceException("Invalid parent document row id", ERROR_CODE_400);
			}
		}
	}

	private void saveDataEntryToDb(String rowId, long caseDetailsId, String parentRowId, long documentMasterId,
			ObjectNode documentNode, CaseAssociatedDocuments caseAssociatedDocuments, String akaName,
			String agencyAkaName, MiFulfilmentRequest miFulfilmentRequest, UserDetailPOJO userDetailPOJO,
			String tokenId) throws ServiceException {

		String option = "ADD";
		JsonNode previousJson = mapper.createObjectNode();

		List<CaseDataEntry> caseDataEntries = caseDataEntryRepository
				.getByDocumentMasterIdAndRowIdAndCaseDetailsId(documentMasterId, rowId, caseDetailsId);
		CaseClientDetails caseClientDetails = caseClientDetailsService.findByCaseDetailsId(caseDetailsId);
		DocumentMaster documentMaster = documentMasterService.findByDocumentMasterId(documentMasterId);

		// Copies Address if permanent and previous/current is same
		addressCopyFunction(rowId, caseDetailsId, documentNode, documentMaster, caseClientDetails, userDetailPOJO,
				tokenId);

		String agencyCompanyAkaName = documentNode.has("agencycompanyakaname")
				? documentNode.get("agencycompanyakaname").asText()
				: "";

		if (agencyCompanyAkaName == null || StringUtils.isEmpty(agencyCompanyAkaName)) {
			agencyCompanyAkaName = agencyAkaName;
		}

		CaseDataEntry caseDataEntry = new CaseDataEntry();
		caseDataEntry.setCreatedDate(new Date());
		caseDataEntry.setUpdatedDate(new Date());
		if (CollectionUtils.isNotEmpty(caseDataEntries)) {

			option = "EDIT";
			previousJson = mapper.convertValue(caseDataEntries.get(0), JsonNode.class);

			caseDataEntry.setCaseDataEntryId(caseDataEntries.get(0).getCaseDataEntryId());
			caseDataEntry.setCreatedDate(caseDataEntries.get(0).getCreatedDate());

			String instructionCheckId = caseDataEntries.get(0).getInstructionCheckId();
			caseDataEntry.setDataEntryError(caseDataEntries.get(0).getDataEntryError());
			caseDataEntry.setInstructionCheckId(instructionCheckId);

			if (instructionCheckId != null && !instructionCheckId.isEmpty()) {
				documentNode.put("instructioncheckid", instructionCheckId);
			}

		}
		caseDataEntry.setAkaName(akaName);

		if (agencyCompanyAkaName != null && StringUtils.isNotEmpty(agencyCompanyAkaName)) {
			caseDataEntry.setAgencyAkaName(agencyCompanyAkaName);
			caseAssociatedDocuments.setAgencyAkaName(agencyCompanyAkaName);
			caseAssociatedDocumentsService.saveNewRecord(caseAssociatedDocuments);
		}

		caseDataEntry.setCaseAssociatedDocuments(caseAssociatedDocuments);
		caseDataEntry.setClientMaster(caseClientDetails.getClientMaster());
		caseDataEntry.setCaseDetails(caseClientDetails.getCaseDetails());
		caseDataEntry.setDataEntryData(documentNode);
		caseDataEntry.setDocumentMaster(documentMaster);
		caseDataEntry.setPackageMaster(caseClientDetails.getPackageMaster());
		caseDataEntry.setParentRowId(parentRowId);
		caseDataEntry.setRowId(rowId);
		caseDataEntry.setSbuMaster(caseClientDetails.getSbuMaster());
		caseDataEntry.setUpdatedByUser(userDetailPOJO.getUserId());

		/*
		 * When user saves the data entry then store the dataEntryError as history and
		 * clear the dataEntryError
		 */
		if (caseDataEntry.getDataEntryError() != null && !caseDataEntry.getDataEntryError().isEmpty()) {
			caseDataEntry.setDataEntryErrorHistory(caseDataEntry.getDataEntryError());
			caseDataEntry.setDataEntryError(mapper.createObjectNode());
		}

		if (miFulfilmentRequest != null) {
			caseDataEntry.setMiFulfilmentRequest(miFulfilmentRequest);
		}

		caseDataEntry = caseDataEntryRepository.save(caseDataEntry);

		JsonNode newJson = mapper.convertValue(caseDataEntry, JsonNode.class);
		logger.info("CaseDataEntry Json: {}", newJson);
		apiService.addAuditLog(CASE_DATA_ENTRY, previousJson, newJson, userDetailPOJO, option, tokenId);

	}

	private void addressCopyFunction(String rowId, long caseDetailsId, ObjectNode documentNode,
			DocumentMaster documentMaster, CaseClientDetails caseClientDetails, UserDetailPOJO userDetailPOJO,
			String tokenId) throws ServiceException {
		if (StringUtils.equalsIgnoreCase(documentMaster.getDocumentName(), ADDRESS_DETAILS_CURRENT_AS_PER_BVF)) {
			Map<String, String> fieldNameDocMap = new HashMap<>();
			fieldNameDocMap.put("iscurrentpermanentbotharesame", ADDRESS_DETAILS_PERMANENT_AS_PER_BVF);
			fieldNameDocMap.put("iscurrentpreviousbotharesame", ADDRESS_PREVIOUS_AS_PER_BVF);

			copyAddressDocuments(rowId, caseDetailsId, documentNode, documentMaster, caseClientDetails, fieldNameDocMap,
					userDetailPOJO, tokenId);
		} else if (StringUtils.equalsIgnoreCase(documentMaster.getDocumentName(),
				ADDRESS_DETAILS_PERMANENT_AS_PER_BVF)) {
			Map<String, String> fieldNameDocMap = new HashMap<>();
			fieldNameDocMap.put("ispermanentpreviousbotharesame", ADDRESS_PREVIOUS_AS_PER_BVF);
			fieldNameDocMap.put("iscurrentpermanentbotharesame", ADDRESS_DETAILS_CURRENT_AS_PER_BVF);

			copyAddressDocuments(rowId, caseDetailsId, documentNode, documentMaster, caseClientDetails, fieldNameDocMap,
					userDetailPOJO, tokenId);
		} else if (StringUtils.equalsIgnoreCase(documentMaster.getDocumentName(), ADDRESS_PREVIOUS_AS_PER_BVF)) {
			Map<String, String> fieldNameDocMap = new HashMap<>();
			fieldNameDocMap.put("ispermanentpreviousbotharesame", ADDRESS_DETAILS_PERMANENT_AS_PER_BVF);
			fieldNameDocMap.put("iscurrentpreviousbotharesame", ADDRESS_DETAILS_CURRENT_AS_PER_BVF);

			copyAddressDocuments(rowId, caseDetailsId, documentNode, documentMaster, caseClientDetails, fieldNameDocMap,
					userDetailPOJO, tokenId);
		}
	}

	private void copyAddressDocuments(String rowId, long caseDetailsId, ObjectNode documentNode,
			DocumentMaster documentMaster, CaseClientDetails caseClientDetails, Map<String, String> fieldNameDocMap,
			UserDetailPOJO userDetailPOJO, String tokenId) throws ServiceException {

		for (Entry<String, String> entry : fieldNameDocMap.entrySet()) {
			String fieldName = entry.getKey();
			String documentName = entry.getValue();

			String isBothAddressSame = documentNode.has(fieldName) ? documentNode.get(fieldName).asText() : "";
			if (StringUtils.equalsIgnoreCase(isBothAddressSame, "Yes")) {
				UUID uuid = UUID.randomUUID();
				String copyRowId = uuid.toString();
				copyOverAddress(rowId, caseDetailsId, documentNode, documentMaster, caseClientDetails, documentName,
						userDetailPOJO, tokenId, copyRowId);
			}
		}
	}

	private void copyOverAddress(String rowId, long caseDetailsId, ObjectNode documentNode,
			DocumentMaster documentMaster, CaseClientDetails caseClientDetails, String documentName,
			UserDetailPOJO userDetailPOJO, String tokenId, String copyRowId) throws ServiceException {
		DocumentMaster copyDocumentMaster = documentMasterService.findByDocumentName(documentName);
		if (copyDocumentMaster != null) {

			long copyDocumentMasterId = copyDocumentMaster.getDocumentMasterId();
			CaseAssociatedDocuments copyCaseAssociatedDocuments = caseAssociatedDocumentsService
					.getCaseAssociateDocumentByCaseDetailsIdAndDocumentMasterId(caseDetailsId, copyDocumentMasterId);
			if (copyCaseAssociatedDocuments == null) {

				String option = "ADD";
				JsonNode previousJson = mapper.createObjectNode();

				CaseAssociatedDocuments newCaseAssociatedDocuments = caseAssociatedDocumentsService
						.getCaseAssociateDocumentByCaseDetailsIdDocumentMasterIdAndRowId(caseDetailsId,
								documentMaster.getDocumentMasterId(), rowId);

				copyCaseAssociatedDocuments = new CaseAssociatedDocuments();
				copyCaseAssociatedDocuments.setActive(newCaseAssociatedDocuments.getActive());
				copyCaseAssociatedDocuments.setAssociateAfterCaseReceivedFromSp(
						newCaseAssociatedDocuments.isAssociateAfterCaseReceivedFromSp());
				copyCaseAssociatedDocuments.setCaseDetails(newCaseAssociatedDocuments.getCaseDetails());
				copyCaseAssociatedDocuments
						.setCaseUploadedDocuments(newCaseAssociatedDocuments.getCaseUploadedDocuments());
				copyCaseAssociatedDocuments.setContactCardMaster(newCaseAssociatedDocuments.getContactCardMaster());
				copyCaseAssociatedDocuments.setDocumentMaster(copyDocumentMaster);
				copyCaseAssociatedDocuments.setEndPage(newCaseAssociatedDocuments.getEndPage());
				copyCaseAssociatedDocuments.setFileName(newCaseAssociatedDocuments.getFileName());
				copyCaseAssociatedDocuments.setFilePath(newCaseAssociatedDocuments.getFilePath());
				copyCaseAssociatedDocuments.setParentRowId(newCaseAssociatedDocuments.getParentRowId());
				copyCaseAssociatedDocuments.setRowId(copyRowId);
				copyCaseAssociatedDocuments.setStartPage(newCaseAssociatedDocuments.getStartPage());
				copyCaseAssociatedDocuments.setUpdatedDate(new Date());
				copyCaseAssociatedDocuments.setCreatedDate(new Date());
				copyCaseAssociatedDocuments.setUpdatedByUser(userDetailPOJO.getUserId());

				copyCaseAssociatedDocuments = caseAssociatedDocumentsService.saveNewRecord(copyCaseAssociatedDocuments);

				JsonNode newJson = mapper.convertValue(copyCaseAssociatedDocuments, JsonNode.class);
				logger.info("case_associated_documents Json: {}", newJson);
				apiService.addAuditLog("case_associated_documents", previousJson, newJson, userDetailPOJO, option,
						tokenId);
			}

			String option = "ADD";
			JsonNode previousJson = mapper.createObjectNode();

			List<CaseDataEntry> copyCaseDataEntries = caseDataEntryRepository
					.getByDocumentMasterIdAndCaseDetailsId(copyDocumentMasterId, caseDetailsId);
			ObjectNode copyDocumentNode;

			CaseDataEntry caseDataEntry = new CaseDataEntry();
			if (CollectionUtils.isEmpty(copyCaseDataEntries)) {
				copyDocumentNode = mapper.createObjectNode();
				List<String> documentFieldKeys = docFieldMappingService
						.getAllDocumentFieldKeysByDocumentMasterId(copyDocumentMasterId);
				for (String documentFieldKey : documentFieldKeys) {
					copyDocumentNode.put(documentFieldKey,
							documentNode.has(documentFieldKey) ? documentNode.get(documentFieldKey).asText() : "");
				}

				caseDataEntry.setAkaName("");
				caseDataEntry.setCaseAssociatedDocuments(copyCaseAssociatedDocuments);
				caseDataEntry.setClientMaster(caseClientDetails.getClientMaster());
				caseDataEntry.setCaseDetails(caseClientDetails.getCaseDetails());
				caseDataEntry.setDocumentMaster(copyDocumentMaster);
				caseDataEntry.setPackageMaster(caseClientDetails.getPackageMaster());
				caseDataEntry.setParentRowId("");
				caseDataEntry.setRowId(copyRowId);
				caseDataEntry.setSbuMaster(caseClientDetails.getSbuMaster());
				caseDataEntry.setCreatedDate(new Date());
				caseDataEntry.setUpdatedDate(new Date());
			} else {

				option = "EDIT";
				previousJson = mapper.convertValue(copyCaseDataEntries.get(0), JsonNode.class);

				caseDataEntry = copyCaseDataEntries.get(0);
				copyDocumentNode = caseDataEntry.getDataEntryData();
				List<String> documentFieldKeys = ConversionUtility.findKeys(copyDocumentNode);
				for (String documentFieldKey : documentFieldKeys) {
					String docFieldValue = documentNode.has(documentFieldKey)
							? documentNode.get(documentFieldKey).asText()
							: "";
					if (docFieldValue != null && StringUtils.isNotEmpty(docFieldValue)) {
						copyDocumentNode.put(documentFieldKey, docFieldValue);
					}
				}
			}

			caseDataEntry.setUpdatedByUser(userDetailPOJO.getUserId());
			caseDataEntry.setUpdatedDate(new Date());
			caseDataEntry.setDataEntryData(copyDocumentNode);
			caseDataEntry = caseDataEntryRepository.save(caseDataEntry);

			JsonNode newJson = mapper.convertValue(caseDataEntry, JsonNode.class);
			logger.info("CaseDataEntry Json: {}", newJson);
			apiService.addAuditLog(CASE_DATA_ENTRY, previousJson, newJson, userDetailPOJO, option, tokenId);
		}
	}

//===============================================================================================================================
//---------------------END-------------------METHOD(S) FOR SAVING DATA ENTRY DATA----------------END-----------------------------
//===============================================================================================================================	

//===============================================================================================================================
//--------------------START-----------------METHOD(S) FOR DELETING DATA ENTRY DATA---------------START---------------------------
//===============================================================================================================================	

	@Override
	public String deleteDataEntry(DeleteDataEntryPOJO deleteDataEntryPOJO, UserDetailPOJO userDetailPOJO,
			String tokenId) throws ServiceException {

		logger.info("DeleteDataEntryPOJOJson :{}", deleteDataEntryPOJO);

		String rowId = deleteDataEntryPOJO.getRowId();
		long caseDetailsId = deleteDataEntryPOJO.getCaseDetailsId();
		long documentMasterId = deleteDataEntryPOJO.getDocumentMasterId();
		Long fulfillmentId = deleteDataEntryPOJO.getFulfillmentId();

		// ***************DE Completion and crn check******************
		CaseDetails caseDetails = caseDetailsService.findByCaseDetailsId(caseDetailsId);
		checkForValidCrn(caseDetails);

		MiFulfilmentRequest miFulfilmentRequest = null;
		if (fulfillmentId != null) {
			miFulfilmentRequest = miFulfilmentRequestService.findByMiFulfilmentRequestId(fulfillmentId);
		}
		checkForDeCompletion(caseDetails, miFulfilmentRequest);
		// ************************************************************

		List<CaseDataEntry> deletionList = new ArrayList<>();
		List<CaseDataEntry> childCaseDataEntries = caseDataEntryRepository.getChildByRowIdAndCaseDetailsId(rowId,
				caseDetailsId);
		if (CollectionUtils.isNotEmpty(childCaseDataEntries)) {
			deletionList.addAll(childCaseDataEntries);
			deleteChildDataEntry(childCaseDataEntries);
		} else {
			logger.info("No supporting data entry done for given rowId : {}", rowId);
		}

		List<CaseDataEntry> caseDataEntries = caseDataEntryRepository
				.getByDocumentMasterIdAndRowIdAndCaseDetailsId(documentMasterId, rowId, caseDetailsId);
		if (CollectionUtils.isNotEmpty(caseDataEntries)) {
			deletionList.addAll(caseDataEntries);
			deleteChildDataEntry(caseDataEntries);
		} else {
			// Delete if caseDocumentAssociation only
			boolean docDeleted = caseAssociatedDocumentsService.deleteByCaseDetailsIdAndRowIdAndDocumentMasterId(
					caseDetailsId, rowId, documentMasterId, userDetailPOJO, tokenId);
			if (!docDeleted) {
				logger.info("No data entry done for given rowId : {}", rowId);
				throw new ServiceException("Invalid data provided to delete data entry", ERROR_CODE_400);
			}
		}

		JsonNode previousJson = mapper.convertValue(deletionList, ArrayNode.class);
		String option = "DELETE";
		JsonNode newJson = mapper.createArrayNode();
		apiService.addAuditLog(CASE_DATA_ENTRY, previousJson, newJson, userDetailPOJO, option, tokenId);
		return "Data Entry for given rowId deleted succesfully";
	}

	private void deleteChildDataEntry(List<CaseDataEntry> caseDataEntries) {
		for (CaseDataEntry caseDataEntry : caseDataEntries) {
			caseDataEntryRepository.delete(caseDataEntry);
		}
	}

	private ObjectNode getSpecificRowIdDataEntry(long caseDetailsId, String rowId, long documentMasterId) {
		List<CaseDataEntry> caseDataEntries = caseDataEntryRepository
				.getByDocumentMasterIdAndRowIdAndCaseDetailsId(documentMasterId, rowId, caseDetailsId);
		if (CollectionUtils.isNotEmpty(caseDataEntries)) {
			return caseDataEntries.get(0).getDataEntryData() != null ? caseDataEntries.get(0).getDataEntryData()
					: mapper.createObjectNode();
		}
		return mapper.createObjectNode();
	}

	private ObjectNode getSpecificRowIdDataEntryError(long caseDetailsId, String rowId, long documentMasterId) {
		List<CaseDataEntry> caseDataEntries = caseDataEntryRepository
				.getByDocumentMasterIdAndRowIdAndCaseDetailsId(documentMasterId, rowId, caseDetailsId);
		if (CollectionUtils.isNotEmpty(caseDataEntries)) {
			return caseDataEntries.get(0).getDataEntryError() != null ? caseDataEntries.get(0).getDataEntryError()
					: mapper.createObjectNode();
		}
		return mapper.createObjectNode();
	}

//===============================================================================================================================
//---------------------END------------------METHOD(S) FOR DELETING DATA ENTRY DATA----------------END----------------------------
//===============================================================================================================================	

	private void checkForValidCrn(CaseDetails caseDetails) throws ServiceException {

		String crNo = caseDetails.getCrn();

		if (crNo == null || StringUtils.isEmpty(crNo) || StringUtils.equalsIgnoreCase(crNo, "pending")) {
			throw new ServiceException("Invalid CRN", ERROR_CODE_404);
		}
	}

	private void checkForDeCompletion(CaseDetails caseDetails, MiFulfilmentRequest miFulfilmentRequest)
			throws ServiceException {

		if (caseDetails.getDeComplete() != null && caseDetails.getDeComplete()) {

			if (miFulfilmentRequest != null) {
				boolean fulfilled = miFulfilmentRequest.getFulfilled() != null && miFulfilmentRequest.getFulfilled();

				if (fulfilled) {
					throw new ServiceException("MI Fulfillment already done", ERROR_CODE_404);
				}
			} else {
				throw new ServiceException("DE Already done", ERROR_CODE_404);
			}
		}
	}

//===============================================================================================================================
//----------------------START-------------------SAVE EXCEL UPLOAD DATA ENTRY-------------------------START-----------------------
//===============================================================================================================================

	@Override
	public String saveAutoDataEntry(AutoDataEntryPOJO autoDataEntryPOJO, UserDetailPOJO userDetailPOJO, String tokenId)
			throws ServiceException {

		JsonNode previousJson = mapper.createArrayNode();
		String operation = "ADD";
		String requestSource = autoDataEntryPOJO.getRequestSource() != null ? autoDataEntryPOJO.getRequestSource() : "";

		logger.info("ExcelDataEntryPOJO: {}", autoDataEntryPOJO);
		String caseNo = autoDataEntryPOJO.getCaseNo() != null ? autoDataEntryPOJO.getCaseNo() : "";
		List<AutoDataEntryDataPOJO> autoDataEntryDataPOJOs = getUpdatedDocumentsUsingCopyFeature(autoDataEntryPOJO);

		CaseDetails caseDetails = caseDetailsService.findByCaseNo(caseNo);
		String caseOrigin = caseDetails.getCaseOrigin() == null ? "" : caseDetails.getCaseOrigin();
		JsonNode caseMoreInfoJson = caseDetails.getCaseMoreInfo();
		JsonNode clientSpecificFieldsJson = caseDetails.getClientSpecificFields();
		JsonNode clientDetailsJson = caseDetails.getCaseDetails();
		JsonNode additionalDetailJson = mapper.createArrayNode();
		JsonNode clientDetailJson = mapper.createArrayNode();
		if (clientDetailsJson != null && !clientDetailsJson.isNull()) {
			if (clientDetailsJson.has("additionalDetail")) {
				additionalDetailJson = clientDetailsJson.get("additionalDetail");
			}
			if (clientDetailsJson.has("clientDetail")) {
				clientDetailJson = clientDetailsJson.get("clientDetail");
			}
		}

		CaseClientDetails caseClientDetails = caseClientDetailsService
				.findByCaseDetailsId(caseDetails.getCaseDetailsId());

		String clientName = caseClientDetails.getClientMaster().getClientName();
		String sbuName = caseClientDetails.getSbuMaster().getSbuName();
		String packageName = caseClientDetails.getPackageMaster().getPackageName();
		// String packageName = "Facis with Database components 20-Mar-20 CRT";
		Map<String, String> caseFields = new HashMap<>();
		Map<String, String> additionalFields = new HashMap<>();
		Map<DocumentMaster, JsonNode> docFieldMap = new HashMap<>();
		if (caseOrigin.equalsIgnoreCase("XLS_CASE_DE") || caseOrigin.equalsIgnoreCase("TOUCHLESS_CASE_DE")) {
			List<CaseDeXlsConfig> caseDeXlsConfigs = caseDeXlsConfigRepository
					.getDocumentNameByClientAndSbuAndPackage(clientName, sbuName, packageName);
			List<String> documentNameList = caseDeXlsConfigs.stream()
					.map(data -> data.getDocumentMaster().getDocumentName().toLowerCase()).collect(Collectors.toList());
			// Map<DocumentMaster, JsonNode> docFieldMap = new HashMap<>();

			if (CollectionUtils.isNotEmpty(documentNameList)) {
				autoDataEntryDataPOJOs = autoDataEntryDataPOJOs.stream()
						.filter(data -> documentNameList.contains(data.getDocumentName().toLowerCase()))
						.collect(Collectors.toList());

				docFieldMap = caseDeXlsConfigs.stream().collect(
						Collectors.toMap(CaseDeXlsConfig::getDocumentMaster, CaseDeXlsConfig::getMappedFields));
			}
		}
		String caseCreationFieldResponse = apiService.sendDataToGet(caseCreationFieldConfigUrl);
		if (!caseCreationFieldResponse.equals("")) {
			try {
				JsonNode caseCreationFieldResponseJson = mapper.readTree(caseCreationFieldResponse);
				if (caseCreationFieldResponseJson.has("success")
						&& caseCreationFieldResponseJson.get("success").asBoolean()) {
					JsonNode responseNode = caseCreationFieldResponseJson.get("response");
					if (responseNode.isArray()) {
						for (JsonNode config : responseNode) {
							if (config.get("code").asText().equalsIgnoreCase("CC")) {
								caseFields.put(config.get("title").asText(), config.get("name").asText());
							} else if (config.get("code").asText().equalsIgnoreCase("AF")) {
								additionalFields.put(config.get("title").asText(), config.get("name").asText());
							}
						}
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		List<CaseDataEntry> caseDataEntries = new ArrayList<>();

		for (AutoDataEntryDataPOJO document : autoDataEntryDataPOJOs) {
			String akaName = "";
			String documentName = document.getDocumentName();
			DocumentMaster documentMaster = documentMasterService.findByDocumentName(documentName);

			List<ObjectNode> records = document.getRecords() != null ? document.getRecords() : new ArrayList<>();
			List<DocFieldMapping> docFieldMappings = docFieldMappingService.findByDocumentMaster(documentMaster);
			JsonNode docFields = docFieldMap.get(documentMaster);
			Map<String, JsonNode> mappedFieldNode = new HashMap<>();
			if (docFields != null && docFields.isArray()) {
				for (JsonNode mapped : docFields) {
					if (mapped.has("mappedField")) {
						mappedFieldNode.put(mapped.get("keyField").asText(), mapped);
					}
				}
			}

			for (ObjectNode recordNode : records) {

				UUID uuid = UUID.randomUUID();
				String copyRowId = uuid.toString();

				ObjectNode deRecord = mapper.createObjectNode();
				ObjectNode dataEntryErrorNode = mapper.createObjectNode();

				for (DocFieldMapping docFieldMapping : docFieldMappings) {

					String fieldName = docFieldMapping.getDocumentFieldMaster().getDocumentFieldName();
					String fieldKey = docFieldMapping.getDocumentFieldMaster().getDocumentFieldKey();
					String recordValue = recordNode.get(fieldName) != null ? recordNode.get(fieldName).asText() : "";

					// Add logic to set Auto PI value for mapped value
					recordValue = setAuoPiMappedFieldValue(caseMoreInfoJson, clientSpecificFieldsJson,
							additionalDetailJson, clientDetailJson, caseFields, additionalFields, mappedFieldNode,
							fieldName, recordValue);

					deRecord.put(ConversionUtility.removeNonAlphaNumericAndSpace(fieldKey),
							ConversionUtility.convertDate(recordValue));

					DocumentFieldMaster documentFieldMaster = docFieldMapping.getDocumentFieldMaster();
					boolean concatenated = documentFieldMaster.getConcatenated() != null
							&& documentFieldMaster.getConcatenated();
					ObjectNode concatenatedKeys = documentFieldMaster.getConcatenatedKeys();

					if (concatenated && concatenatedKeys != null) {

						List<String> fieldKeys = concatenatedKeys.has("keys")
								? mapper.convertValue(concatenatedKeys.get("keys"), new TypeReference<List<String>>() {
								})
								: new ArrayList<>();
						String separator = concatenatedKeys.has("separator")
								? concatenatedKeys.get("separator").asText()
								: "";

						List<String> fieldValues = new ArrayList<>();
						for (String key : fieldKeys) {
							String value = recordNode.has(key) ? recordNode.get(key).asText() : "";
							if (value != null && StringUtils.isNotEmpty(value)) {
								fieldValues.add(value);
							}
						}
						if (CollectionUtils.isNotEmpty(fieldValues)) {
							deRecord.put(fieldKey, String.join(separator, fieldValues));
						}
					}

					ObjectNode remoteApi = docFieldMapping.getRemoteApi() != null ? docFieldMapping.getRemoteApi()
							: mapper.createObjectNode();

					List<String> possibleValues = docFieldMapping.getPossibleValues() != null
							? docFieldMapping.getPossibleValues()
							: new ArrayList<String>();

					ArrayNode calenderCheck = mapper.createArrayNode();
					if (docFieldMapping.getUiControlMaster().getUiControlName().equalsIgnoreCase("Calendar")) {
						String value = ConversionUtility.checkDate(recordValue);
						if (!value.isEmpty()) {
							calenderCheck.add(recordValue);
						}
						if (calenderCheck.isEmpty()) {
							ObjectNode incorrectValueNode = mapper.createObjectNode();
							incorrectValueNode.put("defaultValue", "");
							incorrectValueNode.put("ingestedValue", recordValue);

							dataEntryErrorNode.set(fieldKey, incorrectValueNode);
						}
					}

					/*
					 * A map of possibleValues with possibleValue in lowercase as key and
					 * possibleValue as value
					 */
					Map<String, String> possibleValuesMap = new HashMap<>();
					possibleValues.stream().forEach(data -> {
						String possibleValueKey = data.toLowerCase();
						possibleValuesMap.put(possibleValueKey, data);
					});

					boolean mandatory = docFieldMapping.getMandatory() != null && docFieldMapping.getMandatory();

					if (!remoteApi.isEmpty() && mandatory) {
						String primaryKey = remoteApi.has("primaryKey") ? remoteApi.get("primaryKey").asText() : "";
						if (primaryKey != null && StringUtils.equalsIgnoreCase(primaryKey, "akaName")) {
							akaName = recordValue;
						}
					}

					if (!remoteApi.isEmpty()) {
						String primaryKey = remoteApi.has("primaryKey") ? remoteApi.get("primaryKey").asText() : "";

						boolean isValueIncorrect = getFieldValueList(primaryKey, recordValue, docFieldMappings,
								recordNode);

						if (isValueIncorrect) {
							ObjectNode incorrectValueNode = mapper.createObjectNode();
							incorrectValueNode.put("defaultValue", "");
							incorrectValueNode.put("ingestedValue", recordValue);

							dataEntryErrorNode.set(fieldKey, incorrectValueNode);
						}
					}

					if (!possibleValues.isEmpty() && !recordValue.isEmpty()) {

						boolean isPossibleValueCaseSensitiveCorrect = possibleValues.contains(recordValue);
						/*
						 * 1. check if the value is case-sensitive correct 2. if the value is not
						 * case-sensitive correct then check if the value is case-insensitive correct.
						 */
						if (!isPossibleValueCaseSensitiveCorrect) {
							/*
							 * if the recordValue(lowercase) is inside the possibleValuesMap, then the value
							 * is correct
							 */
							boolean isPossibleValueCaseInsesitiveCorrect = possibleValuesMap
									.containsKey(recordValue.toLowerCase());

							/*
							 * if value is correct then set the default value with correct value from DB and
							 * ingestedValue with the value entered by user, else set the default value as
							 * empty and ingestedValue as the value entered by the user
							 */
							if (isPossibleValueCaseInsesitiveCorrect) {
								ObjectNode incorrectValueNode = mapper.createObjectNode();

								String correctedValue = possibleValuesMap.get(recordValue.toLowerCase());
								incorrectValueNode.put("defaultValue", correctedValue);
								incorrectValueNode.put("ingestedValue", recordValue);

								dataEntryErrorNode.set(fieldKey, incorrectValueNode);
							} else {
								ObjectNode incorrectValueNode = mapper.createObjectNode();

								incorrectValueNode.put("defaultValue", "");
								incorrectValueNode.put("ingestedValue", recordValue);

								dataEntryErrorNode.set(fieldKey, incorrectValueNode);
							}

						}

					}

				}

				/*
				 * if record contains a instruction_checkId then set the instruction_checkid in
				 * data_entry_data for that particular document.
				 */
				String instructionCheckId = "";
				boolean isInstructionIdPresent = recordNode.has("INSTRUCTION_CHECK_ID");
				if (isInstructionIdPresent) {
					instructionCheckId = recordNode.get("INSTRUCTION_CHECK_ID").asText();
					deRecord.put("instructioncheckid", instructionCheckId);
				}

				if (!deRecord.isEmpty()) {
					CaseDataEntry caseDataEntry = new CaseDataEntry();
					caseDataEntry.setAkaName(akaName);
					caseDataEntry.setCaseDetails(caseDetails);
					caseDataEntry.setClientMaster(caseClientDetails.getClientMaster());
					caseDataEntry.setDataEntryData(deRecord);
					caseDataEntry.setInstructionCheckId(instructionCheckId);
					caseDataEntry.setDocumentMaster(documentMaster);
					caseDataEntry.setPackageMaster(caseClientDetails.getPackageMaster());
					caseDataEntry.setRowId(copyRowId);
					caseDataEntry.setSbuMaster(caseClientDetails.getSbuMaster());
					caseDataEntry.setCreatedDate(new Date());
					caseDataEntry.setUpdatedDate(new Date());
					caseDataEntry.setUpdatedByUser(userDetailPOJO.getUserId());
					caseDataEntry.setDataEntryError(dataEntryErrorNode);
					caseDataEntries.add(caseDataEntry);
				}
			}
		}

		if (CollectionUtils.isNotEmpty(caseDataEntries)) {
// Same document is getting associated twice(CDE/Sp)			
			List<CaseUploadedDocuments> caseUploadedDocumentList = new ArrayList<>();
			if (caseDetails.getCaseType() != null && caseDetails.getCaseType().equalsIgnoreCase("CDE")) {
				caseUploadedDocumentList = caseUploadedDocumentsService
						.findByCaseDetailsAndUploadTypeAndCaseOrigin(caseDetails, "converted", "sp");
			} else {
				caseUploadedDocumentList = caseUploadedDocumentsService.findByCaseDetailsAndUploadType(caseDetails,
						"converted");
			}
			if (CollectionUtils.isEmpty(caseUploadedDocumentList)) {
				throw new ServiceException("No Uploaded documents found for given case", ERROR_CODE_404);
			}
			CaseUploadedDocuments caseUploadedDocuments = caseUploadedDocumentList.get(0);

//			List<AutoDocAssociationPOJO> autoDocAssociationPOJOs = autoFileAssociation(caseDataEntries,
//					caseUploadedDocuments, caseDetails);
			List<AutoDocAssociationPOJO> autoDocAssociationPOJOs = new ArrayList<>();
			if (caseUploadedDocumentList.size() > 0) {
				if (caseUploadedDocumentList.size() > caseDataEntries.size()) {
					throw new ServiceException("Less NG documents to associate against the uploaded documents.",
							ERROR_CODE_404);
				}
				autoDocAssociationPOJOs = autoFileAssociation(caseDataEntries, caseUploadedDocumentList, caseDetails);
			}

			for (AutoDocAssociationPOJO autoDocAssociationPOJO : autoDocAssociationPOJOs) {
				CaseAssociatedDocuments caseAssociatedDocuments = new CaseAssociatedDocuments();

				DocumentMaster documentMaster = documentMasterService
						.findByDocumentName(autoDocAssociationPOJO.getDocumentName());

				String deAkaName = autoDocAssociationPOJO.getAkaName() != null ? autoDocAssociationPOJO.getAkaName()
						: "";

				if (StringUtils.isNotEmpty(deAkaName)) {
					ContactCardMaster contactCardMaster = contactCardMasterService.getContactCardByAkaName(deAkaName);

					if (contactCardMaster != null) {
						caseAssociatedDocuments.setContactCardMaster(contactCardMaster);
					} else if (StringUtils.isNotEmpty(requestSource)
							&& (StringUtils.equalsIgnoreCase(requestSource, "sp")
									|| caseOrigin.contains("TOUCHLESS"))) {
						caseAssociatedDocuments.setSpAkaName(deAkaName);
					}
				}

				caseAssociatedDocuments.setActive(true);
				caseAssociatedDocuments.setCaseDetails(caseDetails);
				caseAssociatedDocuments.setCaseUploadedDocuments(caseUploadedDocuments);
				caseAssociatedDocuments.setDocumentMaster(documentMaster);
				caseAssociatedDocuments.setEndPage(autoDocAssociationPOJO.getEndPage());
				caseAssociatedDocuments.setFileName(autoDocAssociationPOJO.getFileName());
				caseAssociatedDocuments.setFilePath(autoDocAssociationPOJO.getSourceFolder());
				caseAssociatedDocuments.setParentRowId("");
				caseAssociatedDocuments.setRowId(autoDocAssociationPOJO.getRowId());
				caseAssociatedDocuments.setStartPage(autoDocAssociationPOJO.getStartPage());
				caseAssociatedDocuments.setUpdatedDate(new Date());
				caseAssociatedDocuments.setCreatedDate(new Date());
				caseAssociatedDocuments.setUpdatedByUser(userDetailPOJO.getUserId());

				CaseAssociatedDocuments newCaseAssociatedDocuments = caseAssociatedDocumentsService
						.saveNewRecord(caseAssociatedDocuments);

				JsonNode newSplitDocJson = mapper.convertValue(newCaseAssociatedDocuments, JsonNode.class);
				apiService.addAuditLog("case_associated_documents", mapper.createObjectNode(), newSplitDocJson,
						userDetailPOJO, "ADD", tokenId);

				caseDataEntries.stream().forEach(data -> {
					String rowId = data.getRowId();
					String documentName = data.getDocumentMaster().getDocumentName();
					if (StringUtils.equals(rowId, autoDocAssociationPOJO.getRowId())
							&& StringUtils.equalsIgnoreCase(documentName, autoDocAssociationPOJO.getDocumentName())) {
						data.setCaseAssociatedDocuments(newCaseAssociatedDocuments);
					}
				});
			}

			caseDataEntries = caseDataEntryRepository.saveAll(caseDataEntries);
			JsonNode newJson = mapper.convertValue(caseDataEntries, ArrayNode.class);
			apiService.addAuditLog(CASE_DATA_ENTRY, previousJson, newJson, userDetailPOJO, operation, tokenId);

//			if (!(StringUtils.isNotEmpty(requestSource) && (StringUtils.equalsIgnoreCase(requestSource, "sp")
//					|| StringUtils.equalsIgnoreCase(requestSource, "TOUCHLESS")))) {
			Boolean insertFlag = false;
			if (caseOrigin.equalsIgnoreCase("XLS_CASE_DE") || caseOrigin.equalsIgnoreCase("TOUCHLESS_CASE_DE")) {
				caseDetails.setDeComplete(true);
				caseDetails.setDeCompletedBy(userDetailPOJO.getUserId());
				caseDetails.setDeCompletedTime(new Date());
				caseDetailsService.saveCaseDetails(caseDetails);
				insertFlag = insertIntoWorkflowService.insertIntoWorkflow(caseDetails);
				logger.info("Inserted Into Workflow :{}", caseDetails.getCaseNo() + "= " + insertFlag);
			}
			if (insertFlag) {
				caseDetails.setMoveToWorkflow(true);
			}
			caseDetails.setDeSave(true);
			caseDetailsService.saveCaseDetails(caseDetails);

			return "Data Entry data saved successfully";
		}

		return "No Data Entry data saved.";

	}

	private String setAuoPiMappedFieldValue(JsonNode caseMoreInfoJson, JsonNode clientSpecificFieldsJson,
			JsonNode additionalDetailJson, JsonNode clientDetailJson, Map<String, String> caseFields,
			Map<String, String> additionalFields, Map<String, JsonNode> mappedFieldNode, String fieldName,
			String recordValue) {
		String recordValueTemp = "";
		if (mappedFieldNode.containsKey(fieldName)) {
			JsonNode mappedFld = mappedFieldNode.get(fieldName);
			logger.info("fieldName {}", fieldName);
			if (mappedFld.has("fieldType")) {
				String fieldType = mappedFld.get("fieldType").asText();
				String mappedField = mappedFld.get("mappedField").asText();
				if (fieldType.equalsIgnoreCase("CC")) {
					if (caseFields.containsKey(mappedField)) {
						String referenceFieldName = caseFields.get(mappedField);
						if (clientDetailJson.has(referenceFieldName)) {
							logger.info("referenceFieldName: {}", referenceFieldName);
							try {
								recordValueTemp = clientDetailJson.get(referenceFieldName) != null
										? clientDetailJson.get(referenceFieldName).asText()
										: "";
								logger.info("ref value: {} ", recordValueTemp);
							} catch (Exception e) {
								e.printStackTrace();
							}
						}
					}
				} else if (fieldType.equalsIgnoreCase("AF")) {
					if (additionalFields.containsKey(mappedField)) {
						String referenceFieldName = additionalFields.get(mappedField);
						if (additionalDetailJson.has(referenceFieldName)) {
							logger.info("referenceFieldName: {}", referenceFieldName);
							try {
								recordValueTemp = additionalDetailJson.get(referenceFieldName) != null
										? additionalDetailJson.get(referenceFieldName).asText()
										: "";
								logger.info("ref value: {} ", recordValueTemp);
							} catch (Exception e) {
								e.printStackTrace();
							}
						}
					}
				} else if (fieldType.equalsIgnoreCase("CMF")) {
					if (caseMoreInfoJson.has(mappedField)) {
						try {
							recordValueTemp = caseMoreInfoJson.get(mappedField) != null
									? caseMoreInfoJson.get(mappedField).asText()
									: "";
							logger.info("ref value: {} ", recordValueTemp);
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				} else if (fieldType.equalsIgnoreCase("CF")) {
					if (clientSpecificFieldsJson.has(mappedField)) {
						try {
							recordValueTemp = clientSpecificFieldsJson.get(mappedField) != null
									? clientSpecificFieldsJson.get(mappedField).asText()
									: "";
							logger.info("ref value: {} ", recordValueTemp);
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				}
			}
		}
		if (StringUtils.isEmpty(recordValueTemp) || recordValueTemp.equalsIgnoreCase("null")) {
			return recordValue;
		} else {
			return recordValueTemp;
		}
	}

	public boolean getFieldValueList(String primaryKey, String nodeVal, List<DocFieldMapping> docFieldMappings,
			ObjectNode recordNode) {

		List<String> result;

		if (StringUtils.equalsIgnoreCase(primaryKey, "country")) {
			result = countryMasterRepository.getByCountryNameList(nodeVal);
		} else if (StringUtils.equalsIgnoreCase(primaryKey, "state")) {
			String countryName = getParentKeyValue("country", docFieldMappings, recordNode);
			logger.info("countryName {}", countryName);
			if (StringUtils.isBlank(countryName)) {
				result = stateMasterRepository.getByStateNameList(nodeVal);
			} else {
				result = stateMasterRepository.getByStateNameAndCountryNameList(nodeVal, countryName);
			}
		} else if (StringUtils.equalsIgnoreCase(primaryKey, "city")) {
			String stateName = getParentKeyValue("state", docFieldMappings, recordNode);
			String countryName = getParentKeyValue("country", docFieldMappings, recordNode);
			logger.info("state {}", stateName);
			logger.info("countryName {}", countryName);
			if (StringUtils.isBlank(stateName) && StringUtils.isBlank(countryName)) {
				result = cityMasterRepository.getByCityNameList(nodeVal);
			} else if (StringUtils.isNotBlank(stateName) && StringUtils.isNotBlank(countryName)) {
				result = cityMasterRepository.getByCityNameAndStateNameAndCountryNameList(nodeVal, stateName,
						countryName);
			} else {
				result = cityMasterRepository.getByCityNameAndStateNameList(nodeVal, stateName);
			}
		} else if (StringUtils.equalsIgnoreCase(primaryKey, "akaName")) {
			result = contactCardMasterRepository.getByAkaNameList(nodeVal);
		} else if (StringUtils.equalsIgnoreCase(primaryKey, "qualification")) {

			String qualificationLevel = getParentKeyValue("qualificationLevel", docFieldMappings, recordNode);
			logger.info("qualificationLevel {}", qualificationLevel);
			if (StringUtils.isBlank(qualificationLevel)) {
				result = qualificationMasterRepository.getByQualificationNameList(nodeVal);
			} else {
				result = qualificationMasterRepository.getByQualificationNameAndQualificationLevelList(nodeVal,
						qualificationLevel);
			}
		} else if (StringUtils.equalsIgnoreCase(primaryKey, "qualificationLevel")) {
			result = qualificationLevelMasterRepository.getByQualificationLevelList(nodeVal);
		} else {
			return false;
		}
		return CollectionUtils.isEmpty(result);
	}

	private String getParentKeyValue(String parentKey, List<DocFieldMapping> docFieldMappings, JsonNode recordNode) {
		List<String> keyList = docFieldMappings.stream().filter(e -> {
			ObjectNode remoteApi = e.getRemoteApi() != null ? e.getRemoteApi() : mapper.createObjectNode();
			String pk = remoteApi.has("primaryKey") ? remoteApi.get("primaryKey").asText() : "";
			if (StringUtils.equalsIgnoreCase(parentKey, pk)) {
				return true;
			}
			return false;
		}).map(e -> e.getDocumentFieldMaster().getDocumentFieldName()).collect(Collectors.toList());

		if (CollectionUtils.isNotEmpty(keyList)) {
			String key = keyList.get(0);
			return recordNode.has(key) ? recordNode.get(key).asText() : "";
		}
		return "";
	}

	private List<AutoDataEntryDataPOJO> getUpdatedDocumentsUsingCopyFeature(AutoDataEntryPOJO autoDataEntryPOJO) {
		List<AutoDataEntryDataPOJO> autoDataEntryDataPOJOs = autoDataEntryPOJO.getDocuments();

		List<AutoDataEntryDataPOJO> tempAutoDataEntryDataPOJOs = autoDataEntryDataPOJOs.stream()
				.filter(data -> StringUtils.equalsAnyIgnoreCase(data.getDocumentName(), deFirstDocument))
				.collect(Collectors.toList());

		List<AutoDataEntryDataPOJO> newAutoDataEntryDataPOJOs = new ArrayList<>();

		if (CollectionUtils.isNotEmpty(tempAutoDataEntryDataPOJOs)) {

			autoDataEntryDataPOJOs.removeAll(tempAutoDataEntryDataPOJOs);
			newAutoDataEntryDataPOJOs.addAll(tempAutoDataEntryDataPOJOs);

			Map<String, List<String>> docFields = copyFeatureConfigSevice.getDocumentAndFiledNameMap();
			List<String> fieldNames = docFields.get("Personal Details (As per BVF)");
			if (fieldNames == null) {
				fieldNames = new ArrayList<>();
			}

			List<ObjectNode> personalDetailsNodes = tempAutoDataEntryDataPOJOs.get(0).getRecords();

			if (CollectionUtils.isNotEmpty(personalDetailsNodes)) {
				ObjectNode personalDetailsNode = personalDetailsNodes.get(0);
				List<String> finalFieldNames = fieldNames;
				autoDataEntryDataPOJOs.stream().forEach(data -> {
					List<ObjectNode> recordNodes = data.getRecords();
					if (recordNodes != null && CollectionUtils.isNotEmpty(recordNodes)) {
						recordNodes.stream().forEach(recordNode -> {
							for (String fieldName : finalFieldNames) {
								String fieldValue = personalDetailsNode.has(fieldName)
										? personalDetailsNode.get(fieldName).asText()
										: "";
								String recordValue = recordNode.get(fieldName) != null
										? recordNode.get(fieldName).asText()
										: "";

								if (StringUtils.isEmpty(recordValue)) {
									recordNode.put(fieldName, fieldValue);
								}
							}
						});
					}
					data.setRecords(recordNodes);
				});
			}
		}

		if (CollectionUtils.isNotEmpty(autoDataEntryDataPOJOs)) {
			newAutoDataEntryDataPOJOs.addAll(autoDataEntryDataPOJOs);
		}
		return newAutoDataEntryDataPOJOs;
	}

//	public List<AutoDocAssociationPOJO> autoFileAssociation(List<CaseDataEntry> caseDataEntries,
//			CaseUploadedDocuments caseUploadedDocuments, CaseDetails caseDetails) throws ServiceException {
//
//		String response = apiService.sendDataToGet(searchS3FileUrl + caseUploadedDocuments.getFileName());
//		if (response == null) {
//			throw new ServiceException("File not found in minio bucket", ERROR_CODE_404);
//		}
//
//		List<StartEndPagePOJO> startEndPagePOJOs = ConversionUtility.getPageRange(caseDataEntries.size(),
//				caseUploadedDocuments.getPageCount());
//
//		List<AutoDocAssociationPOJO> autoDocAssociationPOJOs = new ArrayList<>();
//
//		for (int iter = 0; iter < caseDataEntries.size(); iter++) {
//			CaseDataEntry caseDataEntry = caseDataEntries.get(iter);
//			StartEndPagePOJO startEndPagePOJO = startEndPagePOJOs.get(iter);
//
//			AutoDocAssociationPOJO autoDocAssociationPOJO = new AutoDocAssociationPOJO();
//			autoDocAssociationPOJO.setDocumentName(caseDataEntry.getDocumentMaster().getDocumentName());
//			autoDocAssociationPOJO.setFileName(caseUploadedDocuments.getFileName());
//			autoDocAssociationPOJO.setSourceFolder(response);
//			autoDocAssociationPOJO.setStartPage(startEndPagePOJO.getStartPage());
//			autoDocAssociationPOJO.setEndPage(startEndPagePOJO.getEndPage());
//			autoDocAssociationPOJO.setRowId(caseDataEntry.getRowId());
//			autoDocAssociationPOJO.setCaseDetailsId(caseDetails.getCaseDetailsId());
//			autoDocAssociationPOJO.setAkaName(caseDataEntry.getAkaName());
//
//			autoDocAssociationPOJOs.add(autoDocAssociationPOJO);
//		}
//
//		JsonNode requestNode = mapper.convertValue(autoDocAssociationPOJOs, ArrayNode.class);
//		logger.info("autoDocAssociationPOJOs : {}", requestNode);
//
//		String splitFileResponse = apiService.sendDataToPost(autoSplitFileUrl, requestNode.toString());
//		if (splitFileResponse == null) {
//			throw new ServiceException("File not found in minio bucket", ERROR_CODE_404);
//		}
//		try {
//			autoDocAssociationPOJOs = mapper.readValue(splitFileResponse,
//					new TypeReference<List<AutoDocAssociationPOJO>>() {
//					});
//		} catch (JsonProcessingException e) {
//			logger.error("Unable to convert file association response : {}", e.getMessage());
//			throw new ServiceException("Unable to convert file association response", ERROR_CODE_400);
//		}
//
//		return autoDocAssociationPOJOs;
//
//	}

	public List<AutoDocAssociationPOJO> autoFileAssociation(List<CaseDataEntry> caseDataEntries,
			List<CaseUploadedDocuments> caseUploadedDocumentsList, CaseDetails caseDetails) throws ServiceException {
		List<AutoDocAssociationPOJO> autoDocAssociationPOJOs = new ArrayList<>();
		logger.info("Case Uploaded Document Size:{}", caseUploadedDocumentsList.size());
		if (caseUploadedDocumentsList.size() == 1) {
			logger.info("Inside if:{}", caseUploadedDocumentsList);
			CaseUploadedDocuments caseUploadedDocuments = caseUploadedDocumentsList.get(0);
			String response = apiService.sendDataToGet(searchS3FileUrl + caseUploadedDocuments.getFileName());
			if (response == null) {
				throw new ServiceException("File not found in minio bucket", ERROR_CODE_404);
			}

			List<StartEndPagePOJO> startEndPagePOJOs = ConversionUtility.getPageRange(caseDataEntries.size(),
					caseUploadedDocuments.getPageCount());

			for (int iter = 0; iter < caseDataEntries.size(); iter++) {
				CaseDataEntry caseDataEntry = caseDataEntries.get(iter);
				StartEndPagePOJO startEndPagePOJO = startEndPagePOJOs.get(iter);

				AutoDocAssociationPOJO autoDocAssociationPOJO = new AutoDocAssociationPOJO();
				autoDocAssociationPOJO.setDocumentName(caseDataEntry.getDocumentMaster().getDocumentName());
				autoDocAssociationPOJO.setFileName(caseUploadedDocuments.getFileName());
				autoDocAssociationPOJO.setSourceFolder(response);
				autoDocAssociationPOJO.setStartPage(startEndPagePOJO.getStartPage());
				autoDocAssociationPOJO.setEndPage(startEndPagePOJO.getEndPage());
				autoDocAssociationPOJO.setRowId(caseDataEntry.getRowId());
				autoDocAssociationPOJO.setCaseDetailsId(caseDetails.getCaseDetailsId());
				autoDocAssociationPOJO.setAkaName(caseDataEntry.getAkaName());

				autoDocAssociationPOJOs.add(autoDocAssociationPOJO);
			}

		} else {
			// Count xls then implement the logic
			// CaseUploadedDocuments caseUploadedDocuments=caseUploadedDocumentsList.get(0);
			logger.info("Inside the else:{}", caseUploadedDocumentsList);
			List<CaseUploadedDocuments> xlsCaseUploadedDocumentList = caseUploadedDocumentsList.stream()
					.filter(data -> StringUtils.equalsAnyIgnoreCase(data.getFileExtension(), ".xlsx")
							|| StringUtils.equalsAnyIgnoreCase(data.getFileExtension(), ".xls"))
					.collect(Collectors.toList());
			int xlsDocsSize = xlsCaseUploadedDocumentList.size();
			int newCaseDataEntriesSize = caseDataEntries.size() - xlsDocsSize;
			for (CaseUploadedDocuments caseUploadedDocuments : caseUploadedDocumentsList) {
				if (caseUploadedDocuments.getFileExtension().equalsIgnoreCase(".pdf")) {
					String response = apiService.sendDataToGet(searchS3FileUrl + caseUploadedDocuments.getFileName());
					if (response == null) {
						throw new ServiceException("File not found in minio bucket", ERROR_CODE_404);
					}
//					List<StartEndPagePOJO> startEndPagePOJOs = ConversionUtility.getPageRange(caseDataEntries.size(),
//							caseUploadedDocuments.getPageCount());
					List<StartEndPagePOJO> startEndPagePOJOs = ConversionUtility.getPageRange(newCaseDataEntriesSize,
							caseUploadedDocuments.getPageCount());
//					for (int iter = 0; iter < caseDataEntries.size(); iter++) {
					for (int iter = 0; iter < newCaseDataEntriesSize; iter++) {
						CaseDataEntry caseDataEntry = caseDataEntries.get(iter);
						StartEndPagePOJO startEndPagePOJO = startEndPagePOJOs.get(iter);

						AutoDocAssociationPOJO autoDocAssociationPOJO = new AutoDocAssociationPOJO();
						autoDocAssociationPOJO.setDocumentName(caseDataEntry.getDocumentMaster().getDocumentName());
						autoDocAssociationPOJO.setFileName(caseUploadedDocuments.getFileName());
						autoDocAssociationPOJO.setSourceFolder(response);
						autoDocAssociationPOJO.setStartPage(startEndPagePOJO.getStartPage());
						autoDocAssociationPOJO.setEndPage(startEndPagePOJO.getEndPage());
						autoDocAssociationPOJO.setRowId(caseDataEntry.getRowId());
						autoDocAssociationPOJO.setCaseDetailsId(caseDetails.getCaseDetailsId());
						autoDocAssociationPOJO.setAkaName(caseDataEntry.getAkaName());

						autoDocAssociationPOJOs.add(autoDocAssociationPOJO);
					}
				}
			}
			// Logic for Xls
			for (CaseUploadedDocuments caseUploadedDocuments : xlsCaseUploadedDocumentList) {
				String response = apiService.sendDataToGet(searchS3FileUrl + caseUploadedDocuments.getFileName());
				if (response == null) {
					throw new ServiceException("File not found in minio bucket", ERROR_CODE_404);
				}
				List<StartEndPagePOJO> startEndPagePOJOs = ConversionUtility.getPageRange(
						caseDataEntries.size() - newCaseDataEntriesSize, caseUploadedDocuments.getPageCount());
				for (int iter = 0; iter < caseDataEntries.size() - newCaseDataEntriesSize; iter++) {
					CaseDataEntry caseDataEntry = caseDataEntries.get(newCaseDataEntriesSize + iter);
					StartEndPagePOJO startEndPagePOJO = startEndPagePOJOs.get(iter);

					AutoDocAssociationPOJO autoDocAssociationPOJO = new AutoDocAssociationPOJO();
					autoDocAssociationPOJO.setDocumentName(caseDataEntry.getDocumentMaster().getDocumentName());
					autoDocAssociationPOJO.setFileName(caseUploadedDocuments.getFileName());
					autoDocAssociationPOJO.setSourceFolder(response);
					autoDocAssociationPOJO.setStartPage(startEndPagePOJO.getStartPage());
					autoDocAssociationPOJO.setEndPage(startEndPagePOJO.getEndPage());
					autoDocAssociationPOJO.setRowId(caseDataEntry.getRowId());
					autoDocAssociationPOJO.setCaseDetailsId(caseDetails.getCaseDetailsId());
					autoDocAssociationPOJO.setAkaName(caseDataEntry.getAkaName());

					autoDocAssociationPOJOs.add(autoDocAssociationPOJO);
				}
			}
		}
		JsonNode requestNode = mapper.convertValue(autoDocAssociationPOJOs, ArrayNode.class);
		logger.info("autoDocAssociationPOJOs : {}", requestNode);

		String splitFileResponse = apiService.sendDataToPost(autoSplitFileUrl, requestNode.toString());
		if (splitFileResponse == null) {
			throw new ServiceException("File not found in minio bucket", ERROR_CODE_404);
		}
		try {
			autoDocAssociationPOJOs = mapper.readValue(splitFileResponse,
					new TypeReference<List<AutoDocAssociationPOJO>>() {
					});
		} catch (JsonProcessingException e) {
			logger.error("Unable to convert file association response : {}", e.getMessage());
			throw new ServiceException("Unable to convert file association response", ERROR_CODE_400);
		}

		return autoDocAssociationPOJOs;

	}

	@Override
	public List<CaseDataEntry> findByCaseDetails(CaseDetails caseDetails) {
		return caseDataEntryRepository.findByCaseDetails(caseDetails);
	}

	@Override
	public CaseDataEntry saveNewRecord(CaseDataEntry caseDataEntry) {
		return caseDataEntryRepository.save(caseDataEntry);
	}
}
