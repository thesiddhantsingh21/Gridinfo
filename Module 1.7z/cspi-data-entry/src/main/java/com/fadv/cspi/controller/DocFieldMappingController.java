package com.fadv.cspi.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fadv.cspi.exception.ServiceException;
import com.fadv.cspi.pojo.response.ResponseStatusPOJO;
import com.fadv.cspi.service.DocFieldMappingService;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/india/")
public class DocFieldMappingController {

	@Autowired
	private DocFieldMappingService docFieldMappingService;

	@GetMapping(path = "/document-fields/{documentMasterId}", produces = "application/json")
	public ResponseEntity<ResponseStatusPOJO> getCasesAsPerSearchCriteria(
			@PathVariable(value = "documentMasterId") Long documentMasterId) {
		try {
			return new ResponseEntity<>(
					new ResponseStatusPOJO(true, "Record found", "SUCCESS_CODE_200",
							docFieldMappingService.getAllDocumentsFieldsByDocumentMasterId(documentMasterId)),
					HttpStatus.OK);
		} catch (ServiceException e1) {
			return new ResponseEntity<>(new ResponseStatusPOJO(false, e1.getMessage(), e1.getMessageId()),
					HttpStatus.OK);
		} catch (Exception e2) {
			return new ResponseEntity<>(new ResponseStatusPOJO(false, e2.getMessage()), HttpStatus.OK);
		}
	}
}
