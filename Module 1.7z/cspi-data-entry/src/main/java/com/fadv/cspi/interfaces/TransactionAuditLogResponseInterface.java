package com.fadv.cspi.interfaces;

import java.util.Date;

public interface TransactionAuditLogResponseInterface {

	Long getTransactionAuditLogId();

	String getTableName();

	String getUpdatedBy();

	String getUpdatedByUserId();

	String getOperationType();

	Date getUpdatedDateTime();
}
