package com.fadv.cspi.interfaces;

public interface QualificationMasterListResponseInterface {
	long getQualificationMasterId();

	String getQualificationName();
}
