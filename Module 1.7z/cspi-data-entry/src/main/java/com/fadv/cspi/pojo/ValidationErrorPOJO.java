package com.fadv.cspi.pojo;

import lombok.Data;

@Data
public class ValidationErrorPOJO {

	private String fieldName;
	private String errorMessage;

	public ValidationErrorPOJO(String fieldName, String errorMessage) {
		this.errorMessage = errorMessage;
		this.fieldName = fieldName;
	}
}
