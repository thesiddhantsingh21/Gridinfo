package com.fadv.cspi.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class StartEndPagePOJO {

	private int startPage;
	private int endPage;
}
