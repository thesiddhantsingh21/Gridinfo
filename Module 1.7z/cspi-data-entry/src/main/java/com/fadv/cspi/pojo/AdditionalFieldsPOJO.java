package com.fadv.cspi.pojo;

import java.io.Serializable;

import javax.persistence.MappedSuperclass;

import lombok.Data;

@Data
@MappedSuperclass
public class AdditionalFieldsPOJO implements Serializable {

	private static final long serialVersionUID = 1L;

	private String fieldValue;
	private String fieldName;
}
