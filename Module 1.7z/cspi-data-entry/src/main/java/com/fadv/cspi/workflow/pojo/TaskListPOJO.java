package com.fadv.cspi.workflow.pojo;

import java.util.Date;

import com.fasterxml.jackson.databind.JsonNode;

import lombok.Data;

@Data
public class TaskListPOJO {

	private long taskListId;
	private long activityTypeId;
	private String taskListName;
	private String taskListDescription;
	private JsonNode requestJson;
	private Date createdDate;
	private String status;

	public TaskListPOJO() {
		super();
	}

}
