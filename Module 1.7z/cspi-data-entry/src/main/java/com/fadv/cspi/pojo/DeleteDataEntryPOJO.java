package com.fadv.cspi.pojo;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Positive;

import lombok.Data;

@Data
public class DeleteDataEntryPOJO {

	@Positive
	private long caseDetailsId;

	@Positive
	private long documentMasterId;

	@NotEmpty
	private String rowId;

	private Long fulfillmentId;
}
