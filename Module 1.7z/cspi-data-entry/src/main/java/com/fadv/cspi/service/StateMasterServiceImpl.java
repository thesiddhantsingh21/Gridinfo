package com.fadv.cspi.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fadv.cspi.repository.master.StateMasterRepository;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

@Service
public class StateMasterServiceImpl implements StateMasterService {

	@Autowired
	private StateMasterRepository stateMasterRepository;

	private ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES,
			false);

	@Override
	public List<ObjectNode> getStateListByCountry(String countryName) {

		return mapper.convertValue(stateMasterRepository.getStateListByCountryOrStateName("", countryName),
				new TypeReference<List<ObjectNode>>() {
				});
	}

}
