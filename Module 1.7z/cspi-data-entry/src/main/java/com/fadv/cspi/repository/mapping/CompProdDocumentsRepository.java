package com.fadv.cspi.repository.mapping;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.fadv.cspi.entities.mapping.CompProdDocuments;
import com.fadv.cspi.entities.master.DocumentMaster;

public interface CompProdDocumentsRepository extends JpaRepository<CompProdDocuments, Long> {

	List<CompProdDocuments> findByDocumentMaster(DocumentMaster documentMaster);

	@Query(value = "select cd.* from {h-schema}comp_prod_documents cd  "
			+ "left join {h-schema}component_master cm on cd.component_master_id = cm.component_master_id  "
			+ "where cm.component_name in ('Employment', 'Education') "
			+ "and cd.document_master_id = :documentMasterId", nativeQuery = true)
	List<CompProdDocuments> getEduOrEmpComponentByDocumentMasterId(long documentMasterId);

	@Query(value = "select cd.* from {h-schema}comp_prod_documents cd  "
			+ "left join {h-schema}component_master cm on cd.component_master_id = cm.component_master_id  "
			+ "where cd.document_master_id = :documentMasterId", nativeQuery = true)
	List<CompProdDocuments> getComponentByDocumentMasterId(long documentMasterId);

}
