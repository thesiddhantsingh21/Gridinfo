package com.fadv.cspi.service;

import java.util.List;

import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fadv.cspi.entities.master.SbuMaster;
import com.fadv.cspi.exception.ServiceException;
import com.fadv.cspi.repository.master.SbuMasterRepository;

@Service
public class SbuMasterServiceImpl implements SbuMasterService {

	@Autowired
	private SbuMasterRepository sbuMasterRepository;

	@Override
	public SbuMaster findBySbuName(String sbuName) throws ServiceException {
		List<SbuMaster> sbuMasters = sbuMasterRepository.findBySbuNameIgnoreCaseAndActive(sbuName, true);
		if (CollectionUtils.isNotEmpty(sbuMasters)) {
			return sbuMasters.get(0);
		}

		throw new ServiceException("Sbu Details not found for given sbu name", "ERROR_CODE_400");
	}

}
