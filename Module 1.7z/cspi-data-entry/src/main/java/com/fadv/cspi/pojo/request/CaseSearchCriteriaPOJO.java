package com.fadv.cspi.pojo.request;

import java.util.Date;

import lombok.Data;

@Data
public class CaseSearchCriteriaPOJO {
	private Date startDate;
	private Date endDate;
	private String crnNo;
	private String caseNo;
	private String caseCreationStatus;
	private String clientName;
	private String requestId;
	private String referenceId;
	private String checkId;
	private String fulfillmentType;
}
