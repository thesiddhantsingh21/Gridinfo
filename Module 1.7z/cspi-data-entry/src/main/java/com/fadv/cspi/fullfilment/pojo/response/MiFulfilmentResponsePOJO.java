package com.fadv.cspi.fullfilment.pojo.response;

import java.util.Date;

import com.fasterxml.jackson.databind.node.ArrayNode;

import lombok.Data;

@Data
public class MiFulfilmentResponsePOJO {

	private long miFulfilmentRequestId;

	private long caseDetailsId;

	private ArrayNode deDocuments;

	private boolean fulfilled;

	private String status;

	private String remarks;

	private Date createdDate;

	private Date completedDate;

	private String caseNo;

	private String crn;

	private String clientName;

	private String caseType;

}
