package com.fadv.cspi.service;

import java.util.List;
import java.util.Optional;

import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.fadv.cspi.entities.master.DocumentMaster;
import com.fadv.cspi.exception.ServiceException;
import com.fadv.cspi.pojo.response.DocumentMasterResponsePOJO;
import com.fadv.cspi.repository.master.DocumentMasterRepository;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class DocumentMasterServiceImpl implements DocumentMasterService {

	private static final String ERROR_CODE_404 = "ERROR_CODE_404";

	@Autowired
	private DocumentMasterRepository documentMasterRepository;

	private ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES,
			false);

	@Override
	public DocumentMaster findByDocumentMasterId(Long documentMasterId) throws ServiceException {
		Optional<DocumentMaster> documentMasterOptional = documentMasterRepository.findById(documentMasterId);

		if (documentMasterOptional.isPresent()) {
			return documentMasterOptional.get();
		}

		throw new ServiceException("Document not found for given document id", ERROR_CODE_404);
	}

	@Override
	public DocumentMaster findByDocumentName(String documentName) throws ServiceException {
		List<DocumentMaster> documentMasters = documentMasterRepository
				.findByDocumentNameIgnoreCaseAndActive(documentName, true);

		if (CollectionUtils.isNotEmpty(documentMasters)) {
			return documentMasters.get(0);
		}
		return null;
	}

	@Override
	public List<DocumentMasterResponsePOJO> getAllDocumentsOrderByDocumentName() {
		return mapper.convertValue(documentMasterRepository.findAll(Sort.by("documentName")),
				new TypeReference<List<DocumentMasterResponsePOJO>>() {
				});
	}
}
