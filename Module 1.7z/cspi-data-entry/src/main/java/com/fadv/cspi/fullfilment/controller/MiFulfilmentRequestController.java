package com.fadv.cspi.fullfilment.controller;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fadv.cspi.exception.ServiceException;
import com.fadv.cspi.fullfilment.pojo.request.MiFulfilmentRequestPOJO;
import com.fadv.cspi.fullfilment.service.MiFulfilmentRequestService;
import com.fadv.cspi.pojo.request.CaseSearchCriteriaPOJO;
import com.fadv.cspi.pojo.response.ResponseStatusPOJO;
import com.fadv.cspi.userdetail.pojo.UserDetailPOJO;
import com.fasterxml.jackson.databind.JsonNode;

import io.swagger.annotations.ApiOperation;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/india/")
public class MiFulfilmentRequestController {

	private static final String SUCCESS_CODE_200 = "SUCCESS_CODE_200";

	private static final Logger logger = LoggerFactory.getLogger(MiFulfilmentRequestController.class);

	private static final String TOKEN_ID = "tokenid";

	private static final String USER_ID = "userId";

	private static final String USER_NAME = "userName";

	@Autowired
	private MiFulfilmentRequestService miFulfilmentRequestService;

	@PostMapping(path = "mi_fulfilment_request", produces = "application/json", consumes = "application/json")
	public ResponseEntity<ResponseStatusPOJO> splitAndSaveAssociateDocument(@Valid @RequestBody MiFulfilmentRequestPOJO miFulfilmentReqPOJO) {
		try {
			return new ResponseEntity<>(new ResponseStatusPOJO(true, "mi_fulfilment_request created successfully",
					SUCCESS_CODE_200, miFulfilmentRequestService.createMiFulfilmentRequest(miFulfilmentReqPOJO)),
					HttpStatus.OK);
		} catch (ServiceException e1) {
			return new ResponseEntity<>(new ResponseStatusPOJO(false, e1.getMessage(), e1.getMessageId()),
					HttpStatus.OK);
		} catch (Exception e2) {
			return new ResponseEntity<>(new ResponseStatusPOJO(false, e2.getMessage()),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	

	@ApiOperation(value = "This API is used for fetching all additional details related to given mi_fulfilment_request", response = ResponseStatusPOJO.class)
	@GetMapping(path = "mi_fulfilment_request/{miFulfilmentRequestId}", produces = "application/json")
	public ResponseEntity<ResponseStatusPOJO> getMiFulfilmentRequest(
			@PathVariable(value = "miFulfilmentRequestId") Long miFulfilmentRequestId) {

		try {
			return new ResponseEntity<>(
					new ResponseStatusPOJO(true, "Mi Fulfillment Record found", SUCCESS_CODE_200,
							miFulfilmentRequestService
									.getMiFulfilmentRequestByMiFulfilmentRequestId(miFulfilmentRequestId)),
					HttpStatus.OK);
		} catch (ServiceException e1) {
			return new ResponseEntity<>(new ResponseStatusPOJO(false, e1.getMessage(), e1.getMessageId()),
					HttpStatus.OK);
		} catch (Exception e2) {
			return new ResponseEntity<>(new ResponseStatusPOJO(false, e2.getMessage()), HttpStatus.OK);
		}
	}

	@ApiOperation(value = "This API is used for fetching all additional details related to given mi_fulfilment_request", response = ResponseStatusPOJO.class)
	@GetMapping(path = "mi_fulfilment_request", produces = "application/json")
	public ResponseEntity<ResponseStatusPOJO> getMiFulfilmentRequest() {

		try {
			return new ResponseEntity<>(new ResponseStatusPOJO(true, "All Mi Fulfillment request fetched",
					SUCCESS_CODE_200, miFulfilmentRequestService.getAllMiFulfilmentRequest()), HttpStatus.OK);
		} catch (Exception e2) {
			return new ResponseEntity<>(new ResponseStatusPOJO(false, e2.getMessage()), HttpStatus.OK);
		}
	}

	@ApiOperation(value = "This API is used for searching the cases in mi_fulfilment_request database", response = ResponseStatusPOJO.class)
	@PostMapping(path = "mi_fulfilment_request/search", produces = "application/json", consumes = "application/json")
	public ResponseEntity<ResponseStatusPOJO> getCasesAsPerSearchCriteria(
			@RequestBody CaseSearchCriteriaPOJO caseSearchCriteriaPOJO) {
		logger.info("Mi Fulfillment Case search criteria : {}", caseSearchCriteriaPOJO);
		try {
			return new ResponseEntity<>(
					new ResponseStatusPOJO(true, "Record found", SUCCESS_CODE_200,
							miFulfilmentRequestService.getCaseDetailsUsingFilters(caseSearchCriteriaPOJO)),
					HttpStatus.OK);
		} catch (Exception e2) {
			return new ResponseEntity<>(new ResponseStatusPOJO(false, e2.getMessage()), HttpStatus.OK);
		}
	}

	@GetMapping(path = "mi-release-data/{caseNo}", produces = "application/json")
	public ResponseEntity<ResponseStatusPOJO> getMiReleasedCrns(
			@NotEmpty @PathVariable(value = "caseNo") String caseNo) {
		try {
			return new ResponseEntity<>(new ResponseStatusPOJO(true, "Record found", SUCCESS_CODE_200,
					miFulfilmentRequestService.getAllMiFulfilledRequestData(caseNo)), HttpStatus.OK);
		} catch (ServiceException e1) {
			return new ResponseEntity<>(new ResponseStatusPOJO(false, e1.getMessage(), e1.getMessageId()),
					HttpStatus.OK);
		} catch (Exception e2) {
			return new ResponseEntity<>(new ResponseStatusPOJO(false, e2.getMessage()), HttpStatus.OK);
		}
	}

	@GetMapping(path = "mi-status/{miFulfilmentRequestId}", produces = "application/json")
	public ResponseEntity<ResponseStatusPOJO> getMiStatus(
			@PathVariable(value = "miFulfilmentRequestId") Long miFulfilmentRequestId) {
		try {
			return new ResponseEntity<>(
					new ResponseStatusPOJO(true, "Record found", SUCCESS_CODE_200,
							miFulfilmentRequestService.getFulfillmentStatusByFulfillment(miFulfilmentRequestId)),
					HttpStatus.OK);
		} catch (ServiceException e1) {
			return new ResponseEntity<>(new ResponseStatusPOJO(false, e1.getMessage(), e1.getMessageId()),
					HttpStatus.OK);
		} catch (Exception e2) {
			return new ResponseEntity<>(new ResponseStatusPOJO(false, e2.getMessage()), HttpStatus.OK);
		}
	}

	@PutMapping(path = "mi-status/{miFulfilmentRequestId}/{status}", produces = "application/json")
	public ResponseEntity<ResponseStatusPOJO> updateMiStatus(HttpServletRequest request,
			@PathVariable(value = "miFulfilmentRequestId") Long miFulfilmentRequestId,
			@PathVariable(value = "status") String status,@RequestBody JsonNode requestBody) {

		String userName = request.getAttribute(USER_NAME).toString().isEmpty() ? USER_NAME
				: request.getAttribute(USER_NAME).toString();
		String userId = request.getAttribute(USER_ID).toString().isEmpty() ? USER_ID
				: request.getAttribute(USER_ID).toString();
		String tokenId = request.getHeader(TOKEN_ID).isEmpty() ? TOKEN_ID : request.getHeader(TOKEN_ID);

		UserDetailPOJO userDetailPOJO = new UserDetailPOJO(userName, userId);

		try {
			return new ResponseEntity<>(new ResponseStatusPOJO(true, "Record status updated successfully",
					SUCCESS_CODE_200, miFulfilmentRequestService.updateFulfillmentStatusByFulfillmentId(
							miFulfilmentRequestId, status, userDetailPOJO, tokenId,requestBody)),
					HttpStatus.OK);
		} catch (ServiceException e1) {
			return new ResponseEntity<>(new ResponseStatusPOJO(false, e1.getMessage(), e1.getMessageId()),
					HttpStatus.OK);
		} catch (Exception e2) {
			return new ResponseEntity<>(new ResponseStatusPOJO(false, e2.getMessage()), HttpStatus.OK);
		}
	}
	
	@PostMapping(path = "mi-remarks/{miFulfilmentRequestId}", produces = "application/json")
	public ResponseEntity<ResponseStatusPOJO> createBotMiRemarks(
			@PathVariable(value = "miFulfilmentRequestId") Long miFulfilmentRequestId) {
		try {
			return new ResponseEntity<>(
					new ResponseStatusPOJO(true, "Record found", SUCCESS_CODE_200,
							miFulfilmentRequestService.createBotMiRemarks(miFulfilmentRequestId)),
					HttpStatus.OK);
		} catch (ServiceException e1) {
			return new ResponseEntity<>(new ResponseStatusPOJO(false, e1.getMessage(), e1.getMessageId()),
					HttpStatus.OK);
		} catch (Exception e2) {
			return new ResponseEntity<>(new ResponseStatusPOJO(false, e2.getMessage()), HttpStatus.OK);
		}
	}
	
	@GetMapping(path = "update-mi-fulfillment-request/{miFulfilmentRequestId}", consumes = "application/json", produces = "application/json")
	public ResponseEntity<ResponseStatusPOJO> updateMifulfillmentRequest(@PathVariable Long miFulfilmentRequestId) {

		try {
			miFulfilmentRequestService.updateMifulfillmentRequest(miFulfilmentRequestId);
			return new ResponseEntity<>(new ResponseStatusPOJO(true, "Mi fulfillment request  updated successfully!"), HttpStatus.OK);
		} catch (Exception ex) {
			return new ResponseEntity<>(new ResponseStatusPOJO(false, ex.getMessage()), HttpStatus.BAD_REQUEST);
		}

	}
}
