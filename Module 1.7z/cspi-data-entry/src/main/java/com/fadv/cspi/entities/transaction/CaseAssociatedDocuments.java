package com.fadv.cspi.entities.transaction;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import com.fadv.cspi.entities.master.ContactCardMaster;
import com.fadv.cspi.entities.master.DocumentMaster;
import com.fadv.cspi.fullfilment.entities.MiFulfilmentRequest;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
@Entity
@JsonInclude(value = Include.NON_NULL)
public class CaseAssociatedDocuments implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(nullable = false, updatable = false)
	private Long caseAssociatedDocumentsId;

	@Column(nullable = false, columnDefinition = "boolean default false")
	private boolean isAssociateAfterCaseReceivedFromSp;

	@Column(nullable = false)
	private String rowId;

	private String parentRowId;

	@Column(nullable = false)
	private int startPage;

	@Column(nullable = false)
	private int endPage;

	@Column(nullable = false, columnDefinition = "text")
	private String fileName;

	@Column(nullable = false, columnDefinition = "text")
	private String filePath;

	@ManyToOne
	@JoinColumn(name = "contact_card_master_id", nullable = true)
	private ContactCardMaster contactCardMaster;

	@ManyToOne
	@JoinColumn(name = "case_details_id", nullable = false)
	private CaseDetails caseDetails;

	@ManyToOne
	@OnDelete(action = OnDeleteAction.CASCADE)
	@JoinColumn(name = "case_uploaded_documents_id", nullable = false)
	private CaseUploadedDocuments caseUploadedDocuments;

	@ManyToOne
	@JoinColumn(name = "document_master_id", nullable = false)
	private DocumentMaster documentMaster;

	@Column(columnDefinition = "text", nullable = true)
	private String agencyAkaName;

	@JsonProperty(access = Access.WRITE_ONLY)
	@Column(nullable = false, columnDefinition = "boolean default false")
	private Boolean active;

	private Date updatedDate = new Date();

	private Date createdDate = new Date();

	private String updatedByUser;

	private String spAkaName;

	@ManyToOne
	@JoinColumn(name = "mi_fulfilment_requestId")
	private MiFulfilmentRequest miFulfilmentRequest;
}
