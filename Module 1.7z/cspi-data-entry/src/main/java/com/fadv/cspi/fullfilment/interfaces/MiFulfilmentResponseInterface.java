package com.fadv.cspi.fullfilment.interfaces;

import java.util.Date;

public interface MiFulfilmentResponseInterface {

	Long getMiFulfilmentRequestId();

	Long getCaseDetailsId();

	String getDeDocuments();

	Boolean getFulfilled();

	String getStatus();

	String getRemarks();

	Date getMiRaisedDate();

	Date getMiReleasedDate();

	Date getCaseCreationDate();

	String getCaseNo();

	String getCrn();

	String getClientName();

	String getCaseType();
	
	String getCheckId();

}
