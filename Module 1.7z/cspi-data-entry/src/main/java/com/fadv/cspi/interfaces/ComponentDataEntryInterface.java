package com.fadv.cspi.interfaces;

public interface ComponentDataEntryInterface {

	String getComponentName();

	String getDocumentData();
	
	String getAkaName();
}
