package com.fadv.cspi.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.fadv.cspi.exception.ServiceException;

@Service
public interface CompProdDocumentsService {

	String getEduOrEmpComponentNameByDocumentMasterId(Long documentMasterId) throws ServiceException;

	List<Long> getComponentsByDocumentMasterId(Long documentMasterId) throws ServiceException;

}
