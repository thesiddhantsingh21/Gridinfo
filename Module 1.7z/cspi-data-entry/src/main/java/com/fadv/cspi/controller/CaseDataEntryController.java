package com.fadv.cspi.controller;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fadv.cspi.exception.ServiceException;
import com.fadv.cspi.pojo.AutoDataEntryPOJO;
import com.fadv.cspi.pojo.DataEntryFormSearchPOJO;
import com.fadv.cspi.pojo.DeleteDataEntryPOJO;
import com.fadv.cspi.pojo.FieldFormSearchPOJO;
import com.fadv.cspi.pojo.response.ResponseStatusPOJO;
import com.fadv.cspi.service.CaseDataEntryService;
import com.fadv.cspi.userdetail.pojo.UserDetailPOJO;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/india/")
public class CaseDataEntryController {

	private static final String RECORD_FOUND = "Record found";
	@Autowired
	private CaseDataEntryService caseDataEntryService;

	private static final String SUCCESS_CODE_200 = "SUCCESS_CODE_200";

	private static final Logger logger = LoggerFactory.getLogger(CaseDataEntryController.class);

	private static final String TOKEN_ID = "tokenid";

	private static final String USER_ID = "userId";

	private static final String USER_NAME = "userName";

	@PostMapping(path = "fetch-case-data-entry-form", consumes = "application/json", produces = "application/json")
	public ResponseEntity<ResponseStatusPOJO> fetchCaseDataEntryForm(
			@Valid @RequestBody DataEntryFormSearchPOJO dataEntryFormSearchPOJO) {

		String dataEntryFormJson = dataEntryFormSearchPOJO.toJSON();
		logger.info("Data entry details to search : {}", dataEntryFormJson);

		try {
			return new ResponseEntity<>(new ResponseStatusPOJO(true, RECORD_FOUND, SUCCESS_CODE_200,
					caseDataEntryService.fetchDataEntryForm(dataEntryFormSearchPOJO)), HttpStatus.OK);
		} catch (ServiceException e1) {
			logger.error("Exception occurred while fetching data : {}", e1.getMessage());
			return new ResponseEntity<>(new ResponseStatusPOJO(false, e1.getMessage(), e1.getMessageId()),
					HttpStatus.OK);
		} catch (Exception e2) {
			logger.error("Exception occurred while fetching data : {}", e2.getMessage());
			return new ResponseEntity<>(new ResponseStatusPOJO(false, e2.getMessage()), HttpStatus.OK);
		}
	}
	
	
	@PostMapping(path = "fetch-fields-data-entry-form", consumes = "application/json", produces = "application/json")
	public ResponseEntity<ResponseStatusPOJO> fetchCaseDataEntryForm(
			@Valid @RequestBody FieldFormSearchPOJO fieldFormSearchPOJO) {
		
//		String dataEntryFormJson = dataEntryFormSearchPOJO.toJSON();
//		logger.info("Data entry details to search : {}", dataEntryFormJson);
		
		try {
			return new ResponseEntity<>(new ResponseStatusPOJO(true, RECORD_FOUND, SUCCESS_CODE_200,
					caseDataEntryService.fetchFieldEntryForm(fieldFormSearchPOJO)), HttpStatus.OK);
		} catch (ServiceException e1) {
			logger.error("Exception occurred while fetching data : {}", e1.getMessage());
			return new ResponseEntity<>(new ResponseStatusPOJO(false, e1.getMessage(), e1.getMessageId()),
					HttpStatus.OK);
		} catch (Exception e2) {
			logger.error("Exception occurred while fetching data : {}", e2.getMessage());
			return new ResponseEntity<>(new ResponseStatusPOJO(false, e2.getMessage()), HttpStatus.OK);
		}
	}

	@PostMapping(path = "save-case-data-entry", produces = "application/json", consumes = "application/json")
	public ResponseEntity<ResponseStatusPOJO> processDataEntry(HttpServletRequest request,
			@Valid @RequestBody DataEntryFormSearchPOJO dataEntryFormSearchPOJO) {

		String dataEntryJson = dataEntryFormSearchPOJO.toJSON();
		logger.info("Data Entry to save : {}", dataEntryJson);

		String userName = request.getAttribute(USER_NAME).toString().isEmpty() ? USER_NAME
				: request.getAttribute(USER_NAME).toString();
		String userId = request.getAttribute(USER_ID).toString().isEmpty() ? USER_ID
				: request.getAttribute(USER_ID).toString();
		String tokenId = request.getHeader(TOKEN_ID).isEmpty() ? TOKEN_ID : request.getHeader(TOKEN_ID);

		UserDetailPOJO userDetailPOJO = new UserDetailPOJO(userName, userId);

		try {
			return new ResponseEntity<>(new ResponseStatusPOJO(true, "Record Saved Successfully", SUCCESS_CODE_200,
					caseDataEntryService.saveDataEntryDetails(dataEntryFormSearchPOJO, userDetailPOJO, tokenId)),
					HttpStatus.OK);
		} catch (ServiceException e1) {
			logger.error("Exception occurred while saving data : {}", e1.getMessage());
			if (e1.getObj() != null) {
				return new ResponseEntity<>(new ResponseStatusPOJO(false, e1.getMessage(), e1.getObj()), HttpStatus.OK);
			} else {
				return new ResponseEntity<>(new ResponseStatusPOJO(false, e1.getMessage(), e1.getMessageId()),
						HttpStatus.OK);
			}
		} catch (Exception e2) {
			logger.error("Exception occurred while saving data : {}", e2.getMessage());
			return new ResponseEntity<>(new ResponseStatusPOJO(false, e2.getMessage()), HttpStatus.OK);
		}
	}

	@DeleteMapping(path = "delete-case-data-entry-form", produces = "application/json", consumes = "application/json")
	public ResponseEntity<ResponseStatusPOJO> deleteDataEntry(HttpServletRequest request,
			@Valid @RequestBody DeleteDataEntryPOJO deleteDataEntryPOJO) {

		logger.info("Data Entry to delete : {}", deleteDataEntryPOJO);

		String userName = request.getAttribute(USER_NAME).toString().isEmpty() ? USER_NAME
				: request.getAttribute(USER_NAME).toString();
		String userId = request.getAttribute(USER_ID).toString().isEmpty() ? USER_ID
				: request.getAttribute(USER_ID).toString();
		String tokenId = request.getHeader(TOKEN_ID).isEmpty() ? TOKEN_ID : request.getHeader(TOKEN_ID);

		UserDetailPOJO userDetailPOJO = new UserDetailPOJO(userName, userId);
		try {
			return new ResponseEntity<>(
					new ResponseStatusPOJO(true, "Record Deleted Successfully", SUCCESS_CODE_200,
							caseDataEntryService.deleteDataEntry(deleteDataEntryPOJO, userDetailPOJO, tokenId)),
					HttpStatus.OK);
		} catch (ServiceException e1) {
			return new ResponseEntity<>(new ResponseStatusPOJO(false, e1.getMessage(), e1.getMessageId()),
					HttpStatus.OK);
		} catch (Exception e2) {
			logger.error("Exception occurred while deleting data : {}", e2.getMessage());
			return new ResponseEntity<>(new ResponseStatusPOJO(false, e2.getMessage()), HttpStatus.OK);
		}
	}

	@PostMapping(path = "auto-data-entry", produces = "application/json", consumes = "application/json")
	public ResponseEntity<ResponseStatusPOJO> dataEntryExcelUpload(HttpServletRequest request,
			@Valid @RequestBody AutoDataEntryPOJO autoDataEntryPOJO) {
		logger.info("Excel data entry to save : {}", autoDataEntryPOJO);

		String userName = request.getAttribute(USER_NAME).toString().isEmpty() ? USER_NAME
				: request.getAttribute(USER_NAME).toString();
		String userId = request.getAttribute(USER_ID).toString().isEmpty() ? USER_ID
				: request.getAttribute(USER_ID).toString();
		String tokenId = request.getHeader(TOKEN_ID).isEmpty() ? TOKEN_ID : request.getHeader(TOKEN_ID);

		UserDetailPOJO userDetailPOJO = new UserDetailPOJO(userName, userId);
		try {
			return new ResponseEntity<>(
					new ResponseStatusPOJO(true, "Record saved Successfully", SUCCESS_CODE_200,
							caseDataEntryService.saveAutoDataEntry(autoDataEntryPOJO, userDetailPOJO, tokenId)),
					HttpStatus.OK);
		} catch (ServiceException e1) {
			return new ResponseEntity<>(new ResponseStatusPOJO(false, e1.getMessage(), e1.getMessageId()),
					HttpStatus.OK);
		} catch (Exception e2) {
			logger.error("Exception occurred while saving data : {}", e2.getMessage());
			return new ResponseEntity<>(new ResponseStatusPOJO(false, e2.getMessage()), HttpStatus.OK);
		}
	}
}