package com.fadv.cspi.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.fadv.cspi.entities.master.CityMaster;
import com.fadv.cspi.exception.ServiceException;
import com.fadv.cspi.pojo.response.CityMasterResponsePOJO;
import com.fasterxml.jackson.databind.node.ObjectNode;

@Service
public interface CityMasterService {

	CityMaster findByCityMasterId(Long cityMasterId) throws ServiceException;

	CityMasterResponsePOJO getCityDetailsByCityMasterId(Long cityMasterId) throws ServiceException;

	List<ObjectNode> getCityListByStateName(String stateName);

	List<CityMaster> findByCityNameAndCountryNameAndStateName(String cityName, String countryName, String stateName);

}
