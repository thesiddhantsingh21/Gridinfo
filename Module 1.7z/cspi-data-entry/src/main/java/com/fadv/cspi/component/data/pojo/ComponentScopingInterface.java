package com.fadv.cspi.component.data.pojo;

public interface ComponentScopingInterface {

	String getCaseNo();

	String getCspiCheckId();

	String getRequestId();

}
