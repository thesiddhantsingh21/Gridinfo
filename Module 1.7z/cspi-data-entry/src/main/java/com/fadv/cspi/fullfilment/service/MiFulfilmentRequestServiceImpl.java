package com.fadv.cspi.fullfilment.service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.fadv.cspi.entities.master.CaseReference;
import com.fadv.cspi.entities.master.CaseSpecificInfo;
import com.fadv.cspi.entities.master.CaseSpecificRecordDetail;
import com.fadv.cspi.entities.master.CheckVerification;
import com.fadv.cspi.entities.master.FileUpload;
import com.fadv.cspi.entities.master.TaskSpecs;
import com.fadv.cspi.entities.transaction.CaseClientDetails;
import com.fadv.cspi.entities.transaction.CaseDetails;
import com.fadv.cspi.entities.transaction.ProcessTaskStages;
import com.fadv.cspi.exception.ServiceException;
import com.fadv.cspi.fullfilment.entities.MiFulfilmentRequest;
import com.fadv.cspi.fullfilment.interfaces.MiFulfilmentResponseInterface;
import com.fadv.cspi.fullfilment.pojo.CaseDetailsDocValPOJO;
import com.fadv.cspi.fullfilment.pojo.CasePOJO;
import com.fadv.cspi.fullfilment.pojo.DocumentsPOJO;
import com.fadv.cspi.fullfilment.pojo.FulfillmentResponsePOJO;
import com.fadv.cspi.fullfilment.pojo.IncompleteFieldsPOJO;
import com.fadv.cspi.fullfilment.pojo.InvalidFieldsPOJO;
import com.fadv.cspi.fullfilment.pojo.MiCasePOJO;
import com.fadv.cspi.fullfilment.pojo.MiDocumentsPOJO;
import com.fadv.cspi.fullfilment.pojo.RuleOutputPOJO;
import com.fadv.cspi.fullfilment.pojo.RuleResultPOJO;
import com.fadv.cspi.fullfilment.pojo.request.MiFulfilmentRequestPOJO;
import com.fadv.cspi.fullfilment.pojo.response.MiFulfilmentResponsePOJO;
import com.fadv.cspi.fullfilment.repository.MiFulfilmentRequestRepository;
import com.fadv.cspi.pojo.request.CaseSearchCriteriaPOJO;
import com.fadv.cspi.repository.master.CaseSpecificInfoRepository;
import com.fadv.cspi.repository.master.CaseSpecificRecordDetailRepository;
import com.fadv.cspi.repository.transaction.CaseClientDetailsRepository;
import com.fadv.cspi.repository.transaction.CaseDetailsRepository;
import com.fadv.cspi.repository.transaction.ProcessTaskStagesRepository;
import com.fadv.cspi.service.ApiService;
import com.fadv.cspi.service.CaseClientDetailsService;
import com.fadv.cspi.service.CaseDetailsService;
import com.fadv.cspi.userdetail.pojo.UserDetailPOJO;
import com.fadv.cspi.utility.ConversionUtility;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

@Service
public class MiFulfilmentRequestServiceImpl implements MiFulfilmentRequestService {

	private static final String ERROR_CODE_404 = "ERROR_CODE_404";

	@Autowired
	private MiFulfilmentRequestRepository miFulfilmentRequestRepository;

	@Autowired
	private CaseDetailsService caseDetailsService;

	@Autowired
	private ApiService apiService;

	@Autowired
	private CaseClientDetailsService caseClientDetailsService;

	@Autowired
	private CaseSpecificInfoRepository caseSpecificInfoRepository;

	@Autowired
	private CaseDetailsRepository caseDetailsRepository;

	@Autowired
	private CaseClientDetailsRepository caseClientDetailsRepository;

	@Autowired
	private CaseSpecificRecordDetailRepository caseSpecificRecordDetailRepository;

	@Autowired
	private ProcessTaskStagesRepository processTaskStagesRepository;
	

	@Value("${mi.remarks.bot.task.api}")
	private String miRemarksBotTaskUrl;

	@Value("${activity.mi.release.worker.name}")
	private String miReleaseWorkerName;

	@Value("${activity.mi.release.worker.description}")
	private String miReleaseWorkerDescription;

	@Value("${workflow.activity.worker.url}")
	private String searchActivityWorkerURL;

	@Value("${workflow.create.bot.task.url}")
	private String createBotTaskUrl;

	@Value("${fetch.metadata.url}")
	private String fetchMetaDataUrl;

	@Value("${mi.fulfilment.scoping.url}")
	private String miFulfilmentScopingUrl;

	private ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES,
			false);

	private static final Logger logger = LoggerFactory.getLogger(MiFulfilmentRequestServiceImpl.class);

	private static final String INDIA = "India";

	@Override
	public MiFulfilmentResponsePOJO createMiFulfilmentRequest(MiFulfilmentRequestPOJO miFulfilmentReqPOJO)
			throws ServiceException {

		logger.info("Got mi fulfillment entry create request : {}", miFulfilmentReqPOJO);
		long caseDetailsId = miFulfilmentReqPOJO.getCaseDetailsId();
		String remarks = miFulfilmentReqPOJO.getRemarks() != null ? miFulfilmentReqPOJO.getRemarks() : "";
		String status = miFulfilmentReqPOJO.getStatus() != null ? miFulfilmentReqPOJO.getStatus() : "created";
		ObjectNode ruleOutput = miFulfilmentReqPOJO.getRuleOutput() != null ? miFulfilmentReqPOJO.getRuleOutput()
				: mapper.createObjectNode();
		boolean fulfilled = miFulfilmentReqPOJO.isFulfilled();

		FulfillmentResponsePOJO fulfillmentResponsePOJO = parseMiResponse(ruleOutput);

		MiFulfilmentRequest miFulfilmentRequest = new MiFulfilmentRequest();
		CaseDetails caseDetail = caseDetailsService.findByCaseDetailsId(caseDetailsId);
		caseDetail.setIsFulfillment(true);
		caseDetailsService.saveCaseDetails(caseDetail);
		miFulfilmentRequest.setCaseDetails(caseDetail);
		miFulfilmentRequest.setCreatedDate(new Date());
		miFulfilmentRequest.setFulfilled(fulfilled);
		miFulfilmentRequest.setRuleOutput(ruleOutput);
		miFulfilmentRequest.setStatus(status);
		miFulfilmentRequest.setActive(true);
		miFulfilmentRequest.setReleased(false);
		miFulfilmentRequest.setCheckId(miFulfilmentReqPOJO.getCheckId());
		miFulfilmentRequest.setMiMessage(fulfillmentResponsePOJO.getMessage());
		
		if (fulfillmentResponsePOJO != null && CollectionUtils.isNotEmpty(fulfillmentResponsePOJO.getMiDocuments())) {
			miFulfilmentRequest.setDeDocuments(mapper.convertValue(fulfillmentResponsePOJO.getMiDocuments(), ArrayNode.class));
			// SET USER ID here => miFulfilmentRequest.setUserId()
		
		}else {
			miFulfilmentRequest.setDeDocuments(mapper.createArrayNode());
			miFulfilmentRequest.setRemarks(remarks);
		}
		
		try {
			miFulfilmentRequest = miFulfilmentRequestRepository.save(miFulfilmentRequest);
			logger.info("MI fulfillment entry request saved successfully : {}", miFulfilmentRequest);
			return convertMiFulMiFulfilmentToResponse(miFulfilmentRequest);
		}catch(Exception e){
			e.printStackTrace();
			logger.info("Invalid data received to save mi fulfillment request");
			throw new ServiceException("Invalid data received to save", ERROR_CODE_404);
		}
		
	}

	public FulfillmentResponsePOJO parseMiResponse(ObjectNode ruleOutput) {

		MiCasePOJO miCasePOJO = mapper.convertValue(ruleOutput, MiCasePOJO.class);
		List<DocumentsPOJO> documentsPOJOs = miCasePOJO.getDocuments();

		List<MiDocumentsPOJO> miDocumentsPOJOs = new ArrayList<>();
		for (DocumentsPOJO documentsPOJO : documentsPOJOs) {
			RuleResultPOJO ruleResultPOJO = documentsPOJO.getRuleResult();
			List<Object> reasons = ruleResultPOJO.getReason();

			boolean isValid = true;
			for (Object reason : reasons) {
				try {
					String tmpReason = (String) reason;
					if (tmpReason.equalsIgnoreCase("Invalid")) {
						isValid = false;
						break;
					}
				} catch (Exception e) {
					logger.error("Exception : {}", e.getMessage());
				}
			}

			List<InvalidFieldsPOJO> invalidFieldsPOJOs = new ArrayList<>();
			if (!isValid) {
				for (Object reason : reasons) {
					try {
						IncompleteFieldsPOJO incompleteFieldsPOJO = mapper.convertValue(reason,
								IncompleteFieldsPOJO.class);
						InvalidFieldsPOJO invalidFieldsPOJO = new InvalidFieldsPOJO();
						invalidFieldsPOJO.setField(incompleteFieldsPOJO.getField());
						invalidFieldsPOJO.setValue(incompleteFieldsPOJO.getValue());
						invalidFieldsPOJO
								.setExpectedValue(CollectionUtils.isNotEmpty(incompleteFieldsPOJO.getExpectedValue())
										? incompleteFieldsPOJO.getExpectedValue().get(0)
										: "");
						invalidFieldsPOJOs.add(invalidFieldsPOJO);
					} catch (Exception e) {
						logger.error("Exception : {}", e.getMessage());
					}
				}

				for (JsonNode recordNode : documentsPOJO.getRecords()) {
					MiDocumentsPOJO miDocumentsPOJO = new MiDocumentsPOJO();
					miDocumentsPOJO.setInvalidFields(invalidFieldsPOJOs);
					miDocumentsPOJO.setDocumentName(documentsPOJO.getDocumentName());
					miDocumentsPOJO.setType("invalid");
					miDocumentsPOJO.setParentRowId(
							recordNode.has("parentRowId") ? recordNode.get("parentRowId").asText() : "");
					miDocumentsPOJO.setRowId(recordNode.has("rowId") ? recordNode.get("rowId").asText() : "");
					miDocumentsPOJOs.add(miDocumentsPOJO);
				}
			}

		}

		RuleOutputPOJO ruleOutputPOJO = miCasePOJO.getRuleOutput();
		if (ruleOutputPOJO != null) {
			List<String> missingDocs = ruleOutputPOJO.getMissingDocs();
			List<String> missingOrDocs = ruleOutputPOJO.getMissingOrDocs();
			if (missingOrDocs != null && CollectionUtils.isNotEmpty(missingOrDocs)) {
				missingDocs.addAll(missingOrDocs);
			}
			if (missingDocs != null && CollectionUtils.isNotEmpty(missingDocs)) {
				List<MiDocumentsPOJO> newMiDocumentsPOJOs = missingDocs.stream().map(data -> {
					UUID uuid = UUID.randomUUID();
					String copyRowId = uuid.toString();

					MiDocumentsPOJO miDocumentsPOJO = new MiDocumentsPOJO();
					miDocumentsPOJO.setInvalidFields(new ArrayList<>());
					miDocumentsPOJO.setDocumentName(data);
					miDocumentsPOJO.setType("missing");
					miDocumentsPOJO.setParentRowId("");
					miDocumentsPOJO.setRowId(copyRowId);
					return miDocumentsPOJO;
				}).collect(Collectors.toList());

				miDocumentsPOJOs.addAll(newMiDocumentsPOJOs);
			}
		}
		FulfillmentResponsePOJO fulfillmentResponsePOJO = new FulfillmentResponsePOJO();
		fulfillmentResponsePOJO.setMessage(ruleOutputPOJO != null ? ruleOutputPOJO.getMessage() : "");
		fulfillmentResponsePOJO.setMiDocuments(miDocumentsPOJOs);
		return fulfillmentResponsePOJO;
	}

	@Override
	public MiFulfilmentResponseInterface getMiFulfilmentRequestByMiFulfilmentRequestId(Long miFulfilmentRequestId)
			throws ServiceException {
		return miFulfilmentRequestRepository.getMiFulfillmentsById(miFulfilmentRequestId);
	}

	@Override
	public List<MiFulfilmentResponseInterface> getAllMiFulfilmentRequest() {
		return miFulfilmentRequestRepository.getAllMiFulfillments();
	}

	@Override
	public List<MiFulfilmentResponseInterface> getCaseDetailsUsingFilters(
			CaseSearchCriteriaPOJO caseSearchCriteriaPOJO) {

		String caseNo = caseSearchCriteriaPOJO.getCaseNo() != null ? caseSearchCriteriaPOJO.getCaseNo() : "";
		String crnNo = caseSearchCriteriaPOJO.getCrnNo() != null ? caseSearchCriteriaPOJO.getCrnNo() : "";
		String checkId = caseSearchCriteriaPOJO.getCheckId() != null ? caseSearchCriteriaPOJO.getCheckId() : "";
		if (StringUtils.isNotEmpty(caseNo)) {
			return miFulfilmentRequestRepository.getMiFulfillmentsByCaseNo(caseNo);
		} else if (StringUtils.isNotEmpty(crnNo)) {
			return miFulfilmentRequestRepository.getMiFulfillmentsByCrn(crnNo);
		} else if (StringUtils.isNotEmpty(checkId)) {
			return miFulfilmentRequestRepository.getMiFulfillmentsByCheckId(checkId);
		} else {
			Date startDate = caseSearchCriteriaPOJO.getStartDate() != null ? caseSearchCriteriaPOJO.getStartDate()
					: new Date();
			Date endDate = caseSearchCriteriaPOJO.getEndDate() != null ? caseSearchCriteriaPOJO.getEndDate()
					: new Date();

			String caseCreationStatus = caseSearchCriteriaPOJO.getCaseCreationStatus() != null
					? caseSearchCriteriaPOJO.getCaseCreationStatus()
					: "";
			String clientName = caseSearchCriteriaPOJO.getClientName() != null ? caseSearchCriteriaPOJO.getClientName()
					: "";
			String fulfillmentType = caseSearchCriteriaPOJO.getFulfillmentType() != null
					? caseSearchCriteriaPOJO.getFulfillmentType()
					: "";
			if (fulfillmentType.equalsIgnoreCase("all")) {
				fulfillmentType = "";
			}
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
			String startDateStr = simpleDateFormat.format(startDate);
			String endDateStr = simpleDateFormat.format(endDate);

			return miFulfilmentRequestRepository.getMiFulfillmentsByFilter(startDateStr, endDateStr, clientName, crnNo,
					caseCreationStatus, checkId, fulfillmentType);
		}
	}

	private MiFulfilmentResponsePOJO convertMiFulMiFulfilmentToResponse(MiFulfilmentRequest miFulfilmentRequest) {

		MiFulfilmentResponsePOJO fulfilmentResPOJO = new MiFulfilmentResponsePOJO();
		fulfilmentResPOJO.setCaseDetailsId(miFulfilmentRequest.getCaseDetails().getCaseDetailsId());
		fulfilmentResPOJO.setCompletedDate(miFulfilmentRequest.getCompletedDate());
		fulfilmentResPOJO.setCreatedDate(miFulfilmentRequest.getCreatedDate());
		fulfilmentResPOJO.setFulfilled(miFulfilmentRequest.getFulfilled());
		fulfilmentResPOJO.setMiFulfilmentRequestId(miFulfilmentRequest.getMiFulfilmentRequestId());
		fulfilmentResPOJO.setRemarks(miFulfilmentRequest.getRemarks());
		fulfilmentResPOJO.setDeDocuments(miFulfilmentRequest.getDeDocuments());
		fulfilmentResPOJO.setStatus(miFulfilmentRequest.getStatus());
		fulfilmentResPOJO.setCaseNo(miFulfilmentRequest.getCaseDetails().getCaseNo());
		fulfilmentResPOJO.setCrn(miFulfilmentRequest.getCaseDetails().getCrn());
		fulfilmentResPOJO.setCaseType(miFulfilmentRequest.getCaseDetails().getCaseType());

		CaseClientDetails caseClientDetails = caseClientDetailsService
				.findByCaseDetails(miFulfilmentRequest.getCaseDetails());
		if (caseClientDetails != null) {
			fulfilmentResPOJO.setClientName(caseClientDetails.getClientMaster().getClientName());
		}

		return fulfilmentResPOJO;
	}

	@Override
	public MiFulfilmentRequest findByCaseDetails(CaseDetails caseDetails) {
		List<MiFulfilmentRequest> miFulfilmentRequests = miFulfilmentRequestRepository.findByCaseDetails(caseDetails);
		if (CollectionUtils.isNotEmpty(miFulfilmentRequests)) {
			return miFulfilmentRequests.get(0);
		}
		return null;
	}

	@Override
	public MiFulfilmentRequest findByMiFulfilmentRequestId(Long miFulfilmentRequestId) throws ServiceException {
		Optional<MiFulfilmentRequest> miFulfilmentRequests = miFulfilmentRequestRepository
				.findById(miFulfilmentRequestId);
		if (miFulfilmentRequests.isPresent()) {
			return miFulfilmentRequests.get();
		}
		throw new ServiceException("Invalid fulfillment request id", ERROR_CODE_404);
	}

	@Override
	public List<CasePOJO> getAllMiFulfilledRequestData(String caseNo) throws ServiceException {
		List<MiFulfilmentRequest> miFulfilmentRequests = miFulfilmentRequestRepository
				.getAndUpdateMiFulfilledDataByCaseNo(caseNo);

		List<CasePOJO> casePOJOs = new ArrayList<>();
		for (MiFulfilmentRequest miFulfilmentRequest : miFulfilmentRequests) {
			try {
				CasePOJO casePOJO = caseDetailsService
						.getCaseDetailsJsonDataByCrn(miFulfilmentRequest.getCaseDetails().getCaseDetailsId());
				if (casePOJO != null) {
					casePOJO.setMiFulfilmentRequestId(miFulfilmentRequest.getMiFulfilmentRequestId());
					casePOJO.setStatus(miFulfilmentRequest.getStatus());
					casePOJO.setMiRemarks(miFulfilmentRequest.getRemarks());
					if (casePOJO.getCaseDetails() != null) {
						CaseDetailsDocValPOJO caseDetailsDocValPOJO = casePOJO.getCaseDetails();
						caseDetailsDocValPOJO.setRemarks(miFulfilmentRequest.getRemarks());
						casePOJO.setCaseDetails(caseDetailsDocValPOJO);
					}

					casePOJOs.add(casePOJO);
				}
			} catch (JsonProcessingException e) {
				logger.error("Exception while converting case data to json : {}", e.getMessage());
				miFulfilmentRequest.setFulfilled(false);
				miFulfilmentRequestRepository.save(miFulfilmentRequest);
			}
		}
		if (CollectionUtils.isNotEmpty(casePOJOs)) {
			return casePOJOs;
		}
		throw new ServiceException("Record not found", ERROR_CODE_404);
	}

	@Override
	public ObjectNode getFulfillmentStatusByFulfillment(Long miFulfilmentRequestId) throws ServiceException {
		MiFulfilmentRequest miFulfilmentRequest = findByMiFulfilmentRequestId(miFulfilmentRequestId);

		ObjectNode statusNode = mapper.createObjectNode();
		statusNode.put("status", miFulfilmentRequest.getStatus() != null ? miFulfilmentRequest.getStatus() : "");
		statusNode.set("deDocuments", miFulfilmentRequest.getDeDocuments());
		statusNode.put("miRemarks", miFulfilmentRequest.getMiMessage());
		statusNode.put("checkId", miFulfilmentRequest.getCheckId());
		statusNode.set("ruleOutput", miFulfilmentRequest.getRuleOutput());

		String missingInfo = miFulfilmentRequest.getRuleOutput().get("missingInfo") != null
				? miFulfilmentRequest.getRuleOutput().get("missingInfo").asText()
				: "";
		statusNode.put("missingInfo", missingInfo);

		return statusNode;
	}

	
	@Override
	public ObjectNode updateFulfillmentStatusByFulfillmentId(Long miFulfilmentRequestId, String status,
			UserDetailPOJO userDetailPOJO, String tokenId,JsonNode requestBody) throws ServiceException {
		MiFulfilmentRequest miFulfilmentRequest = findByMiFulfilmentRequestId(miFulfilmentRequestId);
		String missingInfoStr = "";
		String operation = "EDIT";
		JsonNode previousJson = mapper.convertValue(miFulfilmentRequest, JsonNode.class);
		
		JsonNode missingInfoNode = requestBody.get("missingInfo");
		try {
			missingInfoStr = mapper.writeValueAsString(missingInfoNode);
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

		miFulfilmentRequest.setStatus(status);
		miFulfilmentRequest.setMissingInfo(missingInfoStr);
		miFulfilmentRequest = miFulfilmentRequestRepository.save(miFulfilmentRequest);
		String caseNo = miFulfilmentRequest.getCaseDetails().getCaseNo();
		String crn = miFulfilmentRequest.getCaseDetails().getCrn();
		String requestStage = "scoping";
		JsonNode newJson = mapper.convertValue(miFulfilmentRequest, JsonNode.class);
		logger.info("mi_fulfilment_request -NEW- EDIT - Json: {}", newJson);
		apiService.addAuditLog("mi_fulfilment_request", previousJson, newJson, userDetailPOJO, operation, tokenId);
		ObjectNode statusNode = mapper.createObjectNode();
		statusNode.put("status", miFulfilmentRequest.getStatus() != null ? miFulfilmentRequest.getStatus() : "");
		statusNode.set("deDocuments", miFulfilmentRequest.getDeDocuments());
		if(missingInfoNode == null) {
		List<ProcessTaskStages> ProcessTaskStagesList = processTaskStagesRepository
				.findByCaseNoAndRequestStageOrderByRequestDateDesc(caseNo, requestStage);
		ProcessTaskStages processTaskStages = null;
		JsonNode responseNode = null;
		JsonNode resultNode = mapper.createObjectNode();
		JsonNode componentScopingNode = mapper.createObjectNode();
		if (CollectionUtils.isNotEmpty(ProcessTaskStagesList)) {
			processTaskStages = ProcessTaskStagesList.get(0);
			String resonseStr = processTaskStages.getResponseBody();
			responseNode = ConversionUtility.convertStringToJsonNode(resonseStr);

			ArrayNode dataArray = (ArrayNode) responseNode.get("data");
			ArrayNode componentsArray = null;
			for (JsonNode dataNode : dataArray) {
				resultNode = dataNode.get("result");
				componentScopingNode = resultNode.get("ComponentScoping");
				componentsArray = (ArrayNode) componentScopingNode.get("Components");
				logger.info("components Array {} ", componentsArray.size());

				miFulfilmentScopingUrl = miFulfilmentScopingUrl.replace("{crNo}", crn);
				String miFulfilmentScopingUrlStr = miFulfilmentScopingUrl.replace("{mi_fullfilment_request_id}",
						miFulfilmentRequestId.toString());
				String response = apiService.sendDataToGet(miFulfilmentScopingUrlStr);
				JsonNode resNode = null;
				ArrayNode componentsArrays = null;
				if (!StringUtils.isEmpty(response)) {
					resNode = ConversionUtility.convertStringToJsonNode(response);
					if (resNode.has("success")) {
						JsonNode responNode = resNode.get("response");
						JsonNode engineOutputNode = responNode.get("engineOutput");
						ArrayNode dataArrayNode = (ArrayNode) engineOutputNode.get("data");
						for (JsonNode dataNodes : dataArrayNode) {
							JsonNode resultNodes = dataNodes.get("result");
							JsonNode componentScopingNodes = resultNodes.get("ComponentScoping");
							componentsArrays = (ArrayNode) componentScopingNodes.get("Components");
							componentsArray.addAll(componentsArrays);

							logger.info("componentsArray {} ", componentsArray.size());
							logger.info("response Node {}", responseNode);
//							componentScopingNode.set("Components",componentsArray);

						}

					}
				}

			}
			
			String responseBody = responseNode.toString();
			logger.info("responseBody {}" +responseBody);
			
			processTaskStages.setResponseBody(responseBody);
			processTaskStagesRepository.save(processTaskStages);
		}
		}
		String checkId = miFulfilmentRequest.getCheckId();
		
		String miReleaseWorkerResponse=null;
		
		if (!StringUtils.isEmpty(checkId)) {

			String miRemarksBotTaskUrlStr = miRemarksBotTaskUrl.replace("{miFulfilmentRequestId}",
					miFulfilmentRequestId.toString());
			miReleaseWorkerResponse=apiService.sendDataToPostMi(miRemarksBotTaskUrlStr, "{}",tokenId);
		}
		
//		if(miReleaseWorkerResponse!=null && !StringUtils.isEmpty(miReleaseWorkerResponse)) {}

		return statusNode;
	}

	@Override
	public MiFulfilmentRequest updateDeDocumentsByFulfillment(String documentName, String rowId, String parentRowId,
			MiFulfilmentRequest miFulfilmentRequest, UserDetailPOJO userDetailPOJO, String tokenId) {

		String operation = "EDIT";
		JsonNode previousJson = mapper.convertValue(miFulfilmentRequest, JsonNode.class);

		String newRowId = rowId != null ? rowId : "";
		String newParentRowId = parentRowId != null ? parentRowId : "";

		ArrayNode deDocuments = miFulfilmentRequest.getDeDocuments();
		List<MiDocumentsPOJO> miDocumentsPOJOs = deDocuments == null ? new ArrayList<>()
				: mapper.convertValue(deDocuments, new TypeReference<List<MiDocumentsPOJO>>() {
				});
		List<MiDocumentsPOJO> newMiDocumentsPOJOs = miDocumentsPOJOs
				.stream().filter(data -> data.getRowId().equals(newRowId)
						&& data.getParentRowId().equals(newParentRowId) && data.getDocumentName().equals(documentName))
				.collect(Collectors.toList());

		if (CollectionUtils.isEmpty(newMiDocumentsPOJOs)) {
			MiDocumentsPOJO miDocumentsPOJO = new MiDocumentsPOJO();
			miDocumentsPOJO.setDocumentName(documentName);
			miDocumentsPOJO.setParentRowId(parentRowId);
			miDocumentsPOJO.setRowId(parentRowId);
			miDocumentsPOJO.setType("new");
			miDocumentsPOJO.setInvalidFields(new ArrayList<>());

			miDocumentsPOJOs.add(miDocumentsPOJO);

			miFulfilmentRequest.setDeDocuments(mapper.convertValue(miDocumentsPOJOs, ArrayNode.class));
			miFulfilmentRequest = miFulfilmentRequestRepository.save(miFulfilmentRequest);

			JsonNode newJson = mapper.convertValue(miFulfilmentRequest, JsonNode.class);
			logger.info("mi_fulfilment_request -NEW- EDIT - Json: {}", newJson);
			apiService.addAuditLog("mi_fulfilment_request", previousJson, newJson, userDetailPOJO, operation, tokenId);
		}

		return miFulfilmentRequest;
	}

	@Override
	public JsonNode createBotMiRemarks(long miFulfilmentRequestId) throws ServiceException, JsonProcessingException {
		JsonNode miBotRequestJson = null;
		MiFulfilmentResponseInterface miFulfilmentResponseInterface = miFulfilmentRequestRepository
				.getMiFulfillmentsById(miFulfilmentRequestId);
		if (miFulfilmentResponseInterface != null) {
			String caseReferenceStr = null;
			Long caseDetailsId = miFulfilmentResponseInterface.getCaseDetailsId();
			String checkId = miFulfilmentResponseInterface.getCheckId();
			String remarks = miFulfilmentResponseInterface.getRemarks()!=null?miFulfilmentResponseInterface.getRemarks():"";
			Optional<CaseDetails> caseDetails = caseDetailsRepository.findById(caseDetailsId);
			String caseNumber = "";
			if (caseDetails.isPresent()) {
				caseNumber = caseDetails.get().getCaseNo();
			}
			try {
				List<CaseSpecificInfo> caseSpecificInfoList = caseSpecificInfoRepository.findByCaseNumber(caseNumber);
				JsonNode caseReferenceNode = null;

				if (CollectionUtils.isNotEmpty(caseSpecificInfoList)) {
					caseReferenceNode = caseSpecificInfoList.get(0).getCaseReference();

					caseReferenceStr = mapper.writeValueAsString(caseReferenceNode);

				}
			} catch (Exception e) {
				e.printStackTrace();
			}

			TaskSpecs taskSpecs = new TaskSpecs();
			CaseReference caseReference = null;
			;

			caseReference = mapper.readValue(caseReferenceStr, CaseReference.class);

			String caseNo = caseReference.getCaseNo() != "" ? caseReference.getCaseNo() : "";
			// CaseDetails caseDetails = null;

//			if (!caseDetailsList.isEmpty()) {
//				caseDetails = caseDetailsList.get(0);
//			}
			List<CaseClientDetails> caseClientDetailsList = caseClientDetailsRepository
					.findByCaseDetails(caseDetails.get());
			CaseClientDetails caseClientDetails = null;
			if (!caseClientDetailsList.isEmpty()) {
				caseClientDetails = caseClientDetailsList.get(0);

			}

			List<CaseSpecificRecordDetail> caseSpecificRecordDetailList = caseSpecificRecordDetailRepository
					.findByInstructionCheckId(checkId);
			CaseSpecificRecordDetail caseSpecificRecordDetail = new CaseSpecificRecordDetail();
			if (CollectionUtils.isNotEmpty(caseSpecificRecordDetailList)) {
				caseSpecificRecordDetail = caseSpecificRecordDetailList.get(0);

			}
			caseReference.setCheckId(checkId);
			caseReference.setNgStatus("");
			caseReference.setNgStatusDescription("Missing Information - Requested");
			caseReference.setSbuName(caseClientDetails.getSbuMaster().getSbuName());
			caseReference.setProductName(caseSpecificRecordDetail.getProduct());
			caseReference.setPackageName(caseClientDetails.getPackageMaster().getPackageName());
			caseReference.setComponentName(caseSpecificRecordDetail.getComponentName());
			caseReference.setMiFulfilmentRequestId(miFulfilmentRequestId);

			CheckVerification checkVerification = new CheckVerification();
			checkVerification.setCountry(INDIA);
			checkVerification.setExecutiveSummaryComments(remarks);
			checkVerification.setReportComments(remarks);
			checkVerification.setResultCode("");
			checkVerification.setEmailId("");
			checkVerification.setVerifierName("");
			checkVerification.setGeneralRemarks("");
			checkVerification.setModeOfVerification("");
			checkVerification.setVerifiedDate("");
			checkVerification.setAction("checkLevelMIRelease");
			checkVerification.setSubAction("databasemi");
			checkVerification.setActionCode("");
			checkVerification.setComponentName(caseSpecificRecordDetail.getComponentName());
			checkVerification.setProductName(caseSpecificRecordDetail.getProduct());
			checkVerification.setAttempts("");
			checkVerification.setDepartmentName("");
			checkVerification.setKeyWords("");
			checkVerification.setCost("");
			checkVerification.setIsThisAVerificationAttempt("No");
			checkVerification.setInternalNotes("");
			checkVerification.setDateVerificationCompleted("");
			checkVerification.setDisposition("");
			checkVerification.setExpectedClosureDate("");
			checkVerification.setEndStatusOfTheVerification("Additional Information Required");
			checkVerification.setVerifierDesignation("");
			checkVerification.setFollowUpDateAndTimes("");
			checkVerification.setVerifierNumber("");
			checkVerification.setMiRemarks(remarks);

			taskSpecs.setCaseReference(caseReference);
			taskSpecs.setCheckVerification(checkVerification);

			taskSpecs.setQuestionaire(new ArrayList<>());

			FileUpload fileUpload = new FileUpload();
			ObjectNode fullfillment = mapper.createObjectNode();
			fullfillment.put("insufficiencyStatus","");
			fullfillment.put("mandatoryDocumentsRemarks","");
			fullfillment.put("remarks",remarks);
			fullfillment.put("changeCaseStatus", "Completed");
			
			fileUpload.setVerificationReplyDocument(new ArrayList<>());
			ArrayNode missingFields = mapper.createArrayNode();
			missingFields.add(missingFields);
			
			 ObjectNode documentUpload= mapper.createObjectNode();
			 documentUpload.put("filePath", "");
			 taskSpecs.setDocumentUpload(documentUpload);
			
			taskSpecs.setFileUpload(fileUpload);
			taskSpecs.setFullfillment(fullfillment);
			taskSpecs.setMissingFields(mapper.createArrayNode());
			String taskSpecsStr = mapper.writeValueAsString(taskSpecs);
			JsonNode botRequestJson = mapper.readTree(taskSpecsStr);

			miBotRequestJson = createTaskInWorkFlow(caseNo, botRequestJson,checkId);
		}
		return miBotRequestJson;

	}

	private JsonNode createTaskInWorkFlow(String caseNo, JsonNode botRequestJson,String checkId) throws ServiceException {
		JsonNode botReqJson = null;
		ObjectMapper mapper = new ObjectMapper();

		ObjectNode searchPreviousActivityWorkerId = mapper.createObjectNode();
		searchPreviousActivityWorkerId.put("activityWorkerName", miReleaseWorkerName);
		String activityWorkerSearchResp = apiService.sendDataToPost(searchActivityWorkerURL,
				searchPreviousActivityWorkerId.toString());

		JsonNode activityWorkerSearchRespJson = ConversionUtility.convertStringToJsonNode(activityWorkerSearchResp);
		String activityTypeId = activityWorkerSearchRespJson.get(0).get("activityWorkerId").asText();

		String findMetadataNewURL = fetchMetaDataUrl.replace("{caseNo}", caseNo);
		
		logger.info("findMetadataNewURL {} " +findMetadataNewURL);
		ObjectNode requestBody = mapper.createObjectNode();
		requestBody.put("caseNo", caseNo);

		String metaDataResponseStr = apiService.sendDataToGet(findMetadataNewURL);

		if (metaDataResponseStr == null) {
			throw new ServiceException("Unable to connect to workflow API to fetch metadata");
		}

		logger.info("Got response from the find-metadata api: {}", metaDataResponseStr);

		JsonNode metadataResponseNode = ConversionUtility.convertStringToJsonNode(metaDataResponseStr);
		
		boolean isSuccess = metadataResponseNode.has("success") && metadataResponseNode.get("success").asBoolean();

		if (!isSuccess) {
			String successMsg = metadataResponseNode.has("successMsg") ? metadataResponseNode.get("successMsg").asText()
					: "";
			throw new ServiceException(successMsg);
		}

		JsonNode metadataNode = metadataResponseNode.has("response") ? metadataResponseNode.get("response")
				: mapper.createObjectNode();

		botReqJson = sendDataToWorkflowToCreateNewTask(botRequestJson, metadataNode,checkId);

		return botReqJson;

	}

	private JsonNode sendDataToWorkflowToCreateNewTask(JsonNode botRequestJson, JsonNode metadata,String checkId)
			throws ServiceException {

		
		ObjectNode metadataNode = ((ObjectNode) metadata);
		metadataNode.put("status", "ready");
		metadataNode.put("checkId", checkId);
		ObjectMapper mapper = new ObjectMapper();

//		JsonNode botReqJson = ConversionUtility.convertStringToJsonNode(botRequestJson);

		ObjectNode requestJson = mapper.createObjectNode();
		requestJson.put("taskType", "BOT");
		requestJson.set("requestJson", botRequestJson);
		requestJson.set("metaData", metadataNode);
		requestJson.put("workerName", miReleaseWorkerName);

		String response = apiService.sendDataToPost(createBotTaskUrl, requestJson.toString());
		JsonNode responseJson = ConversionUtility.convertStringToJsonNode(response);

		logger.info("Bot task creation response: {}", response);
		return responseJson;
	}
	
	public void updateMifulfillmentRequest(Long miFulfilmentRequestId) throws ServiceException {
		
	MiFulfilmentRequest miFulfilmentRequest = findByMiFulfilmentRequestId(miFulfilmentRequestId);
	if (miFulfilmentRequest!=null) {
				
			// update mi-fulfillment-resuest table 
			miFulfilmentRequest.setFulfilled(true);
			miFulfilmentRequest.setReleased(true);;
			miFulfilmentRequestRepository.save(miFulfilmentRequest);
		
	}
	}
}
