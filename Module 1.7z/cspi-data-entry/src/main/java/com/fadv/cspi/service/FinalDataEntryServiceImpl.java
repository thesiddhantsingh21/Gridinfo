package com.fadv.cspi.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fadv.cspi.entities.transaction.CaseDataEntry;
import com.fadv.cspi.entities.transaction.CaseDetails;
import com.fadv.cspi.exception.ServiceException;
import com.fadv.cspi.interfaces.ComponentAkaNameInterface;
import com.fadv.cspi.repository.transaction.CaseDataEntryRepository;
import com.fadv.cspi.service.remote.RemoteDataService;
import com.fadv.cspi.userdetail.pojo.UserDetailPOJO;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

@Service
public class FinalDataEntryServiceImpl implements FinalDataEntryService {

	private static final String ERROR_CODE_404 = "ERROR_CODE_404";

	private static final String ERROR_CODE_400 = "ERROR_CODE_400";

	private static final Logger logger = LoggerFactory.getLogger(FinalDataEntryServiceImpl.class);

	@Autowired
	private CaseDetailsService caseDetailsService;

	@Autowired
	private CaseDataEntryRepository caseDataEntryRepository;

	@Autowired
	private RemoteDataService remoteDataService;

	@Autowired
	ApiService apiService;

	@Autowired
	private InsertIntoWorkflowService insertIntoWorkflowService;

	private ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES,
			false);

	@Override
	public String finalDataEntrySave(long caseDetailsId, boolean validate, UserDetailPOJO userDetailPOJO)
			throws ServiceException {
		CaseDetails caseDetails = caseDetailsService.findByCaseDetailsId(caseDetailsId);

		// ***************DE Completion and crn check******************
		checkForValidCrn(caseDetails);
		checkForDeCompletion(caseDetails);
		// ************************************************************

		// ***************DE Validation Check**************************
		if (validate) {
			validateDataEntry(caseDetailsId);
		}
		caseDetails.setDeCompletedBy(userDetailPOJO.getUserId());
		caseDetails.setDeCompletedTime(new Date());
		caseDetails.setDeComplete(true);
		caseDetails.setDeCompletedTime(new Date());
		caseDetails.setDeSave(true);
		caseDetailsService.saveCaseDetails(caseDetails);
		Boolean insertFlag = insertIntoWorkflowService.insertIntoWorkflow(caseDetails);
		logger.info("Inserted Into Workflow :{}", caseDetails.getCaseNo() + "= " + insertFlag);
		if (insertFlag) {
			caseDetails.setMoveToWorkflow(true);
			caseDetailsService.saveCaseDetails(caseDetails);
		}
		return "Final Data Entry submit successful";
	}

	private void validateDataEntry(long caseDetailsId) throws ServiceException {
		List<ComponentAkaNameInterface> componentAkaNameInterfaces = caseDataEntryRepository
				.getAllAkaNameWithComponentByCaseDetailsId(caseDetailsId);

		List<String> errors = new ArrayList<>();
		for (ComponentAkaNameInterface componentAkaNameInterface : componentAkaNameInterfaces) {
			String akaName = componentAkaNameInterface.getAkaName();

			ObjectNode mrlNode = mapper.createObjectNode();
			mrlNode.put("akaName", akaName);
			mrlNode.put("componentName", componentAkaNameInterface.getComponentName());

			try {
				List<String> documentNameList = remoteDataService.getMrlDocs(mrlNode);
				List<String> errDocList = new ArrayList<>();
				for (String documentName : documentNameList) {
					List<CaseDataEntry> caseDataEntries = caseDataEntryRepository
							.getByCaseDetailsIdAndDocumentNameAndAkaName(caseDetailsId, documentName, akaName);
					if (CollectionUtils.isEmpty(caseDataEntries)) {
						errDocList.add(documentName);
					}
				}
				if (CollectionUtils.isNotEmpty(errDocList)) {
					String docList = String.join(", ", errDocList);
					String errorMsg = "You have not associated " + docList + " for " + akaName
							+ " which is a mandatory requirement. Do you want to proceed?";
					errors.add(errorMsg);
				}
			} catch (ServiceException e) {
				logger.info("{} {}", e.getMessageId(), e.getMessage());
			}
		}

		if (CollectionUtils.isNotEmpty(errors)) {
			logger.info("Final data entry errors : {}", errors);
			throw new ServiceException("Validation Error occurred", ERROR_CODE_400, errors);
		}
	}

	private void checkForValidCrn(CaseDetails caseDetails) throws ServiceException {

		String crNo = caseDetails.getCrn();

		if (crNo == null || StringUtils.isEmpty(crNo) || StringUtils.equalsIgnoreCase(crNo, "pending")) {
			throw new ServiceException("Invalid CRN", ERROR_CODE_404);
		}
	}

	private void checkForDeCompletion(CaseDetails caseDetails) throws ServiceException {

		if (caseDetails.getDeComplete() != null && caseDetails.getDeComplete()) {
			throw new ServiceException("DE Already done", ERROR_CODE_404);
		}
	}
}