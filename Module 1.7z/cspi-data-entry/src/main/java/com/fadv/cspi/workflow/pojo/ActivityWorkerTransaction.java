package com.fadv.cspi.workflow.pojo;


import java.util.Date;

import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain=true)
public class ActivityWorkerTransaction {
	private long activityWorkerTransactionId;
	private long activityWorkerId;
	private String key; 
	private String status;
	private Date createdTime;
	private Date updatedTime;
	private String metaData;
}
