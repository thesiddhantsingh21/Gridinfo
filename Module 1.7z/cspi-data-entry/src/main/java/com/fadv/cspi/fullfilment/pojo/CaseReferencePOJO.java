package com.fadv.cspi.fullfilment.pojo;

import lombok.Data;

@Data
public class CaseReferencePOJO {

	private String clientId;

	private String sbuId;

	private String crnCreatedDate;

	private String packageId;

	private String crnNo;

	private String scrnCreatedDate;

	private String caseNo;

	private String checkId;

	private String caseUUID;

	private String caseType;

}
