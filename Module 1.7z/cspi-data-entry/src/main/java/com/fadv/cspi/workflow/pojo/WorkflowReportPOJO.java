package com.fadv.cspi.workflow.pojo;

import java.util.Date;

import lombok.Data;

@Data
public class WorkflowReportPOJO {
	private String requestJson;
	private String wdTransactionId;
	private String taskListId;
	private String metaData;
	private String status;
	private String activityWorkerName;
	private String activityTypeId;
	private String workerStage;
	private String workerName;
	private String errorJson;
	private Date issuedTimestamp;
	private String responseJson;
	private String workerType;
	private Date responseTimestamp;
	private Date requestTimestamp;
	private Date acknowledgementTimestamp;
	private String failureCount;
	private String botActivities;
	private String botId;
	private String errorCause;;
}
