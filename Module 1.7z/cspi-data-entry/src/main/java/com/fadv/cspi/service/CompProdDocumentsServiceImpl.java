package com.fadv.cspi.service;

import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fadv.cspi.entities.mapping.CompProdDocuments;
import com.fadv.cspi.entities.master.ComponentMaster;
import com.fadv.cspi.exception.ServiceException;
import com.fadv.cspi.repository.mapping.CompProdDocumentsRepository;

@Service
public class CompProdDocumentsServiceImpl implements CompProdDocumentsService {

	private static final String ERROR_CODE_404 = "ERROR_CODE_404";

	@Autowired
	private CompProdDocumentsRepository compProdDocumentsRepository;

	@Override
	public String getEduOrEmpComponentNameByDocumentMasterId(Long documentMasterId) throws ServiceException {

		List<CompProdDocuments> compProdDocuments = compProdDocumentsRepository
				.getEduOrEmpComponentByDocumentMasterId(documentMasterId);

		if (CollectionUtils.isNotEmpty(compProdDocuments)) {
			ComponentMaster componentMaster = compProdDocuments.get(0).getComponentMaster();
			if (componentMaster != null) {
				return componentMaster.getComponentName();
			}
		}
		throw new ServiceException("Component name not found for given ng document id", ERROR_CODE_404);
	}

	@Override
	public List<Long> getComponentsByDocumentMasterId(Long documentMasterId) throws ServiceException {

		List<CompProdDocuments> compProdDocuments = compProdDocumentsRepository
				.getComponentByDocumentMasterId(documentMasterId);

		if (CollectionUtils.isNotEmpty(compProdDocuments)) {
			return compProdDocuments.parallelStream().map(data -> data.getComponentMaster().getComponentMasterId())
					.collect(Collectors.toList());
		}
		throw new ServiceException("Component name not found for given ng document id", ERROR_CODE_404);
	}
}
