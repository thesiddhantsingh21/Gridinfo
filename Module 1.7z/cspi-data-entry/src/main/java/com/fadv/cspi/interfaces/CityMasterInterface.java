package com.fadv.cspi.interfaces;

public interface CityMasterInterface {

	long getCityMasterId();

	String getCityName();

	long getStateMasterId();

	String getStateName();

	long getCountryMasterId();

	String getCountryName();

	String getCountryCode();
}
