package com.fadv.cspi.utility;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;

public class ValidationUtility {

	private static final String YYYY_MM_DD = "yyyy-MM-dd";
	private static final String MM_DD_YYYY = "MM/dd/yyyy";

	private ValidationUtility() {
		throw new IllegalStateException("ValidationUtility class");
	}

	public static Date checkAndParseValidDate(String dateStr) {
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(YYYY_MM_DD);
		simpleDateFormat.setLenient(false);
		SimpleDateFormat simpleDateFormat2 = new SimpleDateFormat(MM_DD_YYYY);
		try {
			return simpleDateFormat.parse(dateStr);
		} catch (ParseException e) {
			try {
				return simpleDateFormat2.parse(dateStr);
			} catch (ParseException e1) {
				return null;
			}
		}
	}

	public static boolean checkDateOverLap(Date start1, Date end1, Date start2, Date end2) {
		if (start1.before(start2) && end1.after(start2))
			return true;
		if (start1.before(start2) && end1.after(end2))
			return true;
		if (start1.before(end2) && end1.after(end2))
			return true;
		if (start1.after(start2) && end1.before(end2))
			return true;
		if (start1.after(start2) && start1.before(end2))
			return true;
		if (start1.equals(start2) || start1.equals(end2) || end1.equals(start2) || end1.equals(end2))
			return true;
		return false;
	}

	public static Integer converYearToDate(String year) {

		try {
			return Integer.parseInt(year);
		} catch (Exception e) {
			return null;
		}
	}

	// To check stayFrom should less than stayTo
	public static boolean compareDateGreater(Date fromDate, Date toDate) {

		return toDate.after(fromDate);
	}

	// To check stayFrom should less than or equal stayTo
	public static boolean compareDateEqual(String stayFrom, String stayTo) throws ParseException {
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(YYYY_MM_DD);
		Date fromDate = simpleDateFormat.parse(stayFrom);
		Date toDate = simpleDateFormat.parse(stayTo);

		return toDate.after(fromDate) || toDate.equals(fromDate);
	}

	// Should not be **Less** greater than or Equal to Today's date
	public static boolean compareTodaysDate(String date) throws ParseException {
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(YYYY_MM_DD);
		Date expDate = simpleDateFormat.parse(date);
		Date todaysDate = new Date();

		return expDate.after(todaysDate) || expDate.equals(todaysDate);
	}

	// If Passport issued Country Equal To India
	// 1. First letter can be Alphabetic followed rest 7 numeric digits – B1234567
	// 2. Total number of characters should be 8 digits
	public static boolean isPassportNoValid(String passportNo) {
		Pattern p = Pattern.compile("^[a-zA-Z][0-9]{7}$");
		Matcher m = p.matcher(passportNo);
		return m.find();
	}

	// should have @ as special character i.e. xyz@gmail.com
	public static boolean isValidEmail(String emailId) {
		Pattern p = Pattern.compile("^([a-zA-Z0-9_\\-\\.]+)@([a-zA-Z0-9_\\-\\.]+)\\.([a-zA-Z]{2,5})$");
		Matcher m = p.matcher(emailId);
		return m.find();
	}

	// 1. First 3 digits alphabetic followed by 7 Numeric. I.e. - GTL1393461
	// 2. Voter Id number should always consists of 10 Digits
	public static boolean isVoterIdValid(String voterId) {
		Pattern p = Pattern.compile("^[a-zA-Z]{3}[0-9]{7}$");
		Matcher m = p.matcher(voterId);
		return m.find();
	}

	// Pan card can be configured as below especially for India
	// 1.First 5 digits alphabetic followed by 4 Numeric and 1 alphabetic letter at
	// the last Eg : BJAPR2608R
	// 2.Pan Card Number should always consists of 10 Digits
	public static boolean isPanNoValid(String panNo) {
		Pattern p = Pattern.compile("^[a-zA-Z]{5}[0-9]{4}[a-zA-Z]$");
		Matcher m = p.matcher(panNo);
		return m.find();
	}

	// If Nationality is India then Only 10  digits to be accepted in Mobile Field
	public static boolean isMobileNoValid(String mobileNo, String nationality) {
		if (StringUtils.equalsIgnoreCase(nationality, "India")) {
			Pattern p = Pattern.compile("^[0-9]{10}$");
			Matcher m = p.matcher(mobileNo);
			if (m.find()) {
				return true;
			}
		}
		return false;
	}

}
