package com.fadv.cspi.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.fadv.cspi.entities.master.ContactCardMaster;
import com.fadv.cspi.exception.ServiceException;
import com.fadv.cspi.interfaces.ContactCardMasterInterface;
import com.fadv.cspi.pojo.request.ContactCardMasterRequestPOJO;
import com.fadv.cspi.pojo.response.ContactCardMasterResponsePOJO;
import com.fadv.cspi.userdetail.pojo.UserDetailPOJO;
import com.fasterxml.jackson.databind.node.ObjectNode;

@Service
public interface ContactCardMasterService {

	ContactCardMaster getContactCardByAkaName(String akaName);

	List<ContactCardMasterInterface> getUniversityEmploymentName(String searchStr, String componentName);

	List<ObjectNode> getContactCardDetailsBySearch(String componentName, String akaName);

	ContactCardMasterResponsePOJO createNewContactCardMaster(ContactCardMasterRequestPOJO contactCardMasterRequestPOJO,
			UserDetailPOJO userDetailPOJO, String tokenId) throws ServiceException;

}
