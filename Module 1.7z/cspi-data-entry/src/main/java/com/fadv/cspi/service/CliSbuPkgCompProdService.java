package com.fadv.cspi.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.fadv.cspi.entities.mapping.CliSbuPkgCompProd;
import com.fadv.cspi.exception.ServiceException;

@Service
public interface CliSbuPkgCompProdService {

	List<CliSbuPkgCompProd> findByClientNameAndSbuNameAndPackageMasterId(String clientName, String sbuName,
			Long packageMasterId) throws ServiceException;

}
