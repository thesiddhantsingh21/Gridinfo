package com.fadv.cspi.repository.master;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.fadv.cspi.entities.master.QualificationLevelMaster;
import com.fadv.cspi.entities.master.QualificationMaster;
import com.fadv.cspi.interfaces.QualificationMasterListResponseInterface;

@Repository
public interface QualificationMasterRepository extends JpaRepository<QualificationMaster, Long> {

	List<QualificationMaster> findByQualificationNameAndQualificationLevelMasterAndActive(String qualificationName,
			QualificationLevelMaster qualificationLevelMaster, boolean active);

	@Query(value = "select qm.qualification_master_id as qualificationMasterId, qm.qualification_name as qualificationName "
			+ "from {h-schema}qualification_master qm, {h-schema}qualification_level_master qlm "
			+ "where qm.qualification_level_master_id = qlm.qualification_level_master_id "
			+ "and case when :qualificationLevel != '' then lower(qlm.qualification_level) = lower(:qualificationLevel) "
			+ "else true end and qm.active is true order by qm.qualification_name", nativeQuery = true)
	List<QualificationMasterListResponseInterface> getQualificationMasterByFilter(String qualificationLevel);

	@Query(value = "select qm.qualification_name from {h-schema}qualification_master qm "
			+ "where lower(qm.qualification_name) = lower(:qualificationName) and qm.active is true", nativeQuery = true)
	List<String> getByQualificationNameList(String qualificationName);
	
	@Query(value = "select qm.qualification_name from {h-schema}qualification_master qm "
			+ "left join {h-schema}qualification_level_master qlm on qm.qualification_level_master_id = qlm.qualification_level_master_id "
			+ "where lower(qm.qualification_name) = lower(:qualificationName) and lower(qlm.qualification_level) = lower(:qualificationLevel)"
			+ " and qm.active is true and qlm.active is true", nativeQuery = true)
	List<String> getByQualificationNameAndQualificationLevelList(String qualificationName, String qualificationLevel);
}
