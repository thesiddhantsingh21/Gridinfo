package com.fadv.cspi.pojo.response;

import lombok.Data;

@Data
public class DocumentMasterResponsePOJO {

	private long documentMasterId;

	private String documentName;

	private Boolean isSupportingDocument = false;

	private Boolean enableContactCard = false;

	private String associatedTo;
}
