package com.fadv.cspi.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.node.ObjectNode;

@Service
public interface QualificationMasterService {

	List<ObjectNode> getQualification(String qualificationLevel);

}
