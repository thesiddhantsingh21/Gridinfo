package com.fadv.cspi.validation.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fadv.cspi.entities.mapping.CaseDeXlsConfig;
import com.fadv.cspi.entities.mapping.DocFieldMapping;
import com.fadv.cspi.entities.master.DocumentMaster;
import com.fadv.cspi.exception.ServiceException;
import com.fadv.cspi.pojo.AutoDataEntryDataPOJO;
import com.fadv.cspi.pojo.AutoDataEntryPOJO;
import com.fadv.cspi.repository.mapping.CaseDeXlsConfigRepository;
import com.fadv.cspi.repository.mapping.DocFieldMappingRepository;
import com.fadv.cspi.repository.master.CityMasterRepository;
import com.fadv.cspi.repository.master.ContactCardMasterRepository;
import com.fadv.cspi.repository.master.CountryMasterRepository;
import com.fadv.cspi.repository.master.QualificationLevelMasterRepository;
import com.fadv.cspi.repository.master.QualificationMasterRepository;
import com.fadv.cspi.repository.master.StateMasterRepository;
import com.fadv.cspi.service.DocumentMasterService;
import com.fadv.cspi.utility.ConversionUtility;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectReader;
import com.fasterxml.jackson.databind.node.ObjectNode;

@Service
public class CaseDataEntryValidationServiceImpl implements CaseDataEntryValidationService {

	private static final Logger logger = LoggerFactory.getLogger(CaseDataEntryValidationServiceImpl.class);

	@Autowired
	private DocumentMasterService documentMasterService;

	@Autowired
	private DocFieldMappingRepository docFieldMappingRepository;

	@Autowired
	private CountryMasterRepository countryMasterRepository;

	@Autowired
	private StateMasterRepository stateMasterRepository;

	@Autowired
	private CityMasterRepository cityMasterRepository;

	@Autowired
	private ContactCardMasterRepository contactCardMasterRepository;

	@Autowired
	private QualificationLevelMasterRepository qualificationLevelMasterRepository;

	@Autowired
	private QualificationMasterRepository qualificationMasterRepository;
	
	@Autowired
	private CaseDeXlsConfigRepository caseDeXlsConfigRepository;

	private ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES,
			false);

	@Override
	public Map<String, Object> validateAutoDataEntry(AutoDataEntryPOJO autoDataEntryPOJO) throws ServiceException {

		Map<String, Object> validationResult = new HashMap<>();
		Map<String, Object> defaultResult = new HashMap<>();
		List<AutoDataEntryDataPOJO> documents = autoDataEntryPOJO.getDocuments();
		String requestSource = autoDataEntryPOJO.getRequestSource() != null ? autoDataEntryPOJO.getRequestSource() : "";

		String clientName = autoDataEntryPOJO.getClientName();
		String sbuName = autoDataEntryPOJO.getSbuName();
		String packageName = autoDataEntryPOJO.getPackageName();
		Map<DocumentMaster,JsonNode> docFieldMap = new HashMap<>();
		if(StringUtils.isNotBlank(clientName) && StringUtils.isNotBlank(sbuName) && StringUtils.isNotBlank(packageName)) {
			List<CaseDeXlsConfig> caseDeXlsConfigs = caseDeXlsConfigRepository
					.getDocumentNameByClientAndSbuAndPackage(clientName, sbuName, packageName);
//			List<String> documentNameList = caseDeXlsConfigs.stream()
//					.map(data -> data.getDocumentMaster().getDocumentName()).collect(Collectors.toList());
			docFieldMap = caseDeXlsConfigs.stream()
					.collect(Collectors.toMap(CaseDeXlsConfig::getDocumentMaster,
							CaseDeXlsConfig::getSelectedFields));
			
			System.out.println(docFieldMap);
		}
		
		for (AutoDataEntryDataPOJO document : documents) {
			String documentName = document.getDocumentName();
			DocumentMaster documentMaster = documentMasterService.findByDocumentName(documentName.trim().toLowerCase());
			logger.info("documentMaster: {}",documentMaster.getDocumentName());
			List<ObjectNode> records = document.getRecords() != null ? document.getRecords() : new ArrayList<>();
			if (CollectionUtils.isEmpty(records)) {
				validationResult.put(documentName, "No record to save.");
			}

			if (documentMaster != null) {
				
				List<String> fieldList =  new ArrayList<>();
				JsonNode docFields = docFieldMap.get(documentMaster);
			
				if(docFields!=null && !docFields.isNull()) {
					try {
						ObjectMapper mapper = new ObjectMapper();
						ObjectReader reader = mapper.readerFor(new TypeReference<List<String>>() {
						});
						fieldList = reader.readValue(docFields);
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
				List<DocFieldMapping> docFieldMappings = new ArrayList<>();
				
				if(CollectionUtils.isEmpty(fieldList)) {
					docFieldMappings = docFieldMappingRepository
							.findByDocumentMasterAndActive(documentMaster, true);
				} else {
					docFieldMappings = docFieldMappingRepository
							.getByDocumentMasterIdAndDocumentFieldNames(documentMaster.getDocumentMasterId(), fieldList);
				}
				
				if (CollectionUtils.isNotEmpty(docFieldMappings) && CollectionUtils.isNotEmpty(records)) {
					List<String> mandatoryFields = docFieldMappings.stream().filter(DocFieldMapping::getMandatory)
							.map(DocFieldMapping::getDocumentName).collect(Collectors.toList());

					List<Map<String, String>> fieldValidations = new ArrayList<>();
					List<Map<String, String>> fieldMatchedList = new ArrayList<>();
					for (ObjectNode recordNode : records) {

						Map<String, String> fieldValidation = new HashMap<>();
						Map<String, String> fieldMatchedMap = new HashMap<>();
						if (recordNode != null && !recordNode.isEmpty()) {

							for (String mandatoryField : mandatoryFields) {
								String nodeVal = recordNode.has(mandatoryField)
										? recordNode.get(mandatoryField).asText()
										: "";

								if (nodeVal == null || StringUtils.isEmpty(nodeVal)) {
									fieldValidation.put(mandatoryField, "This field is mandatory");
								}
							}

							if (!StringUtils.equalsIgnoreCase(requestSource, "sp")) {
								List<String> recordKeys = ConversionUtility.findKeys(recordNode);
								for (String recordKey : recordKeys) {
									String nodeVal = recordNode.has(recordKey) ? recordNode.get(recordKey).asText()
											: "";

									List<DocFieldMapping> newDocFieldMappings = docFieldMappings
											.stream().filter(data -> data.getDocumentFieldMaster()
													.getDocumentFieldName().equalsIgnoreCase(recordKey))
											.collect(Collectors.toList());

									if (CollectionUtils.isNotEmpty(newDocFieldMappings)
											&& StringUtils.isNotEmpty(nodeVal)) {
										DocFieldMapping docFieldMapping = newDocFieldMappings.get(0);
										String uiControl = docFieldMapping.getUiControlMaster().getUiControlName();
										List<String> possibleValues = docFieldMapping.getPossibleValues() != null
												? docFieldMapping.getPossibleValues()
												: new ArrayList<>();
										possibleValues = possibleValues.stream().filter(data -> !data.isEmpty())
												.collect(Collectors.toList());

										ObjectNode remoteApi = docFieldMapping.getRemoteApi() != null
												? docFieldMapping.getRemoteApi()
												: mapper.createObjectNode();

										if (StringUtils.equalsIgnoreCase(uiControl, "Calendar")
												&& !ConversionUtility.checkValidDate(nodeVal)) {
											fieldValidation.put(recordKey, "Invalid date format. yyyy-MM-dd is valid");
										} else if (Arrays.asList("Checkbox", "Dropdown", "Filter Dropdown",
												"Radio Button", "Unique Type Dropdown").contains(uiControl)) {
//											if (CollectionUtils.isNotEmpty(possibleValues)
//													&& !possibleValues.contains(nodeVal)) {
//												fieldValidation.put(recordKey,
//														"Value "+nodeVal+" is not present in given list : " + possibleValues);
//											}
											if (CollectionUtils.isNotEmpty(possibleValues)
											&& possibleValues.stream().anyMatch(d -> d.equalsIgnoreCase(nodeVal.trim()))) {
												Optional<String> dbValue = possibleValues.stream()
											            .filter(str -> nodeVal.trim().equalsIgnoreCase(str))
											            .findFirst();
													if(dbValue.isPresent())	{
														System.out.println(" key "+recordKey+" "+dbValue.get());
														fieldMatchedMap.put(recordKey, dbValue.get());
													}
											}
											if (CollectionUtils.isNotEmpty(possibleValues)
													&& !possibleValues.stream().anyMatch(d -> d.equalsIgnoreCase(nodeVal.trim()))) {
												fieldValidation.put(recordKey,
														"Value "+nodeVal+" is not present in given list : " + possibleValues);
												
											}
											else if (!remoteApi.isEmpty()) {
												String primaryKey = remoteApi.has("primaryKey")
														? remoteApi.get("primaryKey").asText()
														: "";
												StringBuilder originalValue = new StringBuilder();
												boolean fieldInvalid = getFieldValueList(primaryKey, nodeVal.trim().toLowerCase(),docFieldMappings,recordNode,originalValue);
												if (fieldInvalid) {
													fieldValidation.put(recordKey,
															"Value "+nodeVal.trim()+" for given field is not present in database");
												} 
												
												if(!fieldInvalid) {
													System.out.println(originalValue.toString());
													if(originalValue.toString().equalsIgnoreCase(nodeVal.trim())) {
														System.out.println("Case does not match");
														fieldMatchedMap.put(recordKey, originalValue.toString());
													}
												}
											}
										}
									}
								}
							}
						} else {
							for (String mandatoryField : mandatoryFields) {
								fieldValidation.put(mandatoryField, "This field is mandatory");
							}
						}
						if (!fieldValidation.isEmpty()) {
							fieldValidations.add(fieldValidation);
						}
						
						if (!fieldMatchedMap.isEmpty()) {
							fieldMatchedList.add(fieldMatchedMap);
						}
						
					}
					if (CollectionUtils.isNotEmpty(fieldValidations)) {
						validationResult.put(documentName, fieldValidations);
					}
					
					if (CollectionUtils.isNotEmpty(fieldMatchedList)) {
						defaultResult.put(documentName+"##DefaultValue", fieldMatchedList);
					}
				}
			} else {
				validationResult.put(documentName, "Invalid document name");
			}
		}

		logger.info("validationResult : {}", validationResult);
		if (!validationResult.isEmpty()) {
			if(MapUtils.isNotEmpty(defaultResult))
			validationResult.putAll(defaultResult);
			throw new ServiceException("Validation Error occurred", "ERROR_CODE_400", validationResult);
		}
		if(MapUtils.isNotEmpty(defaultResult))
			validationResult.putAll(defaultResult);
		return validationResult;
	}

	public boolean getFieldValueList(String primaryKey, String nodeVal,List<DocFieldMapping> docFieldMappings,JsonNode recordNode,StringBuilder originalValue) {

		List<String> result;
		
		if (StringUtils.equalsIgnoreCase(primaryKey, "country")) {
			result = countryMasterRepository.getByCountryNameList(nodeVal);
		} else if (StringUtils.equalsIgnoreCase(primaryKey, "state")) {
			String countryName = getParentKeyValue("country", docFieldMappings,recordNode);
			logger.info("countryName {}",countryName);
			if(StringUtils.isBlank(countryName)) {
				result = stateMasterRepository.getByStateNameList(nodeVal);
			} else {
				result = stateMasterRepository.getByStateNameAndCountryNameList(nodeVal,countryName);	
			}
		} else if (StringUtils.equalsIgnoreCase(primaryKey, "city")) {
			String stateName = getParentKeyValue("state", docFieldMappings,recordNode);
			String countryName = getParentKeyValue("country", docFieldMappings,recordNode);
			logger.info("state {}",stateName);
			logger.info("countryName {}",countryName);
			if(StringUtils.isBlank(stateName) && StringUtils.isBlank(countryName)) {
				result = cityMasterRepository.getByCityNameList(nodeVal);
			} else if(StringUtils.isNotBlank(stateName) && StringUtils.isNotBlank(countryName)) {
				result = cityMasterRepository.getByCityNameAndStateNameAndCountryNameList(nodeVal,stateName,countryName);
			} else {
				result = cityMasterRepository.getByCityNameAndStateNameList(nodeVal,stateName);
			}
		} else if (StringUtils.equalsIgnoreCase(primaryKey, "akaName")) {
			result = contactCardMasterRepository.getByAkaNameList(nodeVal);
		} else if (StringUtils.equalsIgnoreCase(primaryKey, "qualification")) {
			
			String qualificationLevel = getParentKeyValue("qualificationLevel", docFieldMappings,recordNode);
			logger.info("qualificationLevel {}",qualificationLevel);
			if(StringUtils.isBlank(qualificationLevel)) {
				result = qualificationMasterRepository.getByQualificationNameList(nodeVal);
			} else {
				result = qualificationMasterRepository.getByQualificationNameAndQualificationLevelList(nodeVal,qualificationLevel);	
			}
		} else if (StringUtils.equalsIgnoreCase(primaryKey, "qualificationLevel")) {
			result = qualificationLevelMasterRepository.getByQualificationLevelList(nodeVal);
		} else {
			return false;
		}
		if(CollectionUtils.isNotEmpty(result)) {
			originalValue.append(result.get(0));
		}
		return CollectionUtils.isEmpty(result);
	}

	private String getParentKeyValue(String parentKey, List<DocFieldMapping> docFieldMappings,JsonNode recordNode) {
		List<String> keyList = docFieldMappings.stream().filter(e->{
			ObjectNode remoteApi = e.getRemoteApi() != null
					? e.getRemoteApi()
					: mapper.createObjectNode();
			String pk = remoteApi.has("primaryKey")
					? remoteApi.get("primaryKey").asText()
					: "";
			if (StringUtils.equalsIgnoreCase(parentKey, pk)) {
				return true;
			}
			return false;
		}).map(e->e.getDocumentFieldMaster().getDocumentFieldName()).collect(Collectors.toList());
		
		if(CollectionUtils.isNotEmpty(keyList)) {
			String key = keyList.get(0);
			return recordNode.has(key)?recordNode.get(key).asText():"";
		}
		return "";
	}
}
