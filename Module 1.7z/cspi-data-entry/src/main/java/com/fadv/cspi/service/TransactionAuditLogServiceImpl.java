package com.fadv.cspi.service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fadv.cspi.entities.master.TransactionAuditLog;
import com.fadv.cspi.exception.ServiceException;
import com.fadv.cspi.interfaces.TransactionAuditLogResponseInterface;
import com.fadv.cspi.pojo.request.TransactionAuditLogRequestFilterPOJO;
import com.fadv.cspi.pojo.request.TransactionAuditLogRequestPOJO;
import com.fadv.cspi.pojo.response.TransactionAuditLogResponsePOJO;
import com.fadv.cspi.repository.master.TransactionAuditLogRepository;

@Service
public class TransactionAuditLogServiceImpl implements TransactionAuditLogService {

	@Autowired
	private TransactionAuditLogRepository transactionAuditLogRepository;

	private static final String ERROR_CODE_404 = "ERROR_CODE_404";

	@Override
	public TransactionAuditLogResponsePOJO createTransactionAuditLog(
			TransactionAuditLogRequestPOJO transactionAuditLogRequestPOJO) throws ServiceException {
		TransactionAuditLog transactionAuditLog = new TransactionAuditLog();

		transactionAuditLog.setTableName(transactionAuditLogRequestPOJO.getTableName());
		transactionAuditLog.setNewValues(transactionAuditLogRequestPOJO.getNewValues());
		transactionAuditLog.setPrevValues(transactionAuditLogRequestPOJO.getPrevValues());
		transactionAuditLog.setUpdatedBy(transactionAuditLogRequestPOJO.getUpdatedBy());
		transactionAuditLog.setUpdatedByUserId(transactionAuditLogRequestPOJO.getUpdatedByUserId());
		transactionAuditLog.setOperationType(transactionAuditLogRequestPOJO.getOperationType());
		transactionAuditLog.setUpdatedDateTime(new Date());
		transactionAuditLog = transactionAuditLogRepository.save(transactionAuditLog);

		return convertTransactionAuditLogForResponse(transactionAuditLog);
	}

	private TransactionAuditLogResponsePOJO convertTransactionAuditLogForResponse(
			TransactionAuditLog transactionAuditLog) {
		TransactionAuditLogResponsePOJO auditLogResponsePOJO = new TransactionAuditLogResponsePOJO();
		auditLogResponsePOJO.setTransactionAuditLogId(transactionAuditLog.getTransactionAuditLogId());
		auditLogResponsePOJO.setTableName(transactionAuditLog.getTableName());
		auditLogResponsePOJO.setPrevValues(transactionAuditLog.getPrevValues());
		auditLogResponsePOJO.setNewValues(transactionAuditLog.getNewValues());
		auditLogResponsePOJO.setOperationType(transactionAuditLog.getOperationType());
		auditLogResponsePOJO.setUpdatedDateTime(transactionAuditLog.getUpdatedDateTime());
		auditLogResponsePOJO.setUpdatedBy(transactionAuditLog.getUpdatedBy());
		auditLogResponsePOJO.setUpdatedByUserId(transactionAuditLog.getUpdatedByUserId());
		return auditLogResponsePOJO;
	}

	public List<TransactionAuditLogResponsePOJO> findByTableName(
			TransactionAuditLogRequestPOJO transactionAuditLogRequestPOJO) {
		return transactionAuditLogRepository.findByTableName(transactionAuditLogRequestPOJO.getTableName()).stream()
				.map(data -> convertTransactionAuditLogForResponse(data)).collect(Collectors.toList());
	}

	@Override
	public TransactionAuditLogResponsePOJO getTransactionAuditLogByTransactionAuditLogId(long transactionAuditLogId)
			throws ServiceException {
		return convertTransactionAuditLogForResponse(fetchTransactionAuditLogId(transactionAuditLogId));
	}

	private TransactionAuditLog fetchTransactionAuditLogId(long transactionAuditLogId) throws ServiceException {
		Optional<TransactionAuditLog> transactionAuditLogs = transactionAuditLogRepository
				.findById(transactionAuditLogId);
		if (transactionAuditLogs.isPresent()) {
			return transactionAuditLogs.get();
		}
		throw new ServiceException("transaction_audit_log not found for given id", ERROR_CODE_404);
	}

	public List<TransactionAuditLogResponsePOJO> findByTableNameData(
			TransactionAuditLogRequestPOJO auditLogRequestPOJO) {
		List<TransactionAuditLogResponsePOJO> transactionAuditLogResponsePOJOs = new ArrayList<>();
		List<TransactionAuditLogResponseInterface> transactionAuditLogResponseInterfaces = transactionAuditLogRepository
				.getAuditLogResponseInterface(auditLogRequestPOJO.getTableName());
		transactionAuditLogResponseInterfaces.forEach(e -> {
			TransactionAuditLogResponsePOJO transactionAuditLogResponsePOJO = new TransactionAuditLogResponsePOJO();
			transactionAuditLogResponsePOJO.setOperationType(e.getOperationType());
			transactionAuditLogResponsePOJO.setTransactionAuditLogId(e.getTransactionAuditLogId());
			transactionAuditLogResponsePOJO.setTableName(e.getTableName());
			transactionAuditLogResponsePOJO.setUpdatedBy(e.getUpdatedBy());
			transactionAuditLogResponsePOJO.setUpdatedByUserId(e.getUpdatedByUserId());
			transactionAuditLogResponsePOJO.setUpdatedDateTime(e.getUpdatedDateTime());
			transactionAuditLogResponsePOJOs.add(transactionAuditLogResponsePOJO);
		});
		return transactionAuditLogResponsePOJOs;
	}

	@Override
	public List<TransactionAuditLogResponsePOJO> findByTableNameAndOperationTypeAndUpdatedBy(
			TransactionAuditLogRequestFilterPOJO transactionAuditLogRequestFilterPOJO) {

		String tableName = transactionAuditLogRequestFilterPOJO.getTableName() != null
				? transactionAuditLogRequestFilterPOJO.getTableName()
				: "";

		String updatedBy = transactionAuditLogRequestFilterPOJO.getUpdatedBy() != null
				? transactionAuditLogRequestFilterPOJO.getUpdatedBy()
				: "";
		String operationType = transactionAuditLogRequestFilterPOJO.getOperationType() != null
				? transactionAuditLogRequestFilterPOJO.getOperationType()
				: "";
		Date fromDate = transactionAuditLogRequestFilterPOJO.getFromDate() != null
				? transactionAuditLogRequestFilterPOJO.getFromDate()
				: new Date();
		Date toDate = transactionAuditLogRequestFilterPOJO.getToDate() != null
				? transactionAuditLogRequestFilterPOJO.getToDate()
				: new Date();

		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
		String fromDateStr = simpleDateFormat.format(fromDate);
		String toDateStr = simpleDateFormat.format(toDate);

		return transactionAuditLogRepository
				.fetchByTableNameAndOperationTypeAndUpdatedBy(tableName, updatedBy, operationType, fromDateStr,
						toDateStr)
				.stream().map(data -> convertTransactionAuditLogForResponse(data)).collect(Collectors.toList());

	}
}
