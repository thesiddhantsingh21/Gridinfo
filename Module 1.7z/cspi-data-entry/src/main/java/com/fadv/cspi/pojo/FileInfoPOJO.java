package com.fadv.cspi.pojo;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.UUID;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Data;

@Data
@JsonInclude(Include.NON_NULL)
public class FileInfoPOJO {
	private String id;
	private String name;
	private String url;
	private String path;
	private String originalName;
	private Long size;
	private String extension;
	private String contentType;

//	@JsonFormat(pattern="MMM dd, yyyy, hh:mm:ss a")
	private String createDate;
	private String errorLog;
	private Integer pageCount;
	private String filePathName;
	@JsonIgnore
	private String requestId;
	@JsonIgnore
	private Object fileStatus;

	@JsonIgnore
	public boolean isEmail() {
		return this.getName().endsWith(".eml") || this.getName().endsWith(".msg");
	}

	public FileInfoPOJO(String name, String path, String originalName, long size, String extension, String contentType,
			String errorLog, int pageCount, Object fileStatus) {
		this.name = name;
		this.path = path;
		this.originalName = originalName;
		this.size = size;
		this.extension = extension;
		this.contentType = contentType;
		this.errorLog = errorLog;
		this.pageCount = pageCount;
		this.fileStatus = fileStatus;
		this.createDate = new SimpleDateFormat("MMM dd, yyyy, hh:mm:ss a").format(new Date());
		this.requestId = UUID.randomUUID().toString();
	}

	public FileInfoPOJO() {
	}
}
