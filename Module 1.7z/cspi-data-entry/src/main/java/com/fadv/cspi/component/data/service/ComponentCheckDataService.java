package com.fadv.cspi.component.data.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.fadv.cspi.component.data.pojo.QuestionCheckDataResponsePOJO;
import com.fadv.cspi.exception.ServiceException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

@Service
public interface ComponentCheckDataService {

	JsonNode getComponentCheckData(String checkId) throws ServiceException;

	List<QuestionCheckDataResponsePOJO> getQuestionCheckData(String cspiCheckId) throws ServiceException;
	
    ObjectNode getProcessTaskStagesDataforMiVerification(String cspiCheckId) throws ServiceException ;

}
