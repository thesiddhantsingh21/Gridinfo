package com.fadv.cspi.repository.transaction;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.fadv.cspi.entities.transaction.CaseDataEntry;
import com.fadv.cspi.entities.transaction.CaseDetails;
import com.fadv.cspi.interfaces.ComponentAkaNameInterface;
import com.fadv.cspi.interfaces.ComponentDataEntryInterface;

public interface CaseDataEntryRepository extends JpaRepository<CaseDataEntry, Long> {
	List<CaseDataEntry> findByCaseDetails(CaseDetails caseDetail);

	@Query(value = "select * from {h-schema}case_data_entry cde where cde.document_master_id = :documentMasterId "
			+ "and cde.row_id = :rowId and cde.case_details_id = :caseDetailsId", nativeQuery = true)
	List<CaseDataEntry> getByDocumentMasterIdAndRowIdAndCaseDetailsId(long documentMasterId, String rowId,
			long caseDetailsId);

	@Query(value = "select * from {h-schema}case_data_entry cde where cde.document_master_id = :documentMasterId "
			+ "and cde.case_details_id = :caseDetailsId", nativeQuery = true)
	List<CaseDataEntry> getByDocumentMasterIdAndCaseDetailsId(long documentMasterId, long caseDetailsId);

	@Query(value = "select * from {h-schema}case_data_entry cde where "
			+ "cde.parent_row_id = :rowId and cde.case_details_id = :caseDetailsId", nativeQuery = true)
	List<CaseDataEntry> getChildByRowIdAndCaseDetailsId(String rowId, long caseDetailsId);

	@Query(value = "select * from {h-schema}case_data_entry cde "
			+ "left join {h-schema}document_master dm on cde.document_master_id = dm.document_master_id "
			+ "where lower(dm.document_name) = lower(:documentName) and cde.case_details_id = :caseDetailsId", nativeQuery = true)
	List<CaseDataEntry> getCaseDataEntryByDocumentNameAndCaseDetailsId(String documentName, long caseDetailsId);

	List<CaseDataEntry> findByAkaNameIgnoreCase(String akaName);

	@Query(value = "select cde.aka_name as akaName, cm.component_name as componentName, cast(json_object_agg(dm.document_name, "
			+ "cde.data_entry_data) as varchar) documentData from {h-schema}case_data_entry cde, {h-schema}case_data_entry cde2, "
			+ "{h-schema}document_master dm, {h-schema}comp_prod_doc_precedence cpdp, {h-schema}component_master cm "
			+ "where lower(cde.aka_name) = lower(cde2.aka_name) "
			+ "and cde.document_master_id = dm.document_master_id "
			+ "and cde.document_master_id = cpdp.document_master_id "
			+ "and cpdp.component_master_id = cm.component_master_id and cde.aka_name != '' "
			+ "and cde.row_id not in (:rowIds) and cde.parent_row_id not in (:parentRowIds) "
			+ "and cde.case_details_id = :caseDetailsId "
			+ "group by cm.component_name, cde.aka_name order by cde.aka_name", nativeQuery = true)
	List<ComponentDataEntryInterface> getDataEntryGroupByComponentNameAndRowIdAndCaseDetailsId(List<String> rowIds,
			List<String> parentRowIds, long caseDetailsId);

	@Query(value = "select distinct cm.component_name as componentName, ccm.aka_name as akaName "
			+ "from {h-schema}case_data_entry cde left join {h-schema}contact_card_master ccm on "
			+ "case when cde.agency_aka_name is not null and cde.agency_aka_name <> '' then ccm.aka_name = cde.agency_aka_name "
			+ "else cde.aka_name = ccm.aka_name end "
			+ "left join {h-schema}component_master cm on ccm.component_master_id = cm.component_master_id "
			+ "where ccm.aka_name is not null and ccm.aka_name <> '' "
			+ "and cm.component_name is not null and cm.component_name <> '' and cde.case_details_id = :caseDetailsId "
			+ "union select distinct cm.component_name as componentName, ccm.aka_name as akaName "
			+ "from {h-schema}case_associated_documents cad left join {h-schema}contact_card_master ccm on "
			+ "case when cad.agency_aka_name is not null and cad.agency_aka_name <> '' then ccm.aka_name = cad.agency_aka_name "
			+ "else cad.contact_card_master_id = ccm.contact_card_master_id end "
			+ "left join {h-schema}component_master cm on ccm.component_master_id = cm.component_master_id "
			+ "where ccm.aka_name is not null and ccm.aka_name <> '' "
			+ "and cm.component_name is not null and cm.component_name <> '' "
			+ "and cad.case_details_id = :caseDetailsId", nativeQuery = true)
	List<ComponentAkaNameInterface> getAllAkaNameWithComponentByCaseDetailsId(long caseDetailsId);

	@Query(value = "select * from {h-schema}case_data_entry cde  "
			+ "left join {h-schema}document_master dm on cde.document_master_id = dm.document_master_id  "
			+ "where cde.case_details_id = :caseDetailsId and "
			+ "case when cde.agency_aka_name is not null and cde.agency_aka_name <> '' then lower(cde.agency_aka_name) = lower(:akaName) "
			+ "else lower(cde.aka_name) = lower(:akaName) end "
			+ "and lower(dm.document_name) = lower(:documentName)", nativeQuery = true)
	List<CaseDataEntry> getByCaseDetailsIdAndDocumentNameAndAkaName(long caseDetailsId, String documentName,
			String akaName);

	@Query(value = "select distinct cm.component_name as componentName, ccm.aka_name as akaName "
			+ "from {h-schema}case_data_entry cde left join {h-schema}contact_card_master ccm on "
			+ "case when cde.agency_aka_name is not null and cde.agency_aka_name <> '' then ccm.aka_name = cde.agency_aka_name "
			+ "else cde.aka_name = ccm.aka_name end "
			+ "left join {h-schema}component_master cm on ccm.component_master_id = cm.component_master_id "
			+ "where ccm.aka_name is not null and ccm.aka_name <> '' "
			+ "and cm.component_name is not null and cm.component_name <> '' and cde.case_details_id = :caseDetailsId "
			+ "and cde.mi_fulfilment_request_id = :miFulfilmentRequestId "
			+ "union select distinct cm.component_name as componentName, ccm.aka_name as akaName "
			+ "from {h-schema}case_associated_documents cad left join {h-schema}contact_card_master ccm on "
			+ "case when cad.agency_aka_name is not null and cad.agency_aka_name <> '' then ccm.aka_name = cad.agency_aka_name "
			+ "else cad.contact_card_master_id = ccm.contact_card_master_id end "
			+ "left join {h-schema}component_master cm on ccm.component_master_id = cm.component_master_id "
			+ "where ccm.aka_name is not null and ccm.aka_name <> '' "
			+ "and cm.component_name is not null and cm.component_name <> '' "
			+ "and cad.case_details_id = :caseDetailsId and cad.mi_fulfilment_request_id = :miFulfilmentRequestId ", nativeQuery = true)
	List<ComponentAkaNameInterface> getAllAkaNameWithComponentByCaseDetailsIdAndFulfillmentId(long caseDetailsId,
			long miFulfilmentRequestId);

	List<CaseDataEntry> findByAkaNameIgnoreCaseAndCaseDetailsAndParentRowId(String akaName, CaseDetails caseDetails,
			String parentRowId);

	List<CaseDataEntry> findByAkaNameIgnoreCaseAndCaseDetails(String akaName, CaseDetails caseDetails);
	
	@Query(value = "select * from {h-schema}case_data_entry cde where "
			+ " cde.case_details_id = :caseDetailsId", nativeQuery = true)
	List<CaseDataEntry> getDataEntryByCaseDetailsId(long caseDetailsId);
}
