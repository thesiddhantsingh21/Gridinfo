package com.fadv.cspi.repository.transaction;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fadv.cspi.entities.transaction.ProcessTaskStages;

public interface ProcessTaskStagesRepository extends JpaRepository<ProcessTaskStages, Long> {

	List<ProcessTaskStages> findByCaseNoAndRequestStageOrderByRequestDateDesc(String caseNo, String requestStage);

	

}
