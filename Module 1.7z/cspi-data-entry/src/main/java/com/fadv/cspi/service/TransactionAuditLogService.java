package com.fadv.cspi.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.fadv.cspi.exception.ServiceException;
import com.fadv.cspi.pojo.request.TransactionAuditLogRequestFilterPOJO;
import com.fadv.cspi.pojo.request.TransactionAuditLogRequestPOJO;
import com.fadv.cspi.pojo.response.TransactionAuditLogResponsePOJO;

@Service
public interface TransactionAuditLogService {
	TransactionAuditLogResponsePOJO createTransactionAuditLog(
			TransactionAuditLogRequestPOJO transactionAuditLogRequestPOJO) throws ServiceException;

	List<TransactionAuditLogResponsePOJO> findByTableName(
			TransactionAuditLogRequestPOJO transactionAuditLogRequestPOJO);

	TransactionAuditLogResponsePOJO getTransactionAuditLogByTransactionAuditLogId(long transactionAuditLogId)
			throws ServiceException;

	List<TransactionAuditLogResponsePOJO> findByTableNameData(
			TransactionAuditLogRequestPOJO transactionAuditLogRequestPOJO);

	List<TransactionAuditLogResponsePOJO> findByTableNameAndOperationTypeAndUpdatedBy(
			TransactionAuditLogRequestFilterPOJO transactionAuditLogRequestFilterPOJO);
}
