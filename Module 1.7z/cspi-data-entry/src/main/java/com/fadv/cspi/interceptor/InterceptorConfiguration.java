package com.fadv.cspi.interceptor;

import java.util.Arrays;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class InterceptorConfiguration implements WebMvcConfigurer {

	@Override
	public void addInterceptors(InterceptorRegistry registry) {
		registry.addInterceptor(new AuthInterceptor()).addPathPatterns("/api/india/**")
				.excludePathPatterns(Arrays.asList("/**/mi_fulfilment_request", "/**/de-completed-data",
						"/**/mi-release-data/{caseNo}", "/**/copy-data-entry/{oldCaseNo}/{newCaseNo}",
						"/**/fetch-associated-docs/{caseDetailsId}",
						"/**/fulfillment/fetch-associated-docs/{caseDetailsId}/{fulfillmentId}",
						"/**/validate/auto-data-entry"));
	}
}
