package com.fadv.cspi.repository.transaction;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.fadv.cspi.component.data.pojo.CspiCheckCreationCaseDetailsInterface;
import com.fadv.cspi.entities.transaction.CaseDetails;
import com.fadv.cspi.entities.transaction.CspiCheckCreation;

@Repository
public interface CspiCheckCreationRepository extends JpaRepository<CspiCheckCreation, Long> {

	List<CaseDetails> findCaseDetailsByCspiCheckIdOrderByCheckIdDesc(String cspiCheckId);

	@Query(value = "select ccd.client_master_id as clientMasterId, ccd.sbu_master_id as sbuMasterId, ccd.package_master_id as packageMasterId, "
			+ "cm.component_master_id as componentMasterId, pm.product_master_id as productMasterId, cast(ccc.record_node as varchar) as recordNode "
			+ "from {h-schema}cspi_check_creation ccc "
			+ "left join {h-schema}case_client_details ccd on ccc.case_details_id = ccd.case_details_id "
			+ "left join {h-schema}component_master cm on ccc.component_name = cm.component_name "
			+ "left join {h-schema}product_master pm on ccc.product_name = pm.product_name "
			+ "where ccd.active= :active and ccc.cspi_check_id =:cspiCheckId order by ccc.check_id desc limit 1", nativeQuery = true)
	List<CspiCheckCreationCaseDetailsInterface> findByCheckIdAndActive(String cspiCheckId, boolean active);

	@Query(value = "Select * from {h-schema}cspi_check_creation cc where cc.case_details_id =:caseDetailsId ", nativeQuery = true)
	List<CspiCheckCreation> findByCaseDetailsId(long caseDetailsId);
}
