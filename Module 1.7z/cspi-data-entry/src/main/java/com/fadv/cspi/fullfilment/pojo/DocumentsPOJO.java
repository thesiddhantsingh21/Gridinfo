package com.fadv.cspi.fullfilment.pojo;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.JsonNode;

import lombok.Data;

@Data
public class DocumentsPOJO {

	private Boolean split;
	@JsonProperty("Component Name")
	private String componentName;
	@JsonProperty("Document name")
	private String documentName;
	@JsonProperty("Product Name")
	private String productName;

	private String carryForward;

	private Boolean isvalid;

	private RuleResultPOJO ruleResult;

	private List<String> documentFieldNamesWithValue;
	@JsonProperty("Records")
	private List<JsonNode> records;

}
