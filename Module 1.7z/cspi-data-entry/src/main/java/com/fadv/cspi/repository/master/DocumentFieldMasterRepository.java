package com.fadv.cspi.repository.master;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.fadv.cspi.entities.master.DocumentFieldMaster;

@Repository
public interface DocumentFieldMasterRepository extends JpaRepository<DocumentFieldMaster, Long> {

	List<DocumentFieldMaster> findByDocumentFieldNameIgnoreCase(String documentFieldName);

	List<DocumentFieldMaster> findByDocumentFieldKeyIgnoreCaseAndActive(String documentFieldName, boolean active);

	@Query(value = "select * from {h-schema}document_field_master dfm "
			+ "where :fieldKey = dfm.document_field_key", nativeQuery = true)
	List<DocumentFieldMaster> getByFieldKeyReverse(String fieldKey);
}
