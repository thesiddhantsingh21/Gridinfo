package com.fadv.cspi.service;

import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.Collections;
import java.util.Map;

import javax.net.ssl.SSLContext;

import org.apache.commons.collections4.MapUtils;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.TrustSelfSignedStrategy;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.SSLContextBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.stereotype.Service;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.fadv.cspi.pojo.request.TransactionAuditLogRequestPOJO;
import com.fadv.cspi.userdetail.pojo.UserDetailPOJO;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class ApiServiceImpl implements ApiService {

	@Autowired
	private RestTemplateBuilder restTemplateBuilder;

	private static final Logger logger = LoggerFactory.getLogger(ApiServiceImpl.class);

	private ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES,
			false);

	@Value("${auditLog.url}")
	private String auditLogUrl;

	@Override
	public String sendDataToPost(String requestUrl, String requestStr) {
		logger.info("Request Url for Post : {}", requestUrl);
		logger.info("Request Body for Post : {}", requestStr);
		try {
			HttpHeaders httpHeaders = new HttpHeaders();
			httpHeaders.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<String> requestEntity = new HttpEntity<>(requestStr, httpHeaders);
			RestTemplate restTemplate = restTemplateBuilder.build();
			return restTemplate.postForObject(requestUrl, requestEntity, String.class);
		} catch (Exception e) {
			logger.info("Exception while Post request to request url : {}, Error : {}", requestUrl, e.getMessage());
			return null;
		}
	}
	
	@Override
	public String sendDataToPostMi(String requestUrl, String requestStr,String tokenId) {
		logger.info("Request Url for Post : {}", requestUrl);
		logger.info("Request Body for Post : {}", requestStr);
		try {
			HttpHeaders httpHeaders = new HttpHeaders();
			httpHeaders.setContentType(MediaType.APPLICATION_JSON);
			httpHeaders.add("tokenId", tokenId);
			HttpEntity<String> requestEntity = new HttpEntity<>(requestStr, httpHeaders);
			RestTemplate restTemplate = restTemplateBuilder.build();
			return restTemplate.postForObject(requestUrl, requestEntity, String.class);
		} catch (Exception e) {
			logger.info("Exception while Post request to request url : {}, Error : {}", requestUrl, e.getMessage());
			return null;
		}
	}

	@Override
	public String sendDataToGet(String requestUrl) {
		logger.info("Request Url for Get : {}", requestUrl);
		try {
			HttpHeaders httpHeaders = new HttpHeaders();
			httpHeaders.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<String> requestEntity = new HttpEntity<>(httpHeaders);
			RestTemplate restTemplate = restTemplateBuilder.build();
			ResponseEntity<String> response = restTemplate.exchange(requestUrl, HttpMethod.GET, requestEntity,
					String.class);
			if (HttpStatus.OK.equals(response.getStatusCode()) || HttpStatus.CREATED.equals(response.getStatusCode()))
				return response.getBody();
			return null;
		} catch (Exception e) {
			logger.info("Exception while Get request to request url : {}, Error : {}", requestUrl, e.getMessage());
			return null;
		}
	}

	@Override
	public String sendDataToSecuredPost(String requestUrl, String requestStr, Map<String, String> headerMap) {
		logger.info("Request Url for L3 Post : {}", requestUrl);
		logger.info("Request Body for L3 Post : {}", requestStr);
		try {
			SSLContext sslContext = new SSLContextBuilder().loadTrustMaterial(null, new TrustSelfSignedStrategy() {
				@Override
				public boolean isTrusted(X509Certificate[] chain, String authType) throws CertificateException {
					return true;
				}
			}).build();

			CloseableHttpClient httpClient = HttpClients.custom().setSSLContext(sslContext)
					.setSSLHostnameVerifier(new NoopHostnameVerifier()).build();

			HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory();

			requestFactory.setHttpClient(httpClient);

			HttpHeaders httpHeaders = new HttpHeaders();
			httpHeaders.setContentType(MediaType.APPLICATION_JSON);
			httpHeaders.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));

			if (MapUtils.isNotEmpty(headerMap)) {
				for (Map.Entry<String, String> entry : headerMap.entrySet()) {
					httpHeaders.set(entry.getKey(), entry.getValue());
				}
			}
			HttpEntity<String> requestEntity = new HttpEntity<>(requestStr, httpHeaders);
			RestTemplate restTemplate = restTemplateBuilder.build();
			restTemplate.setRequestFactory(requestFactory);

			return restTemplate.postForObject(requestUrl, requestEntity, String.class);
		} catch (Exception e) {
			logger.info("Exception while calling L3 Post url : {}, Error : {}", requestUrl, e.getMessage());
			return null;
		}
	}

	@Override
	public String sendDataToPostFormData(String requestUrl, MultiValueMap<String, Object> map) {
		logger.info("Request Url for Post : {}", requestUrl);
		logger.info("Request Body for Post : {}", map);
		try {
			HttpHeaders httpHeaders = new HttpHeaders();
			httpHeaders.setContentType(MediaType.MULTIPART_FORM_DATA);
			HttpEntity<MultiValueMap<String, Object>> requestEntity = new HttpEntity<>(map, httpHeaders);
			RestTemplate restTemplate = restTemplateBuilder.build();
			return restTemplate.postForObject(requestUrl, requestEntity, String.class);
		} catch (Exception e) {
			logger.info("Exception while Post request to request url : {}, Error : {}", requestUrl, e.getMessage());
			return null;
		}
	}

	@Override
	public String saveAuditLog(String requestUrl, String requestStr, String tokenId) {

		logger.info("Request Url for Post : {}", requestUrl);
		logger.info("Request Body for Post : {}", requestStr);
		try {
			HttpHeaders httpHeaders = new HttpHeaders();
			httpHeaders.setContentType(MediaType.APPLICATION_JSON);
			httpHeaders.add("tokenid", tokenId);

			HttpEntity<String> requestEntity = new HttpEntity<>(requestStr, httpHeaders);
			RestTemplate restTemplate = restTemplateBuilder.build();
			return restTemplate.postForObject(requestUrl, requestEntity, String.class);
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("Exception while Post request to request url : {}, Error : {}", requestUrl, e.getMessage());
			return null;
		}
	}

	@Override
	public boolean addAuditLog(String tableName, JsonNode prevValues, JsonNode newValues, UserDetailPOJO userDetailPOJO,
			String operationType, String tokenId) {
		boolean isChanged = !(prevValues.equals(newValues));
		logger.info("{} - isValueChanged : {}", tableName, isChanged);
		if (isChanged) {
			TransactionAuditLogRequestPOJO auditLogRequestPOJO = new TransactionAuditLogRequestPOJO();
			auditLogRequestPOJO.setNewValues(newValues);
			auditLogRequestPOJO.setPrevValues(prevValues);
			auditLogRequestPOJO.setTableName(tableName);
			auditLogRequestPOJO.setUpdatedBy(userDetailPOJO.getUserName());
			auditLogRequestPOJO.setUpdatedByUserId(userDetailPOJO.getUserId());
			auditLogRequestPOJO.setOperationType(operationType.toUpperCase());

			try {
				String audiLogResponse = saveAuditLog(auditLogUrl, mapper.writeValueAsString(auditLogRequestPOJO),
						tokenId);
				if (audiLogResponse == null) {
					return false;
				}
				logger.info("{} - audiLogResponse : {}", tableName, audiLogResponse);
			} catch (Exception e) {
				logger.info("{} - Error Occurred : {}", tableName, e.getMessage());
				return false;
			}
		}
		return true;
	}

}
