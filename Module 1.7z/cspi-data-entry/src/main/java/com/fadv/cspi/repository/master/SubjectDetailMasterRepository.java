package com.fadv.cspi.repository.master;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fadv.cspi.entities.master.SubjectDetailMaster;

public interface SubjectDetailMasterRepository extends JpaRepository<SubjectDetailMaster, Long> {

	List<SubjectDetailMaster> findBySubjectName(String subjectName);
}
