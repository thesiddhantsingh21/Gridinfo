package com.fadv.cspi.pojo.request;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Positive;

import lombok.Data;

@Data
public class AutoDocAssociationPOJO {
	@NotEmpty
	private String sourceFolder;
	@NotEmpty
	private String fileName;
	@Positive
	private int startPage;
	@Positive
	private int endPage;
	@NotEmpty
	private String documentName;
	@NotEmpty
	private String rowId;
	@Positive
	private long caseDetailsId;

	private String akaName;
}
