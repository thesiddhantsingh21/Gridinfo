package com.fadv.cspi.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fadv.cspi.repository.master.CountryMasterRepository;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

@Service
public class CountryMasterServiceImpl implements CountryMasterService {

	@Autowired
	private CountryMasterRepository countryMasterRepository;

	private ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES,
			false);

	@Override
	public List<ObjectNode> getCountryList() {
		return mapper.convertValue(countryMasterRepository.getCountryListByFilter(""),
				new TypeReference<List<ObjectNode>>() {
				});
	}

}
