package com.fadv.cspi.component.data.pojo;

import java.util.List;

import com.fadv.cspi.fullfilment.pojo.CaseDetailsDocValPOJO;
import com.fadv.cspi.fullfilment.pojo.CaseReferencePOJO;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.JsonNode;

import lombok.Data;

@Data
public class ComponentScopingPOJO {

	private CaseReferencePOJO caseReference;

	private JsonNode caseMoreInfo;

	private CaseDetailsDocValPOJO caseDetails;

	private JsonNode clientSpecificFields;

	@JsonProperty("TYPE")
	private String type;

	@JsonProperty("CASE_UUID")
	private String caseUuid;

	@JsonProperty("CASE_NUMBER")
	private String caseNumber;

	@JsonProperty("CASE_REF_NUMBER")
	private String caseRefNumber;

	@JsonProperty("CLIENT_CODE")
	private String clientCode;

	@JsonProperty("CLIENT_NAME")
	private String clientName;

	@JsonProperty("SBU_NAME")
	private String sbuName;

	@JsonProperty("Package Name")
	private String packageName;

	@JsonProperty("Candidate_Name")
	private String candidateName;

	@JsonProperty("Components")
	private List<ComponentPOJO> components;

	@JsonProperty("CRNCreationDate")
	private String crnCreationDate;

	@JsonProperty("BaseEJCCountryList")
	private Object baseEJCCountryList;
}
