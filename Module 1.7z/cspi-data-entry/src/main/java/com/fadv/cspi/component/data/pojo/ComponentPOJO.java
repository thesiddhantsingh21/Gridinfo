package com.fadv.cspi.component.data.pojo;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.node.ObjectNode;

import lombok.Data;

@Data
public class ComponentPOJO {

	private String packageName;

	private boolean addOnPackage;

	private Object addOnPackages;

	private int sequence;

	@JsonProperty("Component name")
	private String componentNameFull;

	private Object componentName;

	@JsonProperty("PRODUCT")
	private String product;

	@JsonProperty("Records")
	private List<ObjectNode> records;

	private boolean dbComponent;

}
