package com.fadv.cspi.entities.master;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.vladmihalcea.hibernate.type.json.JsonBinaryType;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
@Entity
@JsonInclude(value = Include.NON_NULL)
@TypeDef(name = "jsonb", typeClass = JsonBinaryType.class)
public class ContactCardMaster implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(nullable = false, updatable = false)
	private long contactCardMasterId;

	@Column(nullable = false)
	private String akaName;

	@ManyToOne
	@JoinColumn(name = "country_master_id", nullable = false)
	private CountryMaster countryMaster;

	@ManyToOne
	@JoinColumn(name = "state_master_id", nullable = false)
	private StateMaster stateMaster;

	@ManyToOne
	@JoinColumn(name = "city_master_id", nullable = false)
	private CityMaster cityMaster;

	@Column(nullable = false)
	private Integer avl;

	@Column(nullable = false)
	private Integer mrl;

	@Column(nullable = false)
	private Integer costApproval;

	@Column(nullable = false)
	private Integer stellar;

	@Column(nullable = false)
	private Integer singleSpoc;

	@Column(nullable = false)
	private Integer bulkSpoc;

	@Column(nullable = false)
	private Integer cbv;

	@Column(nullable = false)
	private Integer utv;

	@Column(nullable = false)
	private Integer suspect;

	@Column(nullable = false)
	private Integer i4v;

	@ManyToOne
	@JoinColumn(name = "component_master_id", nullable = false)
	private ComponentMaster componentMaster;

	private String existingUniversityEmploymentCollege;

	@Column(nullable = false)
	private String universityEmploymentName;

	private String areaLocalityName;

	private String enterAkaName;

	private String fadvRelationship;

	private String mandatoryDocuments;

	private String phoneType;

	private String modeOfInitiation;

	private String entityType;

	private Integer orgId;

	private Date updatedDate = new Date();

	private String userName;

	@Type(type = "jsonb")
	@Column(columnDefinition = "jsonb")
	private ObjectNode additionalFields;

	@JsonProperty(access = Access.WRITE_ONLY)
	@Column(nullable = false, columnDefinition = "boolean default false")
	private Boolean active;
}
