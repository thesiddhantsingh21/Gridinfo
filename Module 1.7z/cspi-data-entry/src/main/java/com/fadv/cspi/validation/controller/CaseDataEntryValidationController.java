package com.fadv.cspi.validation.controller;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fadv.cspi.exception.ServiceException;
import com.fadv.cspi.pojo.AutoDataEntryPOJO;
import com.fadv.cspi.pojo.response.ResponseStatusPOJO;
import com.fadv.cspi.validation.service.CaseDataEntryValidationService;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/india/validate/")
public class CaseDataEntryValidationController {

	@Autowired
	private CaseDataEntryValidationService caseDataEntryValidationService;

	private static final String SUCCESS_CODE_200 = "SUCCESS_CODE_200";

	private static final Logger logger = LoggerFactory.getLogger(CaseDataEntryValidationController.class);

	@PostMapping(path = "auto-data-entry", produces = "application/json", consumes = "application/json")
	public ResponseEntity<ResponseStatusPOJO> dataEntryExcelUpload(
			@Valid @RequestBody AutoDataEntryPOJO autoDataEntryPOJO) {
		logger.info("Excel data entry to validate : {}", autoDataEntryPOJO);

		try {
			return new ResponseEntity<>(new ResponseStatusPOJO(true, "Record validated Successfully", SUCCESS_CODE_200,
					caseDataEntryValidationService.validateAutoDataEntry(autoDataEntryPOJO)), HttpStatus.OK);
		} catch (ServiceException e1) {
			logger.error("Exception occurred while validating data : {}", e1.getMessage());
			if (e1.getObj() != null) {
				return new ResponseEntity<>(new ResponseStatusPOJO(false, e1.getMessage(), e1.getObj()), HttpStatus.OK);
			} else {
				return new ResponseEntity<>(new ResponseStatusPOJO(false, e1.getMessage(), e1.getMessageId()),
						HttpStatus.OK);
			}
		} catch (Exception e2) {
			logger.error("Exception occurred while validating data : {}", e2.getMessage());
			return new ResponseEntity<>(new ResponseStatusPOJO(false, e2.getMessage()), HttpStatus.OK);
		}
	}
}