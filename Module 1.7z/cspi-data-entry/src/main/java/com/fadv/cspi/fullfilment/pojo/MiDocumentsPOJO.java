package com.fadv.cspi.fullfilment.pojo;

import java.util.List;

import lombok.Data;

@Data
public class MiDocumentsPOJO {

	private String documentName;
	private String rowId;
	private String parentRowId;
	private String type;
	private List<InvalidFieldsPOJO> invalidFields;
}
