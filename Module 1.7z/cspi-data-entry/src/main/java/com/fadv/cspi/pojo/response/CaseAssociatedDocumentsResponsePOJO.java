package com.fadv.cspi.pojo.response;

import java.util.List;

import com.fadv.cspi.fullfilment.pojo.InvalidFieldsPOJO;

import lombok.Data;

@Data
public class CaseAssociatedDocumentsResponsePOJO {

	private long caseDetailsId;

	private int pageCount;

	private String sourceFolder;

	private String originalName;

	private Integer startPage;

	private String rowId;

	private String parentRowId;

	private String filePath;

	private Integer endPage;

	private String documentName;

	private long documentMasterId;

	private String akaName;

	private String agencyAkaName;

	private String fileExtension;

	private String fileName;

	private boolean isMandatory;

	private long caseUploadedDocumentsId;

	private Long fulfillmentId;

	private List<InvalidFieldsPOJO> invalidFields;

	private String miMessage;

	private String updatedByUser;

	private String associatedTo;
}
