package com.fadv.cspi.pojo.request;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.databind.JsonNode;

import lombok.Data;

@Data
public class TransactionAuditLogRequestPOJO {

	@NotEmpty
	private String tableName;

	private JsonNode prevValues;

	@NotNull
	private JsonNode newValues;

	private String updatedBy;

	private String updatedByUserId;

	private String operationType;
}
