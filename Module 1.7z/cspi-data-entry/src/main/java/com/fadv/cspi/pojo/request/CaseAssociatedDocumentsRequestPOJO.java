package com.fadv.cspi.pojo.request;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Positive;

import lombok.Data;

@Data
public class CaseAssociatedDocumentsRequestPOJO {

	@Positive
	private long caseDetailsId;

	@Positive
	private int pageCount;

	@NotEmpty
	private String sourceFolder;

	@NotEmpty
	private String originalName;

	@Positive
	private int startPage;

	@NotEmpty
	private String rowId;

	private String parentRowId;

	private String filePath;

	@Positive
	private int endPage;

	@NotEmpty
	private String documentName;

	@Positive
	private long documentMasterId;

	private String akaName;

	private String agencyAkaName;

	@Positive
	private long caseUploadedDocumentsId;

	@NotEmpty
	private String fileExtension;

	@NotEmpty
	private String fileName;

	private boolean isMandatory;

	private Long fulfillmentId;
}
