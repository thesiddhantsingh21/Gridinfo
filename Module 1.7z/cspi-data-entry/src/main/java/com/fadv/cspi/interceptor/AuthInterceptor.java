package com.fadv.cspi.interceptor;

import java.util.Base64;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.servlet.HandlerInterceptor;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

public class AuthInterceptor implements HandlerInterceptor {

	private static final String TOKENID2 = "tokenid";

	private static final String USER_NAME = "userName";

	private static final String USER_ID = "userId";

	private static final String USERID = "userid";

	private static final String EMAIL = "email";

	private static final Logger logger = LoggerFactory.getLogger(AuthInterceptor.class);

	private ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES,
			false);

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {

		if (request.getMethod().equalsIgnoreCase("OPTIONS")) {
			return true;
		}

		Base64.Decoder decoder = Base64.getUrlDecoder();

		String tokenId = request.getHeader(TOKENID2);
		logger.info("token from attribute : {}", request.getAttribute(TOKENID2));

		// Set response content type
		response.setContentType("application/json");
		ObjectNode errorNode = mapper.createObjectNode();
		String error = "";

		logger.info("\n-------- AuthInterception.preHandle --- ");
		logger.info("Request Token : {}", request.getHeader(TOKENID2));
		logger.info("Request URL: {}", request.getRequestURL());
		logger.info("Start Time: {}", System.currentTimeMillis());

		if (tokenId != null) {
			String[] chunks = tokenId.split("\\.");
			if (chunks.length > 1) {
				String payload = new String(decoder.decode(chunks[1]));
				try {
					JsonNode payloadNode = mapper.readTree(payload);
					String userId = payloadNode.has(USERID) ? payloadNode.get(USERID).asText() : "";
					String userName = payloadNode.has(EMAIL) ? payloadNode.get(EMAIL).asText() : "";

					if (StringUtils.isNotEmpty(userName) && StringUtils.isNotEmpty(userId)) {
						request.setAttribute(USER_ID, userId);
						request.setAttribute(USER_NAME, userName);
						return true;
					} else {
						error = "Invalid Token";
					}
				} catch (JsonProcessingException e) {
					logger.error("Invalid Token Payload : {}", e.getMessage());
					error = "Invalid Token";
				}
			} else {
				error = "Invalid Token";
			}
		} else {
			error = "Token Missing";
		}

		errorNode.put("error", error);
		response.getWriter().write(errorNode.asText());
		response.sendError(401);

		return false;
	}

//	@Override
//	public void postHandle(HttpServletRequest request, HttpServletResponse response, //
//			Object handler, ModelAndView modelAndView) throws Exception {
//
//		System.out.println("\n-------- LogInterception.postHandle --- ");
//		System.out.println("Request URL: " + request.getRequestURL());
//
//		// You can add attributes in the modelAndView
//		// and use that in the view page
//	}
//
//	@Override
//	public void afterCompletion(HttpServletRequest request, HttpServletResponse response, //
//			Object handler, Exception ex) throws Exception {
//		System.out.println("\n-------- LogInterception.afterCompletion --- ");
//
//		long startTime = (Long) request.getAttribute("startTime");
//		long endTime = System.currentTimeMillis();
//		System.out.println("Request URL: " + request.getRequestURL());
//		System.out.println("End Time: " + endTime);
//
//		System.out.println("Time Taken: " + (endTime - startTime));
//	}

}