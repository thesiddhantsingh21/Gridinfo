package com.fadv.cspi.repository.transaction;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.fadv.cspi.entities.transaction.CaseDetails;
import com.fadv.cspi.entities.transaction.CaseUploadedDocuments;

public interface CaseUploadedDocumentsRepository extends JpaRepository<CaseUploadedDocuments, Long> {

	List<CaseUploadedDocuments> findByfileNameAndUploadTypeAndCaseDetails(String fileName, String uploadType,
			CaseDetails caseDetails);

	List<CaseUploadedDocuments> findByUploadTypeIgnoreCaseAndCaseDetails(String uploadType, CaseDetails caseDetails);

	@Query(value = "Select * from {h-schema}case_uploaded_documents where lower(file_name) like lower(:fileName) "
			+ "and lower(original_name) = lower(:originalName)", nativeQuery = true)
	List<CaseUploadedDocuments> getByFileNameIgnoreCaseAndOriginalNameIgnoreCase(String fileName, String originalName);

	List<CaseUploadedDocuments> findByCaseDetails(CaseDetails caseDetails);

	List<CaseUploadedDocuments> findByCaseDetailsAndUploadTypeIgnoreCase(CaseDetails caseDetails, String uploadType);

	CaseUploadedDocuments findByCaseUploadedDocumentsIdAndActive(Long id, boolean b);

	List<CaseUploadedDocuments> findByCaseDetailsAndUploadTypeIgnoreCaseAndCaseOriginIgnoreCase(CaseDetails caseDetails,
			String uploadType, String caseOrigin);
}
