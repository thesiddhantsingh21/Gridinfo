package com.fadv.cspi.repository.master;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.fadv.cspi.entities.master.ClientMaster;

public interface ClientMasterRepository extends JpaRepository<ClientMaster, Long> {

	List<ClientMaster> findByClientNameIgnoreCaseAndClientCodeIgnoreCase(String clientName, String clientCode);

	List<ClientMaster> findByClientNameIgnoreCaseAndActive(String clientName, boolean active);

	@Query(value = "select distinct client_name from {h-schema}client_master cm order by client_name", nativeQuery = true)
	List<String> getAllDistinctClientNamesOrderByClientName();
}
