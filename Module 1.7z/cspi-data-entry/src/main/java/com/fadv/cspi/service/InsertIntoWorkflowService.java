package com.fadv.cspi.service;

import org.springframework.stereotype.Service;

import com.fadv.cspi.entities.transaction.CaseDetails;

@Service
public interface InsertIntoWorkflowService {

	Boolean insertIntoWorkflow(CaseDetails caseDetails);

}
