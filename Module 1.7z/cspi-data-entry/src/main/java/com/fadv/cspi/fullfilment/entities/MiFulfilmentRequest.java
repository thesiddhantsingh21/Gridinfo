package com.fadv.cspi.fullfilment.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;

import com.fadv.cspi.entities.transaction.CaseDetails;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.vladmihalcea.hibernate.type.json.JsonBinaryType;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
@Entity
@JsonInclude(value = Include.NON_NULL)
@TypeDef(name = "jsonb", typeClass = JsonBinaryType.class)
public class MiFulfilmentRequest implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(nullable = false, updatable = false)
	private Long miFulfilmentRequestId;

	@ManyToOne
	@JoinColumn(name = "case_details_id", nullable = false)
	private CaseDetails caseDetails;

	@Type(type = "jsonb")
	@Column(columnDefinition = "jsonb", nullable = false)
	private ObjectNode ruleOutput;

	@Column(nullable = false, columnDefinition = "boolean default false")
	private Boolean fulfilled;

	@Column(nullable = false, columnDefinition = "boolean default false")
	private Boolean released;

	private String status;
	
	
	@Column(columnDefinition = "text")
	private String remarks;

	@Column(nullable = false)
	private Date createdDate = new Date();

	private Date completedDate;

	private String updatedByUser;

	@Column(nullable = false, columnDefinition = "boolean default false")
	private Boolean active;

	@Type(type = "jsonb")
	@Column(columnDefinition = "jsonb", nullable = false)
	private ArrayNode deDocuments;

	private String miMessage;
	
	private String checkId;
	
	private String missingInfo;

}
