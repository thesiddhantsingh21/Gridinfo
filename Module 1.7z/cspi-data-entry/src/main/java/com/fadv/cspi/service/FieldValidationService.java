package com.fadv.cspi.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.fadv.cspi.entities.transaction.CaseDetails;
import com.fadv.cspi.pojo.ValidationErrorPOJO;
import com.fadv.cspi.pojo.response.DocumentFieldMasterResponsePOJO;
import com.fadv.cspi.repository.transaction.CaseDataEntryRepository;
import com.fasterxml.jackson.core.JsonProcessingException;

@Service
public interface FieldValidationService {

	List<ValidationErrorPOJO> validatedFormField(List<DocumentFieldMasterResponsePOJO> documentFieldMasterResponsePOJOs,
			String documentName, CaseDataEntryRepository caseDataEntryRepository, String akaName, String rowId,
			String parentRowId, long caseDetailsId, CaseDetails caseDetails) throws JsonProcessingException;

}
