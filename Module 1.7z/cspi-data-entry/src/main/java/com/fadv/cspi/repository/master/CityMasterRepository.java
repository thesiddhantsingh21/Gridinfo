package com.fadv.cspi.repository.master;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.fadv.cspi.entities.master.CityMaster;
import com.fadv.cspi.entities.master.CountryMaster;
import com.fadv.cspi.entities.master.StateMaster;
import com.fadv.cspi.interfaces.CityMasterInterface;
import com.fadv.cspi.interfaces.CityMasterListResponseInterface;

@Repository
public interface CityMasterRepository extends JpaRepository<CityMaster, Long> {

	List<CityMaster> findByCityNameIgnoreCaseAndCountryMasterAndStateMasterAndActive(String cityName,
			CountryMaster countryMaster, StateMaster stateMaster, boolean active);

	List<CityMaster> findByCityNameIgnoreCaseAndActive(String cityName, boolean active);

	@Query(value = "select cm.city_master_id as cityMasterId, cm.city_name as cityName from {h-schema}city_master cm "
			+ "left join {h-schema}state_master sm on cm.state_master_id = sm.state_master_id "
			+ "left join {h-schema}country_master cm2 on cm.country_master_id = cm2.country_master_id "
			+ "where case when :stateName != '' then lower(sm.state_name) like lower(:stateName) else true end "
			+ "and case when :countryName != '' then lower(cm2.country_name) like lower(:countryName) else true end "
			+ "and cm.active is true order by cm.city_name", nativeQuery = true)
	List<CityMasterListResponseInterface> getCitieByFilter(String countryName, String stateName);

	@Query(value = "select cm.city_master_id as cityMasterId, cm.city_name as cityName, sm.state_master_id as stateMasterId, "
			+ "sm.state_name as stateName, cm2.country_master_id as countryMasterId, cm2.country_name as countryName "
			+ "from {h-schema}city_master cm left join {h-schema}state_master sm on cm.state_master_id = sm.state_master_id "
			+ "left join {h-schema}country_master cm2 on cm.city_master_id = cm2.country_master_id "
			+ "where cm.city_master_id = :cityMasterId and cm.active is true limit 1", nativeQuery = true)
	CityMasterInterface getCityDetailsByCityMasterId(Long cityMasterId);

	@Query(value = "select cm.* from {h-schema}city_master cm "
			+ "left join {h-schema}state_master sm on cm.state_master_id = sm.state_master_id "
			+ "left join {h-schema}country_master cm2 on cm.country_master_id = cm2.country_master_id "
			+ "where lower(cm.city_name) = lower(:cityName) and lower(sm.state_name) = lower(:stateName) "
			+ "and lower(cm2.country_name) = lower(:countryName) and cm.active is true ", nativeQuery = true)
	List<CityMaster> getByCityNameAndCountryNameAndStateName(String cityName, String countryName, String stateName);

	@Query(value = "select cm.city_name from {h-schema}city_master cm "
			+ "where lower(cm.city_name) = lower(:cityName) and cm.active is true order by cm.city_name", nativeQuery = true)
	List<String> getByCityNameList(String cityName);
	
	@Query(value = "select cm.city_name from {h-schema}city_master cm "
			+ "left join {h-schema}state_master sm on cm.state_master_id = sm.state_master_id "
			+ "left join {h-schema}country_master cm2 on cm.country_master_id = cm2.country_master_id "
			+ "where lower(cm.city_name) = lower(:cityName) and lower(sm.state_name) = lower(:stateName) and cm.active is true and sm.active is true order by cm.city_name", nativeQuery = true)
	List<String> getByCityNameAndStateNameList(String cityName,String stateName);
	
	@Query(value = "select cm.city_name from {h-schema}city_master cm "
			+ "left join {h-schema}state_master sm on cm.state_master_id = sm.state_master_id "
			+ "left join {h-schema}country_master cm2 on cm.country_master_id = cm2.country_master_id "
			+ "where lower(cm.city_name) = lower(:cityName) and lower(sm.state_name) = lower(:stateName) "
			+ "and lower(cm2.country_name) = lower(:countryName) "
			+ "and cm.active is true and sm.active is true and cm2.active is true order by cm.city_name", nativeQuery = true)
	List<String> getByCityNameAndStateNameAndCountryNameList(String cityName,String stateName,String countryName);
}
