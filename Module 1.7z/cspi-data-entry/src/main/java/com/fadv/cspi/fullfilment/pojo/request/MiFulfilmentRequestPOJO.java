package com.fadv.cspi.fullfilment.pojo.request;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;

import com.fasterxml.jackson.databind.node.ObjectNode;

import lombok.Data;

@Data
public class MiFulfilmentRequestPOJO {

	@Positive
	private long caseDetailsId;
	
	@Positive
	private String checkId;

	@NotNull
	private ObjectNode ruleOutput;

	@NotNull
	private boolean fulfilled;

	private String status;

	private String remarks;

}
