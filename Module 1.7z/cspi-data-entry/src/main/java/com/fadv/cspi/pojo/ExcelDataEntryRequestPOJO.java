package com.fadv.cspi.pojo;

import com.fasterxml.jackson.databind.node.ArrayNode;

import lombok.Data;

@Data
public class ExcelDataEntryRequestPOJO {

	private String caseNo;
	private ArrayNode documents;
}
