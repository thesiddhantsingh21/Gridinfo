package com.fadv.cspi.entities.master;

import lombok.Data;

@Data
public class CaseReference {
	private String crnNo;
	private String sbuId;
	private String caseNo;
	private String caseType;
	private String caseUUID;
	private String clientId;
	private String packageId;
	private String crnCreatedDate;
	private String checkId;
	private String ngStatus;
	private String ngStatusDescription;
	private String sbuName;
	private String productName;
	private String componentName;
	private String packageName;
	private Long miFulfilmentRequestId;

}