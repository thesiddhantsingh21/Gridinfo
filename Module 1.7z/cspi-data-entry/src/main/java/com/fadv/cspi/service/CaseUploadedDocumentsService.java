package com.fadv.cspi.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.fadv.cspi.entities.transaction.CaseDetails;
import com.fadv.cspi.entities.transaction.CaseUploadedDocuments;
import com.fadv.cspi.exception.ServiceException;
import com.fadv.cspi.pojo.ConvertedDocumentsResponsePOJO;
import com.fadv.cspi.pojo.request.SharedPathFilesUploadReqPOJO;
import com.fadv.cspi.pojo.response.CaseUploadedDocumentsResponsePOJO;
import com.fadv.cspi.pojo.response.CombinedFileResposnePOJO;
import com.fadv.cspi.userdetail.pojo.UserDetailPOJO;
import com.fasterxml.jackson.core.JsonProcessingException;

@Service
public interface CaseUploadedDocumentsService {

	List<CaseUploadedDocuments> findByCaseDetailsId(Long caseId) throws ServiceException;

	List<ConvertedDocumentsResponsePOJO> getCaseUploadedDocumentsByCaseDetailsId(Long caseDetailsId)
			throws ServiceException;

	CaseUploadedDocuments findByCaseUploadedDocumentsId(long caseUploadedDocumentsId) throws ServiceException;

	String deleteUploadedDocument(long caseUploadedDocumentsId, Long fulfillmentId, UserDetailPOJO userDetailPOJO,
			String tokenId) throws ServiceException;

	CaseUploadedDocumentsResponsePOJO uploadAndSaveMultipartFile(List<MultipartFile[]> multipartFiles,
			long caseDetailsId, String uploadType, Long fulfillmentId, UserDetailPOJO userDetailPOJO, String tokenId)
			throws ServiceException, JsonProcessingException;

	CaseUploadedDocuments saveNewRecord(CaseUploadedDocuments caseUploadedDocuments);

	List<CaseUploadedDocuments> findByCaseDetails(CaseDetails caseDetails);

	List<CaseUploadedDocuments> findByCaseDetailsAndUploadType(CaseDetails caseDetails, String uploadType);
	
	List<CaseUploadedDocuments> findByCaseDetailsAndUploadTypeAndCaseOrigin(CaseDetails caseDetails, String uploadType, String caseOrigin);

	CombinedFileResposnePOJO convertAndSaveSharedPathFiles(SharedPathFilesUploadReqPOJO sharedPathFilesUploadReqPOJO,
			UserDetailPOJO userDetailPOJO, String tokenId) throws ServiceException, JsonProcessingException;

}
