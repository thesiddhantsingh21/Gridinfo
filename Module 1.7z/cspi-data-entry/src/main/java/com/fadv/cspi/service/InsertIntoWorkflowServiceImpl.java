package com.fadv.cspi.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.fadv.cspi.entities.transaction.CaseAssociatedDocuments;
import com.fadv.cspi.entities.transaction.CaseClientDetails;
import com.fadv.cspi.entities.transaction.CaseDetails;
import com.fadv.cspi.entities.transaction.CaseUploadedDocuments;
import com.fadv.cspi.repository.transaction.CaseAssociatedDocumentsRepository;
import com.fadv.cspi.repository.transaction.CaseClientDetailsRepository;
import com.fadv.cspi.repository.transaction.CaseUploadedDocumentsRepository;
import com.fadv.cspi.workflow.pojo.ActivityWorkerTransactionPOJO;
import com.fadv.cspi.workflow.pojo.TaskListPOJO;
import com.fadv.cspi.workflow.pojo.WorkflowDetailsTransactionPOJO;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

@Service
public class InsertIntoWorkflowServiceImpl implements InsertIntoWorkflowService {

	private ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES,
			false);
	private static final Logger logger = LoggerFactory.getLogger(InsertIntoWorkflowServiceImpl.class);

	@Autowired
	private CaseDetailsService caseDetailsService;

	@Autowired
	private CaseClientDetailsRepository caseClientDetailsRepository;

	@Autowired
	private CaseAssociatedDocumentsRepository caseAssociatedDocumentsRepository;

	@Autowired
	private CaseUploadedDocumentsRepository caseUploadedDocumentsRepository;

	@Autowired
	ApiService apiService;

	@Value("${workflow.activity.worker.transaction.url}")
	private String workflowActivityWorkerURL;

	@Value("${workflow.taskList.url}")
	private String workflowTaskListURL;

	@Value("${workflow.workflow.details.transaction.url}")
	private String workflowWorkflowDetailsTransactionURL;

	@Value("${workflow.activity.worker.url}")
	private String activityWorkerURL;

	@Value("${activity.worker.name.doc}")
	private String activityWorkerName;

	@Value("${activity.worker.name2}")
	private String activityWorkerName2;

	@Value("${taskList.name.doc}")
	private String taskListName;

	@Value("${taskList.name2}")
	private String taskListName2;

	@Value("${activity.worker.description.doc}")
	private String activityWorkerDescription;

	@Value("${activity.worker.description2}")
	private String activityWorkerDescription2;

	@Override
	public Boolean insertIntoWorkflow(CaseDetails caseDetails) {

		List<CaseClientDetails> caseClientDetailsList = caseClientDetailsRepository.findByCaseDetails(caseDetails);
		List<CaseAssociatedDocuments> caseAssocaitedDocumentsList = caseAssociatedDocumentsRepository
				.findByCaseDetails(caseDetails);
		List<CaseAssociatedDocuments> finalCaseAssociatedDocuments = checkDocumentForSpCases(caseClientDetailsList,
				caseAssocaitedDocumentsList, caseDetails);
		logger.info("CaseAssociatedDocs after Checking For SP Cases:{}", finalCaseAssociatedDocuments);
		if (finalCaseAssociatedDocuments.isEmpty()) {
			logger.info("Inserting For DocValidation");
			Boolean flag = insertForDocValidation(caseClientDetailsList, caseDetails);
			logger.info("Inserted For DocValidation:{}", flag);
			return flag;
		}
		logger.info("Inserting For DocMerge");
		Boolean flag = insertForDocMerge(caseClientDetailsList, caseDetails, caseAssocaitedDocumentsList,
				finalCaseAssociatedDocuments);
		logger.info("Inserted For DocMerge:{}", flag);
		return flag;
	}

	private Boolean insertForDocMerge(List<CaseClientDetails> caseClientDetailsList, CaseDetails caseDetails,
			List<CaseAssociatedDocuments> caseAssocaitedDocumentsList,
			List<CaseAssociatedDocuments> finalCaseAssociatedDocuments) {
		String activityWorkerid = "";
		ObjectNode activityWorkerRequestJson = mapper.createObjectNode();
		activityWorkerRequestJson.put("activityWorkerName", activityWorkerName);
		String str = activityWorkerRequestJson.toString();
		try {
			String responseStr = apiService.sendDataToPost(activityWorkerURL, str);
			JsonNode responseJson = mapper.readTree(responseStr);
			JsonNode responseArr = responseJson.get(0);
			activityWorkerid = responseArr.get("activityWorkerId").asText();
		} catch (Exception e1) {
			e1.printStackTrace();
			logger.info("Exception:{}", e1.getMessage());
			return false;
		}
		if (!caseClientDetailsList.isEmpty() && !caseAssocaitedDocumentsList.isEmpty()) {
			ArrayNode requestJson = createBotRequestJson(finalCaseAssociatedDocuments, caseClientDetailsList,
					caseDetails);
			ObjectNode requestNode = (ObjectNode) requestJson.get(0);
			ObjectNode metaData = mapper.createObjectNode();
			String taskListId = insertIntoTaskList(activityWorkerid, requestNode, activityWorkerDescription,
					taskListName);
			metaData = CreateMetaData(requestNode, caseDetails, caseClientDetailsList);
			if (taskListId.equalsIgnoreCase("") || taskListId == null || taskListId.equalsIgnoreCase("0")) {
				return false;
			}
			String workflowDetailsTransactionId = insertIntoWorkflowDetailsTransaction(activityWorkerid, requestNode,
					metaData, taskListId);
			if (workflowDetailsTransactionId.equalsIgnoreCase("") || workflowDetailsTransactionId.equalsIgnoreCase("0")
					|| workflowDetailsTransactionId == null) {
				return false;
			}
			String activityId = insertIntoActivityWorkerTransaction(activityWorkerid, workflowDetailsTransactionId,
					taskListId);
			if (activityId.equalsIgnoreCase("") || activityId.equalsIgnoreCase("0") || activityId == null) {
				return false;
			}
			return true;
		}
		logger.info("CaseClientDetails or CaseAssociatedDocuments is empty");
		return false;
	}

	private Boolean insertForDocValidation(List<CaseClientDetails> caseClientDetailsList, CaseDetails caseDetails) {
		String responseStr = "";
		String activityWorkerid = "";
		ObjectNode activityWorkerRequestJson = mapper.createObjectNode();
		activityWorkerRequestJson.put("activityWorkerName", activityWorkerName2);
		String str = activityWorkerRequestJson.toString();

		try {
			responseStr = apiService.sendDataToPost(activityWorkerURL, str);
			JsonNode responseJson = mapper.readTree(responseStr);
			JsonNode responseArr = responseJson.get(0);
			activityWorkerid = responseArr.get("activityWorkerId").asText();
		} catch (Exception e1) {
			e1.printStackTrace();
			logger.info("Exception:{}", e1.getMessage());
			return false;
		}
		ObjectNode metaData = mapper.createObjectNode();
		ObjectNode taskListRequestJson = createTaskListRequestDocVal(caseDetails);
		String taskListId = insertIntoTaskList(activityWorkerid, taskListRequestJson, activityWorkerDescription2,
				taskListName2);
		metaData = CreateMetaData(mapper.createObjectNode(), caseDetails, caseClientDetailsList);
		if (taskListId == null || taskListId.equalsIgnoreCase("") || taskListId.equalsIgnoreCase("0")) {
			return false;
		}
		String workflowDetailsTransactionId = insertIntoWorkflowDetailsTransaction(activityWorkerid,
				taskListRequestJson, metaData, taskListId);
		if (workflowDetailsTransactionId == null || workflowDetailsTransactionId.equalsIgnoreCase("")
				|| workflowDetailsTransactionId.equalsIgnoreCase("0")) {
			return false;
		}
		String activityId = insertIntoActivityWorkerTransaction(activityWorkerid, workflowDetailsTransactionId,
				taskListId);
		if (activityId == null || activityId.equalsIgnoreCase("") || activityId.equalsIgnoreCase("0")) {
			return false;
		}
		return true;
	}

	private List<CaseAssociatedDocuments> checkDocumentForSpCases(List<CaseClientDetails> caseClientDetailsList,
			List<CaseAssociatedDocuments> caseAssocaitedDocumentsList, CaseDetails caseDetails) {
		List<CaseAssociatedDocuments> finalCaseAssociatedDocuments = new ArrayList<CaseAssociatedDocuments>();
		if (caseDetails.getCaseType().equalsIgnoreCase("CDE")
				&& caseDetails.getCaseOrigin().equalsIgnoreCase("CSPI_SP")) {

			for (CaseAssociatedDocuments caseAssociatedDocuments : caseAssocaitedDocumentsList) {
				Long caseUploadedDocumentsId = caseAssociatedDocuments.getCaseUploadedDocuments()
						.getCaseUploadedDocumentsId();
				CaseUploadedDocuments caseUploadedDocuments = caseUploadedDocumentsRepository
						.findByCaseUploadedDocumentsIdAndActive(caseUploadedDocumentsId, true);
				if (caseUploadedDocuments != null) {
					if (caseUploadedDocuments.getCaseOrigin() == null
							|| caseUploadedDocuments.getCaseOrigin().equalsIgnoreCase("")) {
						finalCaseAssociatedDocuments.add(caseAssociatedDocuments);
					}
				}
			}
			logger.info("CaseAssociatedDocuments is Empty:{}", caseAssocaitedDocumentsList);
		} else {
			finalCaseAssociatedDocuments = caseAssocaitedDocumentsList;
		}
		return finalCaseAssociatedDocuments;
	}

	private ArrayNode createBotRequestJson(List<CaseAssociatedDocuments> finalCaseAssociatedDocuments,
			List<CaseClientDetails> caseClientDetailsList, CaseDetails caseDetails) {
		CaseClientDetails caseClientDetails = caseClientDetailsList.get(0);
		ObjectNode metaDataJson = mapper.createObjectNode();
		metaDataJson.put("processName", "CSPi NG India");
		metaDataJson.put("processId", "11c3a5af-b0dd-4bc8-83bb-9b720f959683");
		metaDataJson.put("stageId", "72dd8fc9-6eda-46cc-80d6-d032ed37393e");
		metaDataJson.put("task", "CreateCSPICaseUpload");
		metaDataJson.put("taskGroupId", "15b3223b-96f1-4376-9b55-721dee7afc16");
		metaDataJson.put("requestDate", new Date().toString());
		metaDataJson.put("requestType", "query");
		metaDataJson.put("requestId", "8e7ffe3e-ebb8-480d-9609-b0d815e92976");
		metaDataJson.put("version", "2.1.0");
		metaDataJson.put("attempt", "1");
		metaDataJson.put("multiTask", "no");
		metaDataJson.put("requestAuthToken",
				"eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJ7XCJtdGVpZFwiOlwiOGI3NGQ0NGMtMDU5MC00MDdjLThiZDgtNjFkM2FkN2Y2ZjM5XCIsXCJ1c2VySWRcIjpcImIxMTA1NDhkLWFmNzgtNGUyNC04ZDZiLWNlN2IyZTE4YWI2OFwiLFwiYXBwU2Vzc2lvbklkXCI6XCIyMjk3ZTJiYS1hM2UwLTQyZmItOTg0Yy0zYWU2ODE3ZGZmMDdcIixcInByb2plY3RJZFwiOlwicHJvamVjdElkXCIsXCJwcm9qZWN0VmVyc2lvbklkXCI6XCJwcm9qZWN0VmVyc2lvbklkXCIsXCJVU0VSX05BTUVcIjpcInN1cGVyIGFkbWluXCIsXCJBRERUSU9OQUxfSU5GT1wiOlwiXCIsXCJleHRlcm5hbFRva2VuXCI6XCJudWxsXCJ9IiwiZXhwIjozMjcxODM4NjMyfQ._8byFadylKhwXKJ1epUHEFJ1rR-FqXtC_KqHFYTj-tOOJWAC_Ayp11Fzy6v0YrtPQiQU8S7lLcZjvEUDmSUUHQ");
		metaDataJson.put("txLabel", "1637692024656");
		metaDataJson.put("stageName", "Doc Stage");
		ObjectNode caseNode = mapper.createObjectNode();

		try {
			ObjectNode caseReferenceNode = mapper.createObjectNode();
			caseReferenceNode.put("crnNo", caseDetails.getCrn());
			caseReferenceNode.put("caseNo", caseDetails.getCaseNo());
			caseReferenceNode.put("caseType", caseDetails.getCaseType());
			caseReferenceNode.put("caseUUID", caseDetails.getCaseDetailsId());
			caseReferenceNode.put("clientId", caseClientDetails.getClientMaster().getClientName());
			caseReferenceNode.put("crnCreatedDate", mapper.writeValueAsString(caseDetails.getCrnCreationDate()));
			caseReferenceNode.put("sbuId", caseClientDetails.getSbuMaster().getSbuName());
			caseReferenceNode.put("packageId", caseClientDetails.getPackageMaster().getPackageName());
			caseReferenceNode.put("checkId", "");
			caseReferenceNode.put("scrnCreatedDate", "");

			ObjectNode fileUploadNode = mapper.createObjectNode();

			fileUploadNode.set("caseAssociatedDocuments",
					mapper.readTree(mapper.writeValueAsString(finalCaseAssociatedDocuments)));

			caseNode.set("fileUpload", fileUploadNode);
			caseNode.set("caseReference", caseReferenceNode);
		} catch (Exception e) {
			logger.info("Json Parsing Exception:{}", e.getMessage());
			e.printStackTrace();
		}
		ObjectNode taskSpecsNode = mapper.createObjectNode();
		taskSpecsNode.set("case", caseNode);

		ObjectNode dataJson = mapper.createObjectNode();
		dataJson.put("taskBy", "BO");
		dataJson.put("taskId", "15b3223b-96f1-4376-9b55-721dee7afc16");
		dataJson.put("taskName", "CreateCSPICaseUpload");
		dataJson.put("taskSerialNo", "1");
		dataJson.set("taskSpecs", taskSpecsNode);

		ArrayNode dataArrayNode = mapper.createArrayNode();
		dataArrayNode.add(dataJson);

		ObjectNode requestJson = mapper.createObjectNode();
		requestJson.set("metadata", metaDataJson);
		requestJson.set("data", dataArrayNode);

		ObjectNode finalJson = mapper.createObjectNode();
		finalJson.set("requestJson", requestJson);
		finalJson.put("requestProcessorId", "");

		ArrayNode finalArrayJson = mapper.createArrayNode();
		finalArrayJson.add(finalJson);

		return finalArrayJson;

	}

	private String insertIntoTaskList(String activityTypeId, ObjectNode requestNode, String activityWorkerDescription,
			String taskListname) {

		TaskListPOJO taskList = new TaskListPOJO();
		taskList.setActivityTypeId(Long.parseLong(activityTypeId));
		taskList.setRequestJson(requestNode);
		taskList.setStatus("new");
		taskList.setTaskListDescription(activityWorkerDescription);
		taskList.setTaskListName(taskListname);
		JsonNode node = mapper.createObjectNode();
		try {
			String taskListResponse = apiService.sendDataToPost(workflowTaskListURL,
					mapper.writeValueAsString(taskList));
			node = mapper.readTree(taskListResponse);
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("Exception Occurred in taskList:{}", e.getMessage());
		}
		String taskListId = "";
		if (node != null) {
			taskListId = node.get("taskListId").asText();
		}
		logger.info("TaskListId:{}", taskListId);

		return taskListId;
	}

	private String insertIntoWorkflowDetailsTransaction(String activityTypeId, ObjectNode requestNode,
			ObjectNode metaData, String taskListId) {

		WorkflowDetailsTransactionPOJO workflowDetailsTransaction = new WorkflowDetailsTransactionPOJO();
		workflowDetailsTransaction.setTaskListId(Long.parseLong(taskListId));
		workflowDetailsTransaction.setActivityTypeId(Long.parseLong(activityTypeId));
		workflowDetailsTransaction.setRequestJson(requestNode);
		workflowDetailsTransaction.setRequestTimestamp(new Date());
		workflowDetailsTransaction.setMetaData(metaData);
		workflowDetailsTransaction.setStatus("ready");
		workflowDetailsTransaction.setResponseJson(mapper.createObjectNode());
		JsonNode workflowDetailsTransactionPOJOResp = mapper.createObjectNode();

		try {
			String workflowDetailsTransactionStr = mapper.writeValueAsString(workflowDetailsTransaction);
			String workflowDetailsTransactionResponse = apiService.sendDataToPost(workflowWorkflowDetailsTransactionURL,
					workflowDetailsTransactionStr);
			workflowDetailsTransactionPOJOResp = mapper.readTree(workflowDetailsTransactionResponse);
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("Exception Occurred in WorkflowDetailsTransaction :{}", e.getMessage());
		}
		String workflowTransactionId = "";
		if (workflowDetailsTransactionPOJOResp != null) {
			workflowTransactionId = workflowDetailsTransactionPOJOResp.get("wdTransactionId").asText();
		}
		logger.info("workflowDetailsTransactionId:{}", workflowTransactionId);

		return workflowTransactionId;
	}

	private String insertIntoActivityWorkerTransaction(String activityTypeId, String workflowDetailsTransactionId,
			String taskListId) {
		String activityWorkerReq = "";
		ActivityWorkerTransactionPOJO activityWorkerTransaction = new ActivityWorkerTransactionPOJO();
		activityWorkerTransaction.setKey(workflowDetailsTransactionId + "#" + taskListId + "#" + activityTypeId);

		activityWorkerTransaction.setActivityWorkerId(Long.parseLong(activityTypeId));
		activityWorkerTransaction.setStatus("new");
		JsonNode node = mapper.createObjectNode();

		try {
			activityWorkerReq = mapper.writeValueAsString(activityWorkerTransaction);
			String activityWorkerTransactionResponse = apiService.sendDataToPost(workflowActivityWorkerURL,
					activityWorkerReq);
			node = mapper.readTree(activityWorkerTransactionResponse);
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("Exception Occurred in activityWorkerTransaction:{}", e.getMessage());
		}
		String activityWorkerTransactionId = "";
		if (node != null) {
			activityWorkerTransactionId = node.get("activityWorkerTransactionId").asText();
		}
		logger.info("ActivityWorkerTransactionId:{}", activityWorkerTransaction);
		return activityWorkerTransactionId;
	}

	private ObjectNode CreateMetaData(ObjectNode requestNode, CaseDetails caseDetails,
			List<CaseClientDetails> caseClientDetailsList) {

		ObjectNode metaData = mapper.createObjectNode();
		CaseClientDetails caseClientDetails = caseClientDetailsList.get(0);
		metaData.put("status", "ready");
		metaData.put("caseNo", caseDetails.getCaseNo());
		metaData.put("caseUUID", caseDetails.getCaseDetailsId());
		metaData.put("checkId", "");
		metaData.put("crnNo", caseDetails.getCrn());
		metaData.put("requestId", caseDetails.getRequestId() == null ? "" : caseDetails.getRequestId());
		metaData.put("caseSource", caseDetails.getCaseOrigin() == null ? "" : caseDetails.getCaseOrigin());
		metaData.put("client", caseClientDetails.getClientMaster().getClientName());
		metaData.put("clientRefrence",
				caseDetails.getClientReference() == null ? "" : caseDetails.getClientReference());
		logger.info("MetaData:{}", metaData);
		return metaData;
	}

	private ObjectNode createTaskListRequestDocVal(CaseDetails caseDetails) {
		ObjectNode taskListRequestJson = mapper.createObjectNode();
		taskListRequestJson.put("crn", caseDetails.getCaseNo());
		taskListRequestJson.put("caseNo", caseDetails.getCrn());
		taskListRequestJson.put("sucaseReferenceess", true);
		taskListRequestJson.put("sucaseReferenceessMsg", "Doc Validation");
		ObjectNode response = mapper.createObjectNode();
		response.set("engineInput", mapper.createObjectNode());
		response.set("engineOutput", mapper.createObjectNode());
		taskListRequestJson.set("response", response);

		return taskListRequestJson;
	}
}
