package com.fadv.cspi.service;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.fadv.cspi.entities.transaction.CaseClientDetails;
import com.fadv.cspi.entities.transaction.CaseDetails;
import com.fadv.cspi.exception.ServiceException;
import com.fadv.cspi.pojo.AutoDataEntryDataPOJO;
import com.fadv.cspi.pojo.AutoDataEntryPOJO;
import com.fadv.cspi.repository.transaction.CaseClientDetailsRepository;
import com.fadv.cspi.repository.transaction.CaseDetailsRepository;
import com.fadv.cspi.utility.ConversionUtility;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;

@Service
public class ExcelDataEntryServiceImpl implements ExcelDataEntryService {

	@Autowired
	private CaseDetailsRepository caseDetailsRepository;

	@Autowired
	private CaseClientDetailsRepository caseClientDetailsRepository;

	@Value("${excel.file.path}")
	private String excelFilePath;

	ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
	private static final Logger logger = LoggerFactory.getLogger(ExcelDataEntryServiceImpl.class);

	@Override
	public String createCaseDetailsExcel(AutoDataEntryPOJO autoDataEntryPOJO) throws ServiceException, IOException {
		logger.info("Request:{}", autoDataEntryPOJO);

		String caseNo = autoDataEntryPOJO.getCaseNo();
		ArrayNode requestArray = extractInputFromPOJO(autoDataEntryPOJO.getDocuments());

		String clientName = fetchClientName(caseNo);

		XSSFWorkbook workbook = new XSSFWorkbook();
		XSSFSheet sheet = workbook.createSheet("Data Entry");
		CellStyle headerCellStyle = setFontStyleOfHeader(workbook);
		CellStyle documentsHeader = setFontStyleForDocumentName(workbook);

		CellStyle cs = workbook.createCellStyle();
		cs.setWrapText(true); // Wrapping text

		int count = 0;
		int row = 0;
		int recordsIncr = 0;
		try {
			for (JsonNode json : requestArray) {
				ArrayNode records = json.has("records") ? (ArrayNode) json.get("records") : mapper.createArrayNode();
				String documentName = json.get("documentName").asText();
				recordsIncr = 0;
				for (JsonNode node : records) {
					count = 0;
					Iterator<Entry<String, JsonNode>> fields = node.fields();

					Row headerRow = createRowAsGivenRowValue(row, sheet);
					row = row + 1;
					Row valueRow = createRowAsGivenRowValue(row, sheet);

					Cell cell = headerRow.createCell(count);
					if (recordsIncr == 0) {
						cell.setCellValue(documentName);
						cell.setCellStyle(documentsHeader);
					}

					while (fields.hasNext()) {
						Entry<String, JsonNode> field = fields.next();

						sheet.autoSizeColumn(count);
						cell = headerRow.createCell(count + 1);
						Cell cell2 = valueRow.createCell(count + 1);
						cell.setCellValue(field.getKey());
						String value = setStyleAndRemoveSpecialCharacterInValue(headerCellStyle, field, cell);
						cell2.setCellValue(value);
						count++;
						cell2.setCellStyle(cs);
					}
					row++;
					recordsIncr++;
				}
				sheet.autoSizeColumn(count);
			}
		} catch (Exception e) {
			e.printStackTrace();
			workbook.close();
			throw new ServiceException(e.getMessage());
		}
		try {
			if (clientName == null || clientName.isEmpty()) {
				throw new ServiceException("Client Name is Empty");
			}
			String path = filePathDir(excelFilePath, clientName);
			String filePath = path + "//" + clientName + caseNo + ".xlsx";
			FileOutputStream outputStream = new FileOutputStream(filePath);
			workbook.write(outputStream);
			workbook.close();
			outputStream.close();
		} catch (Exception e) {
			e.printStackTrace();
			throw new ServiceException(e.getMessage());
		}
		return "completed";
	}

	private ArrayNode extractInputFromPOJO(List<AutoDataEntryDataPOJO> requestList) {
		ArrayNode requestArray = mapper.createArrayNode();
		for (AutoDataEntryDataPOJO autoDataEntryDataPOJO : requestList) {
			JsonNode jsonArr = mapper.convertValue(autoDataEntryDataPOJO, JsonNode.class);
			requestArray.add(jsonArr);
		}
		return requestArray;
	}

	private String filePathDir(String excelFilePath2, String clientName) {
		Date date = new Date();// the date instance
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		String year = calendar.get(Calendar.YEAR) + "";
		String month = calendar.get(Calendar.MONTH) + 1 + "";
		String day = calendar.get(Calendar.DAY_OF_MONTH) + "";

		String path = excelFilePath + "//" + clientName + "//" + year + "//" + month + "//" + day;
		File files = new File(path);
		if (!files.exists()) {
			if (files.mkdirs()) {
				System.out.println("Multiple directories are created successfully");
			} else {
				System.out.println("Failed to create multiple directories!!!");
			}
		}
		return path;
	}

	private String fetchClientName(String caseNo) throws ServiceException {
		String clientName = "";
		List<CaseDetails> caseDetailList = caseDetailsRepository.findByCaseNo(caseNo);
		if (caseDetailList.isEmpty()) {
			throw new ServiceException("Data not found in CaseDetails");
		}
		CaseDetails caseDetails = caseDetailList.get(0);
		List<CaseClientDetails> caseClientDetailsList = caseClientDetailsRepository.findByCaseDetails(caseDetails);
		if (caseClientDetailsList.isEmpty()) {
			throw new ServiceException("Data not found in CaseClientDetails");
		}
		clientName = caseClientDetailsList.get(0).getClientMaster().getClientName();

		return clientName;
	}

	private Row createRowAsGivenRowValue(int row, XSSFSheet sheet) {
		return sheet.createRow(row);
	}

	private String setStyleAndRemoveSpecialCharacterInValue(CellStyle headerCellStyle, Entry<String, JsonNode> field2,
			Cell cell1) throws JsonProcessingException {

		cell1.setCellStyle(headerCellStyle);

		String value = mapper.writeValueAsString(field2.getValue());
		value = ConversionUtility.removeCharacter(value);
		if (value.equalsIgnoreCase("null") || value.isEmpty()) {
			return "";
		}
		return value;
	}

	private CellStyle setFontStyleOfHeader(XSSFWorkbook workbook) {
		Font headerFont = workbook.createFont();
		headerFont.setBold(true);
		headerFont.setFontHeightInPoints((short) 10);
		headerFont.setColor(IndexedColors.BLACK1.getIndex());

		CellStyle headerCellSyle = workbook.createCellStyle();
		headerCellSyle.setFont(headerFont);
		return headerCellSyle;
	}

	private CellStyle setFontStyleForDocumentName(XSSFWorkbook workbook) {
		Font headerFont = workbook.createFont();
		headerFont.setBold(true);
		headerFont.setFontHeightInPoints((short) 10);
		headerFont.setColor(IndexedColors.BLUE_GREY.getIndex());

		CellStyle headerCellSyle = workbook.createCellStyle();
		headerCellSyle.setFont(headerFont);
		return headerCellSyle;
	}

}
