package com.fadv.cspi.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fadv.cspi.entities.master.CityMaster;
import com.fadv.cspi.exception.ServiceException;
import com.fadv.cspi.interfaces.CityMasterInterface;
import com.fadv.cspi.pojo.response.CityMasterResponsePOJO;
import com.fadv.cspi.repository.master.CityMasterRepository;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

@Service
public class CityMasterServiceImpl implements CityMasterService {

	private static final String ERROR_CODE_404 = "ERROR_CODE_404";

	@Autowired
	private CityMasterRepository cityMasterRepository;

	private ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES,
			false);

	@Override
	public CityMaster findByCityMasterId(Long cityMasterId) throws ServiceException {

		Optional<CityMaster> cityMasterOptional = cityMasterRepository.findById(cityMasterId);
		if (cityMasterOptional.isPresent()) {
			return cityMasterOptional.get();
		}
		throw new ServiceException("City Details not found for given city id", ERROR_CODE_404);
	}

	@Override
	public CityMasterResponsePOJO getCityDetailsByCityMasterId(Long cityMasterId) throws ServiceException {
		CityMasterInterface cityMasterInterface = cityMasterRepository.getCityDetailsByCityMasterId(cityMasterId);

		if (cityMasterInterface != null) {
			return mapper.convertValue(cityMasterInterface, CityMasterResponsePOJO.class);
		}

		throw new ServiceException("City Details not found for given city id", ERROR_CODE_404);

	}

	@Override
	public List<ObjectNode> getCityListByStateName(String stateName) {

		return mapper.convertValue(cityMasterRepository.getCitieByFilter("", stateName),
				new TypeReference<List<ObjectNode>>() {
				});
	}

	@Override
	public List<CityMaster> findByCityNameAndCountryNameAndStateName(String cityName, String countryName,
			String stateName) {
		return cityMasterRepository.getByCityNameAndCountryNameAndStateName(cityName, countryName, stateName);
	}
}
