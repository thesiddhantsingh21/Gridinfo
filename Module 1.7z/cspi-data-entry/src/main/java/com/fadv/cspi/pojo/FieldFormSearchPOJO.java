package com.fadv.cspi.pojo;

import java.util.List;

import javax.validation.constraints.Positive;

import com.fadv.cspi.pojo.response.DocumentFieldMasterResponsePOJO;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Data;

@Data
@JsonInclude(value = Include.NON_NULL)
public class FieldFormSearchPOJO {

	@Positive
	private long caseDetailsId;

	List<String> fields;
	
	private int formDataSize;

	private List<DocumentFieldMasterResponsePOJO> formData;
}
