package com.fadv.cspi.pojo.response;

import lombok.Data;

@Data
public class CityMasterResponsePOJO {

	private long cityMasterId;

	private String cityName;

	private long stateMasterId;

	private String stateName;

	private long countryMasterId;

	private String countryName;

	private String countryCode;
}
