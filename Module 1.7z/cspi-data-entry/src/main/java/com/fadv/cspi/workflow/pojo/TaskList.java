package com.fadv.cspi.workflow.pojo;

import java.util.Date;

import com.fasterxml.jackson.databind.JsonNode;

import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain=true)
public class TaskList {

	private long taskListId;
	
	private long activityTypeId;
	private String taskListName;
	private String taskListDescription;
	
	private JsonNode requestJson;
	private String status;
	private Date createDate;
	private Date updatedDate;
}
