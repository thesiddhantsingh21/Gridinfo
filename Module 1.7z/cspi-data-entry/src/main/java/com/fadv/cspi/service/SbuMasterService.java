package com.fadv.cspi.service;

import org.springframework.stereotype.Service;

import com.fadv.cspi.entities.master.SbuMaster;
import com.fadv.cspi.exception.ServiceException;

@Service
public interface SbuMasterService {

	SbuMaster findBySbuName(String sbuName) throws ServiceException;

}
