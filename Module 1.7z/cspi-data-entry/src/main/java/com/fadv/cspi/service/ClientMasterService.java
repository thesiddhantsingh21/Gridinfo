package com.fadv.cspi.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.fadv.cspi.entities.master.ClientMaster;
import com.fadv.cspi.exception.ServiceException;

@Service
public interface ClientMasterService {

	List<String> getAllDistinctClientNamesOrderByClientName();

	ClientMaster findByClientName(String clientName) throws ServiceException;

}
