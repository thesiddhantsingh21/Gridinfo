package com.fadv.cspi.repository.mapping;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.fadv.cspi.component.data.pojo.CliSbuPkgCompProdQstnInterface;
import com.fadv.cspi.entities.mapping.CliSbuPkgCompProdQstn;

public interface CliSbuPkgCompProdQstnRepository extends JpaRepository<CliSbuPkgCompProdQstn, Long> {
	@Query(value = "select qm.global_question_id as globalQuestionId, "
			+ "qm.global_question as questionName, qm.question_scope as questionScope, "
			+ "cspcpq.question_type as questionType, cm.component_name as componentName, "
			+ "pm.product_name as productName, cspcpq.form_label as formLabel, cspcpq.mandatory, "
			+ "cspcpq.mapped_field as mappedField " + "from cspi.cli_sbu_pkg_comp_prod_qstn cspcpq "
			+ "left join cspi.question_master qm on cspcpq.question_master_id = qm.question_master_id "
			+ "left join cspi.component_master cm on cspcpq.component_master_id = cm.component_master_id "
			+ "left join cspi.product_master pm on cspcpq.product_master_id = pm.product_master_id "
			+ "where cspcpq.active =:active and  cspcpq.client_master_id = :clientMasterId and cspcpq.sbu_master_id = :sbuMasterId "
			+ "and cspcpq.packag_master_id = :packageMasterId and cspcpq.component_master_id = :componentMasterId "
			+ "and cspcpq.product_master_id = :productMasterId "
			+ "and cspcpq.mapped_field in :recordNodeKeys", nativeQuery = true)
	List<CliSbuPkgCompProdQstnInterface> findByClientMasterAndSbuMasterAndPackageMasterAndMappedFieldsAndActive(
			Long clientMasterId, Long sbuMasterId, Long packageMasterId, Long componentMasterId, Long productMasterId,
			List<String> recordNodeKeys, boolean active);

}
