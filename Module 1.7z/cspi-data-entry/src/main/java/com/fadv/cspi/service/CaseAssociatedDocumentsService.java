package com.fadv.cspi.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.fadv.cspi.entities.transaction.CaseAssociatedDocuments;
import com.fadv.cspi.entities.transaction.CaseDetails;
import com.fadv.cspi.exception.ServiceException;
import com.fadv.cspi.pojo.request.CaseAssociatedDocumentsRequestPOJO;
import com.fadv.cspi.pojo.request.FecthAssociateDocsPOJO;
import com.fadv.cspi.pojo.response.CaseAssociatedDocumentsResponsePOJO;
import com.fadv.cspi.userdetail.pojo.UserDetailPOJO;
import com.fasterxml.jackson.core.JsonProcessingException;

@Service
public interface CaseAssociatedDocumentsService {

	List<String> getAkaNamesByCaseId(Long caseId) throws ServiceException;

	List<CaseAssociatedDocuments> getAssociatedDocumentsByCaseDetailsId(Long caseDetailsId) throws ServiceException;

	List<CaseAssociatedDocumentsResponsePOJO> getAssociatedDocumentDetailsByCaseDetailsId(Long caseDetailsId)
			throws ServiceException;

	List<CaseAssociatedDocumentsResponsePOJO> fetchSupportingSplitDocuments(
			FecthAssociateDocsPOJO fecthAssociateDocsPOJO) throws ServiceException;

	CaseAssociatedDocuments getCaseAssociateDocumentByCaseDetailsIdDocumentMasterIdAndRowId(long caseDetailsId,
			long documentMasterId, String rowId);

	List<CaseAssociatedDocumentsResponsePOJO> processSplitDocumentRequest(
			CaseAssociatedDocumentsRequestPOJO caseAssociatedDocumentsRequestPOJO, UserDetailPOJO userDetailPOJO,
			String tokenId) throws ServiceException, JsonProcessingException;

	CaseAssociatedDocuments getCaseAssociateDocumentByCaseDetailsIdAndDocumentMasterId(long caseDetailsId,
			long documentMasterId);

	List<CaseAssociatedDocuments> findByCaseDetails(CaseDetails caseDetails);

	CaseAssociatedDocuments saveNewRecord(CaseAssociatedDocuments caseAssociatedDocuments);

	List<CaseAssociatedDocumentsResponsePOJO> getAssociatedDocumentDetailsByCaseDetailsIdAndFulfillmentId(
			Long caseDetailsId, Long fulfillmentId) throws ServiceException;

	boolean deleteByCaseDetailsIdAndRowIdAndDocumentMasterId(long caseDetailsId, String rowId, long documentMasterId,
			UserDetailPOJO userDetailPOJO, String tokenId);

}
