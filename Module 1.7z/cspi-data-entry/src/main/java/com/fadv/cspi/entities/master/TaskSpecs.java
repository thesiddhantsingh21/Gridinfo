package com.fadv.cspi.entities.master;

import java.util.List;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;

import lombok.Data;

@Data
public class TaskSpecs {
	private CaseReference caseReference;
	private CheckVerification checkVerification;
	private List<QuestionnairePOJO> questionaire;
	private JsonNode fullfillment;
	private ArrayNode missingFields;
	private JsonNode documentUpload;
	private FileUpload fileUpload;

}