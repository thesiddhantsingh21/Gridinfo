package com.fadv.cspi.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fadv.cspi.entities.mapping.ComponentProduct;
import com.fadv.cspi.repository.mapping.ComponentProductRepository;

@Service
public class ComponentProductServiceImpl implements ComponentProductService {

	@Autowired
	private ComponentProductRepository componentProductRepository;

	@Override
	public List<ComponentProduct> getComponentProductsByComponentMasterList(List<Long> componentMasterIds) {
		return componentProductRepository.getByListOfComponentsId(componentMasterIds);

	}

}
