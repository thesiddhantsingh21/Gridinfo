package com.fadv.cspi.repository.master;

import java.util.Collection;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.fadv.cspi.entities.master.TransactionAuditLog;
import com.fadv.cspi.interfaces.TransactionAuditLogResponseInterface;

@Repository
public interface TransactionAuditLogRepository extends JpaRepository<TransactionAuditLog, Long> {

	Collection<TransactionAuditLog> findByTableName(String tableName);

	@Query(value = "select transaction_audit_log_id as transactionAuditLogId, table_name as tableName, updated_by as updatedBy, "
			+ "updated_by_user_id as updatedByUserId, operation_type as operationType, updated_date_time as updatedDateTime "
			+ "from {h-schema}transaction_audit_log where table_name = :tableName", nativeQuery = true)
	List<TransactionAuditLogResponseInterface> getAuditLogResponseInterface(String tableName);

	@Query(value = "select al.* from {h-schema}transaction_audit_log al "
			+ " where case when :tableName != '' then lower (al.table_name) like lower(:tableName) else true end and "
			+ " case when :updatedBy != '' then lower (al.updated_by) like lower(:updatedBy) else true end and "
			+ " case when :operationType !='' then lower (al.operation_type) like lower(:operationType) else true end  and "
			+ " case when (:fromDateStr != '' and :toDateStr != '') then (CAST(DATE(al.updated_date_time) AS VARCHAR) "
			+ " BETWEEN SYMMETRIC :fromDateStr AND :toDateStr) else true end  ", nativeQuery = true)
	List<TransactionAuditLog> fetchByTableNameAndOperationTypeAndUpdatedBy(String tableName, String updatedBy,
			String operationType, String fromDateStr, String toDateStr);

}