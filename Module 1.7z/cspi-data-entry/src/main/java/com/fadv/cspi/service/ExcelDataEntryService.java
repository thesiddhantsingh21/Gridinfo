package com.fadv.cspi.service;

import java.io.IOException;

import org.springframework.stereotype.Service;

import com.fadv.cspi.exception.ServiceException;
import com.fadv.cspi.pojo.AutoDataEntryPOJO;

@Service
public interface ExcelDataEntryService {

	String createCaseDetailsExcel(AutoDataEntryPOJO autoDataEntryPOJO) throws ServiceException, IOException;

}
