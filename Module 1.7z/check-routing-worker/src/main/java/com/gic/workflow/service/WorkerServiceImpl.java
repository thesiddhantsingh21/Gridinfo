package com.gic.workflow.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.gic.workflow.exception.ServiceException;
import com.gic.workflowlib.constants.ErrorType;
import com.gic.workflowlib.model.WorkflowDetailsTransaction;
import com.gic.workflowlib.utility.Utility;
import com.gic.workflowlib.worker.Worker;

@Service
public class WorkerServiceImpl implements WorkerService {

	ObjectMapper mapper = new ObjectMapper();
	private static final Logger logger = LoggerFactory.getLogger(WorkerServiceImpl.class);

	@Autowired
	ApiService apiService;

	@Value("${check.routing.url}")
	private String checkRoutingURL;

	@Value("${update.status.url}")
	String updateStatusUrl;

	@Override
	public boolean executeTask(Worker worker, long workflowTransactionId, long taskListId,
			Long activityWorkerTransactionId) throws ServiceException {
		String response = null;
		WorkflowDetailsTransaction workflowDetailsTransaction = worker.fetchMetaData(workflowTransactionId);
		JsonNode metaData = Utility.convertStringToJsonNode(workflowDetailsTransaction.getMetaData());
		String crnNo = metaData.get("crnNo") != null ? metaData.get("crnNo").asText() : "";

		ObjectNode responseStatusNode = mapper.createObjectNode();

		if (crnNo != null && !crnNo.equals("")) {

			if (!crnNo.equalsIgnoreCase("pending")) {
				String reqURL = checkRoutingURL.replace("{crNo}", crnNo);
				response = apiService.sendDataToGet(reqURL);
			}

			String errorCause = null;

			if (response != null && !response.equalsIgnoreCase("")) {

				try {
					JsonNode responseJson = mapper.readTree(response);
					((ObjectNode) responseJson).put("crn", crnNo);

					String status = "completed";
					boolean responseStatus = responseJson.get("success").asBoolean();

					if (!responseStatus) {
						status = "failed";
						errorCause = responseJson.get("successMsg").asText();
					}

					((ObjectNode) metaData).put("status", status);
					worker.updateTask(status, ErrorType.NONE, errorCause, errorCause, workflowTransactionId,
							activityWorkerTransactionId, responseJson.toString(), metaData.toString());

				} catch (Exception e) {
					e.printStackTrace();
					throw new ServiceException("Exception occured: ", e.getMessage());
				}
			} else {

				ObjectNode responseJson = mapper.createObjectNode();
				errorCause = "response is either null or empty";
				((ObjectNode) metaData).put("status", "failed");
				responseStatusNode.put("success", false);
				responseStatusNode.put("successMsg", errorCause);

				worker.updateTask("failed", ErrorType.API_ERROR, errorCause, errorCause, workflowTransactionId,
						activityWorkerTransactionId, responseJson.toString(), metaData.toString());
			}

		}
		ObjectNode updateStatus = mapper.createObjectNode();

		updateStatus.put("caseNo", metaData.get("caseNo").asText());
		updateStatus.put("crn", crnNo);
		updateStatus.put("caseFinalStatus", metaData.get("status").asText());

		try {
			String updateStatusResp = apiService.sendDataToPost(updateStatusUrl, updateStatus.toString());

			logger.info("Update Status Resp:{}", updateStatusResp);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return true;
	}

}
