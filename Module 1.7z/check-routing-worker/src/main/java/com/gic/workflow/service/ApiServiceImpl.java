package com.gic.workflow.service;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
public class ApiServiceImpl implements ApiService {

	private static final Logger logger = LoggerFactory.getLogger(ApiServiceImpl.class);

	public String sendDataToPost(String url1,String json){
		HttpURLConnection con = null;
		try {
			System.setProperty("http.keepAlive","false");
			URL url = new URL(url1);
			con = (HttpURLConnection) url.openConnection();
			con.setRequestMethod("POST");
			con.setRequestProperty("Content-Type", "application/json");
			con.setRequestProperty("Accept", "application/json");

			con.setDoOutput(true);
			OutputStream os = con.getOutputStream();
			os.write(json.toString().getBytes());
			os.flush();
			os.close();

			int responseCode = con.getResponseCode();
			logger.debug("POST Response Code: " + responseCode + " : " + con.getResponseMessage());

			StringBuffer response = new StringBuffer();
			if(responseCode == HttpURLConnection.HTTP_OK)
			{
			    BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
			    String inputLine;
			    while ((inputLine = in.readLine()) != null){
			        response.append(inputLine);
			    }
			    in.close();
			    // print result
			    logger.debug("POST Service Response:\n" + response.toString());
			    return response.toString();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			if(con!=null) {
				con.disconnect();
			}
		}
    	return "";
    }
    
    public String sendDataToGet(String url1) {
    	HttpURLConnection con = null;
		try {
			System.setProperty("http.keepAlive","false");
			URL url = new URL(url1);
			con = (HttpURLConnection) url.openConnection();
			con.setRequestMethod("GET");
			con.setRequestProperty("Content-Type", "application/json");
			con.setRequestProperty("Accept", "application/json");

			con.setDoOutput(true);

			int responseCode = con.getResponseCode();
			logger.debug("POST Response Code: " + responseCode + " : " + con.getResponseMessage());

			StringBuffer response = new StringBuffer();
			if(responseCode == HttpURLConnection.HTTP_OK)
			{
			    BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
			    String inputLine;
			    while ((inputLine = in.readLine()) != null){
			        response.append(inputLine);
			    }
			    in.close();
			    // print result
			    logger.debug("POST Service Response:\n" + response.toString());
			    return response.toString();
			}
		} catch (Exception e) {
			e.printStackTrace();
		} 
    	return "";
    }
}
