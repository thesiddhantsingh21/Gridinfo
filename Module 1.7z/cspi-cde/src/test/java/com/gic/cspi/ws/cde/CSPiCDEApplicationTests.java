package com.gic.cspi.ws.cde;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CSPiCDEApplicationTests {

	@Test
	void contextLoads() {
	}

}
