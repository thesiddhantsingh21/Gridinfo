package com.gic.cspi.ws.cde.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.gic.cspi.ws.cde.model.ClientSbuPackage;

public interface ClientSbuPackageRepository extends JpaRepository<ClientSbuPackage, Long> {

	@Query(value = "select cspm.* from {h-schema}client_sbu_package cspm "
			+ "left join {h-schema}client_master cm on cspm.client_master_id = cm.client_master_id "
			+ "left join {h-schema}sbu_master sm on cspm.sbu_master_id = sm.sbu_master_id "
			+ "left join {h-schema}package_master pm on cspm.package_master_id = pm.package_master_id "
			+ "where cspm.active = :active and cspm.fetch_from_cspi = :fetchFromCspi and "
			+ "lower(cm.client_name) = lower(:clientName) and lower(sm.sbu_name) = lower(:sbuName) "
			+ "and lower(pm.package_name) = lower(:packageName) ", nativeQuery = true)
	List<ClientSbuPackage> fetchByClientNameSbuNamePackageNameAndActive(String clientName, String sbuName,
			String packageName, boolean active, boolean fetchFromCspi);
}
