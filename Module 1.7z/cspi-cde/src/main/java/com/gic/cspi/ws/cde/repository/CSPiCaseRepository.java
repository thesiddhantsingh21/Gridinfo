package com.gic.cspi.ws.cde.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.gic.cspi.ws.cde.model.CspiCaseDetails;

@Repository
public interface CSPiCaseRepository extends JpaRepository<CspiCaseDetails, Long> {

	List<CspiCaseDetails> findByCaseRefNumber(String caseRefNumber);

	@Query(value = "select * from {h-schema}cspi_case_details  "
			+ "where CAST(DATE(cd.update_date) AS VARCHAR) BETWEEN SYMMETRIC :startDate AND :endDate  "
			+ "and case when :caseRefNumber != '' then case_ref_number = :caseRefNumber else true end  "
			+ "and case when :stagingStatus != '' then staging_status = :stagingStatus else true end ", nativeQuery = true)
	List<CspiCaseDetails> getByFilter(String startDate, String endDate, String caseRefNumber, String stagingStatus);

	@Modifying(clearAutomatically = true)
	@Query(value = "UPDATE {h-schema}cspi_case_details SET released_to_workflow = true "
			+ "WHERE id = (select ccd.id from {h-schema}cspi_case_details ccd "
			+ "where ccd.released_to_workflow = false order by ccd.update_date "
			+ "LIMIT 1 FOR UPDATE SKIP LOCKED) RETURNING *", nativeQuery = true)
	List<CspiCaseDetails> getAndUpdateNoRelasedData();
}
