package com.gic.cspi.ws.cde.service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gic.cspi.ws.cde.exception.ServiceException;
import com.gic.cspi.ws.cde.model.CspiDataEntry;
import com.gic.cspi.ws.cde.pojo.DataEntrySearchPOJO;
import com.gic.cspi.ws.cde.repository.CSPiDataEntryRepository;

@Service
public class CSPiDataEntryServiceImpl implements CSPiDataEntryService {

	private static final Logger logger = LoggerFactory.getLogger(CSPiDataEntryServiceImpl.class);

	@Autowired
	public CSPiDataEntryRepository cspiDataEntryRepository;

	@Override
	public List<CspiDataEntry> getDataEntry(DataEntrySearchPOJO dataEntrySearchPOJO) {

		Date startDate = dataEntrySearchPOJO.getStartDate() != null ? dataEntrySearchPOJO.getStartDate() : new Date();
		Date endDate = dataEntrySearchPOJO.getEndDate() != null ? dataEntrySearchPOJO.getEndDate() : new Date();

		String crnNo = dataEntrySearchPOJO.getCrnNo() != null ? dataEntrySearchPOJO.getCrnNo() : "";
		String stagingStatus = dataEntrySearchPOJO.getStagingStatus() != null ? dataEntrySearchPOJO.getStagingStatus()
				: "";

		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
		String startDateStr = simpleDateFormat.format(startDate);
		String endDateStr = simpleDateFormat.format(endDate);

		return cspiDataEntryRepository.getByFilter(startDateStr, endDateStr, crnNo, stagingStatus);
	}

	@Override
	public CspiDataEntry saveCSPiDataEntry(CspiDataEntry cspiDataEntry) {
		List<CspiDataEntry> cspiOpt = cspiDataEntryRepository.findByCaseRefNumber(cspiDataEntry.getCaseRefNumber());
		if (CollectionUtils.isNotEmpty(cspiOpt)) {
			CspiDataEntry deSaved = cspiOpt.get(0);

			Boolean successStatus = deSaved.getSuccessStatus();
			if (successStatus == null) {
				successStatus = false;
			}

			cspiDataEntry.setReleasedToWorkflow(deSaved.getReleasedToWorkflow());
			cspiDataEntry.setId(deSaved.getId());
			cspiDataEntry.setStagingStatus("UPDATE");
			cspiDataEntry.setSuccessStatus(deSaved.getSuccessStatus());
			cspiDataEntry.setCspiNgStatus(deSaved.getCspiNgStatus());
			cspiDataEntry.setSuccessStatus(successStatus);
			cspiDataEntry.setCreatedDate(deSaved.getCreatedDate());
			cspiDataEntry.setRetryCount((deSaved.getRetryCount() == null ? 0 : deSaved.getRetryCount()));
			cspiDataEntry.setTransactionId(deSaved.getTransactionId() != null ? deSaved.getTransactionId() : "");
			cspiDataEntry.setFileConversionCount(
					deSaved.getFileConversionCount() != null ? deSaved.getFileConversionCount() : 0);
			if (deSaved.getCreatedDate() == null) {
				cspiDataEntry.setCreatedDate(deSaved.getUpdateDate());
			}
			cspiDataEntry.setUpdateDate(cspiDataEntry.getCreatedDate());
			logger.info("setting caseRefNumber {} to UPDATE", cspiDataEntry.getCaseRefNumber());
		}

		Boolean successStatus = cspiDataEntry.getReleasedToWorkflow();
		if (successStatus == null) {
			successStatus = false;
		}

		if (!successStatus) {
			return cspiDataEntryRepository.save(cspiDataEntry);
		} else {
			return cspiDataEntry;
		}
	}

	@Override
	public List<CspiDataEntry> getRelasedCspiDataEntry() throws ServiceException {
		List<CspiDataEntry> cspiDataEntries = cspiDataEntryRepository.getAndUpdateNoRelasedData();
		if (CollectionUtils.isNotEmpty(cspiDataEntries)) {
			return cspiDataEntries;
		}
		throw new ServiceException("No data found");
	}
}
