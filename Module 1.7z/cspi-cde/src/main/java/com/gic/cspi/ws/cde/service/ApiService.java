package com.gic.cspi.ws.cde.service;

import org.springframework.stereotype.Service;

@Service
public interface ApiService {

	String sendDataToPost(String requestUrl, String requestStr);

	String sendDataToGet(String requestUrl, String tokenId);

	String sendDataToPostAsync(String urlStr, String requestStr);

	String sendDataToGetAsync(String urlStr);

}
