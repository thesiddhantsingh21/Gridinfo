package com.gic.cspi.ws.cde.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.gic.cspi.ws.cde.exception.ServiceException;
import com.gic.cspi.ws.cde.model.CspiCaseDetails;
import com.gic.cspi.ws.cde.model.NgCaseAttempts;
import com.gic.cspi.ws.cde.pojo.CaseSearchPOJO;

@Service
public interface CSPiCaseService {

	List<NgCaseAttempts> getNGCaseAttempts(String crnStr);

	CspiCaseDetails getCspiCaseByCRN(String crnStr);

	CspiCaseDetails saveCSPiCase(CspiCaseDetails cspiCase);

	List<CspiCaseDetails> getCases(CaseSearchPOJO casesRequest);

	List<CspiCaseDetails> getRelasedCspiCase() throws ServiceException;

}
