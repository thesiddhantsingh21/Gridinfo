package com.gic.cspi.ws.cde.service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gic.cspi.ws.cde.exception.ServiceException;
import com.gic.cspi.ws.cde.model.CspiCaseDetails;
import com.gic.cspi.ws.cde.model.NgCaseAttempts;
import com.gic.cspi.ws.cde.pojo.CaseSearchPOJO;
import com.gic.cspi.ws.cde.repository.CSPiCaseRepository;
import com.gic.cspi.ws.cde.repository.NGCaseAttemptsRepository;

@Service
public class CSPiCaseServiceImpl implements CSPiCaseService {

	private static final Logger logger = LoggerFactory.getLogger(CSPiCaseServiceImpl.class);

	@Autowired
	public CSPiCaseRepository cspiCaseRepository;

	@Autowired
	NGCaseAttemptsRepository ngCaseAttemptsRepository;

	@Override
	public List<CspiCaseDetails> getCases(CaseSearchPOJO caseSearchPOJO) {

		Date startDate = caseSearchPOJO.getStartDate() != null ? caseSearchPOJO.getStartDate() : new Date();
		Date endDate = caseSearchPOJO.getEndDate() != null ? caseSearchPOJO.getEndDate() : new Date();

		String crnNo = caseSearchPOJO.getCrnNo() != null ? caseSearchPOJO.getCrnNo() : "";
		String stagingStatus = caseSearchPOJO.getStagingStatus() != null ? caseSearchPOJO.getStagingStatus() : "";

		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
		String startDateStr = simpleDateFormat.format(startDate);
		String endDateStr = simpleDateFormat.format(endDate);

		return cspiCaseRepository.getByFilter(startDateStr, endDateStr, crnNo, stagingStatus);
	}

	@Override
	public CspiCaseDetails saveCSPiCase(CspiCaseDetails cspiCase) {

		ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

		List<CspiCaseDetails> cspiCaseOpt = cspiCaseRepository.findByCaseRefNumber(cspiCase.getCaseRefNumber());

		JsonNode cspiJson = cspiCase.getCaseJSON();
		JsonNode caseDetails = cspiJson.has("CaseDetails") ? cspiJson.get("CaseDetails") : mapper.createObjectNode();
		String subjectDetail = caseDetails.get("SUBJECT_DETAIL") != null ? caseDetails.get("SUBJECT_DETAIL").asText()
				: "";

		boolean isCandidate = StringUtils.isNotEmpty(subjectDetail)
				&& (subjectDetail.equalsIgnoreCase("Candidate") || subjectDetail.equalsIgnoreCase("HR-XML"));

		if (CollectionUtils.isNotEmpty(cspiCaseOpt)) {
			CspiCaseDetails cspiSaved = cspiCaseOpt.get(0);

			Boolean successStatus = cspiSaved.getSuccessStatus();
			if (successStatus == null) {
				successStatus = false;
			}

			cspiCase.setReleasedToWorkflow(cspiSaved.getReleasedToWorkflow());
			cspiCase.setId(cspiSaved.getId());
			cspiCase.setSuccessStatus(cspiSaved.getSuccessStatus());
			cspiCase.setStagingStatus("UPDATE");
			cspiCase.setCspiNgStatus(cspiSaved.getCspiNgStatus());
			cspiCase.setSuccessStatus(successStatus);
			cspiCase.setCreatedDate(cspiSaved.getCreatedDate());
			cspiCase.setRetryCount((cspiSaved.getRetryCount() == null ? 0 : cspiSaved.getRetryCount()));
			cspiCase.setTransactionId(cspiSaved.getTransactionId() != null ? cspiSaved.getTransactionId() : "");
			cspiCase.setFileConversionCount(
					cspiSaved.getFileConversionCount() != null ? cspiSaved.getFileConversionCount() : 0);
			if (cspiSaved.getCreatedDate() == null) {
				cspiCase.setCreatedDate(cspiSaved.getUpdateDate());
			}
			cspiCase.setUpdateDate(cspiCase.getCreatedDate());
			logger.info("setting caseRefNumber : {} to UPDATE", cspiCase.getCaseRefNumber());
		}
		cspiCase.setIsCandidate(isCandidate);
		Boolean successStatus = cspiCase.getReleasedToWorkflow();
		if (successStatus == null) {
			successStatus = false;
		}
		if (!successStatus) {
			return cspiCaseRepository.save(cspiCase);
		} else {
			return cspiCase;
		}
	}

	@Override
	public CspiCaseDetails getCspiCaseByCRN(String crnStr) {

		List<CspiCaseDetails> cspiCaseOpt = cspiCaseRepository.findByCaseRefNumber(crnStr);
		if (CollectionUtils.isNotEmpty(cspiCaseOpt)) {
			return cspiCaseOpt.get(0);
		}
		return null;
	}

	@Override
	public List<NgCaseAttempts> getNGCaseAttempts(String crnStr) {
		return ngCaseAttemptsRepository.findAllByCaseRefNumberOrderByUpdateDateDesc(crnStr);
	}

	@Override
	public List<CspiCaseDetails> getRelasedCspiCase() throws ServiceException {
		List<CspiCaseDetails> cspiCaseDetails = cspiCaseRepository.getAndUpdateNoRelasedData();
		if (CollectionUtils.isNotEmpty(cspiCaseDetails)) {
			return cspiCaseDetails;
		}
		throw new ServiceException("No data found");
	}
}
