package com.gic.cspi.ws.cde.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;

import com.fasterxml.jackson.databind.JsonNode;
import com.vladmihalcea.hibernate.type.json.JsonBinaryType;

import lombok.Data;

@Data
@Entity
@TypeDef(name = "jsonb", typeClass = JsonBinaryType.class)
@Table(name = "cspi_data_entry")
public class CspiDataEntry {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(nullable = false, updatable = false)
	private Long id;

	@Column(nullable = false, unique = true)
	private String caseRefNumber;

	@Type(type = "jsonb")
	@Column(columnDefinition = "jsonb", name = "data_entry_json", nullable = false)
	private JsonNode dataEntryJSON;

	private Date updateDate;
	private String stagingStatus;
	private String cspiNgStatus;
	private Date createdDate;
	private Integer retryCount;
	private Boolean successStatus;
	private String transactionId;
	private Integer fileConversionCount;

	@Column(nullable = false, columnDefinition = "boolean default false")
	private Boolean releasedToWorkflow;

	public CspiDataEntry(String caseRefNumber, JsonNode dataEntryJSON, Date updateDate, String stagingStatus,
			String cspiNGStatus, Date createdDate, Integer retryCount, Boolean successStatus) {
		this.caseRefNumber = caseRefNumber;
		this.dataEntryJSON = dataEntryJSON;
		this.updateDate = updateDate;
		this.stagingStatus = stagingStatus;
		this.cspiNgStatus = cspiNGStatus;
		this.createdDate = createdDate;
		this.retryCount = retryCount;
		this.successStatus = successStatus;
		this.releasedToWorkflow = false;
	}

	public CspiDataEntry() {
		// Default
	}

	@Override
	public String toString() {
		return "CSPiDataEntry [id=" + id + ", caseRefNumber=" + caseRefNumber + ", dataEntryJSON=" + dataEntryJSON
				+ ", updateDate=" + updateDate + ", stagingStatus=" + stagingStatus + ", cspiNGStatus=" + cspiNgStatus
				+ ", createdDate=" + createdDate + ", retryCount=" + retryCount + ", successStatus=" + successStatus
				+ "]";
	}

}
