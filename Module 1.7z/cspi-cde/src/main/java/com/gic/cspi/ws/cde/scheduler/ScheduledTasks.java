package com.gic.cspi.ws.cde.scheduler;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.gic.cspi.ws.cde.service.ScheduledTaskService;

@Component
public class ScheduledTasks {

	private static final Logger logger = LoggerFactory.getLogger(ScheduledTasks.class);
	private static final DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("HH:mm:ss");

	@Autowired
	ScheduledTaskService scheduledTaskService;

	@Value("${cron.enabled}")
	private String cronEnabled;

	@Scheduled(cron = "${cspi.cron}")
	public void scheduleTaskForCSPi() {

		try {
			if (cronEnabled.equalsIgnoreCase("true")) {
				runCronScheduledTask();
			} else {
				logger.info("cron.enabled not set to true");
			}
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
	}

	private void runCronScheduledTask() {
		String localDateTime = dateTimeFormatter.format(LocalDateTime.now());
		logger.info("Case Creation Cron Task Started :: {}", localDateTime);

		try {
			scheduledTaskService.fetchAndSaveCases();
		} catch (Exception e) {
			logger.info(e.getMessage(), e);
		}

		localDateTime = dateTimeFormatter.format(LocalDateTime.now());
		logger.info("Case Creation Cron Task Ended :: {}", localDateTime);
	}

}
