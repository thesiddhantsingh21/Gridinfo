package com.gic.cspi.ws.cde;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class CSPiCDEApplication {

	public static void main(String[] args) {
		SpringApplication.run(CSPiCDEApplication.class, args);
	}

}
