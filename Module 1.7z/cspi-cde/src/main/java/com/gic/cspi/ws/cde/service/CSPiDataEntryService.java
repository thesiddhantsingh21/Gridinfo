package com.gic.cspi.ws.cde.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.gic.cspi.ws.cde.exception.ServiceException;
import com.gic.cspi.ws.cde.model.CspiDataEntry;
import com.gic.cspi.ws.cde.pojo.DataEntrySearchPOJO;

@Service
public interface CSPiDataEntryService {

	List<CspiDataEntry> getDataEntry(DataEntrySearchPOJO dataEntryRequest);

	CspiDataEntry saveCSPiDataEntry(CspiDataEntry cspiDataEntry);

	List<CspiDataEntry> getRelasedCspiDataEntry() throws ServiceException;

}
