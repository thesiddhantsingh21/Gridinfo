package com.gic.cspi.ws.cde.service;

import org.springframework.stereotype.Service;

@Service
public interface ScheduledTaskService {

	void fetchAndSaveCases();

}
