package com.gic.cspi.ws.cde.service;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class ApiServiceImpl implements ApiService {

	@Autowired
	private RestTemplateBuilder restTemplateBuilder;

	private static final Logger logger = LoggerFactory.getLogger(ApiServiceImpl.class);

	@Override
	public String sendDataToPost(String requestUrl, String requestStr) {
		logger.info("Request Url for Post : {}", requestUrl);
		logger.info("Request Body for Post : {}", requestStr);
		try {
			HttpHeaders httpHeaders = new HttpHeaders();
			httpHeaders.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<String> requestEntity = new HttpEntity<>(requestStr, httpHeaders);
			RestTemplate restTemplate = restTemplateBuilder.build();
			return restTemplate.postForObject(requestUrl, requestEntity, String.class);
		} catch (Exception e) {
			logger.info("Exception while Post request to request url : {}, Error : {}", requestUrl, e.getMessage());
			return null;
		}
	}

	@Override
	public String sendDataToGet(String requestUrl, String tokenId) {
		logger.info("Request Url for Get : {}", requestUrl);
		try {
			HttpHeaders httpHeaders = new HttpHeaders();
			httpHeaders.setContentType(MediaType.APPLICATION_JSON);
			if (tokenId != null && !tokenId.isEmpty()) {
				httpHeaders.set("tokenid", tokenId);
			}

			HttpEntity<String> requestEntity = new HttpEntity<>(httpHeaders);
			RestTemplate restTemplate = restTemplateBuilder.build();
			ResponseEntity<String> response = restTemplate.exchange(requestUrl, HttpMethod.GET, requestEntity,
					String.class);
			if (HttpStatus.OK.equals(response.getStatusCode()) || HttpStatus.CREATED.equals(response.getStatusCode()))
				return response.getBody();
			return null;
		} catch (Exception e) {
			logger.info("Exception while Get request to request url : {}, Error : {}", requestUrl, e.getMessage());
			return null;
		}
	}

	@Override
	public String sendDataToGetAsync(String urlStr) {
		logger.info("URL: {}", urlStr);
		String responseStr = null;
		try {
			URL url = new URL(urlStr);
			HttpURLConnection con = (HttpURLConnection) url.openConnection();
			con.setRequestMethod("GET");

			int responseCode = con.getResponseCode();
			logger.info("response Code: {}", responseCode);
			String readLine = null;
			if (responseCode == HttpURLConnection.HTTP_OK) {
				BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
				StringBuilder response = new StringBuilder();
				while ((readLine = in.readLine()) != null) {
					response.append(readLine);
				}
				in.close();
				responseStr = response.toString();
				logger.info("response received successfully...");

			} else {
				logger.info("GET request FAILED");
			}
		} catch (Exception e) {
			logger.error("Exception while Get request to request url : {}, Error : {}", urlStr, e.getMessage());
		}
		return responseStr;
	}

	@Override
	public String sendDataToPostAsync(String urlStr, String requestStr) {
		logger.info("URL: {}", urlStr);
		String responseStr = null;
		try {
			URL url = new URL(urlStr);
			HttpURLConnection con = (HttpURLConnection) url.openConnection();
			con.setRequestMethod("POST");
			con.setRequestProperty("Content-Type", "application/json");
			con.setRequestProperty("Accept", "application/json");

			con.setDoOutput(true);
			OutputStream os = con.getOutputStream();
			os.write(requestStr.getBytes());
			os.flush();
			os.close();

			int responseCode = con.getResponseCode();
			logger.info("http POST response code: {} : {}", responseCode, con.getResponseMessage());
			String readLine = null;
			if (responseCode == HttpURLConnection.HTTP_OK) {
				BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
				StringBuilder response = new StringBuilder();
				while ((readLine = in.readLine()) != null) {
					response.append(readLine);
				}
				in.close();
				responseStr = response.toString();

			} else {
				logger.error("POST request FAILED");
			}
		} catch (Exception e) {
			logger.info("Exception while Get request to request url : {}, Error : {}", urlStr, e.getMessage());
		}
		return responseStr;
	}
}
