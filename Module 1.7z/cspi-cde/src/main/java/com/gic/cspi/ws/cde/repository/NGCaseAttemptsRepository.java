package com.gic.cspi.ws.cde.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.gic.cspi.ws.cde.model.NgCaseAttempts;

public interface NGCaseAttemptsRepository extends JpaRepository<NgCaseAttempts, Long> {

	Optional<NgCaseAttempts> findByCaseRefNumber(String caseRefNumber);

	List<NgCaseAttempts> findAllByCaseRefNumberOrderByUpdateDateDesc(String caseRefNumber);

}
