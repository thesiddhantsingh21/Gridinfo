package com.gic.cspi.ws.cde.controller;

import java.text.SimpleDateFormat;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gic.cspi.ws.cde.model.CspiCaseDetails;
import com.gic.cspi.ws.cde.model.NgCaseAttempts;
import com.gic.cspi.ws.cde.pojo.CaseSearchPOJO;
import com.gic.cspi.ws.cde.pojo.ResponseStatusPOJO;
import com.gic.cspi.ws.cde.scheduler.ScheduledTasks;
import com.gic.cspi.ws.cde.service.CSPiCaseServiceImpl;

@RestController
@RequestMapping("/cspi-cde/cases")
public class CSPiCaseController {

	private static final Logger logger = LoggerFactory.getLogger(CSPiCaseController.class);

	@Autowired
	private CSPiCaseServiceImpl cspiCaseService;

	@Autowired
	private ScheduledTasks scheduledTasks;

	@PostMapping(path = "/get-cases", consumes = "application/json", produces = "application/json")
	public ResponseEntity<List<CspiCaseDetails>> getCases(@RequestBody CaseSearchPOJO casesRequest) {

		try {
			List<CspiCaseDetails> cspiCases = cspiCaseService.getCases(casesRequest);
			return new ResponseEntity<>(cspiCases, HttpStatus.OK);
		} catch (Exception e) {
			logger.debug(e.getMessage(), e);
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@PostMapping(path = "/save-case", consumes = "application/json", produces = "application/json")
	public ResponseEntity<CspiCaseDetails> saveCSPiCase(@RequestBody CspiCaseDetails cspiCase) {
		try {
			CspiCaseDetails cspiCases = cspiCaseService.saveCSPiCase(cspiCase);
			return new ResponseEntity<>(cspiCases, HttpStatus.CREATED);
		} catch (Exception e) {
			logger.debug(e.getMessage(), e);
			return new ResponseEntity<>(null, HttpStatus.EXPECTATION_FAILED);
		}
	}

	@GetMapping("/getcrn")
	public String getCRN(@RequestParam String CRNStr) {
		String retStr;
		try {
			CspiCaseDetails cspiCase = cspiCaseService.getCspiCaseByCRN(CRNStr);
			List<NgCaseAttempts> ngList = cspiCaseService.getNGCaseAttempts(CRNStr);
			if (cspiCase != null) {
				retStr = generateCRNHTML(CRNStr, cspiCase, ngList);
			} else {
				retStr = "CRN Not Found";
			}
		} catch (Exception e) {
			retStr = e.getMessage();
			logger.debug(e.getMessage(), e);
		}
		return retStr;
	}

	private String generateCRNHTML(String CRNStr, CspiCaseDetails cspiCase, List<NgCaseAttempts> ngList) {
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MMMM dd, yyyy");

		StringBuffer htmlBuf = new StringBuffer();
		htmlBuf.append("<html>");
		htmlBuf.append("<title>CSPi CDE Staging Service Details for CRN : " + CRNStr + "</title>");
		htmlBuf.append("<body>");
		htmlBuf.append("<h2>");
		htmlBuf.append("<u>CSPi CDE Staging Service:</u>");
		htmlBuf.append("</h2>");
		htmlBuf.append("Details for CRN : " + CRNStr);
		htmlBuf.append("<br><br>");
		htmlBuf.append("Staging Database Status: " + cspiCase.getStagingStatus());
		htmlBuf.append("<br><br>");
		htmlBuf.append("NG Status: " + cspiCase.getCspiNgStatus());
		htmlBuf.append("<br><br>");
		String formattedDate = cspiCase.getUpdateDate().toString();
		try {
			formattedDate = simpleDateFormat.format(cspiCase.getUpdateDate());
		} catch (Exception e) {
		}
		htmlBuf.append("Last Update: " + formattedDate);
		htmlBuf.append("<br><br>");
		htmlBuf.append("<b>NG Case Creation Failed Attempts:</b>");
		htmlBuf.append("<br><br>");
		htmlBuf.append("<table cols=4 border=1 cellspacing=0 cellpadding=5>");
		htmlBuf.append("<thead>");
		htmlBuf.append("<tr>");
		htmlBuf.append("<th align=center>");
		htmlBuf.append("S. No.");
		htmlBuf.append("</th>");
		htmlBuf.append("<th align=center>");
		htmlBuf.append("Update Date Time");
		htmlBuf.append("</th>");
		htmlBuf.append("<th align=center>");
		htmlBuf.append("NG Request Status Code");
		htmlBuf.append("</th>");
		htmlBuf.append("<th align=center>");
		htmlBuf.append("NG Request Status");
		htmlBuf.append("</th>");
		htmlBuf.append("</tr>");
		htmlBuf.append("</thead>");
		htmlBuf.append("<tbody>");
		for (int i = 0; i < ngList.size(); i++) {
			NgCaseAttempts ngCase = ngList.get(i);
			htmlBuf.append("<tr>");
			htmlBuf.append("<td align=center>");
			htmlBuf.append(i + 1);
			htmlBuf.append("</td>");
			htmlBuf.append("<td align=center>");
			htmlBuf.append(ngCase.getUpdateDate().toString());
			htmlBuf.append("</td>");
			htmlBuf.append("<td align=center>");
			htmlBuf.append(ngCase.getCaseAttemptStatusCode());
			htmlBuf.append("</td>");
			htmlBuf.append("<td align=center>");
			htmlBuf.append(ngCase.getCaseAttemptStatus());
			htmlBuf.append("</td>");
			htmlBuf.append("</tr>");
		}
		htmlBuf.append("</tbody>");
		htmlBuf.append("</table>");
		htmlBuf.append("</body>");
		htmlBuf.append("</html>");
		return htmlBuf.toString();
	}

	@GetMapping("/scheduled-cases")
	public void invokeScheduledCases() {
		scheduledTasks.scheduleTaskForCSPi();
	}

	@GetMapping(path = "release", produces = "application/json")
	public ResponseEntity<ResponseStatusPOJO> getMiReleasedCrns() {
		try {
			return new ResponseEntity<>(new ResponseStatusPOJO(true, "Record found", "SUCCESS_CODE_200",
					cspiCaseService.getRelasedCspiCase()), HttpStatus.OK);
		} catch (Exception e2) {
			return new ResponseEntity<>(new ResponseStatusPOJO(false, e2.getMessage()), HttpStatus.OK);
		}
	}
}
