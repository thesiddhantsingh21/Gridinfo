package com.gic.cspi.ws.cde.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gic.cspi.ws.cde.model.CspiDataEntry;
import com.gic.cspi.ws.cde.pojo.DataEntrySearchPOJO;
import com.gic.cspi.ws.cde.pojo.ResponseStatusPOJO;
import com.gic.cspi.ws.cde.service.CSPiDataEntryServiceImpl;

@RestController
@RequestMapping("/cspi-cde/data-entry")
public class CSPiDataEntryController {

	private static final Logger logger = LoggerFactory.getLogger(CSPiDataEntryController.class);

	@Autowired
	private CSPiDataEntryServiceImpl cspiDataEntryServiceImpl;

	// Get All cases from Staged DB
	// Start Date
	// End Date
	// CrnNo. (Optional)
	// Status (Optional) Staging Status

	@PostMapping(path = "/get-dataentry", consumes = "application/json", produces = "application/json")
	public ResponseEntity<List<CspiDataEntry>> getDataEntry(@RequestBody DataEntrySearchPOJO dataEntryRequest) {

		try {
			List<CspiDataEntry> cspiDataEntry = cspiDataEntryServiceImpl.getDataEntry(dataEntryRequest);
			return new ResponseEntity<>(cspiDataEntry, HttpStatus.OK);
		} catch (Exception e) {
			logger.debug(e.getMessage(), e);
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@PostMapping(path = "/save-case", consumes = "application/json", produces = "application/json")
	public ResponseEntity<CspiDataEntry> saveCSPiDataEntry(@RequestBody CspiDataEntry cspiDataEntry) {
		try {
			CspiDataEntry _cspiDataEntry = cspiDataEntryServiceImpl.saveCSPiDataEntry(cspiDataEntry);
			return new ResponseEntity<>(_cspiDataEntry, HttpStatus.CREATED);
		} catch (Exception e) {
			logger.debug(e.getMessage(), e);
			return new ResponseEntity<>(null, HttpStatus.EXPECTATION_FAILED);
		}
	}

	@GetMapping(path = "release", produces = "application/json")
	public ResponseEntity<ResponseStatusPOJO> getMiReleasedCrns() {
		try {
			return new ResponseEntity<>(new ResponseStatusPOJO(true, "Record found", "SUCCESS_CODE_200",
					cspiDataEntryServiceImpl.getRelasedCspiDataEntry()), HttpStatus.OK);
		} catch (Exception e2) {
			return new ResponseEntity<>(new ResponseStatusPOJO(false, e2.getMessage()), HttpStatus.OK);
		}
	}

}
