package com.gic.cspi.ws.cde.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Data;

@Data
@Entity
@JsonInclude(value = Include.NON_NULL)
public class NgCaseAttempts {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(nullable = false, updatable = false)
	private Long id;

	@Column(nullable = false, unique = true)
	private String caseRefNumber;

	private Date updateDate;
	private String caseAttemptStatusCode;
	private String caseAttemptStatus;

	public NgCaseAttempts(String caseRefNumber, Date updateDate, String caseAttemptStatusCode,
			String caseAttemptStatus) {
		this.caseRefNumber = caseRefNumber;
		this.updateDate = updateDate;
		this.caseAttemptStatusCode = caseAttemptStatusCode;
		this.caseAttemptStatus = caseAttemptStatus;
	}

	@Override
	public String toString() {
		return "NGCaseAttempts [id=" + id + ", caseRefNumber=" + caseRefNumber + ", updateDate=" + updateDate
				+ ", caseAttemptStatusCode=" + caseAttemptStatusCode + ", caseAttemptStatus=" + caseAttemptStatus + "]";
	}

}
