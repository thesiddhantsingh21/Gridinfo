package com.gic.cspi.ws.cde.pojo;

import java.util.Date;

import lombok.Data;

@Data
public class CaseSearchPOJO {

	private Date startDate;
	private Date endDate;
	private String crnNo;
	private String stagingStatus;

	@Override
	public String toString() {
		return "CasesRequest [" + (startDate != null ? "startDate=" + startDate + ", " : "")
				+ (endDate != null ? "endDate=" + endDate + ", " : "") + (crnNo != null ? "crnNo=" + crnNo + ", " : "")
				+ (stagingStatus != null ? "stagingStatus=" + stagingStatus : "") + "]";
	}
}
