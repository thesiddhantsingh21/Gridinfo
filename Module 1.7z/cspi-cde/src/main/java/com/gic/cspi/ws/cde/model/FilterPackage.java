package com.gic.cspi.ws.cde.model;

import lombok.Data;

@Data
public class FilterPackage {

	private Long id;
	private String customerName;
	private String sbuName;
	private String packageName;

	public FilterPackage(String customerName, String sbuName, String packageName) {
		this.customerName = customerName;
		this.sbuName = sbuName;
		this.packageName = packageName;
	}

	@Override
	public String toString() {
		return "FilterPackages [id=" + id + ", customerName=" + customerName + ", sbuName=" + sbuName + ", packageName="
				+ packageName + "]";
	}

}
