package com.gic.cspi.ws.cde.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;

import com.fasterxml.jackson.databind.JsonNode;
import com.vladmihalcea.hibernate.type.json.JsonBinaryType;

import lombok.Data;

@Data
@Entity
@TypeDef(name = "jsonb", typeClass = JsonBinaryType.class)
@Table(name = "cspi_case_details")
public class CspiCaseDetails {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(nullable = false, updatable = false)
	private Long id;
	private String caseId;

	@Column(nullable = false, unique = true)
	private String caseRefNumber;

	@Type(type = "jsonb")
	@Column(columnDefinition = "jsonb", name = "case_json", nullable = false)
	private JsonNode caseJSON;

	private Date updateDate;
	private String stagingStatus;
	private String cspiNgStatus;
	private Integer retryCount;
	private Boolean successStatus;
	private Date createdDate;
	private String transactionId;
	private Integer fileConversionCount;
	
	@Column(nullable = false, columnDefinition = "boolean default false")
	private Boolean releasedToWorkflow;
	
	@Column(nullable = false, columnDefinition = "boolean default false")
	private Boolean isCandidate;

	public CspiCaseDetails(String caseId, String caseRefNumber, JsonNode caseJSON, Date updateDate,
			String stagingStatus, String cspiNGStatus, Date createdDate, Integer retryCount, Boolean successStatus) {
		this.caseRefNumber = caseRefNumber;
		this.caseId = caseId;
		this.caseJSON = caseJSON;
		this.updateDate = updateDate;
		this.stagingStatus = stagingStatus;
		this.cspiNgStatus = cspiNGStatus;
		this.createdDate = createdDate;
		this.retryCount = retryCount;
		this.successStatus = successStatus;
		this.releasedToWorkflow = false;
	}

	public CspiCaseDetails() {
		// Default
	}

	@Override
	public String toString() {
		return "CSPiCase [id=" + id + ", caseId=" + caseId + ", caseRefNumber=" + caseRefNumber + ", caseJSON="
				+ caseJSON + ", updateDate=" + updateDate + ", stagingStatus=" + stagingStatus + ", cspiNGStatus="
				+ cspiNgStatus + ", retryCount=" + retryCount + ", successStatus=" + successStatus + ", createdDate="
				+ createdDate + "]";
	}

}
