package com.gic.cspi.ws.cde.service;

import java.net.URLEncoder;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.gic.cspi.ws.cde.model.CspiCaseDetails;
import com.gic.cspi.ws.cde.model.CspiDataEntry;
import com.gic.cspi.ws.cde.model.ClientSbuPackage;
import com.gic.cspi.ws.cde.repository.ClientSbuPackageRepository;

@Service
public class ScheduledTaskServiceImpl implements ScheduledTaskService {

	private static final String CASES = "Cases";
	private static final String CASE_REF_NUMBER = "CASE_REF_NUMBER";
	private static final String PACKAGE_NAME = "PACKAGE_NAME";
	private static final String SBU_NAME = "SBU_Name";
	private static final String CLIENT_NAME = "Client_Name";
	private static final String CASE_DETAILS = "CaseDetails";
	private static final String RESPONSE = "response";
	private static final Logger logger = LoggerFactory.getLogger(ScheduledTaskServiceImpl.class);

	@Autowired
	private ApiService apiService;

	@Autowired
	private CSPiCaseServiceImpl csPiCaseService;

	@Autowired
	private CSPiDataEntryServiceImpl csPiDataEntryService;

	@Autowired
	private ClientSbuPackageRepository clientSbuPackageRepository;

	@Value("${filter.packages.flag}")
	private String filterPackageFlag;

	@Value("${fadv.entity.id}")
	private String fadvEntityId;

	@Value("${cspi.search.window.days}")
	private String cspiSearchWindowDays;

	@Value("${cspi.case.create.url}")
	private String cspiCaseCreateUrl;

	@Value("${data.entry.request.max.crns}")
	private int dataEntryRequestMaxCrns;

	@Value("${ng.cases.get.url}")
	private String ngCasesGetUrl;

	@Value("${ng.cases.get.tokenid}")
	private String ngCasesGetTokenId;

	@Value("${cspi.data.entry.url}")
	private String cspiDataEntryUrl;

	private ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES,
			false);

	@Override
	public void fetchAndSaveCases() {
		try {
			logger.info("===== Processing Case Creation =====");

			// Fetch from CSPi Web Service
			// subtract 1 from search window days
			LocalDateTime startDate = LocalDateTime.now().minusDays(Long.parseLong(cspiSearchWindowDays) - 1);
			LocalDateTime endDate = LocalDateTime.now().plusDays(1);
			String formattedStartDate = startDate.format(DateTimeFormatter.ofPattern("MM/dd/yyyy"));
			String formattedEndDate = endDate.format(DateTimeFormatter.ofPattern("MM/dd/yyyy"));

			ObjectNode cspiRequest = mapper.createObjectNode();
			cspiRequest.put("fadvEntityId", fadvEntityId);
			cspiRequest.put("StartDate", formattedStartDate);
			cspiRequest.put("EndDate", formattedEndDate);

			logger.info("calling cspi web service with input: {}", cspiRequest);

			String urlStr = cspiCaseCreateUrl + URLEncoder.encode(cspiRequest.toString(), "UTF-8");
			String responseStr = apiService.sendDataToGetAsync(urlStr);

			ArrayNode caseArr = mapper.createArrayNode();
			if (responseStr != null) {
//				logger.info("NG Case GET Result : {}", responseStr);
				JsonNode responseNode;
				try {
					responseNode = mapper.readTree(responseStr);
					caseArr = responseNode.has(CASES) ? (ArrayNode) responseNode.get(CASES) : mapper.createArrayNode();
				} catch (JsonProcessingException e) {
					logger.error(e.getMessage(), e);
				}
			} else {
				logger.error("CSPi Case GET FAILED");
			}

			// Now get CRNs from NG Endpoint and add to caseRefNumbers
			// to be processed for Data Entry
			List<String> ngCaseRefNumbers = getNGCaseRefNbrs();

			// Now filter and save filtered cases
			List<String> caseRefNumbers = new ArrayList<>();
			logger.info("===== Got : {} Cases =====", caseArr.size());
			for (JsonNode caseNode : caseArr) {

				JsonNode caseDetails = caseNode.has(CASE_DETAILS) ? caseNode.get(CASE_DETAILS)
						: mapper.createObjectNode();

				// check if this case is in filter packages
				String customerName = caseDetails.has(CLIENT_NAME) ? caseDetails.get(CLIENT_NAME).asText() : "";
				String sbuName = caseDetails.has(SBU_NAME) ? caseDetails.get(SBU_NAME).asText() : "";
				String packageName = caseDetails.has(PACKAGE_NAME) ? caseDetails.get(PACKAGE_NAME).asText() : "";

				logger.info("Checking FilterPackages for : {} : {} : {}", customerName, sbuName, packageName);

				boolean isFilterPackageInDb = false;
				List<ClientSbuPackage> clientSbuPackages = clientSbuPackageRepository
						.fetchByClientNameSbuNamePackageNameAndActive(customerName, sbuName, packageName, true, true);
				if (CollectionUtils.isNotEmpty(clientSbuPackages)
						&& (clientSbuPackages.get(0).getFetchFromCspi() != null
								&& clientSbuPackages.get(0).getFetchFromCspi())) {
					isFilterPackageInDb = true;
				}

				if (!filterPackageFlag.equalsIgnoreCase("true")) {
					isFilterPackageInDb = true;
				}

				if (isFilterPackageInDb) {
					logger.info("package found in FilterPackageDB");
					String caseId = caseNode.has("CASE_ID") ? caseNode.get("CASE_ID").asText() : "";
					String caseRefNumber = caseNode.has(CASE_REF_NUMBER) ? caseNode.get(CASE_REF_NUMBER).asText() : "";
					Date updateDate = new Date();
					String stagingStatus = "INSERT";
					String cspiNGStatus = "NOT PROCESSED";
					CspiCaseDetails cspiCase = new CspiCaseDetails(caseId, caseRefNumber, caseNode, updateDate,
							stagingStatus, cspiNGStatus, updateDate, 0, false);
					// Save Case
					cspiCase = csPiCaseService.saveCSPiCase(cspiCase);
					logger.info("After save cspiCaseRefNumber: {}", cspiCase.getCaseRefNumber());
					logger.info("After save stagingStatus: {}", cspiCase.getStagingStatus());
					caseRefNumbers.add(caseRefNumber);
				}
			}

			logger.info("===== Processed {} Cases =====", caseRefNumbers.size());

			if (ngCaseRefNumbers != null) {
				caseRefNumbers = ngCaseRefNumbers;
				// caseRefNumbers.addAll(ngCaseRefNumbers); //Stopped by Shariq on 29/06/2021
				logger.info("===== Added {} Cases from NG =====", ngCaseRefNumbers.size());
			}

			// Now process all cases for Data Entry
			logger.info("===== Total Data Entry Cases {} =====", caseRefNumbers.size());
			int maxCrns = dataEntryRequestMaxCrns;

			if (maxCrns > 0) {
				List<String> tmpList = new ArrayList<>();
				for (int i = 1; i <= caseRefNumbers.size(); i++) {
					tmpList.add(caseRefNumbers.get(i - 1));
					// process max crns allowed
					if ((i % maxCrns) == 0) {
						logger.info("===== Processing Data Entries =====");
						logger.info("Calling processDataEntry for {} cases", maxCrns);
						processDataEntry(tmpList);
						tmpList.clear();
					} else if (i == caseRefNumbers.size()) {
						// process rest
						logger.info("===== Processing Data Entry =====");
						logger.info("Calling processDataEntry for {} cases", tmpList.size());
						processDataEntry(tmpList);
						tmpList.clear();
					}
				}
			} else {
				logger.info("===== Processing Data Entry =====");
				logger.info("Calling processDataEntry for all {} cases", caseRefNumbers.size());
				processDataEntry(caseRefNumbers);
			}
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
	}

	private List<String> getNGCaseRefNbrs() {

		String responseStr = apiService.sendDataToGet(ngCasesGetUrl, ngCasesGetTokenId);

		if (responseStr != null) {
			logger.info("NG Case GET crnlist Result : {}", responseStr);
			JsonNode responseNode;
			try {
				responseNode = mapper.readTree(responseStr);
				ArrayNode responseArr = responseNode.has(RESPONSE) ? (ArrayNode) responseNode.get(RESPONSE)
						: mapper.createArrayNode();

				return mapper.convertValue(responseArr, new TypeReference<List<String>>() {
				});
			} catch (JsonProcessingException e) {
				logger.error(e.getMessage(), e);
				return new ArrayList<>();
			}
		} else {
			logger.info("NG Case GET crnlist FAILED , returning empty JsonArray");
			return new ArrayList<>();
		}
	}

	private void processDataEntry(List<String> caseRefNbrs) {

		// Fetch from Data Entry Web Service

		ObjectNode deRequest = mapper.createObjectNode();

		deRequest.put("fadvEntityId", fadvEntityId);
		deRequest.set("CRNNumbers", mapper.convertValue(caseRefNbrs, ArrayNode.class));

		logger.info("calling data entry web service with POST data: {}", deRequest);

		String responseStr = apiService.sendDataToPostAsync(cspiDataEntryUrl, deRequest.toString());

		if (responseStr != null) {

			// Now save Data Entry response
			JsonNode responseNode;
			try {
				responseNode = mapper.readTree(responseStr);
				ArrayNode dataEntryArray = responseNode.has("DataEntry") ? (ArrayNode) responseNode.get("DataEntry")
						: mapper.createArrayNode();

				int processCount = 0;
				for (JsonNode dataEntryNode : dataEntryArray) {
					logger.info("----- Processing DataEntry -----");
					processCount = processDataEntryResponse(dataEntryNode, processCount);
				}
				logger.info("===== Processed {} Data Entries =====", processCount);

			} catch (JsonProcessingException e) {
				logger.error(e.getMessage(), e);
			}

		} else {
			logger.info("CSPi Data Entry POST FAILED");
		}
	}

	private int processDataEntryResponse(JsonNode dataEntryNode, int processCount) {
		try {
			String caseRefNumber = dataEntryNode.has(CASE_REF_NUMBER) ? dataEntryNode.get(CASE_REF_NUMBER).asText()
					: "";
			String stagingStatus = "INSERT";
			String cspiNGStatus = "NOT PROCESSED";

			CspiDataEntry cspiDataEntry = new CspiDataEntry(caseRefNumber, dataEntryNode, new Date(), stagingStatus,
					cspiNGStatus, new Date(), 0, false);
			csPiDataEntryService.saveCSPiDataEntry(cspiDataEntry);
			logger.info("After save data entry : {}", cspiDataEntry.getCaseRefNumber());
			logger.info("After save stagingStatus : {}", cspiDataEntry.getStagingStatus());
			processCount++;
		} catch (Exception e) {
			logger.error("Skipping dataEntry");
			logger.error(e.getMessage(), e);
		}
		return processCount;
	}

}
