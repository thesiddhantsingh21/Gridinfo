DROP TABLE IF EXISTS packages_filter;
 
CREATE TABLE packages_filter (
  id INT AUTO_INCREMENT  PRIMARY KEY,
  customer_name VARCHAR(250) NOT NULL,
  sbu_name VARCHAR(250) NOT NULL,
  package_name VARCHAR(250) NOT NULL
);
