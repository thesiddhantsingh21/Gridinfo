package com.gic.workflow;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.gic.workflowlib.constants.DependsOn;
import com.gic.workflowlib.constants.TaskType;
import com.gic.workflowlib.decider.Decider;
import com.gic.workflowlib.model.WorkflowDetailsTransaction;
import com.gic.workflowlib.utility.Utility;

@SpringBootApplication
public class CheckCreationDeciderApplication implements CommandLineRunner {
	private static final Logger logger = LoggerFactory.getLogger(CheckCreationDeciderApplication.class);
	@Value("${database}")
	String database;
	@Value("${dbUserName}")
	String dbUserName;
	@Value("${password}")
	String password;
	@Value("${enableSSL}")
	String enableSSL = "false";
	@Value("${host}")
	String host;
	@Value("${schema}")
	String schema;
	@Value("${currentWorker}")
	String currentWorker;
	@Value("${previousWorker}")
	String previousWorker;
	@Value("${taskListName}")
	String taskListName;
	@Value("${taskListName}")
	String taskListDescription;
	@Value("${heart.beat.url}")
	String heartBeatUrl;
//	@Value("${should.send.heartbeat}")
//	String shouldSendHeartBeat;
	
//	static String shouldSendHeartBeat1;
	static String heartBeatURL;
	
	public static void main(String[] args) {
		SpringApplication.run(CheckCreationDeciderApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		logger.info("Running Spring Boot Application");
		logger.info(currentWorker);
		logger.info(previousWorker);
		logger.info(taskListName);
		logger.info(taskListDescription);
		
		this.heartBeatURL = heartBeatUrl; 
//		this.shouldSendHeartBeat1 = shouldSendHeartBeat;

		Map<String, String> configMap = new HashMap<>();
		configMap.put("database", database);
		configMap.put("user", dbUserName);
		configMap.put("password", password);
		configMap.put("host", host);
		configMap.put("schema", schema);
		configMap.put("currentWorker", currentWorker);
		configMap.put("previousWorker", previousWorker);
		configMap.put("taskName", taskListName);
		configMap.put("taskDescription", taskListDescription);

		Decider decider = new Decider(DependsOn.PREVIOUS_WORKER, configMap).init();
		int delay = 0;
		boolean more = true;
		while (more) {
			if (processNextBatch(decider)) {
				delay = 0;
			} else {
				delay = delay + 10;
				if (delay > 60) {
					delay = 10;
				}
			}
			more = pause(delay);
		}

	}

	private static boolean pause(int factor) {
		try {
			logger.info("sleeping for {} seconds", factor);
			TimeUnit.SECONDS.sleep(factor);
		} catch (InterruptedException e) {
			logger.error("Interrupted");
			return false;
		}
		return true;
	}

	private static boolean processNextBatch(Decider decider) {
//		
//		if(Boolean.parseBoolean(shouldSendHeartBeat1)) {
//			Utility.sendHeartBeat(heartBeatURL);
//		}
//		Utility.sendHeartBeat(heartBeatURL);

		boolean isNewTaskCreated = false;
		try {
			WorkflowDetailsTransaction workflowDetailsTransaction = decider.getPreviousCompletedTask();
			if (workflowDetailsTransaction == null) {
				return false;
			}

			isNewTaskCreated = decider.createNewTask(TaskType.DS, workflowDetailsTransaction.getResponseJson(),
					workflowDetailsTransaction.getMetaData());
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return isNewTaskCreated;
	}

}
