package com.gic.fadv.caseCreationJsonWriter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CspiCaseCreationJsonWorkerApplicationTests {

	@Test
	void contextLoads() {
	}

}
