package com.gic.caseCreationJsonWorker.exception;

public class BaseException extends Exception {

	private static final long serialVersionUID = 1L;

	private final String messageId;

	private final Object object;

	public BaseException(String message) {
		super(message);
		this.messageId = "";
		this.object = null;
	}

	public BaseException(String message, Exception e) {
		super(message);
		this.messageId = "";
		this.object = null;
	}

	public BaseException(String message, String messageId) {
		super(message);
		this.messageId = messageId;
		this.object = null;
	}

	public BaseException(String message, String messageId, Exception e) {
		super(message);
		this.messageId = messageId;
		this.object = null;
	}

	public BaseException(String message, String messageId, Object obj) {
		super(message);
		this.messageId = messageId;
		this.object = obj;
	}

	public String getMessageId() {
		return this.messageId;
	}

	public Object getObj() {
		return this.object;
	}
}
