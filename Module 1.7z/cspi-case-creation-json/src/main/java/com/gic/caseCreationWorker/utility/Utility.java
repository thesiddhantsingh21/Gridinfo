package com.gic.caseCreationWorker.utility;

import java.util.Iterator;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.JsonNodeType;
import com.fasterxml.jackson.databind.node.ObjectNode;

public class Utility {
	
	public static String normalizeString(String inputStr) {
		if(StringUtils.isEmpty(inputStr)) {
			return inputStr;
		}else {
			return StringUtils.normalizeSpace( inputStr );
		}
	}
	
	public static JsonNode traverse(JsonNode node) {
		ObjectMapper mapper = new ObjectMapper();
		   if (node.isValueNode()) {
		      if (JsonNodeType.STRING == node.getNodeType()) {
		         return JsonNodeFactory.instance.textNode(Utility.normalizeString(
		               node.asText()));
		      } else if (JsonNodeType.NULL == node.getNodeType()) {
		         return null;
		      } else {
		         return node;
		      }
		   } else if (node.isNull()) {
		      return null;
		   } else if (node.isArray()) {
		      ArrayNode arrayNode = (ArrayNode) node;
		      ArrayNode cleanedNewArrayNode = mapper.createArrayNode();
		      for (JsonNode jsonNode : arrayNode) {
		         cleanedNewArrayNode.add(traverse(jsonNode));
		      }
		      return cleanedNewArrayNode;
		   } else {
		      ObjectNode encodedObjectNode = mapper.createObjectNode();
		      for (Iterator<Map.Entry<String, JsonNode>> it = node.fields(); it.hasNext(); ) {
		         Map.Entry<String, JsonNode> entry = it.next();
		         encodedObjectNode.set(entry.getKey(), traverse(entry.getValue()));
		      }
		      return encodedObjectNode;
		   }
		}
	
	public static void main(String[] args) {
		String str = "{\"crn\": \" G390-7820504-WEST-2022 \", \"success\": true, \"response\": {\"engineInput\": {\"data\": [{\"taskBy\": \"BO\", \"taskId\": \"15b3223b-96f1-4376-9b55-721dee7afc16\", \"taskName\": \"CreateCSPICaseUpload\", \"taskSpecs\": {\"case\": {\"fileUpload\": {\"directory\": \"\\\\\\\\10.2.40.43\\\\CspiNG\\\\India\", \"BVF Document\": [\"BVFMergeFileName-5a051da7-d522-4167-b8d5-ba4a0309e640-1.pdf\"], \"manageCaseDocuments\": [], \"Additional Documents\": [\"AdditionalMergeFileName-a726c769-2b66-4d43-ab1f-7c723607c810-1.pdf\"]}, \"caseReference\": {\"crnNo\": \"G390-7820504-WEST-2022\", \"sbuId\": \"    Greenlam      Industries Limited   \", \"caseNo\": \"1643377219096\", \"checkId\": \"\", \"caseType\": \"MDE\", \"caseUUID\": 163, \"clientId\": \"\", \"packageId\": \"Package 1 17-Oct-18 SRT\", \"crnCreatedDate\": \"2022-01-28T07:13:27.227+00:00\", \"scrnCreatedDate\": \"\"}}, \"fileUpload\": null}, \"taskSerialNo\": 1}], \"metadata\": {\"task\": \"CreateCSPICaseUpload\", \"attempt\": \"1\", \"stageId\": \"72dd8fc9-6eda-46cc-80d6-d032ed37393e\", \"txLabel\": \"1637692024656\", \"version\": \"2.1.0\", \"multiTask\": \"no\", \"processId\": \"11c3a5af-b0dd-4bc8-83bb-9b720f959683\", \"requestId\": \"8e7ffe3e-ebb8-480d-9609-b0d815e92976\", \"stageName\": \"Doc Stage\", \"processName\": \"CSPi NG India\", \"requestDate\": \"Fri Jan 28 08:47:20 EST 2022\", \"requestType\": \"query\", \"taskGroupId\": \"15b3223b-96f1-4376-9b55-721dee7afc16\", \"requestAuthToken\": \"eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJ7XCJtdGVpZFwiOlwiOGI3NGQ0NGMtMDU5MC00MDdjLThiZDgtNjFkM2FkN2Y2ZjM5XCIsXCJ1c2VySWRcIjpcImIxMTA1NDhkLWFmNzgtNGUyNC04ZDZiLWNlN2IyZTE4YWI2OFwiLFwiYXBwU2Vzc2lvbklkXCI6XCIyMjk3ZTJiYS1hM2UwLTQyZmItOTg0Yy0zYWU2ODE3ZGZmMDdcIixcInByb2plY3RJZFwiOlwicHJvamVjdElkXCIsXCJwcm9qZWN0VmVyc2lvbklkXCI6XCJwcm9qZWN0VmVyc2lvbklkXCIsXCJVU0VSX05BTUVcIjpcInN1cGVyIGFkbWluXCIsXCJBRERUSU9OQUxfSU5GT1wiOlwiXCIsXCJleHRlcm5hbFRva2VuXCI6XCJudWxsXCJ9IiwiZXhwIjozMjcxODM4NjMyfQ._8byFadylKhwXKJ1epUHEFJ1rR-FqXtC_KqHFYTj-tOOJWAC_Ayp11Fzy6v0YrtPQiQU8S7lLcZjvEUDmSUUHQ\"}}, \"engineOutput\": {\"data\": [{\"logs\": {\"field1\": \"Bot State logs\"}, \"result\": {\"caseReference\": {\"crnNo\": \"G390-7820504-WEST-2022\", \"sbuId\": \"Greenlam Industries Limited\", \"caseNo\": \"1643377219096\", \"caseType\": \"MDE\", \"caseUUID\": \"163\", \"clientId\": \"\", \"packageId\": \"Package 1 17-Oct-18 SRT\", \"crnCreatedDate\": \"01/28/2022 12:43:27\"}}, \"taskId\": \"15b3223b-96f1-4376-9b55-721dee7afc16\", \"metrics\": {\"endTime\": \"2022-01-28T07:18:29.378Z\", \"startTime\": \"2022-01-28T07:17:22.950Z\", \"statusCode\": \"2200\", \"timeInMills\": 664275481, \"timeInSeconds\": 664275.481}, \"taskName\": \"CreateCSPICaseUpload\", \"taskSerialNo\": \"1\"}], \"metadata\": {\"task\": \"CreateCSPICaseUpload\", \"botId\": \"Cspiindia.robot5\", \"status\": {\"message\": \"Bot Executon Done Successfullly\", \"success\": true, \"statusCode\": \"2200\"}, \"attempt\": \"1\", \"stageId\": \"72dd8fc9-6eda-46cc-80d6-d032ed37393e\", \"version\": \"2.1.0\", \"multiTask\": \"no\", \"processId\": \"11c3a5af-b0dd-4bc8-83bb-9b720f959683\", \"requestId\": \"8e7ffe3e-ebb8-480d-9609-b0d815e92976\", \"responseId\": \"c8602c0a-871f-40ac-a2fc-8163be0e74cf\", \"processName\": \"CSPi NG India\", \"requestDate\": \"Fri Jan 28 08:47:20 EST 2022\", \"requestType\": \"query\", \"taskGroupId\": \"15b3223b-96f1-4376-9b55-721dee7afc16\", \"responseTime\": \"2022-01-28T07:18:29.384Z\", \"responseType\": \"success\", \"requestAuthToken\": \"eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJ7XCJtdGVpZFwiOlwiOGI3NGQ0NGMtMDU5MC00MDdjLThiZDgtNjFkM2FkN2Y2ZjM5XCIsXCJ1c2VySWRcIjpcImIxMTA1NDhkLWFmNzgtNGUyNC04ZDZiLWNlN2IyZTE4YWI2OFwiLFwiYXBwU2Vzc2lvbklkXCI6XCIyMjk3ZTJiYS1hM2UwLTQyZmItOTg0Yy0zYWU2ODE3ZGZmMDdcIixcInByb2plY3RJZFwiOlwicHJvamVjdElkXCIsXCJwcm9qZWN0VmVyc2lvbklkXCI6XCJwcm9qZWN0VmVyc2lvbklkXCIsXCJVU0VSX05BTUVcIjpcInN1cGVyIGFkbWluXCIsXCJBRERUSU9OQUxfSU5GT1wiOlwiXCIsXCJleHRlcm5hbFRva2VuXCI6XCJudWxsXCJ9IiwiZXhwIjozMjcxODM4NjMyfQ._8byFadylKhwXKJ1epUHEFJ1rR-FqXtC_KqHFYTj-tOOJWAC_Ayp11Fzy6v0YrtPQiQU8S7lLcZjvEUDmSUUHQ\"}}}, \"successMsg\": \"Engine     ran     successfully\"}";
		normalizeJsonValues(str);
	}
	
	public static String normalizeJsonValues(String inputJsonStr) {
		ObjectMapper mapper = new ObjectMapper();
		try {
			String normalizedJson = traverse(mapper.readTree(inputJsonStr)).toString();
			System.out.println(normalizedJson);
			return normalizedJson;
		} catch (Exception e) {
			e.printStackTrace();
			return inputJsonStr;
		} 
	}
}

