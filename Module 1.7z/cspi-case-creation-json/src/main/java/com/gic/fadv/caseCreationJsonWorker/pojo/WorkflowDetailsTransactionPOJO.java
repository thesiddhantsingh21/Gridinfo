package com.gic.fadv.caseCreationJsonWorker.pojo;

import java.util.Date;

import com.fasterxml.jackson.databind.JsonNode;

import lombok.Data;

@Data
public class WorkflowDetailsTransactionPOJO {

	private long requestProcessorId;
	private long wdTransactionId;
	private JsonNode responseJson;
	private String status;
	private JsonNode acknowledementJson;
	private Date acknowlegementTimestamp;
}
