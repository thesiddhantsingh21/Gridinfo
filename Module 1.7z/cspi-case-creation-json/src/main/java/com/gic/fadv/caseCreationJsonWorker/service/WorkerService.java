package com.gic.fadv.caseCreationJsonWorker.service;

import java.util.List;

import javax.sql.rowset.serial.SerialException;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.gic.fadv.caseCreationJsonWorker.model.WorkflowDetailsTransaction;
import com.gic.fadv.caseCreationJsonWorker.pojo.BotActivity;
import com.gic.fadv.caseCreationJsonWorker.pojo.ResponseStatusPOJO;
import com.gic.fadv.caseCreationJsonWorker.pojo.WorkflowDetailsTransactionPOJO;

@Service
public interface WorkerService {

	JsonNode prepareJSONForBot(long workflowTransactionId, long taskListId);

	ResponseEntity<ObjectNode> acknowledgeRequest(WorkflowDetailsTransactionPOJO workflowDetailsTransactionPojo);

	ResponseEntity<ObjectNode> updateResponseJson(WorkflowDetailsTransactionPOJO workflowDetailsTransactionPojo);

	void updateBotActivityJson(BotActivity botActivity) throws SerialException;

}
