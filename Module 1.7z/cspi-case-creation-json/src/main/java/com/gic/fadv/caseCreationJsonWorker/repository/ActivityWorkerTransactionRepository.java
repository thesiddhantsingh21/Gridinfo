package com.gic.fadv.caseCreationJsonWorker.repository;

import java.time.Instant;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import com.gic.fadv.caseCreationJsonWorker.model.ActivityWorkerTransaction;


@Transactional
public interface ActivityWorkerTransactionRepository extends JpaRepository<ActivityWorkerTransaction, Long> {

	List<ActivityWorkerTransaction> findByStatus(String status);
	
	List<ActivityWorkerTransaction> findByStatusAndActivityWorkerIdIn(String status,List<Long> activityTypeId);
	
	@Modifying(clearAutomatically = true)
	@Query(value ="UPDATE workflow.activity_worker_transaction SET status = :status "
			+"WHERE activity_worker_transaction_id = (SELECT activity_worker_transaction_id FROM "+
			"workflow.activity_worker_transaction WHERE status='new' and activity_worker_id in (9,10,12,13,14,31,32,41,55,56) LIMIT 1 FOR UPDATE SKIP LOCKED) "
			+ "RETURNING \"key\"", nativeQuery = true)
	List<String> updateActivityWorkerStatus(String status);

	ActivityWorkerTransaction findByKey (String key);
}
