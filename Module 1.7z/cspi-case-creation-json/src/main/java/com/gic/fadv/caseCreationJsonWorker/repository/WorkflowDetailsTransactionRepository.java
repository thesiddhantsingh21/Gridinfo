package com.gic.fadv.caseCreationJsonWorker.repository;

import java.time.Instant;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.gic.fadv.caseCreationJsonWorker.model.WorkflowDetailsTransaction;

@Repository
@Transactional
public interface WorkflowDetailsTransactionRepository extends JpaRepository<WorkflowDetailsTransaction, Long> {
	List<WorkflowDetailsTransaction> findByStatus(String status);

	List<WorkflowDetailsTransaction> findByActivityTypeIdAndStatus(long activityTypeId, String Status);

	WorkflowDetailsTransaction findByTaskListId(Long taskListId);

	@Modifying(clearAutomatically = true)
	@Query(value = "UPDATE workflow.workflow_details_transaction SET status = :status, acknowledgement_timestamp = :responseDate, "
			+ "acknowledgement_json = CAST(:acknowledgementJson AS JSONB) WHERE task_list_id = :taskListId", nativeQuery = true)
	void updateResponseAcknowledged(String status, Instant responseDate, String acknowledgementJson, Long taskListId);

	@Modifying(clearAutomatically = true)
	@Query(value = "UPDATE workflow.workflow_details_transaction SET status = :status, response_timestamp = :responseDate, "
			+ "response_json = CAST(:responseJson AS JSONB) WHERE task_list_id = :taskListId", nativeQuery = true)
	void updateResponse(String status, Instant responseDate, String responseJson, Long taskListId);

	@Modifying(clearAutomatically = true)
	@Query(value = "UPDATE workflow.workflow_details_transaction SET status = :workflowStatus, response_timestamp = :responseDate, "
			+ "response_json = CAST(:responseJson AS JSONB), meta_data = CAST(:metaDataJson AS JSONB), bot_id = :botId WHERE task_list_id = :taskListId", nativeQuery = true)
	void updateResponseWithMetaData(String workflowStatus, Instant responseDate, String responseJson, Long taskListId, String metaDataJson, String botId);

	@Modifying(clearAutomatically = true)
	@Query(value = "UPDATE workflow.workflow_details_transaction SET status = :workflowStatus, response_timestamp = :responseDate, "
			+ "response_json = CAST(:responseJson AS JSONB), error_cause=:error_cause, bot_id = :botId, meta_data = CAST(:metaDataJson AS JSONB) WHERE task_list_id = :taskListId", nativeQuery = true)
	void updateResponseWithMetaDataAndErrorCause(String workflowStatus, Instant responseDate, String responseJson, Long taskListId,
			String metaDataJson, String error_cause, String botId);

	@Modifying(clearAutomatically = true)
	@Query(value = "UPDATE workflow.workflow_details_transaction SET bot_activities = CAST(:botActivities AS JSONB)"
			+ " WHERE task_list_id = :taskListId", nativeQuery = true)
	void updateBotActivity(String botActivities, Long taskListId);

}
