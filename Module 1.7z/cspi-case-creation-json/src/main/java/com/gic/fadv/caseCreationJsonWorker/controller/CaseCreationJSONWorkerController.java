package com.gic.fadv.caseCreationJsonWorker.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.gic.caseCreationWorker.utility.Utility;
import com.gic.fadv.caseCreationJsonWorker.model.ActivityWorkerTransaction;
import com.gic.fadv.caseCreationJsonWorker.model.WorkflowDetailsTransaction;
import com.gic.fadv.caseCreationJsonWorker.pojo.BotActivity;
import com.gic.fadv.caseCreationJsonWorker.pojo.ResponseStatusPOJO;
import com.gic.fadv.caseCreationJsonWorker.pojo.WorkflowDetailsTransactionPOJO;
import com.gic.fadv.caseCreationJsonWorker.repository.ActivityWorkerTransactionRepository;
import com.gic.fadv.caseCreationJsonWorker.repository.TaskListRepository;
import com.gic.fadv.caseCreationJsonWorker.repository.WorkflowDetailsTransactionRepository;
import com.gic.fadv.caseCreationJsonWorker.service.ApiService;
import com.gic.fadv.caseCreationJsonWorker.service.WorkerService;

import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("/api/india")
public class CaseCreationJSONWorkerController {
	
	ObjectMapper mapper = new ObjectMapper();

	private static final Logger logger = LoggerFactory.getLogger(CaseCreationJSONWorkerController.class);

	@Value("${activity.worker.transaction.update.url}")
	private String activityWorkerUpdateURL;

	@Autowired
	WorkflowDetailsTransactionRepository workflowDetailsTransactionRepository;

	@Autowired
	ApiService apiService;

	@Autowired
	ActivityWorkerTransactionRepository activityWorkerTransactionRepository;

	@Autowired
	TaskListRepository taskListRepository;

	@Autowired
	WorkerService workerService;

	@GetMapping(path = "/case-creation-json", produces = "application/json")
	public List<JsonNode> caseCreationJSON(HttpServletRequest request) {
		logger.info(request.getRemoteAddr() + "\n" + request.getLocalAddr() + "\n" + request.getRemotePort() + "\n"
				+ request.getHeaderNames());
		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

		long workflowTransactionId = 0;
		long taskListId = 0;
		long activityTypeId = 0;
		List<JsonNode> botRequest = new ArrayList<>();

//		List<ActivityWorkerTransaction> actvityWorkerTransactionList = activityWorkerTransactionRepository
//				.findByStatus("new");
		List<String> keyList = activityWorkerTransactionRepository.updateActivityWorkerStatus("issued");
		// List<Long> activityTypeIdList =new ArrayList<>();
		// activityTypeIdList.add((long) 9);
		// activityTypeIdList.add((long) 10);
		// List<ActivityWorkerTransaction> actvityWorkerTransactionList =
		// activityWorkerTransactionRepository
		// .findByStatusAndActivityWorkerIdIn("new",activityTypeIdList);
		// if (actvityWorkerTransactionList != null &&
		// !actvityWorkerTransactionList.isEmpty()) {
		// for (ActivityWorkerTransaction actvityWorkerTransaction :
		// actvityWorkerTransactionList) {
		if (CollectionUtils.isNotEmpty(keyList)) {

			ActivityWorkerTransaction actvityWorkerTransaction = activityWorkerTransactionRepository
					.findByKey(keyList.get(0));
			logger.info("Value of key:{}", actvityWorkerTransaction.getKey());
			String keys[] = actvityWorkerTransaction.getKey().split("#");

			try {
				if (keys.length == 3) {
					workflowTransactionId = Long.parseLong(keys[0]);
					taskListId = Long.parseLong(keys[1]);
					activityTypeId = Long.parseLong(keys[2]);

//						if (activityTypeId == 10 || activityTypeId == 9) {
					JsonNode botRequestJSON = workerService.prepareJSONForBot(workflowTransactionId, taskListId);
					botRequest.add(botRequestJSON);
					logger.info("Bot Request:{}", botRequest);
					// update status to completed for every task

					String id = actvityWorkerTransaction.getActivityWorkerTransactionId() + "";
					actvityWorkerTransaction.setStatus("completed");

					String activitryWorkerTransactionUpdateReqStr = mapper.writeValueAsString(actvityWorkerTransaction);
					logger.info("Value of Activity Transaction Request:{}", activitryWorkerTransactionUpdateReqStr);
					String activityUpdateURIWithId = activityWorkerUpdateURL.replace("{id}", id);

					String updatedActivityWorker = apiService.sendDataToPost(activityUpdateURIWithId,
							activitryWorkerTransactionUpdateReqStr);

					logger.info("update activity worker transaction : {}", updatedActivityWorker);
					// }
					logger.info("\nBreak\n");
					// break;
				}
			} catch (Exception e) {
				logger.info("Exception:{} ", e.getMessage());
				e.printStackTrace();
				return null;
			}

			return botRequest;
		}
		return null;
	}

	@PostMapping(path = "acknowledge-request", consumes = "application/json", produces = "application/json")
	public ResponseEntity<ObjectNode> acknowledgeRquest(
			@RequestBody WorkflowDetailsTransactionPOJO workflowDetailsTransactionPojo, HttpServletRequest request) {
		logger.info(request.getRemoteAddr() + "\n" + request.getLocalAddr() + "\n" + request.getRemotePort() + "\n"
				+ request.getHeaderNames());
		logger.info("Acknowledge:{}", workflowDetailsTransactionPojo);
		logger.info("Got Request for acknowledging response : {}", workflowDetailsTransactionPojo.getWdTransactionId());
		 
		JsonNode convertValue = mapper.convertValue(workflowDetailsTransactionPojo,JsonNode.class);
		String normalizeJsonValues = null;
		try {
			normalizeJsonValues = Utility.normalizeJsonValues(mapper.writeValueAsString(convertValue));
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		logger.info("normalizeJsonValues Response : {}",normalizeJsonValues);
		
		WorkflowDetailsTransactionPOJO response = new WorkflowDetailsTransactionPOJO();
		if(normalizeJsonValues!=null && StringUtils.isNotEmpty(normalizeJsonValues)) { 
			
		try {
			response = mapper.convertValue(mapper.readTree(normalizeJsonValues), WorkflowDetailsTransactionPOJO.class);
		} catch (JsonProcessingException | IllegalArgumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
		
		ResponseEntity<ObjectNode> ackObjectNode = workerService.acknowledgeRequest(response);
		logger.info("AckNode:{}", ackObjectNode);
		return ackObjectNode;
	}

	@PostMapping(path = "update-response", consumes = "application/json", produces = "application/json")
	public ResponseEntity<ObjectNode> updateRquestToReady(
			@RequestBody WorkflowDetailsTransactionPOJO workflowDetailsTransactionPojo, HttpServletRequest request) {
		logger.info(request.getRemoteAddr() + "\n" + request.getLocalAddr() + "\n" + request.getRemotePort() + "\n"
				+ request.getHeaderNames());

		logger.info("Got Request for updating response : {}", workflowDetailsTransactionPojo);
		logger.info("Got Request for updating response : {}", workflowDetailsTransactionPojo.getWdTransactionId());

		JsonNode convertValue = mapper.convertValue(workflowDetailsTransactionPojo,JsonNode.class);
		String normalizeJsonValues = null;
		try {
			normalizeJsonValues = Utility.normalizeJsonValues(mapper.writeValueAsString(convertValue));
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		logger.info("normalizeJsonValues Response : {}",normalizeJsonValues);
		
		WorkflowDetailsTransactionPOJO response = new WorkflowDetailsTransactionPOJO();
		if(normalizeJsonValues!=null && StringUtils.isNotEmpty(normalizeJsonValues)) { 
		try {
			response = mapper.convertValue(mapper.readTree(normalizeJsonValues), WorkflowDetailsTransactionPOJO.class);
		} catch (JsonProcessingException | IllegalArgumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
		
		return workerService.updateResponseJson(response);
	}

	@PostMapping(path = "track-activity", consumes = "application/json", produces = "application/json")
	public ResponseEntity<ResponseStatusPOJO> updateBotActivity(@RequestBody @Valid BotActivity botActivity) {

		logger.info("Got Request for updating bot activity for request_processor_id: {}",
				botActivity.getRequestProcessorId());
		logger.info("Recent bot activity : {}", botActivity);
		try {
			workerService.updateBotActivityJson(botActivity);
			return new ResponseEntity<>(new ResponseStatusPOJO(true, "Bot activity updated successfully!"), HttpStatus.OK);
		} catch (Exception ex) {
			return new ResponseEntity<>(new ResponseStatusPOJO(false, ex.getMessage()), HttpStatus.BAD_REQUEST);
		}

	}

}
