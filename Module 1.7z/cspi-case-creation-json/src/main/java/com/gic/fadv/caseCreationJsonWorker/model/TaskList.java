package com.gic.fadv.caseCreationJsonWorker.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;

import org.hibernate.annotations.Type;

import com.fasterxml.jackson.databind.JsonNode;

import lombok.Data;

@Entity
@Table(name = "task_list")
@Data
public class TaskList {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "task_list_id")
	private long taskListId;
	
	private long activityTypeId;
	@NotBlank
	private String taskListName;
	@NotBlank
	private String taskListDescription;
	
	@Type(type = "jsonb")
	@Column(columnDefinition = "jsonb", name = "request_json")
	private JsonNode requestJson;
	
	private String status;

	public TaskList() {
		super();
	}

}
