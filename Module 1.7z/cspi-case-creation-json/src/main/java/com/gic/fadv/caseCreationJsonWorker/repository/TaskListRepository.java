package com.gic.fadv.caseCreationJsonWorker.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.transaction.annotation.Transactional;

import com.gic.fadv.caseCreationJsonWorker.model.TaskList;



@Transactional
public interface TaskListRepository extends JpaRepository<TaskList, Long> {
	List<TaskList> findByStatus(String status);

	List<TaskList> findByStatusAndTaskListId(String status, long taskListId);
}
