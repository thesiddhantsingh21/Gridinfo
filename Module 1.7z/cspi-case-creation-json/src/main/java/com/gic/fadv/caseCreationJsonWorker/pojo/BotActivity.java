package com.gic.fadv.caseCreationJsonWorker.pojo;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Positive;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.JsonNode;

import lombok.Data;

@Data
public class BotActivity {
	
	@Positive
	@JsonProperty(value = "request_processor_id")
	private long requestProcessorId;
	@JsonProperty(value = "response_json")
	private JsonNode responseJson;
}
