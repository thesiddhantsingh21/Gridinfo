package com.gic.fadv.caseCreationJsonWorker.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.vladmihalcea.hibernate.type.json.JsonBinaryType;

import lombok.Data;

@Entity
@Table(name = "workflow_details_transaction")
@Data
@TypeDef(name = "jsonb", typeClass = JsonBinaryType.class)
public class WorkflowDetailsTransaction {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "wd_transcation_id")
	private long wdTransactionId;

	private long taskListId;

	private Date issuedTimestamp;
	@Type(type = "jsonb")
	@Column(columnDefinition = "jsonb", name = "request_json")
	private JsonNode requestJson;
	private Date requestTimestamp;
	@Type(type = "jsonb")
	@Column(columnDefinition = "jsonb", name = "response_json")
	private JsonNode responseJson;
	private Date responseTimestamp;
	private String status;
	@Type(type = "jsonb")
	@Column(columnDefinition = "jsonb", name = "error_json")
	private JsonNode errorJson;
	private String error_cause;
	// domain
	// activity_type_id
	// task_type_id
	// transction_id
	// corelation_id X
	@Type(type="jsonb")
	@Column(columnDefinition = "jsonb", name = "acknowledement_json")
	private JsonNode acknowledgementJson;
	private Date acknowledgementTimestamp;
	private long activityTypeId;
	private boolean isPicked;
	@Type(type = "jsonb")
	@Column(columnDefinition = "jsonb")
	private JsonNode metaData;
	
	@Type(type = "jsonb")
	@Column(columnDefinition = "jsonb", name = "bot_activities")
	private ArrayNode botActivities;
	
	private String botId;
}
