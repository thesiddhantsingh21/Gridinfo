package com.gic.fadv.caseCreationJsonWorker.service;

import java.util.Map;

import org.springframework.stereotype.Service;

@Service
public interface ApiService {

	String sendDataToGet(String url1);

	String sendDataToPost(String url1, String json);

}
