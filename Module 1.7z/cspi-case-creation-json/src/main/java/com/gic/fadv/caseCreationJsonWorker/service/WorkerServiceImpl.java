package com.gic.fadv.caseCreationJsonWorker.service;

import java.time.Instant;
import java.util.Date;

import javax.sql.rowset.serial.SerialException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.gic.fadv.caseCreationJsonWorker.model.ActivityWorkerTransaction;
import com.gic.fadv.caseCreationJsonWorker.model.TaskList;
import com.gic.fadv.caseCreationJsonWorker.model.WorkflowDetailsTransaction;
import com.gic.fadv.caseCreationJsonWorker.pojo.BotActivity;
import com.gic.fadv.caseCreationJsonWorker.pojo.ResponseStatusPOJO;
import com.gic.fadv.caseCreationJsonWorker.pojo.WorkflowDetailsTransactionPOJO;
import com.gic.fadv.caseCreationJsonWorker.repository.ActivityWorkerTransactionRepository;
import com.gic.fadv.caseCreationJsonWorker.repository.TaskListRepository;
import com.gic.fadv.caseCreationJsonWorker.repository.WorkflowDetailsTransactionRepository;

@Service
public class WorkerServiceImpl implements WorkerService {

	private static final String COMPLETED = "completed";

	private static final Logger logger = LoggerFactory.getLogger(WorkerServiceImpl.class);
	private static final String TASK_LIST_NAME = "DocValidation Worker Task";
	private static final String TASK_LIST_DESCRIPTION = "DocValidation Worker Description";
	private static final String READY = "ready";
	private static final String NEW = "new";

	@Autowired
	TaskListRepository taskListRepository;

	@Autowired
	WorkflowDetailsTransactionRepository workflowDetailsTransactionRepository;

	@Autowired
	ActivityWorkerTransactionRepository activityWorkerTransactionRepository;

	@Autowired
	ApiService apiService;

	@Value("${update.status.url}")
	String updateStatusURL;

	@Value("${update.add.check.crn}")
	String updateAddCheckCrnURL;

	ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

	private static final String SYSTEM_EXCEPTION = "system";
	private static final String BUSINESS_EXCEPTION = "business";

	@Override
	public JsonNode prepareJSONForBot(long workflowTransactionId, long taskListId) {

		JsonNode requestJSON = null;

		TaskList taskList = taskListRepository.findById(taskListId).orElse(null);

		if (taskList != null) {
			requestJSON = taskList.getRequestJson();
		}

		return requestJSON;
	}

	@Override
	public ResponseEntity<ObjectNode> acknowledgeRequest(
			WorkflowDetailsTransactionPOJO workflowDetailsTransactionPOJO) {

		logger.info("acknowledgement request :{}", workflowDetailsTransactionPOJO);

		try {

			long taskListId = workflowDetailsTransactionPOJO.getRequestProcessorId();

			ObjectNode responseJson = workflowDetailsTransactionPOJO.getResponseJson() != null
					? (ObjectNode) workflowDetailsTransactionPOJO.getResponseJson()
					: mapper.createObjectNode();

			logger.info("task list Id :{}", taskListId);

			if (!responseJson.isEmpty()) {
				workflowDetailsTransactionRepository.updateResponseAcknowledged("acknowledged", Instant.now(),
						responseJson.toString(), taskListId);
				logger.info("updated");
				return new ResponseEntity<>(createResponse("response acknowledged successfully", true), HttpStatus.OK);
			} else {
				return new ResponseEntity<>(createResponse("Incomplete data provided", false), HttpStatus.BAD_REQUEST);
			}
		} catch (Exception e) {
			return new ResponseEntity<>(createResponse(e.getMessage(), false), HttpStatus.EXPECTATION_FAILED);
		}
	}

	private ObjectNode createResponse(String response, boolean success) {
		ObjectNode returnMessage = mapper.createObjectNode();
		returnMessage.put("message", response);
		returnMessage.put("success", success);
		return returnMessage;
	}

	@Override
	public ResponseEntity<ObjectNode> updateResponseJson(
			WorkflowDetailsTransactionPOJO workflowDetailsTransactionPojo) {

		logger.info("Update request :{}", workflowDetailsTransactionPojo);

		try {
			long taskListId = workflowDetailsTransactionPojo.getRequestProcessorId();

			ObjectNode responseJson = workflowDetailsTransactionPojo.getResponseJson() != null
					? (ObjectNode) workflowDetailsTransactionPojo.getResponseJson()
					: mapper.createObjectNode();
			boolean status = false;
			String message = "";

			String exceptionType = "";
			WorkflowDetailsTransaction workflowDetailsTransaction = workflowDetailsTransactionRepository
					.findByTaskListId(taskListId);
			ResponseStatusPOJO responseStatusPOJO = new ResponseStatusPOJO();

			ObjectNode response = mapper.createObjectNode();
			String crnNo = null;
			String caseNo = null;

			String botId = responseJson.get("metadata").get("botId") != null
					? responseJson.get("metadata").get("botId").asText()
					: "";

			if (workflowDetailsTransaction != null) {

				JsonNode reqJson = workflowDetailsTransaction.getRequestJson();

				if (workflowDetailsTransaction.getActivityTypeId() == 9
						|| workflowDetailsTransaction.getActivityTypeId() == 13
						|| workflowDetailsTransaction.getActivityTypeId() == 14
						|| workflowDetailsTransaction.getActivityTypeId() == 55
						|| workflowDetailsTransaction.getActivityTypeId() == 56) {
					JsonNode caseRef = reqJson.get("requestJson").get("data").get(0).get("taskSpecs")
							.get("caseReference");
					crnNo = caseRef.get("crnNo").asText();
					caseNo = caseRef.get("caseNo").asText();

				}

				if (workflowDetailsTransaction.getActivityTypeId() == 10) {
					JsonNode caseRef = responseJson.get("data").get(0).get("result").get("caseReference");
					crnNo = caseRef.get("crnNo").asText();
					caseNo = caseRef.get("caseNo").asText();
				}
				if (workflowDetailsTransaction.getActivityTypeId() == 12) {
					JsonNode caseRef = responseJson.get("data").get(0).get("result").get("caseReference");
					crnNo = caseRef.get("crnNo").asText();
					caseNo = caseRef.get("caseNo").asText();
				}
				if (workflowDetailsTransaction.getActivityTypeId() == 41) {
					JsonNode caseRef = responseJson.get("data").get(0).get("result").get("caseReference");
					crnNo = caseRef.get("crnNo").asText();
					caseNo = caseRef.get("caseNo").asText();
				}

				if (crnNo != null) {
					responseStatusPOJO.setCrn(crnNo);
				}

				ArrayNode botJson = mapper.createArrayNode();
				botJson.add(reqJson);

				response.set("engineInput", botJson);
				response.set("engineOutput", responseJson);

				responseStatusPOJO.setSuccess(true);
				responseStatusPOJO.setMessage("Engine ran successfully");
				responseStatusPOJO.setData(response);
				try {
					status = responseJson.get("metadata").get("status").get("success").asBoolean();
					message = responseJson.get("metadata").get("status").get("message").asText();

					if (!status) {
						JsonNode exceptionTypeNode = responseJson.path("data").path(0).path("exceptions").path(0)
								.path("type");

						if (!exceptionTypeNode.isMissingNode()) {
							exceptionType = exceptionTypeNode.asText().toLowerCase();
						}
					}

				} catch (Exception e) {
					logger.info("Exception occured for Status:{}", e.getMessage());
				}
			}

			logger.info("task list Id :{}", taskListId);

			if (!responseJson.isEmpty()) {
				String responseStatusPOJOStr = mapper.writeValueAsString(responseStatusPOJO);
				if (workflowDetailsTransaction.getActivityTypeId() == 12
						|| workflowDetailsTransaction.getActivityTypeId() == 41) {
					if (status) {
						JsonNode metaDataJson = workflowDetailsTransaction.getMetaData();
						((ObjectNode) metaDataJson).put("status", COMPLETED);

						ObjectNode updateStatus = mapper.createObjectNode();
						updateStatus.put("status", "Data Entry - Completed");
						updateStatus.put("caseNo", caseNo);
						updateStatus.put("crn", crnNo);

						try {
							String updateStatusResp = apiService.sendDataToPost(updateStatusURL,
									updateStatus.toString());
							logger.info("update response for doc upload worker: {}", updateStatusResp);
						} catch (Exception e) {
							e.printStackTrace();
						}

						workflowDetailsTransactionRepository.updateResponseWithMetaData(COMPLETED, Instant.now(),
								responseStatusPOJOStr, taskListId, metaDataJson.toString(), botId);
					} else {
						JsonNode metaDataJson = workflowDetailsTransaction.getMetaData();
						((ObjectNode) metaDataJson).put("status", "docUpload failed");

						ObjectNode updateStatus = mapper.createObjectNode();
						updateStatus.put("status", "Doc Upload - Failed");
						updateStatus.put("caseNo", caseNo);
						updateStatus.put("crn", crnNo);

						try {
							String updateStatusResp = apiService.sendDataToPost(updateStatusURL,
									updateStatus.toString());
						} catch (Exception e) {
							e.printStackTrace();
						}
						String workflowStatus = getWorkflowStatusByExceptionType(exceptionType);
						workflowDetailsTransactionRepository.updateResponseWithMetaData(workflowStatus, Instant.now(),
								responseStatusPOJOStr, taskListId, metaDataJson.toString(), botId);
					}
				} else {
					if (status) {
						JsonNode metaDataJson = workflowDetailsTransaction.getMetaData();
						
						if (workflowDetailsTransaction.getActivityTypeId() == 14) {
							Boolean flag = insertForDocValidation(workflowDetailsTransaction);
							logger.info("Inserted Into Workflow:{}", flag);
						}
						
						((ObjectNode) metaDataJson).put("status", COMPLETED);

						String statusMsg = "";

						if (workflowDetailsTransaction.getActivityTypeId() == 10) {
							statusMsg = "Case Creation - Completed";
						}

						if (workflowDetailsTransaction.getActivityTypeId() == 9) {
							statusMsg = "CSPI Scoping - Completed";
						}

						if (statusMsg != "") {

							ObjectNode updateStatus = mapper.createObjectNode();
							updateStatus.put("status", statusMsg);
							updateStatus.put("caseNo", caseNo);
							updateStatus.put("crn", crnNo);

							try {
								String updateStatusResp = apiService.sendDataToPost(updateStatusURL,
										updateStatus.toString());
								logger.info("updated status in case browser: {}", updateStatusResp);
							} catch (Exception e) {
								e.printStackTrace();
							}
						}

						if (workflowDetailsTransaction.getActivityTypeId() == 31) {
							String addCheckCrn = responseJson.get("data").get(0).get("result").get("extendCaseStatus")
									.get("crnExtensionNo").asText();
							String packageName = responseJson.get("data").get(0).get("result").get("extendCase")
									.get("packageName").asText();
							String componentName = responseJson.get("data").get(0).get("result").get("extendCase")
									.get("componentName").asText();
							String statusType = responseJson.get("data").get(0).get("result").get("extendCase")
									.get("statusType").asText();

							((ObjectNode) metaDataJson).put("addCheckCrn", addCheckCrn);
							((ObjectNode) metaDataJson).put("addOnPackageName", packageName);
							((ObjectNode) metaDataJson).put("componentName", componentName);
							((ObjectNode) metaDataJson).put("statusType", statusType);

							updateAddCheckCrnInCaseDetails(metaDataJson);
						}

						workflowDetailsTransactionRepository.updateResponseWithMetaData(COMPLETED, Instant.now(),
								responseStatusPOJOStr, taskListId, metaDataJson.toString(), botId);
					} else {

						JsonNode metaDataJson = workflowDetailsTransaction.getMetaData();
						((ObjectNode) metaDataJson).put("status", "failed");

						String statusMsg = "";

						if (workflowDetailsTransaction.getActivityTypeId() == 10) {
							statusMsg = "Case Creation - Failed";
						}

						if (workflowDetailsTransaction.getActivityTypeId() == 9) {
							statusMsg = "CSPI Scoping - Failed";
						}

						if (statusMsg != "") {

							ObjectNode updateStatus = mapper.createObjectNode();
							updateStatus.put("status", statusMsg);
							updateStatus.put("caseNo", caseNo);
							updateStatus.put("crn", crnNo);

							try {
								String updateStatusResp = apiService.sendDataToPost(updateStatusURL,
										updateStatus.toString());
							} catch (Exception e) {
								e.printStackTrace();
							}
						}
						String workflowStatus = getWorkflowStatusByExceptionType(exceptionType);
						workflowDetailsTransactionRepository.updateResponseWithMetaDataAndErrorCause(workflowStatus,
								Instant.now(), responseStatusPOJOStr, taskListId, metaDataJson.toString(), message,
								botId);
					}
				}

				return new ResponseEntity<>(createResponse("response updated successfully", true), HttpStatus.OK);
			} else {
				return new ResponseEntity<>(createResponse("Incomplete data provided", false), HttpStatus.BAD_REQUEST);
			}
		} catch (Exception e) {
			return new ResponseEntity<>(createResponse(e.getMessage(), false), HttpStatus.EXPECTATION_FAILED);
		}
	}

	public void updateAddCheckCrnInCaseDetails(JsonNode metaData) {
		String addCheckCrn = metaData.get("addCheckCrn").asText();
		String caseNo = metaData.get("caseNo").asText();

		ArrayNode updatedCrnNode = mapper.createArrayNode();
		updatedCrnNode.add(addCheckCrn);

		String updateAddCheckCrnURLwithCaseNo = updateAddCheckCrnURL.replace("{caseNo}", caseNo);

		String response = apiService.sendDataToPost(updateAddCheckCrnURLwithCaseNo, updatedCrnNode.toString());
		logger.info("Updated addcheck crn in casedetails: {}", response);
	}

	@Override
	public void updateBotActivityJson(BotActivity botActivity) throws SerialException {
		long requestProcessorId = botActivity.getRequestProcessorId();
		JsonNode responseJson = botActivity.getResponseJson();

		WorkflowDetailsTransaction workflowDetailsTransaction = workflowDetailsTransactionRepository
				.findByTaskListId(requestProcessorId);

		if (workflowDetailsTransaction == null) {
			throw new SerialException("Invalid request processor Id");
		}

		ArrayNode botActivities = workflowDetailsTransaction.getBotActivities() != null
				? workflowDetailsTransaction.getBotActivities()
				: mapper.createArrayNode();

		botActivities.add(responseJson);

		workflowDetailsTransactionRepository.updateBotActivity(botActivities.toString(), requestProcessorId);
	}

	private Boolean insertForDocValidation(WorkflowDetailsTransaction workflowDetailsTransaction) {
		long taskListId = insertIntoTaskList(1, workflowDetailsTransaction.getResponseJson(), TASK_LIST_NAME,
				TASK_LIST_DESCRIPTION);
		logger.info("DocValidation TaskListId:{}", taskListId);
		if (taskListId == 0) {
			return false;
		}
		long workflowDetailsTransactionId = insertIntoWorkflowDetailsTransaction(1,
				workflowDetailsTransaction.getResponseJson(), workflowDetailsTransaction.getMetaData(), taskListId);
		logger.info("DocValidation WorkflowDetailsTransactionId:{}", workflowDetailsTransactionId);

		if (workflowDetailsTransactionId == 0) {
			return false;
		}
		long activityId = insertIntoActivityWorkerTransaction(1, workflowDetailsTransactionId, taskListId);
		logger.info("DocValidation ActivityWorkerTransactionId:{}", activityId);

		if (activityId == 0) {
			return false;
		}
		return true;
	}

	private long insertIntoTaskList(long activityTypeId, JsonNode responseJson, String activityWorkerDescription,
			String taskListname) {

		TaskList taskList = new TaskList();
		taskList.setActivityTypeId(activityTypeId);
		taskList.setRequestJson(responseJson);
		taskList.setStatus(READY);
		taskList.setTaskListDescription(activityWorkerDescription);
		taskList.setTaskListName(taskListname);
		TaskList taskList2 = taskListRepository.save(taskList);

		if (taskList2 != null) {
			return taskList2.getTaskListId();
		}
		return 0;
	}

	private long insertIntoWorkflowDetailsTransaction(long activityTypeId, JsonNode responseJson, JsonNode metaData,
			long taskListId) {

		JsonNode metaJsonNode = metaData;
		((ObjectNode) metaJsonNode).put("status", READY);
		WorkflowDetailsTransaction workflowDetailsTransaction = new WorkflowDetailsTransaction();
		workflowDetailsTransaction.setTaskListId(taskListId);
		workflowDetailsTransaction.setActivityTypeId(activityTypeId);
		workflowDetailsTransaction.setRequestJson(responseJson);
		workflowDetailsTransaction.setRequestTimestamp(new Date());
		workflowDetailsTransaction.setMetaData(metaJsonNode);
		workflowDetailsTransaction.setStatus(READY);
		workflowDetailsTransaction.setResponseJson(mapper.createObjectNode());
		WorkflowDetailsTransaction workflowTransactionId = workflowDetailsTransactionRepository
				.save(workflowDetailsTransaction);
		if (workflowTransactionId != null) {
			return workflowTransactionId.getWdTransactionId();
		}

		return 0;
	}

	private long insertIntoActivityWorkerTransaction(long activityTypeId, long workflowDetailsTransactionId,
			long taskListId) {

		ActivityWorkerTransaction activityWorkerTransaction = new ActivityWorkerTransaction();
		activityWorkerTransaction.setKey(workflowDetailsTransactionId + "#" + taskListId + "#" + activityTypeId);

		activityWorkerTransaction.setActivityWorkerId(activityTypeId);
		activityWorkerTransaction.setStatus(NEW);
		ActivityWorkerTransaction activityWorkerTransactionId = activityWorkerTransactionRepository
				.save(activityWorkerTransaction);
		if (activityWorkerTransactionId != null) {
			return activityWorkerTransactionId.getActivityWorkerTransactionId();
		}
		return 0;
	}

	private String getWorkflowStatusByExceptionType(String exceptionType) {
		String workflowStatus = COMPLETED;

		if (exceptionType.contains(SYSTEM_EXCEPTION)) {
			workflowStatus = "failed";
		} 
		return workflowStatus;
	}

}
