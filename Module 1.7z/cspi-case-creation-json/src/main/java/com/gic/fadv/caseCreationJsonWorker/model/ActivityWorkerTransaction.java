package com.gic.fadv.caseCreationJsonWorker.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(name = "activity_worker_transaction")
@Data
public class ActivityWorkerTransaction {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "activity_worker_transaction_id")
	private long activityWorkerTransactionId;
	private long activityWorkerId;
	private String key; //key (JWT Token)
	public ActivityWorkerTransaction() {
		super();
	}

	private String status;
}
