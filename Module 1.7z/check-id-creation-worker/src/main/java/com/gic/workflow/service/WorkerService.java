package com.gic.workflow.service;

import org.springframework.stereotype.Service;

import com.gic.workflow.exception.ServiceException;
import com.gic.workflowlib.worker.Worker;

@Service
public interface WorkerService {
	boolean workerCheckCreation(long workflowTransactionId, long taskListId, Worker worker,
			Long activityWorkerTransactionId) throws ServiceException;
}
