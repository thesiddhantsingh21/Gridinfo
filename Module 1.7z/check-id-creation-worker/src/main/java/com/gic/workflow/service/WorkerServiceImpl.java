package com.gic.workflow.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.gic.workflow.exception.ServiceException;
import com.gic.workflowlib.constants.ErrorType;
import com.gic.workflowlib.model.WorkflowDetailsTransaction;
import com.gic.workflowlib.utility.Utility;
import com.gic.workflowlib.worker.Worker;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class WorkerServiceImpl implements WorkerService {

	ObjectMapper mapper = new ObjectMapper();

	private static String[] MANUAL_MSGS = { "manual", "matching rule not found" };

	@Autowired
	ApiService apiService;

	@Value("${save.response.url}")
	private String saveResponseURL;

	@Value("${manual.scoping.url}")
	String manualScopingURL;

	@Value("${update.status.url}")
	String updateStatusURL;

	@Override
	public boolean workerCheckCreation(long workflowTransactionId, long taskListId, Worker worker,
			Long activityWorkerTransactionId) throws ServiceException {
		String response = null;
		String caseNo = null;
		String engineOutput = "";
		JsonNode requestJSON = mapper.createObjectNode();
		WorkflowDetailsTransaction workflowDetailsTransaction = worker.fetchMetaData(workflowTransactionId);

//		String json = Database.getEngienOutputData(workflowTransactionId);
		String json = workflowDetailsTransaction.getRequestJson();
		try {
			requestJSON = Utility.convertStringToJsonNode(json);
			engineOutput = requestJSON.path("response").path("engineOutput").toString();
			System.out.println("engineOutput:{}" + engineOutput);

		} catch (Exception e1) {
			e1.printStackTrace();
		}
//		String crnNo = Database.getCRNFromTastList(taskListId);
		String crnNo = requestJSON.get("crn").asText();

		if (crnNo != null && !crnNo.equals("")) {

			if (!crnNo.equalsIgnoreCase("pending")) {
//				String reqURL = scopingURL.replace("{crNo}", crnNo);
				response = apiService.sendDataToPost(saveResponseURL, engineOutput);
			}

			if (response != null && !response.equalsIgnoreCase("")) {

				try {
					JsonNode responseJson = mapper.readTree(response);
					((ObjectNode) responseJson).put("crn", crnNo);

					String status = "completed";
					boolean responseStatus = responseJson.get("success").asBoolean();
					String error_cause = null;

					if (!responseStatus) {
						status = "failed";
						error_cause = responseJson.get("successMsg").asText();
					}

					String metaDataStr = workflowDetailsTransaction.getMetaData();
					JsonNode metaData = Utility.convertStringToJsonNode(metaDataStr);
					((ObjectNode) metaData).put("status", status);

					boolean isTaskUpdated = worker.updateTask(status, ErrorType.NONE, error_cause, error_cause,
							workflowTransactionId, activityWorkerTransactionId, responseJson.toString(),
							metaData.toString());
					log.info("task Status " + isTaskUpdated);
				} catch (Exception e) {
					e.printStackTrace();
					throw new ServiceException("Unable to parse response json");
				}
			}
		}
		return true;
	}

}
