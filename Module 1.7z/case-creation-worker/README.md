# fiesta-boot

This project is used to convert different files to pdf and combine them.  

## Getting Started

1. Clone the project 
```
git clone https://github.com/Grid-Infocom-Pvt-Ltd/fiesta-boot.git
```
2. Open the Spring Tool Suite. Browse to the cloned directory of Projects and open the project.

### Prerequisites

1. Java 8 :- https://www.oracle.com/in/java/technologies/javase/javase-jdk8-downloads.html
2. Maven :- https://maven.apache.org/download.cgi?Preferred=ftp://ftp.osuosl.org/pub/apache/
3. Postgres:- https://www.postgresql.org/download/
4. Spring Tool Suite:- https://www.postgresql.org/download/
5. Lombok:- https://projectlombok.org/download
6. Add maven dependencies: aspose-email-21.3-java, aspose-imaging-21.4, aspose-words-21.4.0-java, aspose.pdf-21.4-java :: Refer: pom.xml

### Installing

A step by step series of examples that tell you how to get a development env running

Say what the step will be

```
Give the example
```

And repeat

```
until finished
```

End with an example of getting some data out of the system or using it for a little demo

## Usage

Write usage instructions


## Running the tests

Explain how to run the automated tests for this system

### Break down into end to end tests

Explain what these tests test and why

```
Give an example
```

### And coding style tests

Explain what these tests test and why

```
Give an example
```

## Deployment

Add additional notes about how to deploy this on a live system

## Built With

* [Spring Boot](https://spring.io/projects/spring-boot) - The web framework used
* [Maven](https://maven.apache.org/) - Dependency Management

## Contributing

1. Fork it!
2. Create your feature branch: `git checkout -b my-new-feature`
3. Commit your changes: `git commit -am 'Add some feature'`
4. Push to the branch: `git push origin my-new-feature`
5. Submit a pull request :D


## License

This will require Aspose License for Prodction uses
