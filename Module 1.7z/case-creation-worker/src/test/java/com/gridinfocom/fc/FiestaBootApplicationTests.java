package com.gridinfocom.fc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FiestaBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
