package com.gic.workflow.model;

import java.util.Date;

import com.fasterxml.jackson.databind.JsonNode;

import lombok.Data;

@Data
public class TaskListPOJO {

	private long taskListId;

	private long activityTypeId;
	private String taskListName;
	private String taskListDescription;

//	@Type(type = "jsonb")
//	@Column(columnDefinition = "jsonb", name = "request_json")
//	private JsonNode requestJson;
	private JsonNode requestJson;
	private String status;
	private Date createDate;
	private Date updatedDate;
}
