package com.gic.workflow.model;

import java.util.Date;


import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.JsonNode;

import lombok.Data;

@Data

public class RuleServiceRequestResponsePOJO {
	private int id;
	private String requestId;
	private String clientName;
	private String clientReference;
	private String receivedRequest;
	private String request;
	private String response;
	private String caseNumber;
	private String crn;
	private String dataEntryStatus;
	private String packageName;
	private String sbu;
	private String oldCRNNumber;
	private JsonNode caseFailReasons;
	private Date creationDate;
	private String autoPI;
}