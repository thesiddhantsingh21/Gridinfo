package com.gic.workflow.model;

import java.util.Date;

import lombok.Data;

@Data
public class ExcelCaseCreationRequest {
	private Long id;
    String referenceId;
    String requestId;
    String clientName;
    String requestJson;
    String fileConvertionErrorJson;
    String fileUploadStatus;
    Date fileUploadedTimestamp;
    String fileConvertedStatus;
    String fileConvertedError;
    Date fileConvertedTimestamp;
    String caseCreationRequestToL3Status;
    Date caseCreationRequestToL3Timestamp;
    String caseCreationResponseToL3Status;
    Date caseCreationResponseToL3Timestamp;
    String caseCreationReqJson;
    String caseCreationResJson;
    private String transactionId;
}
