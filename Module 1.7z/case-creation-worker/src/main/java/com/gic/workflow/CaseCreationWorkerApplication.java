package com.gic.workflow;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.gic.workflow.service.WorkerService;
import com.gic.workflowlib.constants.ErrorType;
import com.gic.workflowlib.model.ActivityWorkerTransaction;
import com.gic.workflowlib.worker.Worker;

@SpringBootApplication
public class CaseCreationWorkerApplication implements CommandLineRunner {
	private static final Logger logger = LoggerFactory.getLogger(CaseCreationWorkerApplication.class);
	@Value("${database}")
	String database;
	@Value("${dbUserName}")
	String dbUserName;
	@Value("${password}")
	String password;
	@Value("${enableSSL}")
	String enableSSL = "false";
	@Value("${host}")
	String host;
	@Value("${schema}")
	String schema;
	@Value("${currentWorker}")
	String currentWorker;
	@Value("${heart.beat.url}")
	String heartBeatUrl;
	static String heartBeatUrl1;
//	@Value("${should.send.heartbeat}")
//	String shouldSendHeartBeat;
//	static String shouldSendHeartBeat1;

	@Autowired
	private WorkerService workerService;

	static Map<String, Long> activityWorkerMap = new HashMap<String, Long>();

	public static void main(String[] args) {
		SpringApplication.run(CaseCreationWorkerApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		logger.info("Running Spring Boot Application");
		logger.info(currentWorker);
		this.heartBeatUrl1 = heartBeatUrl;
//		this.shouldSendHeartBeat1 = shouldSendHeartBeat;

		Map<String, String> configMap = new HashMap<>();
		configMap.put("database", database);
		configMap.put("user", dbUserName);
		configMap.put("password", password);
		configMap.put("host", host);
		configMap.put("schema", schema);
		configMap.put("currentWorker", currentWorker);

		Worker worker = new Worker(configMap).init();

		int delay = 0;
		boolean more = true;
		while (more) {
			if (processNextBatch(workerService, worker)) {
				delay = 0;
			} else {
				delay = delay + 10;
				if (delay > 60) {
					delay = 10;
				}
			}
			more = pause(delay);
		}

	}

	private static boolean pause(int factor) {
		try {
			logger.info("sleeping for " + factor + " seconds");
			TimeUnit.SECONDS.sleep(factor);
		} catch (InterruptedException e) {
			logger.error("Interrupted");
			return false;
		}
		return true;
	}

	private static boolean processNextBatch(WorkerService workerService, Worker worker) {

//		if(Boolean.parseBoolean(shouldSendHeartBeat1)) {
//			Utility.sendHeartBeat(heartBeatUrl1);
//		}

		ActivityWorkerTransaction activityWorkerTransaction = worker.getTask();

		if (activityWorkerTransaction == null) {
			return false;
		}
		long workflowTransactionId = 0;
		long taskListId = 0;

		logger.info("Value of key:{}", activityWorkerTransaction.getKey());
		String keys[] = activityWorkerTransaction.getKey().split("#");
		Long activityWorkerTransactionId = activityWorkerTransaction.getActivityWorkerTransactionId();
		try {
			if (keys.length == 3) {
				workflowTransactionId = Long.parseLong(keys[0]);
				taskListId = Long.parseLong(keys[1]);
				boolean updateFlag = workerService.workerCheckCreation(workflowTransactionId, taskListId, worker,
						activityWorkerTransactionId);
				logger.info("Case Creation worker ran successfully", updateFlag);
			}

		} catch (Exception e) {
			logger.info("Exception:{} ", e.getMessage());
			e.printStackTrace();
			worker.updateWorkerError(ErrorType.DATA_ERROR, "Exception occured: " + e.getMessage(), e.toString(),
					workflowTransactionId);
			return false;
		}

		return true;
	}
}