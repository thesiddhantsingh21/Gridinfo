package com.gic.workflow.model;

import java.util.Date;

import lombok.Data;

@Data
public class RuleServiceRequestResponse {
	private int id;
	private String requestId;
	private String clientName;
	private String clientReference;
	private String receivedRequest;
	private String request;
	private String response;
	private String caseNumber;
	private String crn;
	private String dataEntryStatus;
	private String packageName;
	private String sbu;
	private String oldCRNNumber;
	private String caseFailReasons;
	private Date creationDate;
	private String autoPI;
}