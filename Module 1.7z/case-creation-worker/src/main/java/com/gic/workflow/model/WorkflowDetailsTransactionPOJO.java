package com.gic.workflow.model;

import java.util.Date;

import com.fasterxml.jackson.databind.JsonNode;

import lombok.Data;

@Data
public class WorkflowDetailsTransactionPOJO {
	private long wdTransactionId;

	private long taskListId;

	private Date issuedTimestamp;
	// @Type(type = "jsonb")
	// @Column(columnDefinition = "jsonb", name = "request_json")
	// private JsonNode requestJson;
	private JsonNode requestJson;
	private Date requestTimestamp;
//	@Type(type = "jsonb")
//	@Column(columnDefinition = "text", name = "response_json")
//	private JsonNode responseJson;
	private String responseJson;
	private Date responseTimestamp;
	private String status;
//	@Type(type = "jsonb")
//	@Column(columnDefinition = "jsonb", name = "error_json")
//	private JsonNode errorJson;
	private String errorJson;
	private String error_cause;
	private long activityTypeId;
	private boolean isPicked;

//	@Type(type = "jsonb")
//	@Column(columnDefinition = "jsonb")
//	private JsonNode metaData;
	private JsonNode metaData;

}
