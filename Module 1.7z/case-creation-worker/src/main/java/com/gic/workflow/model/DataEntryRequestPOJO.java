package com.gic.workflow.model;

import java.util.Date;

import com.fasterxml.jackson.databind.JsonNode;


import lombok.Data;

@Data
public class DataEntryRequestPOJO {
	private int id;
	private Integer parentId;
	private String requestId;
	private String clientName;
	private String clientReference;
	private JsonNode request;
	private JsonNode response;
	private String caseNumber;
	private String crn;
	private JsonNode dataEntryFailReasons;
	private JsonNode manualDataEntry;
	private Date creationDate;
}