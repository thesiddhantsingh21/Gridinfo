package com.gic.workflow.service;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.gic.workflow.model.ActivityWorkerTransactionPOJO;
import com.gic.workflow.model.DataEntryRequestPOJO;
import com.gic.workflow.model.ExcelCaseCreationRequest;
import com.gic.workflow.model.RuleServiceRequestResponse;
import com.gic.workflow.model.RuleServiceRequestResponsePOJO;
import com.gic.workflow.model.TaskListPOJO;
import com.gic.workflow.model.WorkflowDetailsTransactionPOJO;
import com.gic.workflowlib.constants.ErrorType;
import com.gic.workflowlib.model.WorkflowDetailsTransaction;
import com.gic.workflowlib.worker.Worker;

@Service
public class WorkerServiceImpl implements WorkerService {
	private static final Logger logger = LoggerFactory.getLogger(WorkerServiceImpl.class);

	ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

	@Autowired
	ApiService apiService;

	@Value("${update.crn.worker.url}")
	private String updateCrnURL;

	@Value("${allocate.task.url}")
	private String allocateTaskURL;

	@Value("${update.status.url}")
	String updateStatusURL;

	@Value("${case.origin.url}")
	String caseOriginUrl;

	@Value("${xls.request.details.url}")
	String xlsRequestUrl;

	@Value("${touchless.request.details.url}")
	String touchlessRequestUrl;

	@Value("${touchless.request.url}")
	String touchlessUrl;

	@Value("${xls.currentWorker}")
	String xlsCurrentWorker;

	@Value("${xls.taskListName}")
	String xlsTaskListName;

	@Value("${xls.taskListDescription}")
	String xlsTaskListDescription;

	@Value("${touchless.rule.service.request.url}")
	String updateRuleServiceUrl;

	@Value("${touchless.rule.data.entry.request.url}")
	String updateDataEntryUrl;

	@Value("${workflow.activity.worker.url}")
	private String activityWorkerURL;

	@Value("${workflow.taskList.url}")
	private String workflowTaskListURL;

	@Value("${workflow.workflow.details.transaction.url}")
	private String workflowWorkflowDetailsTransactionURL;

	@Value("${workflow.activity.worker.transaction.url}")
	private String workflowActivityWorkerURL;

	@Override
	public boolean workerCheckCreation(long workflowTransactionId, long taskListId, Worker worker,
			long activityWorkerTransactionId) {
		String response = null;

		WorkflowDetailsTransaction workflowDetailsTransaction = worker.fetchMetaData(workflowTransactionId);
		String crnNoRequestStr = workflowDetailsTransaction.getRequestJson();
		JsonNode crnNoRequestJson = null;
		String errorCause = null;
		try {
			crnNoRequestJson = mapper.readTree(crnNoRequestStr);
		} catch (JsonMappingException e1) {
			e1.printStackTrace();
		} catch (JsonProcessingException e1) {
			e1.printStackTrace();
		}
		if (crnNoRequestJson != null) {
			String crnNo = crnNoRequestJson.has("crn") ? crnNoRequestJson.get("crn").asText() : "";
			if (crnNo != null && !crnNo.equals("")) {

				if (!crnNo.equalsIgnoreCase("pending")) {

					JsonNode caseReference = crnNoRequestJson.get("response").get("engineOutput").get("data").get(0)
							.get("result").get("caseReference");
					ObjectNode reqJSON = mapper.createObjectNode();
					reqJSON.set("caseDetailsId", caseReference.get("caseUUID"));
					reqJSON.set("crn", caseReference.get("crnNo"));
					reqJSON.set("crnCreatedDate", caseReference.get("crnCreatedDate"));
					ArrayNode reqJSONArr = mapper.createArrayNode();
					reqJSONArr.add(reqJSON);
					response = apiService.sendDataToPost(updateCrnURL, reqJSONArr.toString());
				}

				if (response != null && !response.equalsIgnoreCase("")) {

					try {
						JsonNode responseJson = mapper.readTree(response);
						if (responseJson.isArray()) {
							responseJson = ((ArrayNode) responseJson).get(0);
						}

						String metaDataStr = workflowDetailsTransaction.getMetaData();
						JsonNode metaData = metaDataStr != null ? mapper.readTree(metaDataStr)
								: mapper.createObjectNode();
						((ObjectNode) metaData).put("crnNo", crnNo);
						((ObjectNode) metaData).put("status", "completed");
						logger.info("MetaData After set Values:{}", metaData);

						String caseNo = metaData.get("caseNo").asText();
						worker.updateCrnInPreviousWorkers(caseNo, crnNo);
						boolean isTaskUpdated = worker.updateTask("completed", ErrorType.NONE, errorCause, errorCause,
								workflowTransactionId, activityWorkerTransactionId,
								mapper.writeValueAsString(responseJson), mapper.writeValueAsString(metaData));
						logger.info("task Status " + isTaskUpdated);
						ObjectNode updateStatus = mapper.createObjectNode();
						updateStatus.put("status", "Data Entry - Pending");
						updateStatus.put("caseNo", caseNo);
						updateStatus.put("crn", crnNo);

						try {

							String updateStatusResp = apiService.sendDataToPost(updateStatusURL,
									updateStatus.toString());
						} catch (Exception e) {
							e.printStackTrace();
						}

						// Check the case origin
						logger.info("Value of Case No:{}", caseNo);
						String caseOriginUrl1 = caseOriginUrl + caseNo;
						logger.info("Value of caseOriginUrl:{}", caseOriginUrl1);
						String caseOriginResponse = apiService.sendDataToGet(caseOriginUrl1);
						logger.info("Case Origin API Response:{}", caseOriginResponse);
						JsonNode caseOriginNode = null;
						try {
							caseOriginNode = mapper.readTree(caseOriginResponse);
						} catch (Exception e) {
							logger.info("Exception :{}", e.getMessage());
						}
						logger.info("CaseOriginNode:{}", caseOriginNode);
						String caseOrigin = "";
						String requestId = "";
						if (caseOriginNode != null && caseOriginNode.has("success")) {
							if (caseOriginNode.get("success").asBoolean()) {
								JsonNode responseOrg = caseOriginNode.get("response");
								logger.info("responseOrg:{}", responseOrg);
								caseOrigin = responseOrg.get("caseOrigin").asText();
								logger.info("CaseOrigin:{}", responseOrg.get("caseOrigin").asText());
								requestId = responseOrg.get("requestId").asText();
								((ObjectNode) metaData).put("caseSource", caseOrigin);
							}
						}
						logger.info("Value of caseOrigin:{}", caseOrigin);
						logger.info("Value of requestId:{}", requestId);
						logger.info("Value of metadata:{}", metaData);
						// if(caseOrigin.equalsIgnoreCase("XL_UPLOAD")) {
						if (caseOrigin.equalsIgnoreCase("XLS_CASE_DE")
								|| caseOrigin.equalsIgnoreCase("TOUCHLESS_CASE_DE")
								|| caseOrigin.equalsIgnoreCase("TOUCHLESS")) {
							insertDataToWorkflow(requestId, metaData, caseOrigin);
						} else {
							// Now Allocate the task to user
							allocateCase(metaData);
						}

						// Now Allocate the task to user
//						allocateCase(metaData);
					} catch (Exception e) {
						e.printStackTrace();
						return false;
					}
				}
			}
		}
		return true;
	}

	private void allocateCase(JsonNode metaData) {
		ObjectNode allocateTaskNode = mapper.createObjectNode();
		// {"crnNo": "R276-7813097-WEST-2022", "caseNo": "1643122547747", "status":
		// "completed", "checkId": "", "caseUUID": 636}
		// {"caseNo":"1642162344790","taskType":"Data
		// Entry","caseDetailId":392,"crn":"R276-7787132-WEST-2022"}
		if (metaData != null) {
			allocateTaskNode.set("caseNo", metaData.get("caseNo"));
			allocateTaskNode.put("taskType", "Data Entry");
			allocateTaskNode.set("caseDetailId", metaData.get("caseUUID"));
			allocateTaskNode.set("crn", metaData.get("crnNo"));
		}
		if (allocateTaskNode != null && !allocateTaskNode.isEmpty()) {
			// Now call The End point
			String allocateTaskNodeResponse = apiService.sendDataToPost(allocateTaskURL, allocateTaskNode.toString());
			logger.info("Task Allocateed to user{}", allocateTaskNodeResponse);
		}
	}

	private void insertDataToWorkflow(String requestId, JsonNode metaData, String caseOrigin) {
		logger.info("Value of RequestId:{}", requestId);
		String caseNo = metaData.get("caseNo").asText();
		String crn = metaData.get("crnNo").asText();
		String client = metaData.get("client").asText();
		String manual = null;
		String manual1 = null;
		JsonNode manulNode = null;
		if (StringUtils.isNotEmpty(requestId)) {
			// Now call the API and make request for auto data Entry
			ExcelCaseCreationRequest excelCaseCreationRequest = new ExcelCaseCreationRequest();
			RuleServiceRequestResponse ruleServiceRequestResponse = new RuleServiceRequestResponse();
			String caseCreationReqJsonStr = "";
			ObjectNode requestNode = mapper.createObjectNode();
			requestNode.put("requestId", requestId);
			logger.info("Request Node:{}", requestNode.toString());
			if (caseOrigin.equalsIgnoreCase("XLS_CASE_DE")) {
				String response = null;
				try {
					response = apiService.sendDataToPost(xlsRequestUrl, requestNode.toString());
				} catch (Exception e2) {
					e2.printStackTrace();
				}
				if (response != null) {
					JsonNode responseJsonNode = null;
					try {
						responseJsonNode = mapper.readTree(response);
					} catch (JsonProcessingException e1) {
						e1.printStackTrace();
					}
					if (responseJsonNode != null) {
						if (responseJsonNode.has("success") && responseJsonNode.get("success").booleanValue()) {
							List<ExcelCaseCreationRequest> excelCaseCreationRequestList = new ArrayList<>();
							try {
								JsonNode responseNode = responseJsonNode.get("response");
								excelCaseCreationRequestList = mapper.readValue(mapper.writeValueAsString(responseNode),
										new TypeReference<List<ExcelCaseCreationRequest>>() {
										});
							} catch (JsonProcessingException e) {
								e.printStackTrace();
							}
							if (CollectionUtils.isNotEmpty(excelCaseCreationRequestList)) {
								excelCaseCreationRequest = excelCaseCreationRequestList.get(0);
							}
						} else {
							logger.info("Value of responseJsonNode is not success");
						}

					} else {
						logger.info("Value of responseJsonNode is Null");
					}
				} else {
					logger.info("Value of response is Null");
				}
				caseCreationReqJsonStr = excelCaseCreationRequest.getCaseCreationReqJson();
			} else if (caseOrigin.equalsIgnoreCase("TOUCHLESS_CASE_DE")) {
				String response = apiService.sendDataToPost(touchlessRequestUrl, requestNode.toString());
				if (response != null && !response.equals("[]")) {
					List<RuleServiceRequestResponse> ruleServiceRequestResponseList = new ArrayList<>();
					try {
						ruleServiceRequestResponseList = mapper.readValue(response,
								new TypeReference<List<RuleServiceRequestResponse>>() {
								});
					} catch (JsonProcessingException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					if (CollectionUtils.isNotEmpty(ruleServiceRequestResponseList)) {
						ruleServiceRequestResponse = ruleServiceRequestResponseList.get(0);
						manual = ruleServiceRequestResponse.getDataEntryStatus();
					}
				}
				caseCreationReqJsonStr = ruleServiceRequestResponse.getRequest();
			} else {
				// Call Two Endpoints and Update the case number and crn in request
				DataEntryRequestPOJO dataEntryRequestPOJO = new DataEntryRequestPOJO();
				dataEntryRequestPOJO.setCaseNumber(caseNo);
				dataEntryRequestPOJO.setCrn(crn);
				dataEntryRequestPOJO.setRequestId(requestId);
				RuleServiceRequestResponsePOJO ruleServiceRequestResponsePOJO = new RuleServiceRequestResponsePOJO();
				ruleServiceRequestResponsePOJO.setCaseNumber(caseNo);
				ruleServiceRequestResponsePOJO.setCrn(crn);
				ruleServiceRequestResponsePOJO.setRequestId(requestId);
				try {
					JsonNode dataEntryRequestNode = mapper.convertValue(dataEntryRequestPOJO, JsonNode.class);
					JsonNode ruleServiceRequestNode = mapper.convertValue(dataEntryRequestPOJO, JsonNode.class);
				
					logger.info("dataEntryRequestNode:{}", dataEntryRequestNode.toString());
					logger.info("ruleServiceRequestNode:{}", ruleServiceRequestNode.toString());
					// localhost:8890/api/india/rule-service/update-request
					// localhost:8890/api/india/data-entry/update-request
					String response = apiService.sendDataToPost(updateRuleServiceUrl,
							ruleServiceRequestNode.toString());
					String response1 = apiService.sendDataToPost(updateDataEntryUrl, ruleServiceRequestNode.toString());

				} catch (Exception e) {
					logger.info("Exception Occured:{}", e.getMessage());
				}

				String response = apiService.sendDataToPost(touchlessUrl, requestNode.toString());
				logger.info("Reponse:{}", response);
//				ruleServiceRequestResponse = response;
				try {
					 manulNode = mapper.readTree(response);
					 JsonNode manualData = manulNode.get("manualDataEntry");
					 if(!manualData.isNull()) {
						 manual1 = manualData.asText();
					 }
					 
				} catch (JsonMappingException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (JsonProcessingException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				
				try {
					ruleServiceRequestResponse = mapper.readValue(response,
							new TypeReference<RuleServiceRequestResponse>() {
							});
				} catch (JsonMappingException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (JsonProcessingException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				caseCreationReqJsonStr = ruleServiceRequestResponse.getRequest();
				manual = ruleServiceRequestResponse.getDataEntryStatus();
			}

			logger.info("excelCaseCreationRequest Json:{}", caseCreationReqJsonStr);
			if (StringUtils.isNoneEmpty(caseCreationReqJsonStr)) {
				String responseStr = "";
				String activityWorkerid = "";
				ObjectNode activityWorkerRequestJson = mapper.createObjectNode();
				activityWorkerRequestJson.put("activityWorkerName", xlsCurrentWorker);
				String str = activityWorkerRequestJson.toString();

				try {
					responseStr = apiService.sendDataToPost(activityWorkerURL, str);
					JsonNode responseJson = mapper.readTree(responseStr);
					JsonNode responseArr = responseJson.get(0);
					activityWorkerid = responseArr.get("activityWorkerId").asText();
				} catch (Exception e1) {
					e1.printStackTrace();
					logger.info("Exception:{}", e1.getMessage());
				}
				logger.info("ActivityWorkerId :{}", activityWorkerid);

				TaskListPOJO taskListPOJO = new TaskListPOJO();
				taskListPOJO.setActivityTypeId(Long.parseLong(activityWorkerid));
				try {
					taskListPOJO.setRequestJson(mapper.readTree(caseCreationReqJsonStr));
				} catch (JsonProcessingException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				String ready = "ready";
				String newStatus = "new";
				//// Client Manual
				if((client.equalsIgnoreCase("Cognizant") || client.equalsIgnoreCase("Cognizant Technology Solutions (IT)")) && !StringUtils.isEmpty(manual1)) {
					ready = "manual";
					newStatus = "completed";
				}
				////////////////////////////////////
				taskListPOJO.setStatus(ready);
				taskListPOJO.setTaskListDescription(xlsTaskListDescription);
				taskListPOJO.setTaskListName(xlsTaskListName);

				String taskListId = insertIntoTaskList(taskListPOJO);
				logger.info("taskListId: " + taskListId);
				/*---------------------WorkFlow Transaction---------------*/
				WorkflowDetailsTransactionPOJO workflowDetailsTransactionPOJO = new WorkflowDetailsTransactionPOJO();
				workflowDetailsTransactionPOJO.setTaskListId(Long.parseLong(taskListId));
				workflowDetailsTransactionPOJO.setActivityTypeId(Long.parseLong(activityWorkerid));
				try {
					workflowDetailsTransactionPOJO.setRequestJson(mapper.readTree(caseCreationReqJsonStr));
					((ObjectNode) metaData).put("status", ready);
					workflowDetailsTransactionPOJO.setMetaData(metaData);
				} catch (JsonProcessingException e) {
					e.printStackTrace();
				}
				if(ready.equalsIgnoreCase("manual"))
					workflowDetailsTransactionPOJO.setStatus("completed");
				else
					workflowDetailsTransactionPOJO.setStatus(ready);

				String workflowDetailsTransactionId = insertWorkDetailTransaction(workflowDetailsTransactionPOJO);
				logger.info("workflowDetailsTransactionId: " + workflowDetailsTransactionId);
				// Updating the request_json with wd_transaction_id

				ActivityWorkerTransactionPOJO activityWorkerTransaction = new ActivityWorkerTransactionPOJO();
				activityWorkerTransaction.setKey(workflowDetailsTransactionId + "#" + taskListId + "#"
						+ workflowDetailsTransactionPOJO.getActivityTypeId());

				activityWorkerTransaction.setActivityWorkerId(Long.parseLong(activityWorkerid));
				activityWorkerTransaction.setStatus(newStatus);

				String activityWorkerTransactionId = insertActivityWorkerTransaction(activityWorkerTransaction);
				logger.info("activityWorkerTransactionId: " + activityWorkerTransactionId);
			}

		} else {
			logger.info("RequestId is Empty or null:{}", requestId);
		}

	}

	private String insertIntoTaskList(TaskListPOJO taskList) {
		JsonNode node = mapper.createObjectNode();
		try {
			String taskListResponse = apiService.sendDataToPost(workflowTaskListURL,
					mapper.writeValueAsString(taskList));
			node = mapper.readTree(taskListResponse);
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("Exception Occurred in taskList:{}", e.getMessage());
		}
		logger.info("TaskListResponse:{}", node);
		String taskListId = "";
		if (node != null) {
			taskListId = node.get("taskListId").asText();
		}

		return taskListId;
	}

	private String insertWorkDetailTransaction(WorkflowDetailsTransactionPOJO workflowDetailsTransaction) {
		JsonNode workflowDetailsTransactionPOJOResp = mapper.createObjectNode();

		try {
			String workflowDetailsTransactionResponse = apiService.sendDataToPost(workflowWorkflowDetailsTransactionURL,
					mapper.writeValueAsString(workflowDetailsTransaction));
			workflowDetailsTransactionPOJOResp = mapper.readTree(workflowDetailsTransactionResponse);
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("Exception Occurred in WorkflowDetailsTransaction :{}", e.getMessage());
		}
		String workflowTransactionId = "";
		if (workflowDetailsTransactionPOJOResp != null) {
			workflowTransactionId = workflowDetailsTransactionPOJOResp.get("wdTransactionId").asText();
		}

		return workflowTransactionId;
	}

	private String insertActivityWorkerTransaction(ActivityWorkerTransactionPOJO activityWorkerTransaction) {
		JsonNode node = mapper.createObjectNode();
		try {
			String activityWorkerTransactionResponse = apiService.sendDataToPost(workflowActivityWorkerURL,
					mapper.writeValueAsString(activityWorkerTransaction));
			node = mapper.readTree(activityWorkerTransactionResponse);
		} catch (Exception e) {
			e.printStackTrace();
			logger.info("Exception Occurred in activityWorkerTransaction:{}", e.getMessage());
		}
		String activityWorkerTransactionId = "";
		if (node != null) {
			activityWorkerTransactionId = node.get("activityWorkerTransactionId").asText();
		}
		return activityWorkerTransactionId;
	}
}
