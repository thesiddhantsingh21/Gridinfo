package com.gic.workflow;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.gic.workflow.service.WorkerService;
import com.gic.workflowlib.model.ActivityWorkerTransaction;
import com.gic.workflowlib.utility.Utility;
import com.gic.workflowlib.worker.Worker;

@SpringBootApplication
public class CheckCreationWorkerApplication implements CommandLineRunner {
	private static final Logger logger = LoggerFactory.getLogger(CheckCreationWorkerApplication.class);
	@Value("${database}")
	String database;
	@Value("${dbUserName}")
	String dbUserName;
	@Value("${password}")
	String password;
	@Value("${enableSSL}")
	String enableSSL = "false";
	@Value("${host}")
	String host;
	@Value("${schema}")
	String schema;
	@Value("${currentWorker}")
	String currentWorker;
	@Value("${heart.beat.url}")
	String heartBeatUrl;
//	@Value("${should.send.heartbeat}")
//	String shouldSendHeartBeat;
	
	static String heartBeatURL;
//	static String shouldSendHeartBeat1;

	@Autowired
	private WorkerService workerService;

	static Map<String, Long> activityWorkerMap = new HashMap<String, Long>();

	public static void main(String[] args) {
		
		SpringApplication.run(CheckCreationWorkerApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		logger.info("Running Spring Boot Application");
		logger.info(currentWorker);

		this.heartBeatURL = heartBeatUrl;
//		this.shouldSendHeartBeat1 = shouldSendHeartBeat;

		Map<String, String> configMap = new HashMap<>();
		configMap.put("database", database);
		configMap.put("user", dbUserName);
		configMap.put("password", password);
		configMap.put("host", host);
		configMap.put("schema", schema);
		configMap.put("currentWorker", currentWorker);

		Worker worker = new Worker(configMap).init();

		int delay = 0;
		boolean more = true;
		while (more) {
			if (processNextBatch(worker, workerService)) {
				delay = 0;
			} else {
				delay = delay + 10;
				if (delay > 60) {
					delay = 10;
				}
			}
			more = pause(delay);
		}

	}

	private static boolean pause(int factor) {
		try {
			logger.info("sleeping for {} seconds", factor);
			TimeUnit.SECONDS.sleep(factor);
		} catch (InterruptedException e) {
			logger.error("Interrupted");
			return false;
		}
		return true;
	}

	private static boolean processNextBatch(Worker worker, WorkerService workerService) {
//		if(Boolean.parseBoolean(shouldSendHeartBeat1)) {
//			Utility.sendHeartBeat(heartBeatURL);
//		}
//		Utility.sendHeartBeat(heartBeatURL);

		ActivityWorkerTransaction activityWorkerTransaction = worker.getTask();
		if (activityWorkerTransaction == null) {
			return false;
		}
		long workflowTransactionId = 0;
		long taskListId = 0;
		long activityTypeId = 0;

		logger.info("Value of key:{}", activityWorkerTransaction.getKey());
		String[] keys = activityWorkerTransaction.getKey().split("#");
		Long activityWorkerTransactionId = activityWorkerTransaction.getActivityWorkerTransactionId();
		try {
			if (keys.length == 3) {
				workflowTransactionId = Long.parseLong(keys[0]);
				taskListId = Long.parseLong(keys[1]);
				activityTypeId = Long.parseLong(keys[2]);
				boolean updateFlag = workerService.workerCheckCreation(worker, workflowTransactionId,
						activityWorkerTransactionId, taskListId);

			}

		} catch (Exception e) {
			logger.info("Exception:{} ", e.getMessage());
			e.printStackTrace();
		}

		return true;
	}

}