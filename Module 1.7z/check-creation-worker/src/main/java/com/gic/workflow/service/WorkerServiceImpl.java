package com.gic.workflow.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.gic.workflowlib.constants.ErrorType;
import com.gic.workflowlib.model.WorkflowDetailsTransaction;
import com.gic.workflowlib.utility.Utility;
import com.gic.workflowlib.worker.Worker;

@Service
public class WorkerServiceImpl implements WorkerService {

	ObjectMapper mapper = new ObjectMapper();

	@Autowired
	ApiService apiService;

	@Value("${check.creation.url}")
	private String checkCreationURL;

	@Override
	public boolean workerCheckCreation(Worker worker, long workflowTransactionId, long activityWorkerTransactionId,
			long taskListId) {
		String response = null;
		// JsonNode requestJSON =
		WorkflowDetailsTransaction workflowDetailsTransaction = worker.fetchMetaData(workflowTransactionId);
		JsonNode metaData = Utility.convertStringToJsonNode(workflowDetailsTransaction.getMetaData());
		String crnNo = metaData.get("crnNo") != null ? metaData.get("crnNo").asText() : "";

		if (crnNo != null && !crnNo.equals("")) {

			if (!crnNo.equalsIgnoreCase("pending")) {
				String reqURL = checkCreationURL.replace("{crNo}", crnNo);
				response = apiService.sendDataToGet(reqURL);
			}

			if (response != null && !response.equalsIgnoreCase("")) {

				try {
					JsonNode responseJson = mapper.readTree(response);
					((ObjectNode) responseJson).put("crn", crnNo);

					String status = "completed";
					boolean responseStatus = responseJson.get("success").asBoolean();
					String errorCause = null;

					if (!responseStatus) {
						status = "failed";
						errorCause = responseJson.get("successMsg").asText();
					}

					((ObjectNode) metaData).put("status", status);

					worker.updateTask(status, ErrorType.NONE, errorCause, errorCause, workflowTransactionId,
							activityWorkerTransactionId, responseJson.toString(), metaData.toString());

				} catch (Exception e) {
					e.printStackTrace();
					return false;
				}
			}
		}
		return true;
	}

}
