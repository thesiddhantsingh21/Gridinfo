package com.gic.workflow.service;

import org.springframework.stereotype.Service;

import com.gic.workflowlib.worker.Worker;

@Service
public interface WorkerService {

	boolean workerCheckCreation(Worker worker, long workflowTransactionId, long activityWorkerTransactionId,
			long taskListId);
}
