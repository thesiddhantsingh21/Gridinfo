package com.gic.workflow.model;

import java.util.Date;

import lombok.Data;

@Data
public class TaskList {

	private long taskListId;
	
	private long activityTypeId;
	private String taskListName;
	private String taskListDescription;
	
//	@Type(type = "jsonb")
//	@Column(columnDefinition = "jsonb", name = "request_json")
//	private JsonNode requestJson;
	private String requestJson;
	private String status;
	private Date createDate;
	private Date updatedDate;
}
