package com.gic.workflow.model;

import java.util.Date;


import com.fasterxml.jackson.databind.JsonNode;

import lombok.Data;

@Data
public class ExcelCaseCreationRequest {
	private Long id;
    String referenceId;
    String requestId;
    String clientName;
    JsonNode requestJson;
    JsonNode fileConvertionErrorJson;
    String fileUploadStatus;
    Date fileUploadedTimestamp;
    String fileConvertedStatus;
    String fileConvertedError;
    Date fileConvertedTimestamp;
    String caseCreationRequestToL3Status;
    Date caseCreationRequestToL3Timestamp;
    String caseCreationResponseToL3Status;
    Date caseCreationResponseToL3Timestamp;
    JsonNode caseCreationReqJson;
    JsonNode caseCreationResJson;
    private String transactionId;
    private String uploadType;
}
