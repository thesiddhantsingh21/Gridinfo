package com.gic.workflow;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.gic.workflow.model.ActivityWorkerTransaction;
import com.gic.workflow.model.ExcelCaseCreationRequest;
import com.gic.workflow.model.MetaData;
import com.gic.workflow.model.TaskList;
import com.gic.workflow.model.WorkflowDetailsTransaction;
import com.gic.workflow.service.ApiService;

@SpringBootApplication
public class XlsCaseCreationDeciderApplication implements CommandLineRunner {
	private static final Logger logger = LoggerFactory.getLogger(XlsCaseCreationDeciderApplication.class);
	@Value("${database}")
	String database;
	@Value("${dbUserName}")
	String dbUserName;
	@Value("${password}")
	String password;
	@Value("${enableSSL}")
	String enableSSL = "false";
	@Value("${host}")
	String host;
	@Value("${schema}")
	String schema;
	@Value("${currentWorker}")
	String currentWorker;
	static String currentWorker1;

	@Value("${file.conversion.response.url}")
	String fileConversionResponseUrl;
	static String fileConversionResponseUrl1;

	@Value("${xls.case-creation.url}")
	String xlsCaseCreationUrl;
	static String xlsCaseCreationUrl1;

	@Value("${case-creation.autopi.url}")
	String caseCreationAutoPiUrl;
	static String caseCreationAutoPiUrl1;

	@Autowired
	private ApiService apiService;

	static Map<String, Long> activityWorkerMap = new HashMap<String, Long>();

	public static void main(String[] args) {
		SpringApplication.run(XlsCaseCreationDeciderApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		logger.info("Running Spring Boot Application");
		logger.info(currentWorker);
		this.currentWorker1 = currentWorker;
		this.fileConversionResponseUrl1 = fileConversionResponseUrl;
		this.xlsCaseCreationUrl1 = xlsCaseCreationUrl;
		this.caseCreationAutoPiUrl1 = caseCreationAutoPiUrl;

		Database.Initialize(database, dbUserName, password, Boolean.getBoolean(enableSSL), host, schema);
		activityWorkerMap = Database.getActivityWorkerMap();
		logger.info("activityWorkerMap {}", activityWorkerMap);
		int delay = 0;
		boolean more = true;
		while (more) {
			if (processNextBatch(apiService)) {
				delay = 0;
			} else {
				delay = delay + 10;
				if (delay > 60) {
					delay = 10;
				}
			}
			more = pause(delay);
		}
	}

	private static boolean pause(int factor) {
		try {
			logger.info("sleeping for {} seconds", factor);
			TimeUnit.SECONDS.sleep(factor);
		} catch (InterruptedException e) {
			logger.error("Interrupted");
			return false;
		}
		return true;
	}

	private static boolean processNextBatch(ApiService apiService) {
		logger.info("Case Cration URL:{}", fileConversionResponseUrl1);
		String response = apiService.sendDataToGet(fileConversionResponseUrl1);
		logger.info("Value of Case Creation:{}", response);
		if (StringUtils.isNotEmpty(response) && !response.equals("[]")) {
			ObjectMapper mapper = new ObjectMapper();
			JsonNode responseNode = null;
			try {
				responseNode = mapper.readTree(response);
			} catch (JsonProcessingException e1) {
				e1.printStackTrace();
			}
			ArrayNode jsonArr = mapper.createArrayNode();
			String error = "";
			String infoError = "";
			List<String> infoErrorList = new ArrayList<String>();
			List<String> batchErrorList = new ArrayList<String>();
			if (responseNode.isArray()) {
				jsonArr = (ArrayNode) responseNode;
				for (JsonNode jsonel : jsonArr) {
					ArrayNode jsonErrArr = (ArrayNode) jsonel.get("batchErrors");
					ArrayNode inFoMap = (ArrayNode) jsonel.get("infoMap");
					boolean isError = false;
					for (JsonNode jsonElement : jsonErrArr) {
						try {
							error = jsonElement.get("error").asText();
							String fileName = jsonElement.get("path").asText();
							batchErrorList.add(fileName + " => " + error.trim());
							logger.info(error);// File does not exist

							if (!(error.contains(
									"Pdf format is not supported on this platform. Use .NET Standard or .NET 4.6.1 version of Aspose.Words for loading Pdf documents."))) {
								isError = true;
							}
						} catch (Exception e) {
							e.printStackTrace();
							isError = true;
						}
					}
					for (JsonNode json : inFoMap) {
						try {
							infoError = json.get("infoMsg").asText();
							String fileName = json.get("path").asText();
							logger.info(infoError);
							infoErrorList.add(fileName + " => " + infoError.trim());
						} catch (Exception e) {
							e.printStackTrace();
						}
					}

					String transactionID = jsonel.get("transactionID").asText();
					String newUrl = xlsCaseCreationUrl1.replace("{transactionId}", transactionID);
					String excelCaseCreationStr = apiService.sendDataToGet(newUrl);
					if (excelCaseCreationStr != null && !excelCaseCreationStr.equals("[]")) {
						List<ExcelCaseCreationRequest> excelCaseCreationRequestList = new ArrayList<>();
						try {
							excelCaseCreationRequestList = mapper.readValue(excelCaseCreationStr,
									new TypeReference<List<ExcelCaseCreationRequest>>() {
									});
						} catch (JsonMappingException e1) {
							e1.printStackTrace();
						} catch (JsonProcessingException e1) {
							e1.printStackTrace();
						}

						for (ExcelCaseCreationRequest excelCaseCreationRequest : excelCaseCreationRequestList) {

							excelCaseCreationRequest.setFileConvertedStatus("Yes");
							excelCaseCreationRequest.setFileConvertedTimestamp(new Date());
							excelCaseCreationRequest.setCaseCreationRequestToL3Status("Yes");
							excelCaseCreationRequest.setCaseCreationRequestToL3Timestamp(new Date());
							excelCaseCreationRequest.setFileConvertionErrorJson(jsonel);

							String apiRes = "{}";
							JsonNode caseCreationReqJson = excelCaseCreationRequest.getCaseCreationReqJson();

							if (!isError) {
								try {
									logger.info("caseCreationJSon :{}", caseCreationReqJson.asText());
								} catch (Exception e) {
									e.printStackTrace();
								}

								excelCaseCreationRequest.setCaseCreationResponseToL3Status("Yes");
								excelCaseCreationRequest.setCaseCreationResponseToL3Timestamp(new Date());
								JsonNode apiResNode = null;
								try {
									apiResNode = mapper.readTree(apiRes);
								} catch (JsonMappingException e) {
									e.printStackTrace();
								} catch (JsonProcessingException e) {
									e.printStackTrace();
								}
								excelCaseCreationRequest.setCaseCreationResJson(apiResNode);
								excelCaseCreationRequest.setFileConvertedError("No");
							} else {
								excelCaseCreationRequest.setFileConvertedError("Yes");
							}

							String json = "";
							try {
								json = mapper.writeValueAsString(excelCaseCreationRequest);
							} catch (JsonProcessingException e1) {
								e1.printStackTrace();
							}
							try {
								apiRes = apiService.sendDataToPost(newUrl, json);
							} catch (Exception e) {
								e.printStackTrace();
							}

							insertDataInWorkflow(json, batchErrorList, infoErrorList);
							error = "";
						}
					}
				}
			}
			return true;
		} else {
			return false;
		}
	}

	private static void insertDataInWorkflow(String json, List<String> batchErrorList, List<String> infoErrorList) {
		ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		try {
			batchErrorList.addAll(infoErrorList);
			TaskList taskListPOJO = new TaskList();
			taskListPOJO.setRequestJson(json != null ? mapper.writeValueAsString(json) : "");
			taskListPOJO.setStatus("ready");
			taskListPOJO.setTaskListDescription("Xls Data Worker Description");
			taskListPOJO.setTaskListName("Xls Data Worker");

			Long taskListId = Database.insertTask(taskListPOJO);
			logger.info("taskListId: {}", taskListId);

			/*---------------------------Make MetaData-----------------------*/
			MetaData metaData = new MetaData();
			JsonNode metaDataNode = null;
			try {
				JsonNode inputJson = mapper.readTree(json);

				metaData.setCaseNo("Pending");
				metaData.setCaseUUID(0);
				metaData.setCheckId("");
				metaData.setCrnNo("Pending");

				metaData.setReferenceId(inputJson.has("referenceId") ? inputJson.get("referenceId").asText() : "");
				metaData.setRequestId(inputJson.has("requestId") ? inputJson.get("requestId").asText() : "");
				metaData.setTransactionId(
						inputJson.has("transactionId") ? inputJson.get("transactionId").asText() : "");
				if (inputJson.has("fileConvertedError")) {
					if (inputJson.get("fileConvertedError").asText().equalsIgnoreCase("No")) {
						metaData.setStatus("completed");
					} else {
						metaData.setStatus("failed");
					}
				}
				metaData.setClient(inputJson.has("clientName") ? inputJson.get("clientName").asText() : "");
				metaData.setCaseSource(inputJson.has("uploadType") ? inputJson.get("uploadType").asText() : "");

				metaDataNode = mapper.convertValue(metaData, JsonNode.class);
			} catch (Exception e) {
				e.printStackTrace();
			}

			/*---------------------WorkFlow Transaction---------------*/
			WorkflowDetailsTransaction workflowDetailsTransactionPOJO = new WorkflowDetailsTransaction();
			workflowDetailsTransactionPOJO.setTaskListId(taskListId);
	
			workflowDetailsTransactionPOJO.setActivityTypeId(activityWorkerMap.get(currentWorker1));
			workflowDetailsTransactionPOJO.setRequestJson(json != null ? json : "");
			workflowDetailsTransactionPOJO
					.setMetaData(metaDataNode != null ? mapper.writeValueAsString(metaDataNode) : "");
			workflowDetailsTransactionPOJO.setStatus("completed");
			ObjectNode responseStatusNode = mapper.createObjectNode();
			ObjectNode responseNode = mapper.createObjectNode();
			responseNode.set("engineInput", mapper.readTree(json));
			if (metaData.getStatus().equalsIgnoreCase("failed")) {
				workflowDetailsTransactionPOJO.setError_cause(mapper.writeValueAsString(batchErrorList));
				try {
					responseNode.set("engineOutput", mapper.readTree(mapper.writeValueAsString(batchErrorList)));
				} catch (Exception e) {
					responseNode.put("engineOutput", mapper.writeValueAsString(batchErrorList));
				}
			} else {
				responseNode.put("engineOutput", "");
			}
			responseStatusNode.put("success", true);
			responseStatusNode.put("successMsg", "Engine ran successfully");
			responseStatusNode.set("response", responseNode);
			logger.info("Value of Response JSon:{}", responseStatusNode.toString());
			logger.info("Value of Response JSon:{}", responseStatusNode.asText());
			workflowDetailsTransactionPOJO.setResponseJson(mapper.writeValueAsString(responseStatusNode));
			Long workflowDetailsTransactionId = Database.insertWorkDetailTransaction(workflowDetailsTransactionPOJO);
			logger.info("workflowDetailsTransactionId: {}", workflowDetailsTransactionId);

			ActivityWorkerTransaction activityWorkerTransaction = new ActivityWorkerTransaction();
			activityWorkerTransaction.setKey(workflowDetailsTransactionId + "#" + taskListId + "#"
					+ workflowDetailsTransactionPOJO.getActivityTypeId());

			activityWorkerTransaction.setActivityWorkerId(activityWorkerMap.get(currentWorker1));
			activityWorkerTransaction.setStatus("completed");

			Long activityWorkerTransactionId = Database.insertActivityWorkerTransaction(activityWorkerTransaction);
			logger.info("activityWorkerTransactionId: {}", activityWorkerTransactionId);
		} catch (Exception e) {
			logger.info("Ecxeption Occurred:{}", e.getMessage());
		}
	}
}