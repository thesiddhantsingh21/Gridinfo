package com.gic.workflow.model;

import lombok.Data;

@Data
public class MetaData {
	
	private String crnNo;
    private String caseNo;
    private String checkId;
    private long caseUUID;
    private String status;
    private String referenceId;
    private String requestId;
    private String transactionId;
    private String caseSource;
    private String client;
}
