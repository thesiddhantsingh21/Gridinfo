package com.gic.workflow.model;


import java.util.Date;

import lombok.Data;

@Data
public class ActivityWorkerTransaction {
	private long activityWorkerTransactionId;
	private long activityWorkerId;
	private String key; 
	private String status;
	private Date createdTime;
	private Date issuedTime;
	private Date completedTime;
}
