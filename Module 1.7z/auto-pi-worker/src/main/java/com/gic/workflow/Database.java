package com.gic.workflow;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.Instant;
import java.util.HashMap;
import java.util.Map;

import org.postgresql.util.PGobject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.gic.workflow.model.ActivityWorkerTransaction;
import com.gic.workflow.model.TaskList;
import com.gic.workflow.model.WorkflowDetailsTransaction;

public class Database {
	private static final Logger logger = LoggerFactory.getLogger(Database.class);
	static Connection connection;
	static String database;
	static String schema;
	static String user;
	static String password;
	static String host;
	static boolean ssl;

	static void Initialize(String database, String user, String password, boolean ssl, String host, String schema) {
		Database.database = database;
		Database.schema = schema;
		Database.user = user;
		Database.password = password;
		Database.host = host;
		Database.ssl = ssl;
		String url = "jdbc:postgresql://" + host + "/" + database + "?user=" + user + "&password=" + password + "&ssl="
				+ ssl;
		logger.info("url:" + url);
		connection = null;
		try {
			connection = DriverManager.getConnection(url);
		} catch (SQLException e) {
			logger.error(e.getMessage());
//            System.exit(-1);
		}
	}

	static Connection getConnection() {
		try {
			if (connection == null || connection.isClosed()) {
				Initialize(database, user, password, ssl, host, schema);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return connection;
	}

	public static Map<String, Long> getActivityWorkerMap() {
		Map<String, Long> activityMap = new HashMap<String, Long>();
		try {
			String sql = "SELECT * FROM " + schema + ".activity_worker";
			Statement stmt = getConnection().createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			while (rs.next()) { // max 1
				activityMap.put(rs.getString("activity_worker_name"), rs.getLong("activity_worker_id"));
			}
		} catch (SQLException e) {
			logger.error(e.getMessage());
			return null;
		}
		return activityMap;
	}

	public static ActivityWorkerTransaction getWorkflowDetailsTransaction(Long activityTypeId) {
		try {
			String nextConversionRequestSQL = "UPDATE " + Database.schema
					+ ".activity_worker_transaction SET status = 'issued'," + " issued_date = '" + Instant.now()
					+ "' WHERE activity_worker_transaction_id = (SELECT activity_worker_transaction_id FROM workflow.activity_worker_transaction"
					+ " WHERE status='new' and activity_worker_id=" + activityTypeId
					+ " LIMIT 1 FOR UPDATE SKIP LOCKED)"
					+ " RETURNING activity_worker_transaction_id, activity_worker_id, \"key\", status;";

			Statement stmt = getConnection().createStatement();
			ResultSet rs = stmt.executeQuery(nextConversionRequestSQL);
			if (rs.next()) { // max 1
				ActivityWorkerTransaction activityWorkerTransaction = new ActivityWorkerTransaction();
				activityWorkerTransaction.setActivityWorkerTransactionId(rs.getLong("activity_worker_transaction_id"));
				activityWorkerTransaction.setActivityWorkerId(rs.getLong("activity_worker_id"));
				activityWorkerTransaction.setKey(rs.getString("key"));
				activityWorkerTransaction.setStatus(rs.getString("status"));
				return activityWorkerTransaction;
			} else {
				return null;
			}
		} catch (SQLException e) {
			logger.error(e.getMessage());
			return null;
		}
	}

	public static String getCRNFromTastList(Long taskListId) {
		try {
			String sql = "SELECT request_json->>'crn' as crn FROM " + schema + ".task_list where task_list_id ="
					+ taskListId;
			Statement stmt = getConnection().createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			if (rs.next()) { // max 1
				return rs.getString("crn");
			}
		} catch (SQLException e) {
			logger.error(e.getMessage());
			return null;
		}
		return null;
	}

	public static String getMetaData(Long wd_transaction_id) {
		try {
			String sql = "SELECT meta_data from " + schema + ".workflow_details_transaction where wd_transcation_id="
					+ wd_transaction_id;
			Statement stmt = getConnection().createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			if (rs.next()) { // max 1
				return rs.getString("meta_data");
			}
		} catch (Exception e) {
			logger.error(e.getMessage());
			return null;
		}
		return null;
	}

	//////////////////////////////////////////////////////////////////////////////////
	public static long insertTask(TaskList taskList) {
		String sql = "INSERT INTO " + Database.schema + ".task_list"
				+ "(activity_type_id,  request_json, status, task_list_description, task_list_name,created_date,updated_date)"
				+ "VALUES(?,?, ?, ?, ?,'" + Instant.now() + "','" + Instant.now() + "')";
		System.out.println(sql);
		long id = 0;
		PreparedStatement pstmt = null;
		try {

			pstmt = getConnection().prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
			pstmt.setLong(1, taskList.getActivityTypeId());

			PGobject jsonObject = new PGobject();
			jsonObject.setType("json");
			jsonObject.setValue(taskList.getRequestJson());

			pstmt.setObject(2, jsonObject);
			pstmt.setString(3, taskList.getStatus());
			pstmt.setString(4, taskList.getTaskListDescription());
			pstmt.setString(5, taskList.getTaskListName());

			int affectedRows = pstmt.executeUpdate();
			// check the affected rows
			if (affectedRows > 0) {
				// get the ID back
				try (ResultSet rs = pstmt.getGeneratedKeys()) {
					if (rs.next()) {
						id = rs.getLong(1);
					}
				} catch (SQLException ex) {
					ex.printStackTrace();
				}
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return id;
	}

	public static long insertWorkDetailTransaction(WorkflowDetailsTransaction workflowDetailsTransaction) {
		String sql = "INSERT INTO " + Database.schema + ".workflow_details_transaction"
				+ "(request_json, status, task_list_id,activity_type_id,error_cause, meta_data,response_json,request_timestamp,response_timestamp,is_picked)"
				+ "VALUES(?, ?, ?, ?,?, ?,?,'" + Instant.now() + "','" + Instant.now() + "',false);";
		// response_timestamp='"+Instant.now()+"',
		System.out.println(sql);
		long id = 0;
		PreparedStatement pstmt = null;
		try {
			pstmt = getConnection().prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
			PGobject jsonObject1 = new PGobject();
			jsonObject1.setType("json");
			jsonObject1.setValue(workflowDetailsTransaction.getRequestJson());

			pstmt.setObject(1, jsonObject1);
			// pstmt.setDate(2, workflowDetailsTransaction.getRequestTimestamp());
			pstmt.setString(2, workflowDetailsTransaction.getStatus());
			pstmt.setLong(3, workflowDetailsTransaction.getTaskListId());
			pstmt.setLong(4, workflowDetailsTransaction.getActivityTypeId());
			PGobject jsonObject3 = new PGobject();
			jsonObject3.setType("text");
			jsonObject3.setValue(workflowDetailsTransaction.getError_cause());
			pstmt.setObject(5, jsonObject3);

			PGobject jsonObject = new PGobject();
			jsonObject.setType("json");
			jsonObject.setValue(workflowDetailsTransaction.getMetaData());

			pstmt.setObject(6, jsonObject);
			PGobject jsonObject2 = new PGobject();
			jsonObject2.setType("json");
			jsonObject2.setValue(workflowDetailsTransaction.getResponseJson());
			logger.info("11111111:{}", jsonObject2);
			pstmt.setObject(7, jsonObject2);

			int affectedRows = pstmt.executeUpdate();
			// check the affected rows
			if (affectedRows > 0) {
				// get the ID back
				try (ResultSet rs = pstmt.getGeneratedKeys()) {
					if (rs.next()) {
						id = rs.getLong(1);
					}
				} catch (SQLException ex) {
					System.out.println(ex.getMessage());
				}
			}
		} catch (SQLException ex) {
			System.out.println(ex.getMessage());
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return id;
	}

	public static long insertActivityWorkerTransaction(ActivityWorkerTransaction activityWorkerTransaction) {
		String sql = "INSERT INTO " + Database.schema + ".activity_worker_transaction"
				+ "(activity_worker_id, key, status,created_date)" + "VALUES(?, ?, ?,'" + Instant.now() + "')";
		System.out.println(sql);
		long id = 0;
		PreparedStatement pstmt = null;
		try {
			pstmt = getConnection().prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
			pstmt.setLong(1, activityWorkerTransaction.getActivityWorkerId());
			pstmt.setString(2, activityWorkerTransaction.getKey());
			pstmt.setString(3, activityWorkerTransaction.getStatus());

			int affectedRows = pstmt.executeUpdate();
			// check the affected rows
			if (affectedRows > 0) {
				// get the ID back
				try (ResultSet rs = pstmt.getGeneratedKeys()) {
					if (rs.next()) {
						id = rs.getLong(1);
					}
				} catch (SQLException ex) {
					System.out.println(ex.getMessage());
				}
			}
		} catch (SQLException ex) {
			System.out.println(ex.getMessage());
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return id;
	}

	public static boolean updateWorkflowDetailTransaction(Long wdTranscationId, String responseJson, String meta_data) {
		String sql = "UPDATE " + Database.schema + ".workflow_details_transaction"
				+ " SET response_json=?, response_timestamp='" + Instant.now() + "', status='completed', meta_data=?  "
				+ " WHERE wd_transcation_id=? and status !='failed' and picked_for_retry = false";
		System.out.println(sql);
		PreparedStatement pstmt = null;
		try {
			pstmt = getConnection().prepareStatement(sql);
			PGobject jsonObject1 = new PGobject();
			jsonObject1.setType("json");
			jsonObject1.setValue(responseJson);
			pstmt.setObject(1, jsonObject1);

			PGobject metaDataObject = new PGobject();
			metaDataObject.setType("json");
			metaDataObject.setValue(meta_data);
			pstmt.setObject(2, metaDataObject);
			pstmt.setLong(3, wdTranscationId);

			int affectedRows = pstmt.executeUpdate();
			if (affectedRows > 0) {
				return true;
			}
		} catch (SQLException ex) {
			System.out.println(ex.getMessage());
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return false;
	}

	public static boolean updateActivityWorkerTransaction(Long activityWorkerTransactionId) {
		String sql = "UPDATE " + Database.schema + ".activity_worker_transaction" + " SET completed_date='"
				+ Instant.now() + "', status='completed' " + " WHERE activity_worker_transaction_id=?";
		System.out.println(sql);
		PreparedStatement pstmt = null;
		try {

			pstmt = getConnection().prepareStatement(sql);
			pstmt.setLong(1, activityWorkerTransactionId);

			int affectedRows = pstmt.executeUpdate();
			if (affectedRows > 0) {
				return true;
			}
		} catch (SQLException ex) {
			System.out.println(ex.getMessage());
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return false;
	}
}
