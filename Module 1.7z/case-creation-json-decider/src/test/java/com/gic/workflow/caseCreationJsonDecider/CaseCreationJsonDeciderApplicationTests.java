package com.gic.workflow.caseCreationJsonDecider;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CaseCreationJsonDeciderApplicationTests {

	@Test
	void contextLoads() {
	}

}
