package com.gic.workflow.caseCreationJsonDecider.utility;

import org.apache.commons.lang3.StringUtils;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.gic.workflow.caseCreationJsonDecider.service.BotJSONServiceImpl;

public class DateFormatter {

	private static final Logger logger = LoggerFactory.getLogger(DateFormatter.class);
	
	public static String convertDate(String inputDate) {

		if (StringUtils.isEmpty(inputDate) && inputDate == null) {
			return "";
		}

		try {
			DateTime date = new DateTime(inputDate); // A Date object coming from other code.

			// Pass the java.util.Date object to constructor of Joda-Time DateTime object.
			DateTimeZone kolkataTimeZone = DateTimeZone.forID("Asia/Kolkata");
			DateTime dateTimeInKolkata = new DateTime(date, kolkataTimeZone);

			DateTimeFormatter formatter = DateTimeFormat.forPattern("yyyy-MM-dd");
			String formattedDate = formatter.print(dateTimeInKolkata);
			return formattedDate;

		} catch (Exception e) {
			logger.info(e.getMessage());
			return inputDate;
		}

	}

}
