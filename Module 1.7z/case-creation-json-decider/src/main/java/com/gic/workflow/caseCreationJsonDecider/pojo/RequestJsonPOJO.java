package com.gic.workflow.caseCreationJsonDecider.pojo;

import java.util.List;

import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Data
public class RequestJsonPOJO {

	private MetaDataPOJO metadata;
	private List<DataPOJO> data;
}
