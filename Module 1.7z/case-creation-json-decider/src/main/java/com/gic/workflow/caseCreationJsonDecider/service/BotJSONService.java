package com.gic.workflow.caseCreationJsonDecider.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.gic.workflow.caseCreationJsonDecider.pojo.CaseCreationPOJO;
import com.gic.workflow.caseCreationJsonDecider.pojo.RootPOJO;


@Service
public interface BotJSONService {

	List<RootPOJO> createBOTJson(ObjectMapper mapper, CaseCreationPOJO caseCreationPOJO);

}
