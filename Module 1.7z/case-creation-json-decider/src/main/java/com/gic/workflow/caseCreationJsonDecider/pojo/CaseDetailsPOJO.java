package com.gic.workflow.caseCreationJsonDecider.pojo;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.JsonNode;

import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class CaseDetailsPOJO {
	private JsonNode clientDetail;
//	private AdditionalDetailPOJO additionalDetail;
//	private CaseDocumentMainObject caseDocument;
//	private CaseReferencePOJO caseReference;
	// private int mobileNumber;
	// private String mobileMandatory;
	// private int mobileCountryCode;

	private JsonNode fileUpload;
	private JsonNode packageList;

	private String clientId;
	private String caseOrigin;
	private String clientName;
	private String firstName;
	private String lastName;
	private String middleName;
	private String subjectDetails;
	private String email;
	private String mobileMandatory;
	private String sbuId;
	private String packageId;
	private String emailTemplate;
	private String mobileNumber;
	private String subjectType;
	private String emailTo;
	private String officalEmailAddress;
	private String grantPermissionToFADV;
	private String mobileCountryCode;
	private String caseDate;
	private String dateOfBirth;
	private String startDate;
	private String dobMandatory;
	private String ClientCostCode;
	private String contactDate;
	private String contactCurrentEmployer;
	private String sbuName;
	private String packageName;
	private String candidateName;
	private String type;
	private String primaryPackage;
	private String srtData;
	private String loaSubmited;
	private String bvfSubmitted;

//Extra Fields

//	private String grantPermissionToFADV;
	private String personalEmailAddress;
	private String clientReferenceNo;
	private String typeOfCheck;
	private String authorizationLetter;
	private String packageType;
	private Boolean isDuplicate;
	private String requestStatus;
	private String comment;
	private String isSingleDataEntry;
}
