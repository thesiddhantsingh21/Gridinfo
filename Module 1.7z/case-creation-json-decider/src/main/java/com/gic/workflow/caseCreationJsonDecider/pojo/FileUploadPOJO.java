package com.gic.workflow.caseCreationJsonDecider.pojo;

import java.util.List;

import com.fasterxml.jackson.databind.JsonNode;

import lombok.Data;

@Data
public class FileUploadPOJO
{
//    private List<String> verificationReplyDocument;

    private String directory;
    private JsonNode files;
}
