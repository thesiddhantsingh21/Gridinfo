package com.gic.workflow.caseCreationJsonDecider.pojo;

import java.util.Date;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

import lombok.Data;

@Data
public class CaseCreationPOJO {

	private long caseDetailsId;
	private Integer cdeDataEntryStatus;
	private String deType;
	private String crNo;
	private String caseNo;
	private String crnCreationDate;
	private Date requestdate;
	private String caseCreationStatus;
	private String caseType;
	private String type;
	private String remarks;
	private String clientName;
	private String caseCreatedBy;
	private JsonNode caseDetails;
	private JsonNode caseMoreInfoFields;
	private JsonNode clientSpecificFields;
	//Add client fields
	private ObjectNode customerFields;
	private String caseOrigin;
	private String requestId;
}
