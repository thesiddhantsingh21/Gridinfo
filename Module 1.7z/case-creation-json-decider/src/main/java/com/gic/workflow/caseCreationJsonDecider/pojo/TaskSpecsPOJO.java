package com.gic.workflow.caseCreationJsonDecider.pojo;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class TaskSpecsPOJO
{
//    private L3CaseReferencePOJO caseReference;
//
//    private CheckVerificationPOJO checkVerification;
//    
//	List<QuestionnairePOJO> questionaire;

//    private FileUploadPOJO fileUpload;
	@JsonProperty("case")
	private CasePOJO casePOJO;

}