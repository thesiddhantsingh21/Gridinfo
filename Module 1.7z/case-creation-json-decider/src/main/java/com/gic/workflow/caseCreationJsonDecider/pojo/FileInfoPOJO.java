package com.gic.workflow.caseCreationJsonDecider.pojo;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Data;

@Data
@JsonInclude(Include.NON_NULL)
public class FileInfoPOJO {
//	private String id;
//	private String name;
//	private String url;
//	private String path;
//	private String originalName;
//	private Long size;
//	private String extension;
//	private String contentType;
//
////	@JsonFormat(pattern="MMM dd, yyyy, hh:mm:ss a")
//	private String createDate;
//	private String errorLog;
//	private Integer pageCount;
//	private String filePathName;
//	@JsonIgnore
//	private String requestId;
//	@JsonIgnore
//	private Object fileStatus;
	private long caseUploadedDocumentsId;
	private String transactionId;
	private String fileName;
	private String filePath;
	private String fileUrl;
	private String originalName;
	private Long fileSize;
	private String fileExtension;
	private String contentType;
	private String errorLog;
	private Integer pageCount;
	private String filePathName;
	private String uploadType;
	private String fileStatus;
	private String requestId;
//	private long caseDetailsId;
	
}
