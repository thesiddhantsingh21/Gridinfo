package com.gic.workflow.caseCreationJsonDecider.pojo;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.JsonNode;

import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class AdditionalDetailPOJO {
	private String pointContactId;
	private String locationId;
	private String priorityId;
	private String typeOfCheckId;
	private String modeReceiptId;
	private String clientReference;
	private String localName;
	private String akaFirstName;
	private String akaLastName;
	private String akaMiddleName;
	private String akaLocalName;
	private String genderId;
	private String confidentialCase;
	private String authLetter;
	private boolean singleDataEntry = true;
	private JsonNode address;
	private JsonNode contactNumber;
	private String remarks;
	private boolean isDuplicateEntry = false;
}
