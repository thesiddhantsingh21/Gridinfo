package com.gic.workflow.caseCreationJsonDecider.pojo;

import java.util.Date;

import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Data
public class CaseReferencePOJO {

	private long caseUUID;
	private String clientId;
	private String sbuId;
	private String packageId;
	private String crnNo;
	private String crnCreatedDate;
//	private String caseNo;
	private String caseNo;
	private String caseType;
	private String scrnCreatedDate;
	private String checkId;
}
