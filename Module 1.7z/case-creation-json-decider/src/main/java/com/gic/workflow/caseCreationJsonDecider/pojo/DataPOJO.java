package com.gic.workflow.caseCreationJsonDecider.pojo;

import lombok.Data;

@Data
public class DataPOJO {
	private String taskBy;

	private Integer taskSerialNo;

	private String taskName;

	private String taskId;

	private Object taskSpecs;

}
