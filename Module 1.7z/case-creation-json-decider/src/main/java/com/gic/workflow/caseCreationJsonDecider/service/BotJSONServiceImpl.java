package com.gic.workflow.caseCreationJsonDecider.service;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gic.workflow.caseCreationJsonDecider.pojo.CaseCreationPOJO;
import com.gic.workflow.caseCreationJsonDecider.pojo.CaseDetailsPOJO;
import com.gic.workflow.caseCreationJsonDecider.pojo.CasePOJO;
import com.gic.workflow.caseCreationJsonDecider.pojo.CaseReferencePOJO;
import com.gic.workflow.caseCreationJsonDecider.pojo.DataPOJO;
import com.gic.workflow.caseCreationJsonDecider.pojo.FileInfoPOJO;
import com.gic.workflow.caseCreationJsonDecider.pojo.FileUploadPOJO;
import com.gic.workflow.caseCreationJsonDecider.pojo.InputJsonPOJO;
import com.gic.workflow.caseCreationJsonDecider.pojo.MetaDataPOJO;
import com.gic.workflow.caseCreationJsonDecider.pojo.RequestJsonPOJO;
import com.gic.workflow.caseCreationJsonDecider.pojo.RootPOJO;
import com.gic.workflow.caseCreationJsonDecider.pojo.TaskSpecsPOJO;
import com.gic.workflow.caseCreationJsonDecider.utility.DateFormatter;

@Service
public class BotJSONServiceImpl implements BotJSONService {

	private static final Logger logger = LoggerFactory.getLogger(BotJSONServiceImpl.class);

	// @Autowired
	// TaskListRepository taskListRepository;

	@Autowired
	ApiService apiService;

	@Override
	public List<RootPOJO> createBOTJson(ObjectMapper mapper, CaseCreationPOJO caseCreationPOJO) {
		RootPOJO rootPOJO = makeBotJson(mapper, caseCreationPOJO);
		logger.info("Bot json POJO:{}", rootPOJO);
		List<RootPOJO> rootPOJOList = new ArrayList<>();
		rootPOJOList.add(rootPOJO);
		return rootPOJOList;
	}

	public RootPOJO makeBotJson(ObjectMapper mapper, CaseCreationPOJO caseCreationPOJO) {
		RequestJsonPOJO requestJsonPOJO = new RequestJsonPOJO();
		MetaDataPOJO metaDataPOJO = new MetaDataPOJO();
		metaDataPOJO.setProcessName("CSPi NG India");
		metaDataPOJO.setProcessId("4eae3272-aade-48e0-9c4f-44e77ac37f0f");
		metaDataPOJO.setStageId("483a6d8f-e619-484c-af98-a6472c5070f6");
		metaDataPOJO.setTask("CreateCSPICase");
		metaDataPOJO.setTaskGroupId("e9a3b062-69f0-46ed-bb67-acf9d6655c3e");
		metaDataPOJO.setRequestDate(new Date().toString());
		metaDataPOJO.setRequestType("query");
		metaDataPOJO.setRequestId("81a0b6f5-cd69-485e-bad7-ed87a5696aab");
		metaDataPOJO.setVersion("2.1.0");
		metaDataPOJO.setAttempt("1");
		metaDataPOJO.setMultiTask("no");
		metaDataPOJO.setRequestAuthToken(
				"eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJ7XCJtdGVpZFwiOlwiOGI3NGQ0NGMtMDU5MC00MDdjLThiZDgtNjFkM2FkN2Y2ZjM5XCIsXCJ1c2VySWRcIjpcImIxMTA1NDhkLWFmNzgtNGUyNC04ZDZiLWNlN2IyZTE4YWI2OFwiLFwiYXBwU2Vzc2lvbklkXCI6XCIyMjk3ZTJiYS1hM2UwLTQyZmItOTg0Yy0zYWU2ODE3ZGZmMDdcIixcInByb2plY3RJZFwiOlwicHJvamVjdElkXCIsXCJwcm9qZWN0VmVyc2lvbklkXCI6XCJwcm9qZWN0VmVyc2lvbklkXCIsXCJVU0VSX05BTUVcIjpcInN1cGVyIGFkbWluXCIsXCJBRERUSU9OQUxfSU5GT1wiOlwiXCIsXCJleHRlcm5hbFRva2VuXCI6XCJudWxsXCJ9IiwiZXhwIjozMjcxODM4NjMyfQ._8byFadylKhwXKJ1epUHEFJ1rR-FqXtC_KqHFYTj-tOOJWAC_Ayp11Fzy6v0YrtPQiQU8S7lLcZjvEUDmSUUHQ");
		metaDataPOJO.setTxLabel("1635789717525");
		metaDataPOJO.setStageName("Case Creation Stages");

		List<DataPOJO> dataPOJOList = new ArrayList<>();
		DataPOJO dataPOJO = new DataPOJO();
		dataPOJO.setTaskBy("BO");
		dataPOJO.setTaskId("e9a3b062-69f0-46ed-bb67-acf9d6655c3e");
		dataPOJO.setTaskName("CreateCSPICase");
		dataPOJO.setTaskSerialNo(1);
		TaskSpecsPOJO taskSpecPOJO = new TaskSpecsPOJO();

		CasePOJO casePOJO = new CasePOJO();
		InputJsonPOJO caseDetails2 = null;
		logger.info("CaseCreationPOJO:{}", caseCreationPOJO);
		try {
			caseDetails2 = mapper.readValue(caseCreationPOJO.getCaseDetails().toString(), InputJsonPOJO.class);
		} catch (Exception e) {
			logger.info("Exception while converting caseDetail into inputJsonPOJO");
			e.printStackTrace();
		}

		CaseReferencePOJO caseReferencePOJO = new CaseReferencePOJO();
		caseReferencePOJO.setCaseNo(caseCreationPOJO.getCaseNo());
		caseReferencePOJO.setCaseType(caseCreationPOJO.getCaseType());
		caseReferencePOJO.setCaseUUID(caseCreationPOJO.getCaseDetailsId());
		caseReferencePOJO.setClientId(
				caseDetails2.getClientDetail().getClientId() != null ? caseDetails2.getClientDetail().getClientId()
						: "");
		caseReferencePOJO.setCrnCreatedDate(
				caseCreationPOJO.getCrnCreationDate() != null ? caseCreationPOJO.getCrnCreationDate() : "");
		caseReferencePOJO.setCrnNo(caseCreationPOJO.getCrNo());
		caseReferencePOJO.setPackageId(caseDetails2.getClientDetail().getPackageId());
		caseReferencePOJO.setSbuId(caseDetails2.getClientDetail().getSbuId());
		caseReferencePOJO.setScrnCreatedDate("");
		caseReferencePOJO.setCheckId("");

		casePOJO.setCaseReference(caseReferencePOJO);
		casePOJO.setCaseMoreInfo(caseCreationPOJO.getCaseMoreInfoFields());

		logger.info("client fields:{}", caseCreationPOJO.getCustomerFields());

		casePOJO.setClientSpecificFields((JsonNode) caseCreationPOJO.getClientSpecificFields());

		logger.info("client Specific fields:{}", caseCreationPOJO.getClientSpecificFields());
		CaseDetailsPOJO caseDetailsPOJO = new CaseDetailsPOJO();
		FileUploadPOJO fileUploadPOJO = new FileUploadPOJO();
		List<FileInfoPOJO> fileInfoPOJOList = caseDetails2.getCaseDocument().getConvertedData();
		logger.info("FileInfoPOJOList:{}", fileInfoPOJOList);
		List<String> nameList = new ArrayList<String>();
		logger.info("Size of FileInfoPOJOList:{}", fileInfoPOJOList.size());

		JsonNode nameJson = null;
		try {
			nameJson = mapper.convertValue(nameList, JsonNode.class);
		} catch (Exception e2) {
			logger.info("Exception while converting nameList into JsonNode");
			e2.printStackTrace();
		}
		logger.info("Value Of nameList==" + nameJson);
		fileUploadPOJO.setFiles(nameJson);
		fileUploadPOJO.setDirectory("\\\\10.2.40.43\\CspiNG\\India");

		JsonNode fileUploadJsonNode = null;
		fileUploadJsonNode = mapper.convertValue(fileUploadPOJO, JsonNode.class);

		caseDetailsPOJO.setFileUpload(fileUploadJsonNode);
		caseDetailsPOJO.setPackageList(mapper.createArrayNode());
		caseDetailsPOJO.setBvfSubmitted(caseDetails2.getClientDetail().getBvfSubmitted());
		caseDetailsPOJO.setCandidateName(caseDetails2.getClientDetail().getCandidateName());
		caseDetailsPOJO.setCaseDate(DateFormatter.convertDate(caseDetails2.getClientDetail().getCaseDate()));
		caseDetailsPOJO.setCaseOrigin(caseDetails2.getClientDetail().getCaseOrigin());
		caseDetailsPOJO.setClientId(caseDetails2.getClientDetail().getClientId());
		caseDetailsPOJO.setClientName(caseDetails2.getClientDetail().getClientName());
		caseDetailsPOJO.setContactCurrentEmployer(caseDetails2.getClientDetail().getContactCurrentEmployer());
		caseDetailsPOJO.setContactDate(DateFormatter.convertDate(caseDetails2.getClientDetail().getContactDate()));
		caseDetailsPOJO.setClientCostCode(caseDetails2.getClientDetail().getCostCode());
		caseDetailsPOJO.setDateOfBirth(DateFormatter.convertDate(caseDetails2.getClientDetail().getDob() == null ? "" : caseDetails2.getClientDetail().getDob()));
		caseDetailsPOJO.setDobMandatory(caseDetails2.getClientDetail().getDobMandatory());
		caseDetailsPOJO.setEmail(caseDetails2.getClientDetail().getEmail());
		caseDetailsPOJO.setEmailTemplate(caseDetails2.getClientDetail().getEmailTemplateId());
		caseDetailsPOJO.setEmailTo(caseDetails2.getClientDetail().getEmailToId());
		caseDetailsPOJO.setFirstName(caseDetails2.getClientDetail().getFirstName());
		caseDetailsPOJO.setLastName(caseDetails2.getClientDetail().getLastName());
		caseDetailsPOJO.setLoaSubmited(caseDetails2.getClientDetail().getLoaSubmitted());
		caseDetailsPOJO.setMiddleName(caseDetails2.getClientDetail().getMiddleName());
		caseDetailsPOJO.setMobileCountryCode(caseDetails2.getClientDetail().getMobileCountryCode());
		caseDetailsPOJO.setMobileMandatory(caseDetails2.getClientDetail().getMobileMandatory());
		caseDetailsPOJO.setMobileNumber(caseDetails2.getClientDetail().getMobileNumber() == null ? "":caseDetails2.getClientDetail().getMobileNumber());

		caseDetailsPOJO.setEmail(
				caseDetails2.getClientDetail().getEmail() != null ? caseDetails2.getClientDetail().getEmail() : "");
		caseDetailsPOJO.setPackageId(caseDetails2.getClientDetail().getPackageId());
		caseDetailsPOJO.setPackageName(caseDetails2.getClientDetail().getPackageName());
		caseDetailsPOJO.setPrimaryPackage(caseDetails2.getClientDetail().getPrimaryPackage());
		caseDetailsPOJO.setSbuId(caseDetails2.getClientDetail().getSbuId());
		caseDetailsPOJO.setSbuName(caseDetails2.getClientDetail().getSbuName());
		caseDetailsPOJO.setSrtData(caseDetails2.getClientDetail().getSrt());
		if (caseDetails2.getClientDetail().getStartDate() != null) {
			caseDetailsPOJO.setStartDate(DateFormatter.convertDate(caseDetails2.getClientDetail().getStartDate()));
		}
		caseDetailsPOJO.setSubjectDetails(caseDetails2.getClientDetail().getSubjectDetailId());
		caseDetailsPOJO.setSubjectType(caseDetails2.getClientDetail().getSubjectTypeId());
		caseDetailsPOJO.setType(caseDetails2.getClientDetail().getType());

		caseDetailsPOJO.setGrantPermissionToFADV(caseDetails2.getClientDetail().getRecentEmployer());
		caseDetailsPOJO.setPersonalEmailAddress(
				caseDetails2.getClientDetail().getEmail() != null ? caseDetails2.getClientDetail().getEmail() : "");
		caseDetailsPOJO.setClientReferenceNo(caseDetails2.getAdditionalDetail().getClientReference() != null
				? caseDetails2.getAdditionalDetail().getClientReference()
				: "");
		caseDetailsPOJO.setTypeOfCheck(caseDetails2.getAdditionalDetail().getTypeOfCheckId() != null
				? caseDetails2.getAdditionalDetail().getTypeOfCheckId()
				: "");
		caseDetailsPOJO.setAuthorizationLetter(caseDetails2.getAdditionalDetail().getAuthLetter() != null
				? caseDetails2.getAdditionalDetail().getAuthLetter()
				: "");
		caseDetailsPOJO.setPackageType(caseDetails2.getClientDetail().getPackageName() != null
				? caseDetails2.getClientDetail().getPackageName()
				: "");
		caseDetailsPOJO.setIsDuplicate(caseDetails2.getAdditionalDetail().isDuplicateEntry());
		caseDetailsPOJO.setOfficalEmailAddress(caseDetails2.getClientDetail().getOfficialEmail() != null
				? caseDetails2.getClientDetail().getOfficialEmail()
				: "");
		caseDetailsPOJO.setRequestStatus("Recieved");
		caseDetailsPOJO.setComment("");

		JsonNode clientDetailJsonNode = null;
		clientDetailJsonNode = mapper.convertValue(caseDetailsPOJO, JsonNode.class);

		casePOJO.setCaseDetails(clientDetailJsonNode);
		casePOJO.setRemarks(caseDetails2.getAdditionalDetail().getRemarks() != null
				? caseDetails2.getAdditionalDetail().getRemarks()
				: "");

		taskSpecPOJO.setCasePOJO(casePOJO);
		dataPOJO.setTaskSpecs(taskSpecPOJO);
		dataPOJOList.add(dataPOJO);
		requestJsonPOJO.setData(dataPOJOList);

		requestJsonPOJO.setMetadata(metaDataPOJO);

		RootPOJO rootPOJO = new RootPOJO();
		rootPOJO.setRequestJson(requestJsonPOJO);
		rootPOJO.setRequestProcessorId(caseCreationPOJO.getCaseDetailsId());
		return rootPOJO;
	}

	public void copyFileToAnotherPath(String remotePath, String localPath, String fileName) throws IOException {

		String copyPath = remotePath + "/" + fileName;

		logger.info("Source path : {} ", localPath);
		logger.info("Destination path : {}", copyPath);

		File localFile = new File(localPath);
		File destFile = new File(copyPath);

		// FileUtils.copyFile(localFile, destFile);

	}

}
