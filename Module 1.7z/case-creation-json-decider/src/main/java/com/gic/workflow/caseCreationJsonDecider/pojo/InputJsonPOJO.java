package com.gic.workflow.caseCreationJsonDecider.pojo;

import java.util.List;

import lombok.Data;
import lombok.NoArgsConstructor;
@NoArgsConstructor
@Data
public class InputJsonPOJO {

	private ClientDetailPOJO clientDetail;
	private AdditionalDetailPOJO additionalDetail;
	private CaseDocumentMainObject caseDocument;
}
