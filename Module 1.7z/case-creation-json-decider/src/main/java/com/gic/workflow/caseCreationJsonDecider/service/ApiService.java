package com.gic.workflow.caseCreationJsonDecider.service;

import org.springframework.stereotype.Service;

@Service
public interface ApiService {

	String sendDataToGet(String requestUrl);

	String sendDataToPost(String requestUrl, String requestStr);


}
