package com.gic.workflow.caseCreationJsonDecider.pojo;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class ClientDetailPOJO {
	private String clientId;
	private String caseOrigin;
	private String clientName;
	private String firstName;
	private String lastName;
	private String middleName;
	private String subjectDetailId;
	private String email;
	private String mobileMandatory;
	private String sbuId;
	private String packageId;
	private String emailTemplateId;
	private String mobileNumber;
	private String subjectTypeId;
	private String emailToId;
	private String officialEmail;
	private String recentEmployer;
	private String mobileCountryCode;
	private String caseDate;
	private String dob;
	private String startDate;
	private String dobMandatory;
	private String costCode;
	private String contactDate;
	private String contactCurrentEmployer;
	private String sbuName;
	private String packageName;
	private String candidateName;
	private String type;
	private String primaryPackage;
	private String srt;
	private String loaSubmitted;
	private String bvfSubmitted;
}
