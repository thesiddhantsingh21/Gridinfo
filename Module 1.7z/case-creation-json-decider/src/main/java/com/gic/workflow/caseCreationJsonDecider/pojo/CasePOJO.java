package com.gic.workflow.caseCreationJsonDecider.pojo;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

import lombok.Data;

@Data
public class CasePOJO {

	private CaseReferencePOJO caseReference;

	private JsonNode caseDetails;

	private JsonNode clientSpecificFields;

	private JsonNode caseMoreInfo;

//	//Add client fields
//	private ObjectNode customerFields;

	private String remarks;

//	private CaseDetailsDocValPOJO caseDetails;
//	private ClientDetailPOJO clientDetail;
//	private AdditionalDetailPOJO additionalDetail;
//	private CaseDocumentMainObject caseDocument;

}
