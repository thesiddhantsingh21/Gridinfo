package com.gic.workflow.caseCreationJsonDecider;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.gic.workflow.caseCreationJsonDecider.model.MetaData;
import com.gic.workflow.caseCreationJsonDecider.pojo.CaseCreationPOJO;
import com.gic.workflow.caseCreationJsonDecider.pojo.RootPOJO;
import com.gic.workflow.caseCreationJsonDecider.service.ApiService;
import com.gic.workflow.caseCreationJsonDecider.service.BotJSONService;
import com.gic.workflowlib.constants.DependsOn;
import com.gic.workflowlib.constants.TaskType;
import com.gic.workflowlib.decider.Decider;
import com.gic.workflowlib.model.WorkflowDetailsTransaction;

@SpringBootApplication
public class CaseCreationJsonDeciderApplication implements CommandLineRunner {

	private static final Logger logger = LoggerFactory.getLogger(CaseCreationJsonDeciderApplication.class);
	@Value("${database}")
	String database;
	@Value("${dbUserName}")
	String dbUserName;
	@Value("${password}")
	String password;
	@Value("${enableSSL}")
	String enableSSL = "false";
	@Value("${host}")
	String host;
	@Value("${schema}")
	String schema;
	@Value("${currentWorker}")
	String currentWorker;
	@Value("${taskListName}")
	String taskListName;
	@Value("${taskListDescription}")
	String taskListDescription;
	@Value("${case.creation.list.url}")
	private String caseCreationListURL;
	@Value("${heart.beat.url}")
	String heartBeatUrl;
	static String heartBeatURL;

	static String currentWorker1;
	static String caseCreationListURL1;
	static String taskListName1;
	static String taskListDescription1;

	@Autowired
	private ApiService apiService;
	@Autowired
	private BotJSONService botJSONService;

	static Map<String, Long> activityWorkerMap = new HashMap<String, Long>();

	public static void main(String[] args) {
		SpringApplication.run(CaseCreationJsonDeciderApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		logger.info("Running Spring Boot Application");
		logger.info(currentWorker);
		logger.info(taskListName);
		logger.info(taskListDescription);
		this.heartBeatURL = heartBeatUrl;
		this.caseCreationListURL1 = caseCreationListURL;

		Map<String, String> configMap = new HashMap<>();
		configMap.put("database", database);
		configMap.put("user", dbUserName);
		configMap.put("password", password);
		configMap.put("host", host);
		configMap.put("schema", schema);
		configMap.put("currentWorker", currentWorker);
		configMap.put("apiURL", caseCreationListURL);
		configMap.put("taskName", taskListName);
		configMap.put("taskDescription", taskListDescription);

		Decider decider = new Decider(DependsOn.API, configMap).init();
		int delay = 0;
		boolean more = true;
		while (more) {
			if (processNextBatch(botJSONService, apiService, decider)) {
				delay = 0;
			} else {
				delay = delay + 10;
				if (delay > 60) {
					delay = 10;
				}
			}
			more = pause(delay);
		}

	}

	private static boolean pause(int factor) {
		try {
			logger.info("sleeping for " + factor + " seconds");
			TimeUnit.SECONDS.sleep(factor);
		} catch (InterruptedException e) {
			logger.error("Interrupted");
			return false;
		}
		return true;
	}

	private static boolean processNextBatch(BotJSONService botJSONService, ApiService apiService, Decider decider) {
//		Utility.sendHeartBeat(heartBeatURL);
		logger.info("Case Cration URL:{}", caseCreationListURL1);
		String caseJson = decider.fetchDataFromGetAPI();
		logger.info("Value of File Conversion:{}", caseJson);
//		String caseJson = apiService.sendDataToGet(caseCreationListURL1);

		logger.info("Value of Case Creation:{}", caseJson);
		if (caseJson != null && !StringUtils.isEmpty(caseJson) && !StringUtils.equals("[]", caseJson)) {
			ObjectMapper mapper = new ObjectMapper();

			mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

			ArrayNode inputJson = null;
			try {
				inputJson = (ArrayNode) mapper.readTree(caseJson);
			} catch (JsonProcessingException e) {
				// TODO Auto-generated catch block
				logger.info("Exception:{}", e.getMessage());
				e.printStackTrace();
			}
			logger.info("Input Json:{}", inputJson);
			for (JsonNode caseCreationJson : inputJson) {
				CaseCreationPOJO caseCreationPOJO = mapper.convertValue(caseCreationJson, CaseCreationPOJO.class);
				List<RootPOJO> rootPOJOList = botJSONService.createBOTJson(mapper, caseCreationPOJO);

				if (CollectionUtils.isNotEmpty(rootPOJOList)) {
					for (RootPOJO rootPOJO1 : rootPOJOList) {
						JsonNode arrayToJson = mapper.convertValue(rootPOJO1, JsonNode.class);
						MetaData metaData = new MetaData();
						JsonNode metaDataNode = null;
						try {
							JsonNode caseReference = arrayToJson.get("requestJson").get("data").get(0).get("taskSpecs")
									.get("case").get("caseReference");

							metaData.setCaseNo(caseReference.get("caseNo").asText());
							metaData.setCaseUUID(caseReference.get("caseUUID").asLong());
							metaData.setCheckId("");
							metaData.setStatus("ready");
							metaData.setCrnNo(StringUtils.isEmpty(caseReference.get("crnNo").asText()) ? "Pending"
									: caseReference.get("crnNo").asText());
							metaData.setRequestId(
									caseCreationPOJO.getRequestId() != null ? caseCreationPOJO.getRequestId() : "");
							metaData.setCaseSource(caseCreationPOJO.getCaseOrigin());
							metaData.setClient(
									caseCreationPOJO.getCaseDetails().get("clientDetail").get("clientName").asText());
							metaDataNode = mapper.convertValue(metaData, JsonNode.class);
						} catch (Exception e) {
							e.printStackTrace();
						}

						boolean isNewTaskCreated = false;
						try {
//							WorkflowDetailsTransaction workflowDetailsTransaction = decider.getPreviousCompletedTask();
//							if (workflowDetailsTransaction == null) {
//								return false;
//							}

							isNewTaskCreated = decider.createNewTask(TaskType.BOT, mapper.writeValueAsString(rootPOJO1),
									mapper.writeValueAsString(metaDataNode));
						} catch (Exception e) {
							e.printStackTrace();
							return false;
						}
						return isNewTaskCreated;

					}
				}
			}
			return true;
		}
		return false;
	}
}
