package com.gic.main;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JsonjacksondemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
