package com.gi.main.bean;

public class CaseMoreInfo {

}
